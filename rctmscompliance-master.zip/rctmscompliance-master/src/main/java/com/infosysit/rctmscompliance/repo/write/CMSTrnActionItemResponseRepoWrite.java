package com.infosysit.rctmscompliance.repo.write;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnActionItemResponse;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSTrnActionItemResponseRepoWrite extends JpaRepository<CMSTrnActionItemResponse, Integer> {

	@Modifying
	@Query(value=CustomQueries.SUBMITACTIONITEMTOOWNER)
	public void submitToOwner(@Param("txtActionItemComments") String txtActionItemComments,@Param("txtEmployeeId") String txtEmployeeId,
			@Param("txtFindings") String txtFindings,@Param("txtReason") String txtReason,
			@Param("txtCorrectiveAction") String txtCorrectiveAction,@Param("txtRemediation") String txtRemediation,@Param("intActionItemId") int intActionItemId );
	
	@Modifying
	@Query(value=CustomQueries.REJECTACTIONITEM)
	public void rejectActionItem(@Param("txtActionItemComments") String txtActionItemComments,@Param("txtEmployeeId") String txtEmployeeId,
			@Param("txtFindings") String txtFindings,@Param("txtReason") String txtReason,
			@Param("txtCorrectiveAction") String txtCorrectiveAction,@Param("txtRemediation") String txtRemediation,@Param("intActionItemId") int intActionItemId );
	
	@Modifying
	@Query(value=CustomQueries.CLOSEACTIONITEM)
	public void closeActionItem(@Param("txtActionItemComments") String txtActionItemComments,@Param("txtEmployeeId") String txtEmployeeId,
			@Param("txtFindings") String txtFindings,@Param("txtReason") String txtReason,
			@Param("txtCorrectiveAction") String txtCorrectiveAction,@Param("txtRemediation") String txtRemediation,@Param("intActionItemId") int intActionItemId );
	
	@Modifying
	@Query(value=CustomQueries.UPDATEACTIONITEMNOOFCYCLE)
	public void changeNoOfCycles(@Param("intActionItemId") int intActionItemId,@Param("intNoOfCycle") int intNoOfCycle);
}
