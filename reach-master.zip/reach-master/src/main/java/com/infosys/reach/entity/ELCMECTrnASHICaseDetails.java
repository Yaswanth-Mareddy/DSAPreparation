package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.ashi.ValidatedCaseDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmectrnashicasedetails")
public class ELCMECTrnASHICaseDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="intcategoryid")
	private int categoryId;
	
	@Column(name="txtplaceofincident")
	private String placeOfIncident;
	
	@Column(name="txtdescription")
	private String description;
	
	@Column(name="txtstatus")
	private String status;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtincidentdate")
	private Timestamp incidentDate;
	
	@Column(name="flgstakeholder")
	private int flgStakeHolder;
	
	@Column(name="txtmodifiedby")
	private String modifiedBy;
	
	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;
	
	@Column(name="txtrespondenttype")
	private String respondentType;
	
	@Column(name="txtraisedby")
	private String raisedBy;
	
	@Column(name="txtselectedcountry")
	private String selectedCountry;
	
	@Column(name="txtselectedcity")
	private String selectedCity;
	
	@Column(name="txtcreatedapp")
	private String createdApp;
	
	@Column(name="txtlastaction")
	private String lastAction;
	
	@Column(name="dtlastaction")
	private Timestamp lastActionDate;
	
	@Column(name="txtinvestigationtype")
	private String investigationType;
	
	@Column(name="flgchargesheet")
	private int flgChargeSheet;

	@Column(name="txtdmschargesheets")
	private String dmsChargeSheets;
	
	@Column(name="dtcasecloseddate")
	private Timestamp caseClosedDate;

	public ELCMECTrnASHICaseDetails(ValidatedCaseDetails obj,Timestamp currentDate) {
		super();
		if(obj.isGRB()) {
			this.categoryId = obj.getComplaintCategory();
			this.placeOfIncident=obj.getPlaceOfIncident();
			
			if(obj.getRaisingFor()==1) {
				this.raisedBy = "Self";
				this.lastAction = "Complaint reported by employee";
			}
			else {
				this.raisedBy = "GRB";
				this.lastAction = "Complaint reported by GRB";
			}
		}
		else {
			this.raisedBy = "Self";
			this.flgStakeHolder = obj.getIsStakeHolder();
		}
		this.moduleId = 2;
		this.description = obj.getDescription();
		this.status = "WE";
		this.createdBy = obj.getCaseInitiator().getEmpNo();
		this.createdOn = currentDate;
		this.incidentDate = currentDate;
		this.respondentType = obj.getStrRespondentType();
		this.selectedCountry = obj.getCountry();
		this.selectedCity = obj.getBaseLocation();
		this.createdApp = obj.getCreatedApp();
		this.lastActionDate = currentDate;
	}
	
	

	
}
