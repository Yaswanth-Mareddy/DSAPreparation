package com.infosys.reach.model.hear;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SubmitCaseOutput {

	private int caseid;
	private String message;
	private String status;
}
