package com.infosys.reach;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.entity.ELCMECMstConcernModulesDetails;
import com.infosys.reach.entity.ELCMECMstHearEmployeeCaseDetails;
import com.infosys.reach.entity.ELCMECMstHearTaggedEmpDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnHearActionDetails;
import com.infosys.reach.entity.ELCMECTrnHearCaseDetails;
import com.infosys.reach.entity.ELCMECTrnHearEmpGeneralDetails;
import com.infosys.reach.entity.ELCMECtrnHEARConcernSLADetails;
import com.infosys.reach.entity.HRISTrnEmpLocation;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.hear.CaseDetailsValidationResponse;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.model.hear.HearAccess;
import com.infosys.reach.model.hear.HearCaseDetails;
import com.infosys.reach.model.hear.HearCaseResponse;
import com.infosys.reach.model.hear.Policy;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstHearEmployeeCaseDetailsRepository;
import com.infosys.reach.repository.ELCMECMstHearTaggedEmpDetailsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECMstUnitHearRepository;
import com.infosys.reach.repository.ELCMECTrnHearActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnHearCaseDetailsRepo;
import com.infosys.reach.repository.ELCMECTrnHearEmpGeneralDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECtrnHEARConcernSLADetailsRepository;
import com.infosys.reach.repository.GENMstCityRepository;
import com.infosys.reach.repository.GenMstInfosysEstablishmentsRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.repository.HRISTrnEmpLocationRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.service.HearServiceImpl;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@ExtendWith(MockitoExtension.class)
@SuppressWarnings("unchecked")
class HearServiceTests {
	@InjectMocks
	HearServiceImpl hearService;

	@Mock
	HearServiceImpl hearServiceMock;


	@Mock
	private Property mockProperty;

	@Mock
	CommonServiceImpl commonservice;

	@Mock
	ViewCurrEmpAllDetailsRepository viewAllEmpDetailsRepository;

	@Mock
	ELCMECTrnHearCaseDetailsRepo hearCaseDetailsRepo;

	@Mock
	ELCMECTrnHearEmpGeneralDetailsRepository elcmecTrnHearEmpGeneralDetailsRepository;

	@Mock
	GenMstInfosysEstablishmentsRepository genMstInfosysEstablishmentsRepository;

	@Mock
	HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Mock
	ELCMECMstHearEmployeeCaseDetailsRepository hearEmployeeCaseDetailsRepository;

	@Mock
	ELCMECMstHearTaggedEmpDetailsRepository hearTaggedEmpDetailsRepository;

	@Mock
	ELCMECTrnHearActionDetailsRepository hearActionDetailsRepository;

	@Mock
	ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;

	@Mock
	ELCMECtrnHEARConcernSLADetailsRepository  hearConcernSLADetailsRepository;

	@Mock
	ELCMECMstConcernModulesDetailsRepository concernModulesDetailsRepository;

	@Mock
	ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Mock
	GENMstCityRepository cityRepository;

	@Mock
	HRISTrnEmpLocationRepository empLocationRepository;

	@Mock
	GenMstMailConfigHeaderRepository mailConfigHeaderRepository;

	@Mock
	ELCMECMstUnitHearRepository unitHearRepository;

	@Test
	void initiateHearCaseTest() throws CustomException {

		Timestamp currentDateTime=new Timestamp(System.currentTimeMillis()+19800000);
		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		//		caseDetails.setCategoryId(1);
		//		caseDetails.setModuleId(1);
		//		caseDetails.setTaggedEmpMailId("TaggedEmpMailId");
		//		caseDetails.setFlgSeniorManagement(1);

		String reporteeEmpNo ="722284";
		//ELCMECTrnHearCaseDetails elcmecTrnHearCaseDetails=new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		//elcmecTrnHearCaseDetails.setCaseId(2);
		ELCMECTrnHearCaseDetails reportedCaseDetails = new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		//reportedCaseDetails.setCaseId(3);

		Mockito.when(hearCaseDetailsRepo.save(Mockito.any())).thenReturn(reportedCaseDetails);

		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(2, reporteeEmpNo, caseDetails, currentDateTime);

		Mockito.when(elcmecTrnHearEmpGeneralDetailsRepository.save(Mockito.any())).thenReturn(hearEmpGeneralDetails);

		String countryCode = "IN";
		Mockito.when(genMstInfosysEstablishmentsRepository.findSapCountryCode(null)).thenReturn(countryCode);

		List<CaseEmployeeDetails> respondentCaseDetailsObj = new ArrayList<>();
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(respondentCaseDetailsObj);

		List<String> taggedEmpMailIdList =new ArrayList<>();
		taggedEmpMailIdList.add("dilisha.m");


		CustomException thrown = assertThrows(
				CustomException.class,
				() -> hearService.initiateHearCase(reporteeEmpNo, "dilisha.m", "dilisha", caseDetails, taggedEmpMailIdList),
				Message.SOMETHING_WENT_WRONG
				);

		assertTrue(thrown.getMessage().contains(Message.SOMETHING_WENT_WRONG));
	}

	@Test
	void initiateHearCaseTest1() throws CustomException {

		Timestamp currentDateTime=new Timestamp(System.currentTimeMillis()+19800000);
		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");

		String reporteeEmpNo ="722284";
		ELCMECTrnHearCaseDetails reportedCaseDetails = new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);

		Mockito.when(hearCaseDetailsRepo.save(Mockito.any())).thenReturn(reportedCaseDetails);

		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(2, reporteeEmpNo, caseDetails, currentDateTime);

		Mockito.when(elcmecTrnHearEmpGeneralDetailsRepository.save(Mockito.any())).thenReturn(hearEmpGeneralDetails);

		String countryCode = "";
		Mockito.when(genMstInfosysEstablishmentsRepository.findSapCountryCode(null)).thenReturn(countryCode);

		ELCMECMstASHICaseEmployeeDetails details = new ELCMECMstASHICaseEmployeeDetails(2,"name","actor");
		List<CaseEmployeeDetails> respondentCaseDetailsObj = new ArrayList<>();
		respondentCaseDetailsObj.add(new CaseEmployeeDetails(details));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getRespondentEmpNo())).thenReturn(respondentCaseDetailsObj);

		List<CaseEmployeeDetails> accusedCaseDetailsObj = new ArrayList<>();
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(reporteeEmpNo)).thenReturn(accusedCaseDetailsObj);

		List<String> taggedEmpMailIdList =new ArrayList<>();
		taggedEmpMailIdList.add("dilisha.m");

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> hearService.initiateHearCase(reporteeEmpNo, "dilisha.m", "dilisha", caseDetails, taggedEmpMailIdList),
				Message.SOMETHING_WENT_WRONG
				);

		assertTrue(thrown.getMessage().contains(Message.SOMETHING_WENT_WRONG));
	}

	@Test
	void initiateHearCaseTest2() throws CustomException {

		Timestamp currentDateTime=new Timestamp(System.currentTimeMillis()+19800000);
		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("");

		String reporteeEmpNo ="722284";
		ELCMECTrnHearCaseDetails reportedCaseDetails = new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		reportedCaseDetails.setCaseId(2);

		Mockito.when(hearCaseDetailsRepo.save(Mockito.any())).thenReturn(reportedCaseDetails);

		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(2, reporteeEmpNo, caseDetails, currentDateTime);

		Mockito.when(elcmecTrnHearEmpGeneralDetailsRepository.save(Mockito.any())).thenReturn(hearEmpGeneralDetails);


		String countryCode = "";
		Mockito.when(genMstInfosysEstablishmentsRepository.findSapCountryCode(null)).thenReturn(countryCode);

		ELCMECMstASHICaseEmployeeDetails details = new ELCMECMstASHICaseEmployeeDetails(2,"name","actor");
		//		List<CaseEmployeeDetails> respondentCaseDetailsObj = new ArrayList<>();
		//		respondentCaseDetailsObj.add(new CaseEmployeeDetails(details));
		//		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getRespondentEmpNo())).thenReturn(respondentCaseDetailsObj);

		List<CaseEmployeeDetails> accusedCaseDetailsObj = new ArrayList<>();
		accusedCaseDetailsObj.add(new CaseEmployeeDetails(details));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(reporteeEmpNo)).thenReturn(accusedCaseDetailsObj);

		List<ELCMECMstHearEmployeeCaseDetails> hearEmployeeCaseDetailsList=new ArrayList<>();
		ELCMECMstHearEmployeeCaseDetails accusedCaseDetails = new ELCMECMstHearEmployeeCaseDetails(2, accusedCaseDetailsObj.get(0), countryCode,"A", caseDetails.getSelectedCountry(), caseDetails.getSelectedCity());
		hearEmployeeCaseDetailsList.add(accusedCaseDetails);
		Mockito.when(hearEmployeeCaseDetailsRepository.saveAll(Mockito.anyList())).thenReturn(hearEmployeeCaseDetailsList);

		ELCMECMstHearTaggedEmpDetails hearTaggedEmpDetails=new ELCMECMstHearTaggedEmpDetails(2, "mailID");
		Mockito.when(hearTaggedEmpDetailsRepository.save(Mockito.any())).thenReturn(hearTaggedEmpDetails);

		ELCMECTrnHearActionDetails hearActionDetails=new ELCMECTrnHearActionDetails(2, caseDetails.getComments(), reporteeEmpNo, currentDateTime);
		Mockito.when(hearActionDetailsRepository.save(Mockito.any())).thenReturn(hearActionDetails);

		Optional<ELCMECMstSysParams> sysParam =Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("1");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("CH", "SLA")).thenReturn(sysParam);

		int slaDays=1;
		Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
		ELCMECtrnHEARConcernSLADetails hearConcernSLADetails=new ELCMECtrnHEARConcernSLADetails(2, slaDays, currentDateTime, slaEndDateTime, reporteeEmpNo);
		Mockito.when(hearConcernSLADetailsRepository.save(Mockito.any())).thenReturn(hearConcernSLADetails);

		Mockito.when(concernModulesDetailsRepository.findCategoryByCaseId(Mockito.anyInt())).thenReturn("categoty");

		MailContent reporteesMailInfo = new MailContent();
		reporteesMailInfo.setBody("Body");
		reporteesMailInfo.setSubject("Suject");
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCI")).thenReturn(reporteesMailInfo);

		Mockito.when(mockProperty.getInfyDomain()).thenReturn("URL");

		Mockito.when(mockProperty.getHearMailerAappCode()).thenReturn("URL");
		Mockito.when(mockProperty.getHearMailerEventId()).thenReturn("URL");
		Mockito.when(mockProperty.getHearMailerTemplateId()).thenReturn(3);
		Mockito.when(mockProperty.getHearFromId()).thenReturn("URL");

		MailerAssistResponse assistResponse = new MailerAssistResponse();
		assistResponse.setCode(1);
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(assistResponse);

		List<String> taggedEmpMailIdList =new ArrayList<>();
		taggedEmpMailIdList.add("dilisha.m");

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> hearService.initiateHearCase(reporteeEmpNo, "dilisha.m", "dilisha", caseDetails, taggedEmpMailIdList),
				"Reportees "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Reportees "+Message.MAIL_NOT_TRIGGERED));	
	}

	@Test
	void initiateHearCaseTest3() throws CustomException {

		Timestamp currentDateTime=new Timestamp(System.currentTimeMillis()+19800000);
		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("");

		String reporteeEmpNo ="722284";
		ELCMECTrnHearCaseDetails reportedCaseDetails = new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		reportedCaseDetails.setCaseId(2);

		Mockito.when(hearCaseDetailsRepo.save(Mockito.any())).thenReturn(reportedCaseDetails);

		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(2, reporteeEmpNo, caseDetails, currentDateTime);

		Mockito.when(elcmecTrnHearEmpGeneralDetailsRepository.save(Mockito.any())).thenReturn(hearEmpGeneralDetails);


		String countryCode = "";
		Mockito.when(genMstInfosysEstablishmentsRepository.findSapCountryCode(null)).thenReturn(countryCode);

		ELCMECMstASHICaseEmployeeDetails details = new ELCMECMstASHICaseEmployeeDetails(2,"name","actor");

		//		List<CaseEmployeeDetails> respondentCaseDetailsObj = new ArrayList<>();
		//		respondentCaseDetailsObj.add(new CaseEmployeeDetails(details));
		//		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getRespondentEmpNo())).thenReturn(respondentCaseDetailsObj);

		List<CaseEmployeeDetails> accusedCaseDetailsObj = new ArrayList<>();
		accusedCaseDetailsObj.add(new CaseEmployeeDetails(details));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(reporteeEmpNo)).thenReturn(accusedCaseDetailsObj);

		List<ELCMECMstHearEmployeeCaseDetails> hearEmployeeCaseDetailsList=new ArrayList<>();
		ELCMECMstHearEmployeeCaseDetails accusedCaseDetails = new ELCMECMstHearEmployeeCaseDetails(2, accusedCaseDetailsObj.get(0), countryCode,"A", caseDetails.getSelectedCountry(), caseDetails.getSelectedCity());
		hearEmployeeCaseDetailsList.add(accusedCaseDetails);
		Mockito.when(hearEmployeeCaseDetailsRepository.saveAll(Mockito.anyList())).thenReturn(hearEmployeeCaseDetailsList);

		//		ELCMECMstHearTaggedEmpDetails hearTaggedEmpDetails=new ELCMECMstHearTaggedEmpDetails(2, "mailID");
		//		Mockito.when(hearTaggedEmpDetailsRepository.save(hearTaggedEmpDetails)).thenReturn(hearTaggedEmpDetails);

		ELCMECTrnHearActionDetails hearActionDetails=new ELCMECTrnHearActionDetails(2, caseDetails.getComments(), reporteeEmpNo, currentDateTime);
		Mockito.when(hearActionDetailsRepository.save(Mockito.any())).thenReturn(hearActionDetails);

		Optional<ELCMECMstSysParams> sysParam =Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("1");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("CH", "SLA")).thenReturn(sysParam);

		int slaDays=1;
		Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
		ELCMECtrnHEARConcernSLADetails hearConcernSLADetails=new ELCMECtrnHEARConcernSLADetails(2, slaDays, currentDateTime, slaEndDateTime, reporteeEmpNo);
		Mockito.when(hearConcernSLADetailsRepository.save(Mockito.any())).thenReturn(hearConcernSLADetails);

		Mockito.when(concernModulesDetailsRepository.findCategoryByCaseId(Mockito.anyInt())).thenReturn("categoty");

		MailContent reporteesMailInfo = new MailContent();
		reporteesMailInfo.setBody("Body");
		reporteesMailInfo.setSubject("Suject");
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCI")).thenReturn(reporteesMailInfo);

		Mockito.when(mockProperty.getInfyDomain()).thenReturn("URL");

		Mockito.when(mockProperty.getHearMailerAappCode()).thenReturn("AppCode");
		Mockito.when(mockProperty.getHearMailerEventId()).thenReturn("EventId");
		Mockito.when(mockProperty.getHearMailerTemplateId()).thenReturn(3);
		Mockito.when(mockProperty.getHearFromId()).thenReturn("FormId");


		MailerAssistResponse assistResponse = new MailerAssistResponse();
		assistResponse.setCode(2);

		//Mockito.when(commonservice.triggerMail(reporteesMailObj)).thenReturn(assistResponse);

		MailContent corporateHearMailInfo = new MailContent();
		corporateHearMailInfo.setBody("Body");
		corporateHearMailInfo.setSubject("Suject");
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCH")).thenReturn(corporateHearMailInfo);

		Mockito.when(mockProperty.getHearURL()).thenReturn("HearURL");

		List<String> unitHearMailIDs =new ArrayList<>();
		unitHearMailIDs.add("mailID");
		unitHearMailIDs.add("mailID1");
		Mockito.when(unitHearRepository.findUnitHearMailIds()).thenReturn(unitHearMailIDs);

		Mockito.when(mockProperty.getInfyDomain()).thenReturn("${infydomain}");

		MailerAssistResponse assistResponse1 = new MailerAssistResponse();
		assistResponse1.setCode(1);
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(assistResponse, assistResponse1);

		List<String> taggedEmpMailIdList =new ArrayList<>();
		taggedEmpMailIdList.add("");

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> hearService.initiateHearCase(reporteeEmpNo, "dilisha.m", "dilisha", caseDetails, taggedEmpMailIdList),
				"Unit Hear "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Unit Hear "+Message.MAIL_NOT_TRIGGERED));	
	}

	@Test
	void initiateHearCaseTest4() throws CustomException {

		Timestamp currentDateTime=new Timestamp(System.currentTimeMillis()+19800000);
		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("");

		String reporteeEmpNo ="722284";
		ELCMECTrnHearCaseDetails reportedCaseDetails = new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		reportedCaseDetails.setCaseId(2);

		Mockito.when(hearCaseDetailsRepo.save(Mockito.any())).thenReturn(reportedCaseDetails);

		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(2, reporteeEmpNo, caseDetails, currentDateTime);

		Mockito.when(elcmecTrnHearEmpGeneralDetailsRepository.save(Mockito.any())).thenReturn(hearEmpGeneralDetails);

		String countryCode = "";
		Mockito.when(genMstInfosysEstablishmentsRepository.findSapCountryCode(null)).thenReturn(countryCode);

		ELCMECMstASHICaseEmployeeDetails details = new ELCMECMstASHICaseEmployeeDetails(2,"name","actor");
		//		List<CaseEmployeeDetails> respondentCaseDetailsObj = new ArrayList<>();
		//		respondentCaseDetailsObj.add(new CaseEmployeeDetails(details));
		//		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getRespondentEmpNo())).thenReturn(respondentCaseDetailsObj);

		List<CaseEmployeeDetails> accusedCaseDetailsObj = new ArrayList<>();
		accusedCaseDetailsObj.add(new CaseEmployeeDetails(details));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(reporteeEmpNo)).thenReturn(accusedCaseDetailsObj);

		List<ELCMECMstHearEmployeeCaseDetails> hearEmployeeCaseDetailsList=new ArrayList<>();
		ELCMECMstHearEmployeeCaseDetails accusedCaseDetails = new ELCMECMstHearEmployeeCaseDetails(2, accusedCaseDetailsObj.get(0), countryCode,"A", caseDetails.getSelectedCountry(), caseDetails.getSelectedCity());
		hearEmployeeCaseDetailsList.add(accusedCaseDetails);
		Mockito.when(hearEmployeeCaseDetailsRepository.saveAll(Mockito.anyList())).thenReturn(hearEmployeeCaseDetailsList);

		//		ELCMECMstHearTaggedEmpDetails hearTaggedEmpDetails=new ELCMECMstHearTaggedEmpDetails(2, "mailID");
		//		Mockito.when(hearTaggedEmpDetailsRepository.save(hearTaggedEmpDetails)).thenReturn(hearTaggedEmpDetails);

		ELCMECTrnHearActionDetails hearActionDetails=new ELCMECTrnHearActionDetails(2, caseDetails.getComments(), reporteeEmpNo, currentDateTime);
		Mockito.when(hearActionDetailsRepository.save(Mockito.any())).thenReturn(hearActionDetails);

		Optional<ELCMECMstSysParams> sysParam =Optional.empty();
		//sysParam.get().setParamValue("1");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("CH", "SLA")).thenReturn(sysParam);

		int slaDays=1;
		Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
		ELCMECtrnHEARConcernSLADetails hearConcernSLADetails=new ELCMECtrnHEARConcernSLADetails(2, slaDays, currentDateTime, slaEndDateTime, reporteeEmpNo);
		Mockito.when(hearConcernSLADetailsRepository.save(Mockito.any())).thenReturn(hearConcernSLADetails);

		Mockito.when(concernModulesDetailsRepository.findCategoryByCaseId(Mockito.anyInt())).thenReturn("categoty");

		MailContent reporteesMailInfo = new MailContent();
		reporteesMailInfo.setBody("Body");
		reporteesMailInfo.setSubject("Suject");
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCI")).thenReturn(reporteesMailInfo);

		Mockito.when(mockProperty.getInfyDomain()).thenReturn("URL");

		Mockito.when(mockProperty.getHearMailerAappCode()).thenReturn("AppCode");
		Mockito.when(mockProperty.getHearMailerEventId()).thenReturn("EventId");
		Mockito.when(mockProperty.getHearMailerTemplateId()).thenReturn(3);
		Mockito.when(mockProperty.getHearFromId()).thenReturn("FormId");

		MailerAssistResponse assistResponse = new MailerAssistResponse();
		assistResponse.setCode(2);

		//Mockito.when(commonservice.triggerMail(reporteesMailObj)).thenReturn(assistResponse);

		MailContent corporateHearMailInfo = new MailContent();
		corporateHearMailInfo.setBody("Body");
		corporateHearMailInfo.setSubject("Suject");
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCH")).thenReturn(corporateHearMailInfo);

		Mockito.when(mockProperty.getHearURL()).thenReturn("HearURL");

		List<String> unitHearMailIDs =new ArrayList<>();
		unitHearMailIDs.add("mailID");
		unitHearMailIDs.add("mailID1");
		Mockito.when(unitHearRepository.findUnitHearMailIds()).thenReturn(unitHearMailIDs);

		Mockito.when(mockProperty.getInfyDomain()).thenReturn("${infydomain}");

		MailerAssistResponse assistResponse1 = new MailerAssistResponse();
		assistResponse1.setCode(2);
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(assistResponse, assistResponse1);

		List<String> taggedEmpMailIdList =new ArrayList<>();
		taggedEmpMailIdList.add("");

		HearCaseResponse objExpected = new HearCaseResponse(2,"Done! Your appeal is submitted under "+"categoty"+" category with Appeal id "+2+".");

		HearCaseResponse objActual = hearService.initiateHearCase(reporteeEmpNo, "dilisha.m", "dilisha", caseDetails, taggedEmpMailIdList);

		assertEquals(objExpected.getCaseId(), objActual.getCaseId());

	}


	@Test
	void validateCaseDetailsTest() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"You don't have access to use hear.");	
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest1() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(2);

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Module id should be 3 only");	
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest2() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(2);

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"FlgManager should be 1 or 0");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest3() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		caseDetails.setManagerReason("Reason");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"ManagerReason should be empty if FlgManager is 1");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest4() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(0);
		caseDetails.setManagerReason("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"ManagerReason is required if FlgManager is 0");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest5() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(0);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(2);

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"ManagerReason is required if FlgManager is 0");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest6() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(1);
		caseDetails.setReviewerReason("Reason");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"ReviewerReason should be empty if FlgReviewer is 1");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest7() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(2);
		caseDetails.setReviewerReason("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"FlgReviewer should be 1 or 0");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());

	}

	@Test
	void validateCaseDetailsTest8() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(1);
		//caseDetails.setReviewerReason("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());

	}

	@Test
	void validateCaseDetailsTest9() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"ReviewerReason is required if FlgReviewer is 0");

		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest10() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(2);

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"FlgUnitHR should be 1 or 0");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest11() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		caseDetails.setUnitHRReason("reason");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"UnitHRReason should be empty if FlgUnitHR is 1");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest12() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(0);
		caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Manager's mailid can't be empty");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest13() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("dilisha.m");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Manager's id cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest14() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		//caseDetails.setEmpManager("dilisha.m");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Manager's mailid can't be empty");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest15() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.empty();
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Manager's mailid is invalid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest16() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Reviewer's mailid can't be empty");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest17() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Reviewer's mailid can't be empty");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest18() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("722284");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Reviewer's id cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest19() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("dilisha.m");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Reviewer's id cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest20() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.empty();
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Reviewer's mailid is invalid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest21() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("722284");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Respondent's id cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest22() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("dilisha.m");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Respondent's id cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest23() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("722280");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);


		Optional<ViewCurrEmpAllDetails> respondentDetails = Optional.empty();
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getRespondentEmpNo())).thenReturn(respondentDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Respondent's mailid is invalid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest24() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("722280");
		caseDetails.setTaggedEmpMailId("dilisha.m");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);


		Optional<ViewCurrEmpAllDetails> respondentDetails = Optional.of(new ViewCurrEmpAllDetails());
		respondentDetails.get().setEmpName("dilisha");
		respondentDetails.get().setEmpNo("722284");
		respondentDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getRespondentEmpNo())).thenReturn(respondentDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Tagged employee id '"+caseDetails.getTaggedEmpMailId()+"' cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}


	@Test
	void validateCaseDetailsTest25() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		caseDetails.setTaggedEmpMailId("722284");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);


		Optional<ViewCurrEmpAllDetails> respondentDetails = Optional.of(new ViewCurrEmpAllDetails());
		respondentDetails.get().setEmpName("dilisha");
		respondentDetails.get().setEmpNo("722284");
		respondentDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails, reviewerDetails, respondentDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Tagged employee id '"+caseDetails.getTaggedEmpMailId()+"' cannot be same as reportees mailid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest26() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		caseDetails.setTaggedEmpMailId("722281");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);


		Optional<ViewCurrEmpAllDetails> respondentDetails = Optional.of(new ViewCurrEmpAllDetails());
		respondentDetails.get().setEmpName("dilisha");
		respondentDetails.get().setEmpNo("722284");
		respondentDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails, reviewerDetails, respondentDetails);

		Optional<ViewCurrEmpAllDetails> taggedEmpDetails = Optional.empty();
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getTaggedEmpMailId())).thenReturn(taggedEmpDetails);




		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Tagged employee id '"+caseDetails.getTaggedEmpMailId()+"' is invalid");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest27() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		caseDetails.setTaggedEmpMailId("722281");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> managerDetails = Optional.of(new ViewCurrEmpAllDetails());
		managerDetails.get().setEmpName("dilisha");
		managerDetails.get().setEmpNo("722284");
		managerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager())).thenReturn(managerDetails);

		Optional<ViewCurrEmpAllDetails> reviewerDetails = Optional.of(new ViewCurrEmpAllDetails());
		reviewerDetails.get().setEmpName("dilisha");
		reviewerDetails.get().setEmpNo("722284");
		reviewerDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer())).thenReturn(reviewerDetails);


		Optional<ViewCurrEmpAllDetails> respondentDetails = Optional.of(new ViewCurrEmpAllDetails());
		respondentDetails.get().setEmpName("dilisha");
		respondentDetails.get().setEmpNo("722284");
		respondentDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getRespondentEmpNo())).thenReturn(respondentDetails);

		Optional<ViewCurrEmpAllDetails> taggedEmpDetails = Optional.of(new ViewCurrEmpAllDetails());
		taggedEmpDetails.get().setEmpName("dilisha");
		taggedEmpDetails.get().setEmpNo("722284");
		taggedEmpDetails.get().setMailId("dilisha.m");
		//Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getTaggedEmpMailId())).thenReturn(taggedEmpDetails);
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(managerDetails, reviewerDetails, respondentDetails, taggedEmpDetails);


		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Selected country is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest28() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		caseDetails.setTaggedEmpMailId("722281,722282");
		caseDetails.setSelectedCountry("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Selected country is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest29() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		caseDetails.setTaggedEmpMailId("");
		caseDetails.setSelectedCountry("IN");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Selected city is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest30() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		//caseDetails.setTaggedEmpMailId("");
		caseDetails.setSelectedCountry("IN");
		caseDetails.setSelectedCity("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Selected city is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest31() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		//caseDetails.setTaggedEmpMailId("");
		caseDetails.setSelectedCountry("IN");
		caseDetails.setSelectedCity("BLR");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Comment is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest32() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		//caseDetails.setTaggedEmpMailId("");
		caseDetails.setSelectedCountry("IN");
		caseDetails.setSelectedCity("BLR");
		caseDetails.setComments("");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Comment is required");
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void validateCaseDetailsTest33() throws CustomException {

		HearCaseDetails caseDetails = new HearCaseDetails();
		caseDetails.setRespondentEmpNo("722285");
		caseDetails.setModuleId(3);
		caseDetails.setFlgManager(1);
		//caseDetails.setManagerReason("");
		caseDetails.setFlgReviewer(0);
		caseDetails.setReviewerReason("reason");
		caseDetails.setFlgUnitHR(1);
		//caseDetails.setUnitHRReason("reason");
		caseDetails.setEmpManager("mailID");
		caseDetails.setEmpReviewer("ReviewerID");
		caseDetails.setRespondentEmpNo("");
		//caseDetails.setTaggedEmpMailId("");
		caseDetails.setSelectedCountry("IN");
		caseDetails.setSelectedCity("BLR");
		caseDetails.setComments("Comment");

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		Optional<ViewCurrEmpAllDetails> employeeDetails = Optional.of(new ViewCurrEmpAllDetails());
		employeeDetails.get().setEmpName("dilisha");
		employeeDetails.get().setEmpNo("722284");
		employeeDetails.get().setMailId("dilisha.m");
		Mockito.when(viewAllEmpDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(employeeDetails);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(true, "Validated",caseDetails,new ArrayList<>());
		CaseDetailsValidationResponse objActual = hearService.validateCaseDetails("722284","dilisha.m",caseDetails);

		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());

	}

	@Test
	void getConcernModuleDetailsTest() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		List<Categories> categories = new ArrayList<>();
		Categories category =new Categories(obj) ;
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompany(3, "INFSYS")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(3, "INFSYS", "IN");

		assertEquals(objExpected, objActual);
	}



	@Test
	void getConcernModuleDetailsTest1() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		List<Categories> categories = new ArrayList<>();
		Categories category =new Categories(obj) ;
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompany(3, "INFSYS")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(3, null, "IN");

		assertEquals(objExpected, objActual);
	}

	@Test
	void getConcernModuleDetailsTest2() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		List<Categories> categories = new ArrayList<>();
		Categories category =new Categories(obj) ;
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompany(3, "INFSYS")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(3, "", "IN");

		assertEquals(objExpected, objActual);
	}

	@Test
	void getConcernModuleDetailsTest3() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		Categories category =new Categories(obj) ;
		List<Categories> categories = new ArrayList<>();
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(2, "INFSYS", "IN")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(2, "INFSYS", "IN");

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getConcernModuleDetailsTest4() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		Categories category =new Categories(obj) ;
		List<Categories> categories = new ArrayList<>();
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(2, "INFSYS", "IN")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(2, "INFSYS", "");

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getConcernModuleDetailsTest5() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		Categories category =new Categories(obj) ;
		List<Categories> categories = new ArrayList<>();
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(2, "INFSYS", "IN")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(2, "", "IN");

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getConcernModuleDetailsTest6() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		Categories category =new Categories(obj) ;
		List<Categories> categories = new ArrayList<>();
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(2, "INFSYS", "IN")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(2, null, "IN");

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getConcernModuleDetailsTest7() {

		ELCMECMstConcernModulesDetails obj =new ELCMECMstConcernModulesDetails();
		Categories category =new Categories(obj) ;
		List<Categories> categories = new ArrayList<>();
		categories.add(category);
		Mockito.when(concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(2, "INFSYS", "IN")).thenReturn(categories);

		List<Categories> objExpected = categories;

		List<Categories> objActual = hearService.getConcernModuleDetails(2, "INFSYS", null);

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getCountriesByModuleIdTest() {

		Countries countries =new Countries() ;

		List<Countries> objExpected = new ArrayList<>();
		objExpected.add(countries);
		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnable(3, 1)).thenReturn(objExpected);
		List<Countries> objActual = hearService.getCountriesByModuleId(3);

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getCitiesByCountryCodeTest() {

		List<Cities> objExpected = new ArrayList<>();
		objExpected.add(new Cities(0,"MYSORE-GEC"));
		Mockito.when(cityRepository.getCitiesByCountryCode("IN")).thenReturn(objExpected);
		List<Cities> objActual = hearService.getCitiesByCountryCode("IN");

		assertEquals(objExpected.get(0), objActual.get(0));
	}

	@Test
	void getCitiesByCountryCodeTest1() {

		List<Cities> objExpected = new ArrayList<>();
		Mockito.when(cityRepository.getCitiesByCountryCode("IN")).thenReturn(objExpected);
		List<Cities> objActual = hearService.getCitiesByCountryCode("IN");

		assertEquals(objExpected, objActual);
	}

	@Test
	void getCitiesByCountryCodeTest2() {

		List<Cities> objExpected = new ArrayList<>();
		Mockito.when(cityRepository.getCitiesByCountryCode(Mockito.anyString())).thenReturn(objExpected);
		List<Cities> objActual = hearService.getCitiesByCountryCode("US");

		assertEquals(objExpected, objActual);
	}

	@Test
	void getHearPolicyTest() {

		Policy objExpected = new Policy();

		Policy objActual = hearService.getHearPolicy();

		assertEquals(objExpected.getHearModulePolicy(), objActual.getHearModulePolicy());
	}

	@Test
	void checkHearAccessTest() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("content");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		HearAccess objExpected = new HearAccess(true,"content");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());

	}

	@Test
	void checkHearAccessTest1() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenReturn(consentStatus);

		HearAccess objExpected = new HearAccess(true,"");
		HearAccess objActual = hearService.checkHearAccess("722284");
		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest2() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest3() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);


		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest4() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("USA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);


		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest5() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		//empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);



		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest6() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn(null);

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);



		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest7() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("US");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest8() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation());
		empLocationObj.get().setEmpNo("722284");
		empLocationObj.get().setMailId("dilisha.m");
		empLocationObj.get().setCurrentCountryCode("IN");
		empLocationObj.get().setCurrentCityName("BLR");
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		DPServiceOutput consentStatus = new DPServiceOutput();
		consentStatus.setContent("");
		Mockito.when(commonservice.dpService("Hear","STATUS")).thenThrow(new CustomException());

		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}

	@Test
	void checkHearAccessTest9() throws CustomException {

		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo("722284")).thenReturn("INDIA");

		Optional<HRISTrnEmpLocation> empLocationObj = Optional.empty();
		Mockito.when(empLocationRepository.findByEmpNo("722284")).thenReturn(empLocationObj);

		HearAccess objExpected = new HearAccess(false,"");
		HearAccess objActual = hearService.checkHearAccess("722284");

		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}
}
