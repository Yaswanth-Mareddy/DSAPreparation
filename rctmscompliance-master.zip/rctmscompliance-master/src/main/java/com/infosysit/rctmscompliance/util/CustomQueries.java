package com.infosysit.rctmscompliance.util;


public class CustomQueries {
	private CustomQueries()
	{
		
	}
	public static final String CMSGETDATAFORINBOX="select distinct new com.infosysit.rctmscompliance.model.ComplianceInbox(view.txtComplianceName,view.dtAssignedDate,view.txtGroupName,"
			+ "view.txtLocation,view.txtDept,view.dtDueDate,view.txtFrequency,view.txtStatus,view.txtAssignee,view.txtVerifier,view.txtOwner,view.intComplianceID,view.dtActualFilingDate"
			+ ",view.txtPendingwith,view.assignee,view.verifier,view.owner,view.pendingwith) from ViewCMSMstInboxDetailsWithEmpID view ";
	
	public static final String GETCOMPLIANCEDETAILSFORUSERDATENULL="select distinct new com.infosysit.rctmscompliance.model.ComplianceDetailsForUserDateNull(CD.intComplianceID, CD.txtComplianceName, "
			+ "H.intNodeID, CD.txtDescription, CD.intLocationID,CD.intCompGroupID,CD.dtDueDate,CD.dtEndDate,CD.intFrequencyID, CD.intDaysBeforeStart,CD.intReminderInterval,view.assignee,"
			+ "view.verifier,view.owner,D.txtNodeName, D.intNodeID,H.txtXPathToNode,CD.txtType) from CMSMstComplianceDetails as CD inner join CMSTrnHierarchy as H " 
			+ "ON CD.intNodeID = H.intNodeID inner join CMSTrnHierarchy as D on D.intNodeID = CD.intDept inner join ViewCMSMstInboxDetailsWithEmpID view on view.intComplianceID=CD.intComplianceID "
			+ "where CD.intComplianceID = :intComplianceID";
	
	public static final String GETCOMPLIANCEDETAILSFORUSERDATENOTNULL="SELECT distinct new com.infosysit.rctmscompliance.model.ComplianceDetailsForUserDateNotNull(CD.txtComplianceName, H.txtNodeName, CD.txtDescription, L.txtLocationName, G.txtGroupName,F.txtFrequency, CD.dtEndDate, CD.intDaysBeforeStart," + 
			"CD.intReminderInterval,view.assignee,view.verifier,view.owner,CI.txtStatus,CI.compPKey.dtAssignedDate,CI.dtDueDate,CI.dtFiledDate,CI.intEscalatedLevel,CI.txtAssigneeRemarks,CI.txtVerifierApprovalRemarks, CI.txtOwnerRemarks,"
			+" CI.txtAttachmentList,CI.txtVerifierRejectRemark, CI.txtAssigneeFileRemark, CI.txtAssigneeAfterRejectRemark,CI.intNoOfCycles, CI.txtAttachmentListVerifier, CI.txtAttachmentListOwner,CI.txtAttachmentListFile,"
			+ "CI.dtActualFilingDate,CD.txtType,CI.dtEscalatedDate,view.txtAssignee,view.txtVerifier,view.txtOwner) FROM CMSMstComplianceDetails AS CD INNER JOIN CMSTrnComplianceInstance AS CI ON CD.intComplianceID = CI.compPKey.intComplianceID" + 
			" INNER JOIN CMSTrnHierarchy AS H ON CD.intNodeID = H.intNodeID INNER JOIN CMSMstLocation AS L ON CD.intLocationID = L.intLocationID INNER JOIN CMSMstFrequency AS F "
			+ "ON CD.intFrequencyID = F.intFrequencyID INNER JOIN CMSMstComplianceGroup AS G ON CD.intCompGroupID = G.intGroupID inner join ViewCMSMstInboxDetailsWithEmpID view on view.intComplianceID=CD.intComplianceID And view.dtAssignedDate=CI.compPKey.dtAssignedDate"
			+ " WHERE CI.compPKey.dtAssignedDate = :dtAssignedDate AND CD.intComplianceID = :intComplianceID ";
	
	public static final String GETTXTOLDDATAFORAUDIT="SELECT distinct new com.infosysit.rctmscompliance.model.AuditTxtOldData(CD.intComplianceID,CD.txtComplianceName,CD.txtDescription,CG.txtGroupName,L.txtLocationName,CD.dtDueDate," + 
			"CD.dtEndDate,F.txtFrequency,CD.intDaysBeforeStart,CD.intReminderInterval,H.txtNodeName,CD.flgIsNewlyCreated,DH.txtNodeName,CD.txtLastModifiedBy, CD.dtLastModified,A.txtAssigneeID,V.txtVerifierID,O.txtOwnerID) FROM CMSMstComplianceDetails AS CD INNER JOIN CMSMstComplianceGroup AS CG ON CD.intCompGroupID = CG.intGroupID " + 
			"INNER JOIN CMSMstLocation AS L ON CD.intLocationID = L.intLocationID INNER JOIN CMSMstFrequency AS F ON CD.intFrequencyID = F.intFrequencyID INNER JOIN CMSTrnHierarchy AS H ON CD.intNodeID = H.intNodeID INNER JOIN CMSTrnHierarchy AS DH " + 
			"ON CD.intDept = DH.intNodeID INNER JOIN CMSTrnAssignee A ON CD.intComplianceID = A.intComplianceID INNER JOIN CMSTrnVerifier V ON CD.intComplianceID = V.intComplianceID INNER JOIN CMSTrnOwner O ON CD.intComplianceID = O.intComplianceID AND CD.intComplianceID = :intComplianceID";
	public static final String GETOLDASSIGNEEREM="SELECT new com.infosysit.rctmscompliance.model.OldAssigneeRem(CI.txtAssigneeRemarks,CI.txtVerifierApprovalRemarks, CI.txtOwnerRemarks,CI.txtVerifierRejectRemark," + 
			" CI.txtAssigneeAfterRejectRemark,CI.intNoOfCycles, CI.txtAttachmentListVerifier,CI.txtStatus) FROM CMSTrnComplianceInstance AS " + 
			" CI WHERE CI.compPKey.dtAssignedDate = :dtAssignedDate AND CI.compPKey.intComplianceID = :intComplianceID";
	
	public static final String GETCOMPISWITH="select case " + 
			"when txtStatus= 'Pending Input' or txtStatus='NonComplianceA' then 'Compliance is with assignee' " + 
			"when txtStatus='Pending Verification' or txtStatus='NonComplianceV' then 'Compliance is with verifier' " + 
			"when txtStatus='Verified' or txtStatus='NonComplianceO' then 'Compliance is with owner' " + 
			"else 'Compliance is closed' end " + 
			"From CMSTrnComplianceInstance where compPKey.intComplianceID = :intComplianceID and compPKey.dtAssignedDate = :dtAssignedDate";
	public static final String GETMOBILECONTROLS="select Distinct new com.infosysit.rctmscompliance.model.MobileControlModel(cntrl.txtParamName,cntrl.intType,cntrl.txtControlDesc,cntrl.txtDisplayMessage,cntrl.txtIsDependent,cntrl.txtDependentTo,cntrl.txtUrl,"
			+ "cntrl.flgActive,cntrl.txtIsPastDateRestricted,cntrl.txtIsRequired,cntrl.intLength,cntrl.txtErrorMsg,cntrl.txtIsVisible,cntrl.intOrder,cntrl.options) From "
			+ "CMSMstMobileControls cntrl where cntrl.txtPageName like '%'||:txtPageName||'%' and cntrl.flgActive= :flgActive";
	
	public static final String GETACTIONITEMDETAILS=" SELECT Distinct new com.infosysit.rctmscompliance.model.RCTMSActionItemDetails(AIT.intActionItemId,CASE DLG.flgActive " + 
			" WHEN 'Y' THEN DLG.txtOwnerto ELSE AIT.txtActionItemOwner END as ActionItemOwner,AIT.txtActionItemDescription,CASE AIT.flgIsAssigneeDelegated " + 
			" WHEN 'Y' THEN CND.txtAssigneeTo ELSE AIT.txtActionItemAssignee END as ActionItemAssignee,AIT.dtActionItemDueDate,AIR.txtActionItemAssigneeComments," + 
			" AIT.dtActionItemReminderInterval,AIT.txtActionItemStatus ,NT.txtReferenceNumber,NT.dtNoticeDueDate,NT.txtDescription,AIT.intLinkNoticeflg,AIT.txtEscalationowner," + 
			" AIT.intEscatationInterval,AIR.txtFindings,AIR.txtReason,AIT.txtApplicationName,AIT.txtMakerEmpNo,AIT.txtCheckerEmpNo," + 
			" AIT.txtTransactionID,AIT.intRuleID,AIR.txtCorrectiveAction,AIR.txtRemediation,AIR.txtActionItemRejectComments) FROM " + 
			" CMSTrnActionItemTracking as AIT  inner join CMSTrnNoticeTracking AS NT   on  NT.intNoticeId=AIT.intNoticeMappedTo " + 
			" LEFT OUTER JOIN  CMSTrnActionItemDelegation AS CND  ON CND.intActionItemId=AIT.intActionItemId  AND CND.flgActive='Y' " + 
			" LEFT OUTER JOIN CMSTrnActionItemResponse AS AIR  ON AIR.intActionItemId=AIT.intActionItemId " + 
			" LEFT OUTER JOIN CMSTrnNoticeDelegation DLG ON DLG.flgActive = 'Y' and  DLG.intNoticeID = NT.intNoticeId " + 
			" WHERE  AIT.intActionItemId = :intActionItemId ";
	
	public static final String GETNOTICEDETAILFORBIS="select Distinct count(BIS.txtNoticeReferenceNo) from CMSmstBISNoticeDetails BIS  where BIS.txtNoticeReferenceNo = :txtNoticeReferenceNo";

	public static final String GETFINDINGS="select distinct BISF.txtFinding from CMSmstBISfilterdetails BISF";
	public static final String GETREASON="select distinct BISF.txtReason from CMSmstBISfilterdetails BISF where BISF.txtFinding= :txtFinding";
	public static final String GETCORRECTIVEACTION="select distinct CF.txtCorrectiveAction from CMSmstfilterdetails CF";
	public static final String GETREMEDIATION="select distinct RF.txtRemediation from CMSmstfilterdetails RF";
	public static final String GETEMPLOYEEMAILID="select txtMailId from ViewCurrEmpAllDetails where txtEmpNo= :txtEmpNo";
	public static final String ISACTIONITEMEXISTS="select distinct count(AIT.intActionItemId) from CMSTrnActionItemTracking AIT where AIT.intActionItemId= :intActionItemId";
	public static final String SUBMITACTIONITEMTOOWNER="UPDATE CMSTrnActionItemResponse SET " + 
			"txtActionItemAssigneeComments =:txtActionItemComments,dtActionItemAssigneeComments=GETDATE()," + 
			"txtLastModifiedBy = :txtEmployeeId,dtLastModified=GETDATE(),txtFindings=:txtFindings,txtReason=:txtReason,txtCorrectiveAction=:txtCorrectiveAction,txtRemediation=:txtRemediation WHERE intActionItemId=:intActionItemId";
	public static final String REJECTACTIONITEM="UPDATE CMSTrnActionItemResponse SET " + 
			"txtactionitemrejectcomments =:txtActionItemComments,dtActionItemRejectComments=GETDATE()," + 
			"txtLastModifiedBy = :txtEmployeeId,dtLastModified=GETDATE(),txtFindings=:txtFindings,txtReason=:txtReason," + 
			"txtCorrectiveAction=:txtCorrectiveAction,txtRemediation=:txtRemediation WHERE intActionItemId=:intActionItemId";
	public static final String CLOSEACTIONITEM="UPDATE CMSTrnActionItemResponse SET txtactionitemclosecomments =:txtActionItemComments,dtActionItemCloseComments=GETDATE()," + 
			"txtLastModifiedBy = :txtEmployeeId,dtLastModified=GETDATE(),txtFindings=:txtFindings,txtReason=:txtReason," + 
			"txtCorrectiveAction=:txtCorrectiveAction,txtRemediation=:txtRemediation WHERE intActionItemId=:intActionItemId";
	public static final String GETPREVCOMMENTS="SELECT Distinct new com.infosysit.rctmscompliance.model.ActionItemPrevCommentAndDetails"+
			" (AIR.txtActionItemAssigneeComments,AIR.txtActionItemRejectComments,AIR.txtActionItemCloseComments,CASE DLG.flgActive" + 
			" WHEN 'Y' THEN DLG.txtOwnerto ELSE AIT.txtActionItemOwner END as ActionItemOwner," + 
			" CASE AIT.flgIsAssigneeDelegated WHEN 'Y' THEN CND.txtAssigneeTo ELSE AIT.txtActionItemAssignee END as ActionItemAssignee,AIR.intNoOfCycles) FROM " + 
			" CMSTrnActionItemTracking as AIT LEFT OUTER JOIN  CMSTrnActionItemDelegation AS CND  ON CND.intActionItemId=AIT.intActionItemId  AND CND.flgActive='Y' " + 
			" inner join CMSTrnNoticeTracking AS NT on  NT.intNoticeId=AIT.intNoticeMappedTo LEFT OUTER JOIN CMSTrnActionItemResponse AS AIR  "
			+ "ON AIR.intActionItemId=AIT.intActionItemId LEFT OUTER JOIN CMSTrnNoticeDelegation DLG ON DLG.flgActive = 'Y' and  DLG.intNoticeID = NT.intNoticeId WHERE  AIR.intActionItemId = :intActionItemId";
	public static final String UPDATEACTIONITEMSTATUS="UPDATE CMSTrnActionItemTracking SET txtActionItemStatus =:txtActionItemStatus WHERE intActionItemId=:intActionItemId";
	public static final String UPDATEACTIONITEMNOOFCYCLE="UPDATE CMSTrnActionItemResponse SET intNoOfCycles =:intNoOfCycles WHERE intActionItemId=:intActionItemId";
}
