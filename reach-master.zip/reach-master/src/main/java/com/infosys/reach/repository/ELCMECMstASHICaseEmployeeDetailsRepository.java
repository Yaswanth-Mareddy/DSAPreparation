package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

@Repository
public interface ELCMECMstASHICaseEmployeeDetailsRepository extends JpaRepository<ELCMECMstASHICaseEmployeeDetails, Integer> {

	@TrackExecutionTime
	@Override
	<S extends ELCMECMstASHICaseEmployeeDetails> List<S> saveAll(Iterable<S> entities);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCASEEMPLOYEEDETAILSBYCASEID)
	List<EmployeeDetails> findEmployeeDetailsByCaseId(@Param("caseId") int caseId, @Param("actor") List<String> actor);
	
	@TrackExecutionTime
	List<ELCMECMstASHICaseEmployeeDetails> findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(int caseId,  String mailId, int flgActive, int flgValid, List<String> comparisonTypes);

	@TrackExecutionTime
	Optional<ELCMECMstASHICaseEmployeeDetails> findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActor(int caseId,  String mailId, int flgActive, int flgValid, String actor);

	@TrackExecutionTime
	@Override
	Optional<ELCMECMstASHICaseEmployeeDetails> findById(Integer id);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCASESUMMARYDROPDOWN)
	List<GenModelOption> getCaseSummaryDropDownByCaseIdAndActor(@Param("caseId") int caseId, @Param("actor") List<String> actor);
	
	@Query(value=QueryConstants.GETEMPLOYEES)
	List<GenModelOption> getEmployeesByCaseIdAndActor(@Param("caseId") int caseId, @Param("actor") List<String> actor);

	@TrackExecutionTime
	List<ELCMECMstASHICaseEmployeeDetails> findByCaseId(int caseid);
}
