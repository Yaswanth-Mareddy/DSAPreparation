package com.infosys.hello.springboot.util;

public class QueryConstants {

	public static final String FIND_BY_NAME = "SELECT * FROM customer_details WHERE txt_Name = ?1";
	   
    public static final String CUSTOMER_COUNT = "SELECT COUNT(*) FROM customer_details";
	/*
	 * public static final String FIND_BY_NAME =
	 * "SELECT * FROM customer_details WHERE txt_Name = ?1";
	 * 
	 * public static final String CUSTOMER_COUNT =
	 * "SELECT COUNT(*) FROM customer_details";
	 */

}
