package com.infosys.hello.springboot.repository;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.infosys.hello.springboot.config.CustomMessageSourceConfiguration;
import com.infosys.hello.springboot.dto.ValidatorDTO;

@Repository
public class ValidatorRepository{
	
//	@Value("${validatordto.save}")
//	private String saveSuccess;

	@Autowired
	CustomMessageSourceConfiguration configuration;
	
	public ValidatorDTO getValidateDTO(String name) {
		ValidatorDTO obj = new ValidatorDTO();
		obj.setName(name);
		obj.setPhoneNumber("123");
		obj.setAge(23);
		return obj;
	}

	public String save(@Valid @NotNull ValidatorDTO obj) {
//		return saveSuccess;
		return configuration.messageSource().getMessage("success", null, "Saved successfully", null);
	}

}
