package com.infosys.reach.model.ashiadmin;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InvestigationType {

	private boolean isConciliation;
	private boolean isFormal;
	
}
