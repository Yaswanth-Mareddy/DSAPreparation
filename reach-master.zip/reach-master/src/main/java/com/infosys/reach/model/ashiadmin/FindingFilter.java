package com.infosys.reach.model.ashiadmin;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FindingFilter {

	private int caseid;
	private String recipient;
	private String recipientType;
}
