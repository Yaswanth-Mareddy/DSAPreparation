package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSMstConfigurableDetails;
import com.infosysit.rctmscompliance.model.ComplianceConfigurableDetails;

@Repository
public interface CMSMstConfigurableDetailsRepoRead extends JpaRepository<CMSMstConfigurableDetails, Integer> {

	List<ComplianceConfigurableDetails> findAllByIntComplianceID(int intComplianceID);
	
}
