package com.infosys.reach.model.ashi;

import java.util.ArrayList;
import java.util.List;

import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModelOption;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class GMFields {

	private int caseid;
	private boolean isGRB=false;
	private int raisingFor;
	private int respondentType;
	private int isRespondentKnown;
	private int complainantType;
	private int isComplainantKnown;
	private String complainantsOther;
	private String complainantsInfy;
	private String respondentsOther;
	private String respondentsInfy;
	private String country;
	private String baseLocation;
	private String description;
	private String cocomplainants;
	private String witnesses;
	private int isStakeHolder;
	private String stakeholderRole;
	private String stakeholder;
	private List<DocumentData> evidences;
	private int complaintCategory;
	private String placeOfIncident;
	private boolean isDPAccepted;
	private String role;
	private String company;
	private int isApproval;
	private List<String> location;
	private List<String> status;
	private String discussedOn;
	private String discussedWith;
	private String discussionSummary;
	private List<DocumentData> documents = new ArrayList<>();
	private String comments;
	private String assignedRole;
	private String assignedLocation;
	private String assignedTo = "";
	private String complainant;
	private int flgRelief;
	private String reliefs;
	private String remarks;
	private String mailTo = "";
	private String investigationType;
	private String conciliationReason;
	private String conciliationFindings;
	private String conciliationRecommendations;
	private List<DocumentData> conciliationAggrementDocs;
	private String action;
	private String transactionid;
	private String actionAgainst;
	private String respondent;
	private String witness;
	private String severityLevel;
	private String recommendedActions;
	private String summonsTo;
	private String summonsWith;
	private String formalCaseSummary;
	private String formalOtherRecommendation;
	private List<DocumentData> formalInvestigationDocs;
	private List<DocumentData> investigationPanelApprovals;
	private int flgInvestigationPanelApproval;
	private String investigationPanelReason;
	private List<DocumentData> presidingOfficersApprovals;
	private int flgPresidingOfficersApproval;
	private String presidingOfficersReason;
	private List<DocumentData> extICMembersapprovals;
	private int flgExtICMembersApproval;
	private String extICMembersReason;
	private String slaExtendDate;
	private String extensionReason;
	private String recipientType;
	private String recipient;
	private String allegationDesc;
	private String findings;
	private String outcome;
	private String incidentDate;
	private int flgBothPartiesClosure;
	private List<Integer> checkedRecommendations = new ArrayList<>();
	private List<Integer> uncheckedRecommendations = new ArrayList<>();
	private List<DocumentData> implementationDocs;
	private String response;
	private String template;
	private String chargeSheetIssued;
	private List<DocumentData> uploadchargesheet;
	
	public void setChecklistRecommendations(List<GenModelOption> options) {
		for(GenModelOption option : options) {
			if(option.isSelected())
				this.checkedRecommendations.add(Integer.valueOf(option.getKey()));
			
			else
				this.uncheckedRecommendations.add(Integer.valueOf(option.getKey()));
		}
	}
	
	public void setFlgRelief(String reliefRequired) {
		if(reliefRequired.equalsIgnoreCase("yes"))
			this.flgRelief = 1;
		else if(reliefRequired.equalsIgnoreCase("no"))
			this.flgRelief = 2;
		else
			this.flgRelief = 0;
	}
	
	public void setReliefs(List<GenModelOption> options, List<String> reliefList) {
		StringBuilder reliefsBuilder = new StringBuilder();
		
		for(GenModelOption option : options) {
			if(reliefList.contains(option.getKey()))
				reliefsBuilder.append(",").append(option.getValue());
				
		}
		this.reliefs = reliefsBuilder.length()!=0 ? reliefsBuilder.substring(1) : "";
	}
	
	public void setRecipient(List<String> recipients) {

		StringBuilder recipientBuilder = new StringBuilder();
	
		for(String mailid : recipients) {
			recipientBuilder.append(",").append(mailid);
				
		}
		this.recipient = recipientBuilder.length()!=0 ? recipientBuilder.substring(1) : "";
	}
	
	public void setOtherRelief(String otherRelief) {
		if(otherRelief!=null && !otherRelief.isEmpty()) {
			if(this.reliefs!=null && !this.reliefs.isEmpty())
				this.reliefs = this.reliefs + "," + otherRelief;
			else
				this.reliefs = otherRelief;
		}
	}
	
	public void setRecommendedActions(List<GenModelOption> options, List<String> recommendations) {
		StringBuilder recommendedActionsBuilder = new StringBuilder();
		
		for(GenModelOption option : options) {
			if(recommendations.contains(option.getKey()))
				recommendedActionsBuilder.append(",").append(option.getValue());
				
		}
		this.recommendedActions = recommendedActionsBuilder.length()!=0 ? recommendedActionsBuilder.substring(1) : "";
	}

}
