package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.model.ashi.ComplaintDetails;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashiadmin.AdminInboxRow;
import com.infosys.reach.model.ashiadmin.CaseSummary;
import com.infosys.reach.model.ashiadmin.MailEmployeeDetails;
import com.infosys.reach.model.common.CaseDetailsAuthorization;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnASHICaseDetailsRepository extends JpaRepository<ELCMECTrnASHICaseDetails, Integer> {

	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnASHICaseDetails> S save(S entity);
	
	@TrackExecutionTime
	@Override
	Optional<ELCMECTrnASHICaseDetails> findById(Integer id);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCOMPLAINTDETAILSBYCASEID)
	List<ComplaintDetails> findComplaintDetailsByCaseId(@Param("caseId") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETMYCASES)
	List<InboxCaseDetails> findMyCases(@Param("empNo") String empNo, @Param("raisedBy") List<String> raisedBy);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETTAGGEDCASES)
	List<InboxCaseDetails> findTaggedCases(@Param("mailId") String mailId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCASESASRESPONDENT)
	List<InboxCaseDetails> findCasesAsRespondent(@Param("mailId") String mailId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCASESUMMARY)
	List<CaseSummary> findCaseSummaryByCaseId(@Param("caseid") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETLOCATIONS)
	List<GenModelOption> getLocation(@Param("country") String country);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETSTATUS)
	List<GenModelOption> getStatus(@Param("role") String role);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETADMININBOXROWS + QueryConstants.NOTINCASEFILTER + QueryConstants.ORDERBY)
	List<AdminInboxRow> findCasesByCaseStatusAndCountryAndCompany(@Param("role") String role, @Param("country") String country, @Param("company") String company, @Param("status") List<String> status);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETADMININBOXROWS + QueryConstants.INCASEFILTER + QueryConstants.ORDERBY)
	List<AdminInboxRow> findClosedCasesByCaseStatusAndCountryAndCompanyAndStatus(@Param("role") String role, @Param("country") String country, @Param("company") String company, @Param("status") List<String> status);

	@TrackExecutionTime
	@Query(value=QueryConstants.GETADMININBOXROWS + QueryConstants.ASSIGNEE_LOCATION_FILTER + QueryConstants.NOTINCASEFILTER + QueryConstants.ORDERBY)
	List<AdminInboxRow> findCasesByCaseStatusAndCountryAndCompanyAndAssigneeLocation(@Param("role") String role, @Param("country") String country, @Param("company") String company, @Param("assigneeLocation") List<String> assigneeLocation, @Param("status") List<String> status);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETADMININBOXROWS_SLAAPPROVALCASES + QueryConstants.GETADMININBOXROWS_APPROVALCASES_FILTER + QueryConstants.NOTINCASEFILTER + QueryConstants.ORDERBY)
	List<AdminInboxRow> findSLAApprovalCasesByCaseStatusAndCountryAndCompany(@Param("role") String role, @Param("country") String country, @Param("company") String company, @Param("status") List<String> status);

	@TrackExecutionTime
	@Query(value=QueryConstants.GETADMININBOXROWS_INTERIMAPPROVALCASES + QueryConstants.GETADMININBOXROWS_APPROVALCASES_FILTER + QueryConstants.NOTINCASEFILTER + QueryConstants.ORDERBY)
	List<AdminInboxRow> findInterimApprovalCasesByCaseStatusAndCountryAndCompany(@Param("role") String role, @Param("country") String country, @Param("company") String company, @Param("status") List<String> status);

	
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETPREVIOUSCASES)
	List<Card> findPreviousCaseByActorAndEmpno(@Param("empNo") String empNo, @Param("actor") String actor);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETDETAILSFORMAIL)
	List<MailEmployeeDetails> getDetailsForMail(@Param("caseId") int caseId, @Param("actor") String actor, @Param("role") String role);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCASEDETAILSFORAUTHORIZATION)
	Optional<CaseDetailsAuthorization> getCaseDetailsForAuthorization(@Param("caseid") int caseId);


}
