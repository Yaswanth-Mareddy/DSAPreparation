package com.infosys.reach.model.common;

import org.apache.commons.lang3.StringUtils;

import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class CaseDetailsAuthorization {

	private String moduleId;
	private String status;
	private String currentRole;
	private String country;
	private String company;
	private String assigneeLocation;
	private ELCMECTrnASHICaseDetails caseDetails;
	
	public CaseDetailsAuthorization(int moduleId, String status, String currentRole, String country,
			String company, String assigneeLocation, ELCMECTrnASHICaseDetails caseDetails) {
		super();
		this.moduleId = String.valueOf(moduleId);
		this.status = status.trim();
		this.currentRole = currentRole.trim();
		this.country = StringUtils.isBlank(country) ? "" : country.trim();
		this.company = StringUtils.isBlank(company) ? "" : company.trim();
		this.assigneeLocation = StringUtils.isBlank(assigneeLocation) ? "" : assigneeLocation.trim();
		this.caseDetails = caseDetails;
	}
	
	
}
