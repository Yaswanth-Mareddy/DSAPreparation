package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECMstASHIRecommendationsDetails;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.QueryConstants;

public interface ELCMECMstASHIRecommendationsDetailsRepository
		extends JpaRepository<ELCMECMstASHIRecommendationsDetails, Integer> {
	
	List<ELCMECMstASHIRecommendationsDetails> findByCaseId(int caseid);
	
	List<ELCMECMstASHIRecommendationsDetails> findByCaseIdAndFlgImplemented(int caseid, int flgImplemented);
	
	@Query(value = QueryConstants.GETRECOMMENDEDACTIONBYCASEIDANDACTOR)
	List<GenModelOption> findByCaseIdAndActor(@Param(Constants.CASEID) int caseid, @Param(Constants.ACTOR) String actor);
	
	Optional<ELCMECMstASHIRecommendationsDetails> findBySerialNoAndCaseId(int serialNo, int caseid);
	
	Optional<ELCMECMstASHIRecommendationsDetails> findByCaseIdAndMailIdAndActor(int caseid, String mailId, String actor);

}
