package com.infosys.hello.springboot.service;

import com.infosys.hello.springboot.model.Greeting;


public interface GreetingsService {

    public Greeting getGreetings(String name);
}
