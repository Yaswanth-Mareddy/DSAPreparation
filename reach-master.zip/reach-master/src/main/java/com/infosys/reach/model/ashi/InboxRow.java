package com.infosys.reach.model.ashi;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InboxRow {

	private int caseId;
	private String reportedOn;
	private String managedBy;
	private String status;
	public InboxRow(InboxCaseDetails obj) {
		super();
		this.caseId = obj.getCaseId();
		this.reportedOn = obj.getReportedOn();
		this.managedBy = obj.getManagedBy();
		this.status = obj.getStatus();
	}
	
	
}
