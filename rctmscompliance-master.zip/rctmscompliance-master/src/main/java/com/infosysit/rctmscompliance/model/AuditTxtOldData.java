package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
public class AuditTxtOldData {
	
	private int complianceID;
	private String complianceName;
	private String description;
	private String compGroupName;
	private String locationName;
	private String dueDate;
	private String endDate;
	private String frequency;
	private int daysBeforeStart;
	private int reminderInterval;
	private String nodeName;
	private String isNewlyCreated;
	private String deptName;
	private String lastModifiedBy;
	private String lastModified;
	private String assignee;
	private String verifier;
	private String owner;

	public String toString() {
		return "ComplianceID="+complianceID+"||ComplianceName="+complianceName+"||Description="+description+"||CompGroupName="+compGroupName+"||LocationName="
				+locationName+"||DueDate="+dueDate+"||EndDate="+endDate+"||Frequency="+frequency+"||DaysBeforeStart="+daysBeforeStart+"||ReminderInterval="
				+reminderInterval+"||NodeName="+nodeName+"||IsNewlyCreated="+isNewlyCreated+"||DeptName="+deptName+"||LastModifiedBy="+ lastModifiedBy + "||LastModified="+lastModified 
				+"||Assignee="+assignee+ "||Verifier="+verifier+"||Owner="+owner;
	}
}
