package com.infosys.reach.model.hear;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CaseDetailsValidationResponse {

	private boolean status;
	private String message;
	private HearCaseDetails caseDetails;
	private List<String> taggedEmpMailIdList;
	
	public CaseDetailsValidationResponse(boolean status, String message) {
		super();
		this.status = status;
		this.message = message;
	}
	
	public CaseDetailsValidationResponse(boolean status) {
		super();
		this.status = status;
	}
	
}
