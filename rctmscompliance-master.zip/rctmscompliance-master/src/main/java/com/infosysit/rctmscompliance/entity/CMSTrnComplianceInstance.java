package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrncomplianceinstance")
public class CMSTrnComplianceInstance {
	
	
	@EmbeddedId
	private ComplianceInstanceCompPKey compPKey;
	
	@Column(name="txtstatus")
	private String txtStatus;
	
	@Column(name="intnoofcycles")
	private int intNoOfCycles;
	
	
	@Column(name="dtduedate")
	private String dtDueDate;
	
	@Column(name="dtfileddate")
	private String dtFiledDate;
	
	@Column(name="dtnextexecutiondate")
	private String dtNextExecutionDate;
	
	@Column(name="intescalatedlevel")
	private int intEscalatedLevel;
	
	@Column(name="txtassigneeremarks")
	private String txtAssigneeRemarks;
	
	@Column(name="txtverifierapprovalremarks")
	private String txtVerifierApprovalRemarks;
	
	@Column(name="txtownerremarks")
	private String txtOwnerRemarks;
	
	@Column(name="txtattachmentlist")
	private String txtAttachmentList;
	
	@Column(name="dtescalateddate")
	private String dtEscalatedDate;
	
	@Column(name="dtassigneddtassignee")
	private String dtAssignedDtAssignee;

	@Column(name="dtassigneddtverifier")
	private String dtAssignedDtVerifier;
	
	@Column(name="dtassigneddateowner")
	private String dtAssignedDateOwner;
	
	@Column(name="txtverifierrejectremark")
	private String txtVerifierRejectRemark;
	
	@Column(name="txtassigneefileremark")
	private String txtAssigneeFileRemark;
	
	@Column(name="txtassigneeafterrejectremark")
	private String txtAssigneeAfterRejectRemark;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtattachmentlistverifier")
	private String txtAttachmentListVerifier;
	
	@Column(name="txtattachmentlistowner")
	private String txtAttachmentListOwner;
	
	@Column(name="txtattachmentlistfile")
	private String txtAttachmentListFile;
	
	@Column(name="flgisassigneedelegated")
	private String flgIsAssigneeDelegated;
	
	@Column(name="flgisverifierdelegated")
	private String flgIsVerifierDelegated;
	
	@Column(name="flgisownerdelegated")
	private String flgIsOwnerDelegated;
	
	@Column(name="dtactualfilingdate")
	private String dtActualFilingDate;
}
