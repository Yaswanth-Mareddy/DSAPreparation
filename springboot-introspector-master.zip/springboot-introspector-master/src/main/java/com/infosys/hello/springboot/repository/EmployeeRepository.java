package com.infosys.hello.springboot.repository;

import java.util.Map;

import com.infosys.hello.springboot.model.Employee;

public interface EmployeeRepository {
     
	Map<Integer,Employee> findAll();
	
	Employee find(int id);
	
	void save(Employee employee);
	
	void update(Employee employee);
	
	void delete(int id);

}