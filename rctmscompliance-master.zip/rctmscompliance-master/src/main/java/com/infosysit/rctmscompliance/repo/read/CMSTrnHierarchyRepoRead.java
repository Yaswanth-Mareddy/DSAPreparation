package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnHierarchy;

@Repository
public interface CMSTrnHierarchyRepoRead extends JpaRepository<CMSTrnHierarchy, Integer> {

}
