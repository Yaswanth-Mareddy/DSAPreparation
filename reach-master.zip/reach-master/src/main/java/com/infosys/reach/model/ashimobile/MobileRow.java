package com.infosys.reach.model.ashimobile;

import java.util.List;

import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashi.InboxRow;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MobileRow {

	private InboxRow details;
	private List<MobileInboxAction> actions;

	public MobileRow(InboxCaseDetails oneRow, List<MobileInboxAction> actions) {
		super();
		this.details = new InboxRow(oneRow);
		this.actions = actions;
	}

}
