package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Label {

	private List<CardViewAction> actions;
	private List<CardViewField> highlightFields;
	private List<CardViewField> fields;
	
	public Label(List<CardViewField> fields) {
		this(new ArrayList<>(), new ArrayList<>(), fields);
	}
	
	public Label(List<CardViewField> fields, List<CardViewAction> actions) {
		this(actions, new ArrayList<>(), fields);
	}
	
	
}
