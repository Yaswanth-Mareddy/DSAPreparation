package com.infosys.reach.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.stereotype.Service;

import com.infosys.reach.model.common.FileGenerationServiceResponse;
import com.infosys.reach.model.generic.DocumentData;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.filespec.PdfFileSpec;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;



@Service
public class FileGenerationServiceImpl implements FileGenerationService{

	@Override
	public FileGenerationServiceResponse pdfGenerator(String tempStoragePath,String targetFileName,String letterContent) {
		StringBuilder filename = new StringBuilder(tempStoragePath).append(targetFileName);
		File file = new File(filename.toString());
		try(OutputStream os = new FileOutputStream(file);)
		{

			InputStream is = new ByteArrayInputStream(letterContent.getBytes());

			Charset charset = StandardCharsets.ISO_8859_1;

			Document document = new Document();
			PdfWriter writer = PdfWriter.getInstance(document, os);
			document.setMargins(50, 50, 75, 75);
			document.open();
			XMLWorkerHelper.getInstance().parseXHtml(writer, document, is,charset);
			document.close();
			writer.close();
			return new FileGenerationServiceResponse(true, "");

		}
		catch (Exception e)
		{
			return new FileGenerationServiceResponse(false, e.getMessage());
		}
	}


	@Override
	public FileGenerationServiceResponse addAttachmentsToPDF(String tempStoragePath, String sourceFileName, String targetFileName, List<DocumentData> attachments) {
		StringBuilder sourceFilePath = new StringBuilder(tempStoragePath).append(sourceFileName);
		StringBuilder targetFilePath = new StringBuilder(tempStoragePath).append(targetFileName);

		try(PdfDocument pdfDoc = new PdfDocument(new com.itextpdf.kernel.pdf.PdfReader(sourceFilePath.toString()), new com.itextpdf.kernel.pdf.PdfWriter(targetFilePath.toString()));){

			for(DocumentData attachment : attachments) {
				String embeddedFileName = attachment.getFilename();
				String embeddedFileDescription = attachment.getFilename();
				byte[] embeddedFileContentBytes = com.itextpdf.io.codec.Base64.decode(attachment.getBase64file());

				PdfFileSpec spec = PdfFileSpec.createEmbeddedFileSpec(pdfDoc, embeddedFileContentBytes,
						embeddedFileDescription, embeddedFileName, null, null, null);

				pdfDoc.addFileAttachment("embedded_file " + embeddedFileDescription , spec);
			}
			return new FileGenerationServiceResponse(true, "");
		}
		catch (Exception e)
		{
			return new FileGenerationServiceResponse(false, e.getMessage());
		}
		
	}
	
	
}
