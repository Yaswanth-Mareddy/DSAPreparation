package com.infosys.reach.model.ashimobile;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EvidenceCard {

	private String displayName;
	private int type;
	private boolean isSelected;
	private List<EvidenceField> fields;

	public EvidenceCard(List<EvidenceField> fields) {
		super();
		this.displayName = "";
		this.isSelected = false;
		this.fields = fields;
	}

}
