package com.infosys.reach.entity;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.common.CaseEmployeeDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="elcmecmstashicaseemployeedetails")
public class ELCMECMstASHICaseEmployeeDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="txtempname")
	private String empName;
	
	@Column(name="txtunit")
	private String unit;
	
	@Column(name="txtsbucode")
	private String sbuCode;
	
	@Column(name="txtempbandcode")
	private String empBandCode;
	
	@Column(name="dtjoineddate")
	private Date joinedDate;
	
	@Column(name="txtducode")
	private String duCode;
	
	@Column(name="txtroledesc")
	private String roleDesc;
	
	@Column(name="txtprojectcode")
	private String projectCode;
	
	@Column(name="txtcompany")
	private String company;
	
	@Column(name="txtcountrycode")
	private String countryCode;
	
	@Column(name="txtcurrentcity")
	private String currentCity;
	
	@Column(name="txtbasecity")
	private String baseCity;
	
	@Column(name="txtconfirmationstatus")
	private String confirmationStatus;
	
	@Column(name="txtreportingmanager")
	private String reportingManager;
	
	@Column(name="txtactor")
	private String actor;
	
	@Column(name="flgvalid")
	private int flgValid;
	
	@Column(name="txtselectedcountry")
	private String selectedCountry;
	
	@Column(name="txtselectedcity")
	private String selectedCity;
	
	@Column(name="flgactive")
	private int flgActive;

	public ELCMECMstASHICaseEmployeeDetails(int caseId,CaseEmployeeDetails caseDetails,String actor, String role) {
		super();
		this.caseId=caseId;
		this.empNo = caseDetails.getEmpNo();
		this.mailId = caseDetails.getMailId();
		this.empName = caseDetails.getEmpName();
		this.unit = caseDetails.getUnit();
		this.sbuCode = caseDetails.getSbuCode();
		this.empBandCode = caseDetails.getEmpBandCode();
		this.joinedDate = (Date) caseDetails.getJoinedDate();
		this.duCode = caseDetails.getDuCode();
		this.roleDesc = actor.equals("S")?role+" | "+caseDetails.getRoleDesc():caseDetails.getRoleDesc();
		this.projectCode = caseDetails.getProjectCode();
		this.company = caseDetails.getCompany();
		this.currentCity = caseDetails.getCurrentCity();
		this.baseCity = caseDetails.getBaseCity();
		this.confirmationStatus = caseDetails.getConfirmationStatus();
		this.reportingManager = caseDetails.getReportingManager();
		this.actor=actor;
		this.flgValid=1;
		this.flgActive=1;
	}
	
	
	public ELCMECMstASHICaseEmployeeDetails(int caseId,String name, String actor) {
		super();
		this.caseId=caseId;
		this.empName=name;
		this.actor=actor;
		this.flgValid=0;
		this.flgActive=1;
	}
	
	public ELCMECMstASHICaseEmployeeDetails(int caseId,CaseEmployeeDetails caseDetails, String actor) {
		this(caseId, caseDetails, actor, "");
	}
	
	
	
	
}
