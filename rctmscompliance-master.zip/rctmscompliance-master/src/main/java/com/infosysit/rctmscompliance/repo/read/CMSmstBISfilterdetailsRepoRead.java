package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSmstBISfilterdetails;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSmstBISfilterdetailsRepoRead extends JpaRepository<CMSmstBISfilterdetails, Integer> {

	@Query(value = CustomQueries.GETFINDINGS)
	List<String> getFindings();
	
	@Query(value = CustomQueries.GETREASON)
	List<String> getReason(@Param("txtFinding") String txtFinding);
}
