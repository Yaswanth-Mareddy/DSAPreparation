package com.infosys.reach.model.generic;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommentSummary {

	private String status;
    private String heading;
    private String description;
    private String comment;
    private String mailid;
    private String employeenumber;
    private List<CommentSummary> replies;
    private List<CommentSummaryAction> actions;
}
