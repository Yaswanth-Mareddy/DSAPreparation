package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Immutable
@Table(name="Viewcmsmstinboxdetailswithempid")
public class ViewCMSMstInboxDetailsWithEmpID {
	
	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="txtcompliancename")
	private String txtComplianceName;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
	
	@Column(name="txtgroupname")
	private String txtGroupName;
	
	@Column(name="txtlocation")
	private String txtLocation;
	
	@Column(name="txtdept")
	private String txtDept;
	
	@Column(name="dtduedate")
	private String dtDueDate;
	
	@Column(name="txtfrequency")
	private String txtFrequency;
	
	@Column(name="txtstatus")
	private String txtStatus;
	
	@Column(name="txtassignee")
	private String txtAssignee;
	
	@Column(name="txtverifier")
	private String txtVerifier;
	
	@Column(name="txtowner")
	private String txtOwner;
	
	@Column(name="dtactualfilingdate")
	private String dtActualFilingDate;
	
	@Column(name="txtpendingwith")
	private String txtPendingwith;
	
	@Column(name="assignee")
	private String assignee;
	
	@Column(name="verifier")
	private String verifier;
	
	@Column(name="owner")
	private String owner;
	
	@Column(name="pendingwith")
	private String pendingwith;
	

}
