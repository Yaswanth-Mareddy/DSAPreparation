package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmecmstashicommunicationdetails")
public class ELCMECMstASHICommunicationDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtseekedbymailid")
	private String seekedBy;
	
	@Column(name="txtseekedbyrole")
	private String seekedByRole;

	@Column(name="txtcomments")
	private String comments;
	
	@Column(name="txtrespondedbymailid")
	private String respondedBy;
	
	@Column(name="txtrespondedbyrole")
	private String respondedByRole;

	@Column(name="txtresponse")
	private String response;

	@Column(name="dtcreateddate")
	private Timestamp createdDate;
	
	@Column(name="dtupdateddate")
	private Timestamp updatedDate;
	
	@Column(name="flgresponded")
	private int flgResponded;

	public ELCMECMstASHICommunicationDetails(int caseId, String seekedBy, String seekedByRole, String comments,
			String respondedBy, String respondedByRole, Timestamp createdDate) {
		super();
		this.caseId = caseId;
		this.seekedBy = seekedBy;
		this.seekedByRole = seekedByRole;
		this.comments = comments;
		this.respondedBy = respondedBy;
		this.respondedByRole = respondedByRole;
		this.createdDate = createdDate;
		this.flgResponded = 0;
	}


	
}
