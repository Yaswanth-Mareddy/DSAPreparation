package com.infosys.reach.repository;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.HRISTrnEmpInfosysLocation;
import com.infosys.reach.util.QueryConstants;

public interface HRISTrnEmpInfosysLocationRepository extends JpaRepository<HRISTrnEmpInfosysLocation, Integer> {
	
	@Query(value = QueryConstants.GETEMPCOUNTRYFORDISCANDBG)
	Optional<String> findEmpCountryCodeForDiscAndBG(@Param("currentDate") Date currentDate, @Param("empNo") String empNo);

}
