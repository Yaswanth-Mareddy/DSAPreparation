package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.HRISMstEmployee;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface HRISMstEmployeeRepository extends JpaRepository<HRISMstEmployee, String>{
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETEMPLOYEECASEDETAILS)
	List<CaseEmployeeDetails> findCaseEmployeeDetails(@Param("reporteesEmpNo") String reporteesEmpNo);
	
}
