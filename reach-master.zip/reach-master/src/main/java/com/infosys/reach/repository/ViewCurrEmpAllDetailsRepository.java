package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ViewCurrEmpAllDetailsRepository extends JpaRepository<ViewCurrEmpAllDetails, String>,JpaSpecificationExecutor<ViewCurrEmpAllDetails>{
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETEMPLOYEEBYEMPNOORMAILID)
	Optional<ViewCurrEmpAllDetails> findByEmpNoOrMailId(@Param("id")String id);

}
