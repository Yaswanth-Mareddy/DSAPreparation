package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="genmstcity")
public class GENMstCity {
	@Id
	@Column(name="txtcountrycode")
	private String countryCode;	
	
	@Column(name="intcitycode")
	private String cityCode;
	
	@Column(name="txtcity")
	private String city;
	
	@Column(name="flgactive")
	private int isActive;

}
