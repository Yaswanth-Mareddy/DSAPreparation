package com.infosys.hello.springboot.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.hello.springboot.model.Employee;
import com.infosys.hello.springboot.service.EmployeeService;


import io.swagger.v3.oas.annotations.Operation;

@RequestMapping("/springboot/v1")
@RestController
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	/**
	 * This method is used to fetch employee data based on the employee id
	 * 
	 * @param id - Employee ID
	 * @return - Employee information
	 */
	@Operation(summary = "Find an employee record based on the id", tags = "employee")
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.GET, produces = "application/json")
	public Employee find(@PathVariable int id) {
		return employeeService.getEmployee(id);
	}

	/**
	 * This method is used to return all the employee details
	 * 
	 * @return - Returns all employee data
	 */
	@Operation(summary = "Fetch all employees", tags = "employee")
	@RequestMapping(value = "/employees", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON)
	public List<Employee> findAll() {
		Map<Integer, Employee> employees = employeeService.getEmployees(); 
		List<Employee> employeeList = new ArrayList<Employee>();
		for (Map.Entry<Integer, Employee> employee : employees.entrySet()) {
			employeeList.add(employee.getValue());
		}
		return employeeList;
	}

	/**
	 * This method is used to create a new employee
	 * 
	 * @param id   - Employee ID
	 * @param name - Employee Name
	 * @return
	 */
	@Operation(summary = "Create an employee record", tags = "employee")
	@RequestMapping(value = "/employee", method = RequestMethod.POST)
	public String save(@NotNull @NotEmpty @RequestParam("id") int id,
			@NotNull @NotEmpty @RequestParam("name") String name) {
		Employee employee = new Employee(id, name);
		employeeService.saveEmployee(employee);
		return "Employee data created successfully for the id " + id;
	}

	/**
	 * This method is used to delete an employee record based on the employee id
	 * 
	 * @param id - Employee ID
	 * @return
	 */
	@Operation(summary = "Delete an employee record by id", tags = "employee")
	@RequestMapping(value = "/employee/{id}", method = RequestMethod.DELETE)
	public String delete(@RequestParam("id") int id) {
		employeeService.deleteEmployee(id);
		return "Deleted employee data of id - " + id + " Successfully";
	}

}
