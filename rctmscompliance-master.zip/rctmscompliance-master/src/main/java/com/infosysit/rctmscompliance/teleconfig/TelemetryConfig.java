package com.infosysit.rctmscompliance.teleconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("telemetry")
public class TelemetryConfig {

	private Context context = new Context();

	public Context getContext() {
		return this.context;
	}

	public static class Context {
		private String channel;
		private PData pData = new PData();

		public static class PData {
			private String id;
			private String pid;
			private String version;

			public String getId() {
				return this.id;
			}

			public void setId(String id) {
				this.id = id;
			}

			public String getPid() {
				return this.pid;
			}

			public void setPid(String pid) {
				this.pid = pid;
			}

			public String getVersion() {
				return this.version;
			}

			public void setVersion(String version) {
				this.version = version;
			}
		}

		public String getChannel() {
			return this.channel;
		}

		public void setChannel(String channel) {
			this.channel = channel;
		}

		public PData getpData() {
			return this.pData;
		}

	}

}

