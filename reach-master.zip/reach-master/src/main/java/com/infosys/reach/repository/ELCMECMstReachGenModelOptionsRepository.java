package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECMstReachGenModelOptions;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstReachGenModelOptionsRepository extends JpaRepository<ELCMECMstReachGenModelOptions, Integer>{

	@TrackExecutionTime
	@Query(value=QueryConstants.GETGENMODELOPTIONSBYGROUPID)
	List<GenModelOption> getGenModelOptionsByGroupIdOrderByKeyAsc(@Param("moduleId") int moduleId, @Param("groupId") String groupId);
}
