package com.infosys.hello.springboot.service;

import java.util.List;

import com.infosys.hello.springboot.entity.Customer;

public interface CustomerService {
	void saveCustomer(Customer customer);

	List<Customer> getCustomers();

	List<Customer> getCustomerByName(String name);

	int getCustomerCount();
}
