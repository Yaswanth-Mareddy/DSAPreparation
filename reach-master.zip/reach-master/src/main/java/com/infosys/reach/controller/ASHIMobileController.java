package com.infosys.reach.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.EmployeeCardView;
import com.infosys.reach.model.ashimobile.EvidenceCardView;
import com.infosys.reach.model.ashimobile.MobileComplaintInboxView;
import com.infosys.reach.model.ashimobile.MobileInboxView;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(tags = "ASHI Module : InfyMe Mobile")
@RequestMapping("/v2/api")
public class ASHIMobileController extends Logging{
	
	
	@ApiOperation(value = "Fetch initiate case GenModel", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/initiatemobilecaseform", produces = "application/json")
	public ResponseEntity<Object> initiateASHICaseForm() {
		try {
			CaseFormGenModel caseForm = ashiMobileService.initiateCaseForm();
			telemetry.setLogEventData(Message.SUCCESSFULLY + "SUCCESSFULLY fetched initiate case GenModel");
			return ResponseEntity.ok(caseForm);
		}

		catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value = "Submit ASHI case", tags = "ASHI Module : InfyMe Mobile")
	@PostMapping(path = "/mobilesubmitcase", produces = "application/json", consumes = "application/json")
	public ResponseEntity<Object> submitASHICase(@RequestBody CaseFormGenModel caseGenModel) {
		try {
			String initiatorId = Session.getTokenEMPNO();

			if (!ashiWebService.checkHearAccess(initiatorId).isHasAccess()) {
				String message = "You don't have access to use this application.";
				Response response = new Response(Message.ERROR, message);
				telemetry.setLogEventData(Message.ERROR + " " + message);
				return ResponseEntity.ok(response);
			}
			GMFields caseDetails=commonService.convertGenModelToObject(caseGenModel, 2);

			CaseDetailsValidationResponse validateResponse = ashiWebService.validateCaseDetails(initiatorId, caseDetails, "MOBILE");

			if(validateResponse.isStatus()) {
				Response caseResponse = ashiWebService.initiateASHICase(validateResponse.getCaseDetails());
				
				telemetry.setLogEventData(Message.SUCCESSFULLY + "SUCCESSFULLY submitted ASHI case.");
				
				return new ResponseEntity<>(caseResponse, HttpStatus.OK);	
			}
			else {
				
				telemetry.setLogEventData(Message.ERROR + validateResponse.getMessage());
				
				return new ResponseEntity<>(new Response(Message.ERROR, validateResponse.getMessage()), HttpStatus.OK);	
			}

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}


	@ApiOperation(value = "Fetch complainant details", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/mobilecomplaintdetails", produces = "application/json")
	public ResponseEntity<Object> getCaseDetailsByCaseId(@RequestParam(name = Constants.CASEID, required = true) int caseId) {
		try {
			MobileComplaintInboxView outputObj = ashiMobileService.getComplaintDetails(caseId);

			return this.registerMobileLogs(outputObj.getRow() != null, outputObj, "SUCCESSFULLY fetched complaint details.", Message.CASENOTREGISTERED);

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value = "Fetch case concerned employees details", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/mobilecaseemployeedetails", produces = "application/json")
	public ResponseEntity<Object> getCaseEmployeeDetails(
			@RequestParam(name = Constants.CASEID, required = true) int caseId) {
		try {
			EmployeeCardView outputObj = ashiMobileService.getCaseEmployeeDetails(caseId);

			return this.registerMobileLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case employee details.", Message.CASENOTREGISTERED);

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}

	}

	@ApiOperation(value = "Fetch case evidences", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/mobileevidences", produces = "application/json")
	public ResponseEntity<Object> getEvidences(@RequestParam(name = Constants.CASEID, required = true) int caseId) {
		try {
			EvidenceCardView outputObj = ashiMobileService.getEvidences(caseId);

			return this.registerMobileLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case evidences.", Message.CASENOTREGISTERED);

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value = "Fetch cases initiated by me", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/mobile/myinbox/initiatedbyme", produces = "application/json")
	public ResponseEntity<Object> getInboxInitiatedByMe() {
		try {

			String empNo = Session.getTokenEMPNO();

			MobileInboxView details = ashiMobileService.getCasesInitiatedByMe(empNo);

			return this.registerMobileLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases initiated by employee.", Message.NOCASEFOUND);

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value = "Fetch cases initiated by cocomplainant", tags = "ASHI Module : InfyMe Mobile")
	@GetMapping(path = "/mobile/myinbox/cocomplainant", produces = "application/json")
	public ResponseEntity<Object> getInboxInitiatedBycocomplainant() {
		try {

			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());

			MobileInboxView details = ashiMobileService.getCasesInitiatedByCoComplainant(mailId);

			return this.registerMobileLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases Tagged for employee.", Message.NOCASEFOUND);

		} catch (Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value="Fetch my inbox tabs", tags="ASHI Module : InfyMe Mobile")
	@GetMapping(path="/mobile/myinboxtabs", produces="application/json")
	public ResponseEntity<Object> getInboxTabs() {
		try{
			List<TabView> tabview=ashiMobileService.getInboxTabs();
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched inbox tabs.");
			return ResponseEntity.ok(tabview);
		}
		catch(Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value="Fetch all cases", tags="ASHI Module : InfyMe Mobile")
	@GetMapping(path="/mobile/myinbox/all", produces="application/json")
	public ResponseEntity<Object> getInboxAll() {
		try {

			String empNo=Session.getTokenEMPNO();

			MobileInboxView details=ashiMobileService.getAllCases(empNo);

			return this.registerMobileLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox all cases.", Message.NOCASEFOUND);

		}
		catch(Exception e) {
			return this.registerMobileExceptionLogs(e);
		}
	}

	@ApiOperation(value="Fetch cases initiated by GRB", tags="ASHI Module : InfyMe Mobile")
	@GetMapping(path="/mobile/myinbox/initiatedbygrb", produces="application/json")
	public ResponseEntity<Object> getInboxInitiatedByGRB() {
		try {

			String empNo=Session.getTokenEMPNO();

			MobileInboxView details=ashiMobileService.getCasesInitiatedByGRB(empNo);

			return this.registerMobileLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases initiated by GRB.", Message.NOCASEFOUND);

		}
		catch(Exception e) {
			return this.registerMobileExceptionLogs(e);
		}

	}

	@ApiOperation(value="Check DP consent status", tags="ASHI Module : InfyMe Mobile")
	@GetMapping(path="/mobile/dpstatus", produces="application/json")
	public ResponseEntity<Object> getDPStatus() {
		try {

			DPServiceOutput output=commonService.dpService("ASHI","STATUS");

			return this.registerMobileLogs(output.getContent().equalsIgnoreCase("true") || output.getContent().equalsIgnoreCase("false"), new Response(Message.SUCCESS, "", "", output.getContent().toLowerCase()), "SUCCESSFULLY fetched DP status eligibility model - "+output.getContent(), Message.NOACCESS);
		}
		catch(Exception e) {
			return this.registerMobileExceptionLogs(e);
		}

	}

}
