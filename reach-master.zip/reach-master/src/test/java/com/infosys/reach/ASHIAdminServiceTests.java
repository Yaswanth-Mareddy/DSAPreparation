package com.infosys.reach;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.WordUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosys.reach.entity.ELCMECMstASHIAllegationsAndFindingsDetails;
import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.entity.ELCMECMstASHICocomplainantsDetails;
import com.infosys.reach.entity.ELCMECMstASHICommunicationDetails;
import com.infosys.reach.entity.ELCMECMstASHIConciliationConsentDetails;
import com.infosys.reach.entity.ELCMECMstASHIFormalInvestigationReportDetails;
import com.infosys.reach.entity.ELCMECMstASHIPreliminaryDiscussionDetails;
import com.infosys.reach.entity.ELCMECMstASHIRecommendationsDetails;
import com.infosys.reach.entity.ELCMECMstASHISummonsDetails;
import com.infosys.reach.entity.ELCMECMstReachWorkFlow;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.entity.ELCMECTrnASHIConciliationReportDetails;
import com.infosys.reach.entity.ELCMECTrnASHIFirstContactMailsDetails;
import com.infosys.reach.entity.ELCMECTrnASHIInterimReliefDetails;
import com.infosys.reach.entity.ELCMECtrnASHIConcernSLADetails;
import com.infosys.reach.entity.ELCMECtrnASHISLAAuditTrial;
import com.infosys.reach.entity.HRISMstEmployee;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.ashiadmin.AdminInboxRow;
import com.infosys.reach.model.ashiadmin.CaseSummary;
import com.infosys.reach.model.ashiadmin.FindingFilter;
import com.infosys.reach.model.ashiadmin.Findings;
import com.infosys.reach.model.ashiadmin.InboxFilter;
import com.infosys.reach.model.ashiadmin.MailEmployeeDetails;
import com.infosys.reach.model.ashiadmin.PreliminaryDiscussionDetails;
import com.infosys.reach.model.ashiadmin.UpdateCaseStatusReturn;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.generic.Accordion;
import com.infosys.reach.model.generic.AccordionView;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.Header;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.repository.ELCMECMstASHIAllegationsAndFindingsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICocomplainantsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICommunicationDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIConciliationConsentDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIFormalInvestigationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIPreliminaryDiscussionDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIRecommendationsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHISummonsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECMstReachWorkFlowRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIConciliationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIFirstContactMailsDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIInterimReliefDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECtrnASHIConcernSLADetailsRepository;
import com.infosys.reach.repository.ELCMECtrnASHISLAAuditTrialRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.service.ASHIAdminServiceImpl;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@ExtendWith(MockitoExtension.class)
class ASHIAdminServiceTests {

	private Timestamp dateTime = new Timestamp(System.currentTimeMillis());

	@InjectMocks
	ASHIAdminServiceImpl adminService;

	@Mock
	private ASHIServiceImpl ashiService;

	@Mock
	HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Mock
	GenMstMailConfigHeaderRepository mailConfigHeaderRepository;

	@Mock
	Property property;

	@Mock
	CommonServiceImpl commonservice;

	@Mock
	ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;

	@Mock
	ELCMECMstASHICocomplainantsDetailsRepository ashiCocomplainantsDetailsRepository;

	@Mock
	ELCMECTrnASHIActionDetailsRepository  ashiActionDetailsRepository;

	@Mock
	ELCMECMstASHICaseEmployeeDetailsRepository caseEmployeeDetailsRepository;

	@Mock
	ELCMECMstConcernModulesDetailsRepository  concernModulesDetailsRepository;
	@Mock
	ELCMECTrnReachCountryDetailsRepository  reachCountryDetailsRepository;

	@Mock
	ELCMECMstASHIPreliminaryDiscussionDetailsRepository preliminaryDiscussionDetailsRepository; 

	@Mock
	ELCMECTrnASHIInterimReliefDetailsRepository interimReliefRepository;

	@Mock
	ELCMECMstASHICommunicationDetailsRepository communicationRepository;

	@Mock
	ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;
	
	@Mock
	ELCMECtrnASHIConcernSLADetailsRepository slaDetailsRepository;
	
	@Mock
	ELCMECtrnASHISLAAuditTrialRepository slaAuditTrialRepository;
	
	@Mock
	ELCMECTrnASHIConciliationReportDetailsRepository conciliationReportDetailsRepository;
	
	@Mock
	ELCMECMstReachWorkFlowRepository workFlowRepository;
	
	@Mock
	ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Mock
	ELCMECTrnASHIFirstContactMailsDetailsRepository firstContactMailsRepository;
	
	@Mock
	ELCMECMstASHIConciliationConsentDetailsRepository conciliationConsentDetailsRepository;
	
	@Mock
	ELCMECMstASHIRecommendationsDetailsRepository recommendationsDetailsRepository;
	
	@Mock
	ELCMECMstASHISummonsDetailsRepository summonsDetailsRepository;

	@Mock
	ELCMECMstASHIFormalInvestigationReportDetailsRepository formalInvestigationReportDetailsRepository;

	@Mock
	ELCMECMstASHIAllegationsAndFindingsDetailsRepository allegationsAndFindingsDetailsRepository;
	
//	Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
//	Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
	
	@Test
	@DisplayName("When role options contains GRB")
	void getInboxFilter1() throws CustomException {
		List<GenModelField> fields = new ArrayList<>();

		List<GenModelOption> roleOptions = new ArrayList<>();
		roleOptions.add(new GenModelOption("GRB", "GRB"));

		GenModelField roleField=new GenModelField( 11, Constants.ROLE.toLowerCase(), Constants.ROLE, Constants.SELECT, "", new ArrayList<>(), true);
		fields.add(roleField);
		GenModelField countryField=new GenModelField( 11, Constants.COUNTRY.toLowerCase(), Constants.COUNTRY, Constants.ROLE.toLowerCase(), "url", true);
		countryField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COUNTRY)));
		fields.add(countryField);

		GenModelField companyField=new GenModelField( 11, Constants.COMPANY.toLowerCase(), Constants.COMPANY, Constants.ROLE.toLowerCase(), "url", true);
		companyField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COMPANY)));
		fields.add(companyField);		

		GenModel objExpected=new GenModel("Admin Inbox", fields, Arrays.asList(new CardViewAction("SUBMIT", Constants.POST,null)));

		Mockito.when(commonservice.getCAMSRoles(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(roleOptions);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn(roleOptions);

		Mockito.when(property.getContextURL()).thenReturn("url");
		Mockito.when(property.getInboxGMFilteredURL()).thenReturn("url");

		GenModel objActual=adminService.getInboxFilterGenmodel();

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	@DisplayName("When role options doesnot contain GRB")
	void getInboxFilter2() throws CustomException {
		List<GenModelField> fields = new ArrayList<>();

		List<GenModelOption> roleOptions = new ArrayList<>();
		roleOptions.add(new GenModelOption("IC", "IC"));

		GenModelField roleField=new GenModelField( 11, Constants.ROLE.toLowerCase(), Constants.ROLE, Constants.SELECT, "", new ArrayList<>(), true);
		fields.add(roleField);
		GenModelField countryField=new GenModelField( 11, Constants.COUNTRY.toLowerCase(), Constants.COUNTRY, Constants.ROLE.toLowerCase(), "url", true);
		countryField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COUNTRY)));
		fields.add(countryField);

		GenModelField companyField=new GenModelField( 11, Constants.COMPANY.toLowerCase(), Constants.COMPANY, Constants.ROLE.toLowerCase(), "url", true);
		companyField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COMPANY)));
		fields.add(companyField);		

		GenModel objExpected=new GenModel("Admin Inbox", fields, Arrays.asList(new CardViewAction("SUBMIT", Constants.POST,null)));

		Mockito.when(commonservice.getCAMSRoles(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(roleOptions);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString(),Mockito.anyString(), Mockito.anyString())).thenReturn(roleOptions);

		Mockito.when(property.getContextURL()).thenReturn("url");
		Mockito.when(property.getInboxGMFilteredURL()).thenReturn("url");

		GenModel objActual=adminService.getInboxFilterGenmodel();

		assertEquals(objExpected.getName(), objActual.getName());
	}
	@Test
	void getInboxInLineFilter() throws CustomException{
		List<GenModelField> fields = new ArrayList<>();
		GenModelField roleField=new GenModelField( 14, Constants.ROLE.toLowerCase(), "", "IC", true, false);
		roleField.setEditable(false);
		fields.add(roleField);

		GenModel objExpected =new GenModel("Filter By", fields,new  ArrayList<>());
		List<GenModelOption> locationOptions=Arrays.asList(new GenModelOption("BANGALORE","BANGALORE"));
		List<GenModelOption> statusOptions=Arrays.asList(new GenModelOption("IC","With IC"));

		Mockito.when(caseDetailsRepository.getLocation("BANGALORE")).thenReturn(locationOptions);
		Mockito.when(caseDetailsRepository.getStatus("IC")).thenReturn(statusOptions);


		GenModel objActual=adminService.getInboxInLineFilterGenmodel("IC","BANGALORE","INFSYS","1");

		assertEquals(objExpected.getName(), objActual.getName());

	}

	@Test
	@DisplayName("When input has empty value for role")
	void getAdminInboxGenModelFiltered1() throws CustomException {
		InboxView objExpected=new InboxView("Please select role");
		InboxFilter inboxFilter=new InboxFilter("", "In", "Infsys","");

		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("When input has empty value for country")
	void getAdminInboxGenModelFiltered2() throws CustomException {
		InboxView objExpected=new InboxView("Please select country");
		InboxFilter inboxFilter=new InboxFilter("GRB", "", "Infsys","");

		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("When input has empty value for company")
	void getAdminInboxGenModelFiltered3() throws CustomException {
		InboxView objExpected=new InboxView("Please select company");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "","");

		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is IC and sla object is present with no active request")
	void getAdminInboxGenModelFiltered4() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("IC", "In", "Infsys","");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WG", "with GRB",false,false));
		////Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(rows);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("Rajnandgaon", "Rajnandgaon")));
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 28, "IC", dateTime, dateTime, "1030816")));
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is IC and sla object is present with active request")
	void getAdminInboxGenModelFiltered5() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("IC", "In", "Infsys","");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WG", "with GRB",false,false));
		////Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(rows);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("Rajnandgaon", "Rajnandgaon")));
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		
		ELCMECtrnASHIConcernSLADetails slaObj = new ELCMECtrnASHIConcernSLADetails(1, 28, "IC", dateTime, dateTime, "1030816");
		slaObj.setFlgSLAExtensionRequest(1);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(slaObj));
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is IC and sla object is not present")
	void getAdminInboxGenModelFiltered6() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("IC", "In", "Infsys","");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WG", "with GRB",false,false));
		////Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(rows);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("Rajnandgaon", "Rajnandgaon")));
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is IC and no mapped IC location")
	void getAdminInboxGenModelFiltered7() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("IC", "In", "Infsys","");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WG", "with GRB",false,false));
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>());
//		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB, no approval cases and status is CIA")
	void getAdminInboxGenModelFiltered8() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","No");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","CIA", "with GRB",false,false));
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB, no approval cases and status is WGA")
	void getAdminInboxGenModelFiltered9() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","No");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WGA", "with GRB",false,false));
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB, no approval cases and status is DMRI")
	void getAdminInboxGenModelFiltered10() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","No");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","DMRI", "with GRB",false,false));
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB with sla and interim approval cases")
	void getAdminInboxGenModelFiltered11() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","DMRI", "with GRB",true,true));
		//Mockito.when(caseDetailsRepository.findSLAApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		//Mockito.when(caseDetailsRepository.findInterimApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
//		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB with sla approval cases")
	void getAdminInboxGenModelFiltered12() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","DMRI", "with GRB",true,false));
		//Mockito.when(caseDetailsRepository.findSLAApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		//Mockito.when(caseDetailsRepository.findInterimApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
//		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is GRB with interim approval cases")
	void getAdminInboxGenModelFiltered13() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("GRB", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","DMRI", "with GRB",false,true));
		//Mockito.when(caseDetailsRepository.findSLAApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		//Mockito.when(caseDetailsRepository.findInterimApprovalCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
//		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is ERH, with action")
	void getAdminInboxGenModelFiltered14() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("ERH", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WE", "with GRB",true,true));
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is ERH, without action")
	void getAdminInboxGenModelFiltered15() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("ERH", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WG", "with GRB",true,true));
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	@DisplayName("Inbox genmodel filtered When role is invalid")
	void getAdminInboxGenModelFiltered16() throws CustomException {
		InboxView objExpected=new InboxView("");
		InboxFilter inboxFilter=new InboxFilter("IM", "In", "Infsys","Yes");
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "","WE", "with GRB",true,true));
//		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(rows);
//		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");
		InboxView objActual= adminService.getAdminInboxGenModelFiltered(inboxFilter);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getAdminInboxInLineFiltered() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");

		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG", "with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(1234, new Date(), "796601", "Bangalore", "code of conduct", "CL,closed", new Date()));
		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndLocationAndStatus("GRB", "In","INFSYS",location, status)).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");

		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),MessageFormat.format(property.getInboxILFilterGenModelURL(), "GRB", "In", "INFSYS"));
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getAdminInboxInLineFilteredForLocation() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");

		List<String> status=new ArrayList<>();
		GMFields fields =new GMFields();
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG","with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
//		List<AdminInboxRow> rows = new ArrayList<>();

		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		List<String> role=new ArrayList<>();
		role.add("GRB");
//		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndLocationAndAssigneeLocation("GRB", "In", "INFSYS", location, location)).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");

		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),MessageFormat.format(property.getInboxILFilterGenModelURL(), "GRB", "In", "INFSYS"));
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getAdminInboxInLineFilteredForStatus() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));
		List<String> location=new ArrayList<>();
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);

		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG","with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
//		List<AdminInboxRow> rows = new ArrayList<>();

		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		List<String> role=new ArrayList<>();
		role.add("GRB");
//		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndStatusAndAssigneeLocation("GRB", fields.getCountry(), "INFSYS", status,new ArrayList<>())).thenReturn(rows);


		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"url");
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getAdminInboxInLineFiltered_IC() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");

		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
		fields.setRole("IC");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG", "with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
		List<AdminInboxRow> rows = new ArrayList<>();
		rows.add(new AdminInboxRow(1234, new Date(), "796601", "Bangalore", "code of conduct", "CL,closed", new Date()));
		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("PUNE", "PUNE")));

		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndLocationAndStatusAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),Mockito.anyList(), Mockito.anyList(), Mockito.anyList())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");

		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),MessageFormat.format(property.getInboxILFilterGenModelURL(), "GRB", "In", "INFSYS"));
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getAdminInboxInLineFilteredForLocation_IC() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");

		List<String> status=new ArrayList<>();
		GMFields fields =new GMFields();
		fields.setRole("IC");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG","with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
		//List<AdminInboxRow> rows = new ArrayList<>();

		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("PUNE", "PUNE")));

		
		List<String> role=new ArrayList<>();
		role.add("GRB");
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndLocationAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList(), Mockito.anyList())).thenReturn(rows);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");

		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),MessageFormat.format(property.getInboxILFilterGenModelURL(), "GRB", "In", "INFSYS"));
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getAdminInboxInLineFilteredForStatus_IC() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));
		List<String> location=new ArrayList<>();
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
		fields.setRole("IC");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);

		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG","with GRB",false,false);
		rowList.add(new Row(row, 2, actions));
		//List<AdminInboxRow> rows = new ArrayList<>();

		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		Mockito.when(commonservice.getCamsContextDropdown(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("PUNE", "PUNE")));
		
		List<String> role=new ArrayList<>();
		role.add("GRB");
		//Mockito.when(caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndStatusAndAssigneeLocation(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyList(),Mockito.anyList())).thenReturn(rows);


		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"url");
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getAdminInboxInLineFilter() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
		List<String> location=new ArrayList<>();
		List<String> status=new ArrayList<>();

		GMFields fields =new GMFields();
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);

		GenModel inLineFilter=new GenModel("", fieldList,actionList);
		List<Row> rowList = new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(Constants.CASE_ID, "GET", "ADIN"));
		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""));
		AdminInboxRow row =new AdminInboxRow(2, "12/03/2020", "796601", "Bangalore", "", "", "WG", "with GRB",false,false);
		rowList.add(new Row(row, 2, actions));

		Mockito.when(commonservice.convertGenModelToObject(inLineFilter, 0)).thenReturn(fields);
		Mockito.when(property.getInboxILFilterGenModelURL()).thenReturn("url");

		InboxView objExpected =new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),MessageFormat.format(property.getInboxILFilterGenModelURL(), "GRB", "In", "INFSYS"));
		InboxView objActual=adminService.getAdminInboxInLineFiltered("GRB", "IN", "INFSYS", "1", inLineFilter);

		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getCasesummary() throws CustomException {
		Date date = new Date();  
		List<CaseSummary> caseSummary =new ArrayList<>();
		caseSummary.add(new CaseSummary("Infoscion", "GRB Team", date, "self", ""));
		Optional<ELCMECTrnASHIActionDetails> actionDetails = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "with GRB", "", "self", dateTime, "DMSFileName"));	
		Mockito.when(caseDetailsRepository.findCaseSummaryByCaseId(Mockito.anyInt())).thenReturn(caseSummary);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(actionDetails);
		Mockito.when(property.getDownloadURL()).thenReturn("url");

		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("", MessageFormat.format(property.getDownloadURL(), "A", actionDetails.get().getCaseActionId(), ""), 35));

		fieldList.add(new CardViewField(Constants.DOCUMENTS, "", 88,Arrays.asList(new GenModelOption("1", "with GRB"))));
		LabelView objExpected= new LabelView("Complaint details", "guid", null);
		LabelView objActual=adminService.getCaseSummaryByCaseId(Mockito.anyInt());


		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getCaseSummary() throws CustomException {
		Date date = new Date();  

		List<CaseSummary> caseSummary =new ArrayList<>();
		caseSummary.add(new CaseSummary("Infoscion", "GRB Team", date, "self", ""));
		Optional<ELCMECTrnASHIActionDetails> actionDetails = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "with GRB", "", "self", dateTime, ""));	
		Mockito.when(caseDetailsRepository.findCaseSummaryByCaseId(Mockito.anyInt())).thenReturn(caseSummary);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(actionDetails);

		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("", MessageFormat.format("abc{0}", "A", actionDetails.get().getCaseActionId(), ""), 35));

		fieldList.add(new CardViewField(Constants.DOCUMENTS, "", 88,Arrays.asList(new GenModelOption("1", "with GRB"))));
		LabelView objExpected= new LabelView("Complaint details", "guid", null);
		LabelView objActual=adminService.getCaseSummaryByCaseId(Mockito.anyInt());


		assertEquals(objExpected.getName(), objActual.getName());

	}

	@Test
	void getCaseSummaryEmployeeDropDown1() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(2)).thenReturn(true);
		List<GenModelOption> options =new ArrayList<GenModelOption>();
		options.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT));
		List<String> actor=new ArrayList<>();
		actor.add("A");
//		Mockito.when(caseEmployeeDetailsRepository.getCaseSummaryDropDownByCaseIdAndActor(2, actor)).thenReturn(options);
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		GenModel objExpected=new GenModel("Complainant"+" Details", "", fields);

		GenModel objActual=adminService. getCaseSummaryEmployeeDropDown(2, "A");

		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getCaseSummaryEmployeeDropDown2() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(2)).thenReturn(true);
		List<GenModelOption> options =new ArrayList<GenModelOption>();
		options.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT));
		List<String> actor=new ArrayList<>();
		actor.add("A");
		Mockito.when(ashiCocomplainantsDetailsRepository.findCocomplainanats(Mockito.anyInt())).thenReturn(options);
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
	

		GenModel objExpected=new GenModel("Co-Complainant"+" Details", "", fields);

		GenModel objActual=adminService. getCaseSummaryEmployeeDropDown(2, "T");

		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void getCaseSummaryEmployeeDetails() throws CustomException {
		long date = 0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"A", "GRB"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("A",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}

	@Test
	void getCaseSummaryEmployeeDetails1() throws CustomException {
		long date = 0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"A", "GRB"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("A",1234);
		assertEquals(objExpected.getName(), objActual.getName());



	}
	@Test
	void getCaseSummaryEmployeeDetails2() throws CustomException {
//		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, "name", "T"));

		List<CaseEmployeeDetails> details = new ArrayList<>();
		long date=0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		details.add(caseDetails);
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(details);
//		Mockito.when(caseEmployeeDetailsRepository.findById(Mockito.anyInt())).thenReturn(employeeDetails);
		Mockito.when(ashiCocomplainantsDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHICocomplainantsDetails(1, 1234, 0, 0, "surajkumar.dewangan", 1)));
		Mockito.when(property.getNotifyEmployeeURL()).thenReturn("NotifyURL{0}");
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("T",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	
	@Test
	void getCaseSummaryEmployeeDetails3() throws CustomException {
		long date = 0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"R", "GRB"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		Mockito.when(property.getRemoveEmployeeURL()).thenReturn("RemoveEmployeeURL{0}");
		Mockito.when(property.getNotifyEmployeeURL()).thenReturn("NotifyURL{0}");
		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("R",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getCaseSummaryEmployeeDetails4() throws CustomException {
		long date = 0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"S", "GRB"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);


		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("S",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getCaseSummaryEmployeeDetails5() throws CustomException {
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, "Suraj","R"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		Mockito.when(property.getRemoveEmployeeURL()).thenReturn("RemoveEmployeeURL{0}");

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("R",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getCaseSummaryEmployeeDetails6() throws CustomException {
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.empty();
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,new ArrayList<>());

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("R",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void getCaseSummaryEmployeeDetails7() throws CustomException {
		Optional<ELCMECMstASHICocomplainantsDetails> obj1 = Optional.empty();
		Optional<ELCMECMstASHICocomplainantsDetails> obj2 = Optional.of(new ELCMECMstASHICocomplainantsDetails(1, 1234, 0, 0, "surajkumar.dewangan", 0));
		Optional<ELCMECMstASHICocomplainantsDetails> obj3 = Optional.of(new ELCMECMstASHICocomplainantsDetails(1, 1234, 1, 0, "surajkumar.dewangan", 1));
		Optional<ELCMECMstASHICocomplainantsDetails> obj4 = Optional.of(new ELCMECMstASHICocomplainantsDetails(1, 1234, 0, 1, "surajkumar.dewangan", 1));
		Optional<ELCMECMstASHICocomplainantsDetails> obj5 = Optional.of(new ELCMECMstASHICocomplainantsDetails(1, 1234, 1, 1, "surajkumar.dewangan", 1));
		Mockito.when(ashiCocomplainantsDetailsRepository.findById(Mockito.anyInt())).thenReturn(obj1,obj2,obj3,obj4,obj5);

		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("T",1234);
		adminService.getCaseSummaryEmployeeDetails("T",1234);
		adminService.getCaseSummaryEmployeeDetails("T",1234);
		adminService.getCaseSummaryEmployeeDetails("T",1234);
		adminService.getCaseSummaryEmployeeDetails("T",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void getCaseSummaryEmployeeDetails8() throws CustomException {
		Optional<ELCMECMstASHICaseEmployeeDetails> obj1 = Optional.empty();
		Optional<ELCMECMstASHICaseEmployeeDetails> obj2 = Optional.of(new ELCMECMstASHICaseEmployeeDetails(1, "", "R"));
		Optional<ELCMECMstASHICaseEmployeeDetails> obj3 = Optional.of(new ELCMECMstASHICaseEmployeeDetails(1, "", "R"));
		Optional<ELCMECMstASHICaseEmployeeDetails> obj4 = Optional.of(new ELCMECMstASHICaseEmployeeDetails(1, "", "T"));
		Optional<ELCMECMstASHICaseEmployeeDetails> obj5 = Optional.of(new ELCMECMstASHICaseEmployeeDetails(1, "", "A"));
		Optional<ELCMECMstASHICaseEmployeeDetails> obj6 = Optional.of(new ELCMECMstASHICaseEmployeeDetails(1, "", "R"));
		obj6.get().setFlgActive(0);
		Mockito.when(caseEmployeeDetailsRepository.findById(Mockito.anyInt())).thenReturn(obj1,obj2,obj3,obj4,obj5,obj6);

		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));

		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("A",1234);
		adminService.getCaseSummaryEmployeeDetails("A",1234);
		adminService.getCaseSummaryEmployeeDetails("R",1234);
		adminService.getCaseSummaryEmployeeDetails("R",1234);
		adminService.getCaseSummaryEmployeeDetails("R",1234);
		adminService.getCaseSummaryEmployeeDetails("R",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getCaseSummaryEmployeeDetails9() throws CustomException {
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", null, "", "Systems Engineer", "GDLYOHIS", "INFSYS", "", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"R", "GRB"));
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Confirmation Status", "Confirmation Status", 14));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		Mockito.when(property.getRemoveEmployeeURL()).thenReturn("RemoveEmployeeURL{0}");
		Mockito.when(property.getNotifyEmployeeURL()).thenReturn("NotifyURL{0}");
		LabelView objExpected=new LabelView(Constants.CASEEMPLOYEE_DETAILS,fieldList);

		LabelView objActual=adminService.getCaseSummaryEmployeeDetails("R",1234);
		assertEquals(objExpected.getName(), objActual.getName());
	}

	@Test
	void getLocationAndCategoryDetails1() throws CustomException {
		Optional<ELCMECTrnASHICaseDetails> caseDetailsObj = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetailsObj.get().setIncidentDate(dateTime);
		caseDetailsObj.get().setSelectedCity("City");
		caseDetailsObj.get().setCategoryId(1);
		caseDetailsObj.get().setPlaceOfIncident("Workplace");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetailsObj);
		
		List<GenModelOption> categoryOptions=new  ArrayList<GenModelOption>();
		categoryOptions.add(new GenModelOption(1, "Quid pro"));
		Mockito.when(concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN")).thenReturn(categoryOptions);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Incident Date", new SimpleDateFormat(Constants.DATE_FORMAT).format(dateTime), 14));
		fieldList.add(new CardViewField("Location Of Complainant", "City", 14));
		fieldList.add(new CardViewField("Category of Concern", "Quid pro", 14));
		fieldList.add(new CardViewField("Case Classification", "Workplace", 14));
		
		List<CardViewAction> actions = Arrays.asList(new CardViewAction(1, Constants.UPDATE, Constants.POST, "1234", Constants.GENERICMODELPOPUP));

		LabelView objExpected=new LabelView(Constants.CASE_DETAILS, "labelview", fieldList, actions, "2");

		LabelView objActual=adminService.getLocationAndCategoryDetails(2);
		
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		assertEquals(objExpected.getView().getActions().size(), objActual.getView().getActions().size());
		assertEquals(objExpected.getTransactionid(), objActual.getTransactionid());

	}
	
	@Test
	void getLocationAndCategoryDetails2() throws CustomException {
		Optional<ELCMECTrnASHICaseDetails> caseDetailsObj = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetailsObj.get().setIncidentDate(dateTime);
		caseDetailsObj.get().setSelectedCity("");
		caseDetailsObj.get().setCategoryId(2);
		caseDetailsObj.get().setPlaceOfIncident("");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetailsObj);
		
		List<GenModelOption> categoryOptions=new  ArrayList<GenModelOption>();
		categoryOptions.add(new GenModelOption(1, "Quid pro"));
		Mockito.when(concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN")).thenReturn(categoryOptions);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WE", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Incident Date", new SimpleDateFormat(Constants.DATE_FORMAT).format(dateTime), 14));
		fieldList.add(new CardViewField("Location Of Complainant", "City", 14));
		fieldList.add(new CardViewField("Category of Concern", "Quid pro", 14));
		fieldList.add(new CardViewField("Case Classification", "Workplace", 14));

		LabelView objExpected=new LabelView(Constants.CASE_DETAILS, "labelview", fieldList, new ArrayList<>(), "2");

		LabelView objActual=adminService.getLocationAndCategoryDetails(2);
		
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		assertEquals(objExpected.getView().getActions().size(), objActual.getView().getActions().size());
		assertEquals(objExpected.getTransactionid(), objActual.getTransactionid());

	}
	
	@Test
	void getLocationAndCategoryDetails3() throws CustomException {
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		LabelView objExpected=new LabelView(Constants.CASE_DETAILS, "labelview", new ArrayList<>(), new ArrayList<>(), "2");

		LabelView objActual=adminService.getLocationAndCategoryDetails(2);
		
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		assertEquals(objExpected.getView().getActions().size(), objActual.getView().getActions().size());
		assertEquals(objExpected.getTransactionid(), objActual.getTransactionid());

	}


	@Test
	void getLocationAndCategoryGenmodel1() throws CustomException {

		ViewCurrEmpAllDetails empDetails=new ViewCurrEmpAllDetails("divya.ramisetty", "796601", "Divya Ramisetty");

		ValidatedCaseDetails obj =new ValidatedCaseDetails(true, 1, 1, 1, 1, 1, "complainantsOther", new ArrayList<>(), "respondentsOther",  new ArrayList<>(), "country", "baseLocation", "description",  new ArrayList<>(),  new ArrayList<>(), 1, "stakeholderRole",  new ArrayList<>(),  new ArrayList<>(), 1, "placeOfIncident",  empDetails, "folder",  new ArrayList<>(), "strRespondentType", "createdApp");

		ELCMECTrnASHICaseDetails optional=new ELCMECTrnASHICaseDetails(obj, dateTime);
		optional.setSelectedCountry("In");
		optional.setSelectedCity("Banaglore");
		Optional<ELCMECTrnASHICaseDetails> caseDetailsObj = Optional.of(optional);
		Mockito.when(caseDetailsRepository.findById(2)).thenReturn(caseDetailsObj);
		
		List<GenModelOption> countryOptions=new ArrayList<GenModelOption>();
		countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1)).thenReturn(countryOptions);

		List<GenModelOption> cities = Arrays.asList(new GenModelOption("1", "Bangalore"));
		Mockito.when(ashiService.getCitiesByCountryCode(Mockito.anyString())).thenReturn(cities);

		List<GenModelOption> categoryOptions=Arrays.asList(new GenModelOption("1", "category"));
		Mockito.when(concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN")).thenReturn(categoryOptions);
		Mockito.when(property.getUpdateLocationURL()).thenReturn("url");
		List<GenModelField> fields=new ArrayList<>();
		GenModelField placeOfIncident=new GenModelField( 18, "placeOfIncident", "Case Classification", caseDetailsObj.get().getPlaceOfIncident(), "",new ArrayList<>(), true);
		fields.add(placeOfIncident);
		GenModelField complaintCategory=new GenModelField( 18, Constants.COMPLAINT_CATEGORY, "Category Of Concern", "", "",categoryOptions, true);
		fields.add(complaintCategory);


		GenModel objExpected=new GenModel("Location and Category", fields, Arrays.asList(new CardViewAction("Save", Constants.POST, property.getUpdateLocationURL())));

		GenModel objActual=adminService.getLocationAndCategoryGenmodel(2);
		assertEquals(objExpected.getName(), objActual.getName());


	}
	
	@Test
	void getLocationAndCategoryGenmodel2() throws CustomException {

		ViewCurrEmpAllDetails empDetails=new ViewCurrEmpAllDetails("divya.ramisetty", "796601", "Divya Ramisetty");

		ValidatedCaseDetails obj =new ValidatedCaseDetails(true, 1, 1, 1, 1, 1, "complainantsOther", new ArrayList<>(), "respondentsOther",  new ArrayList<>(), "country", "baseLocation", "description",  new ArrayList<>(),  new ArrayList<>(), 1, "stakeholderRole",  new ArrayList<>(),  new ArrayList<>(), 0, "",  empDetails, "folder",  new ArrayList<>(), "strRespondentType", "createdApp");

		ELCMECTrnASHICaseDetails optional=new ELCMECTrnASHICaseDetails(obj, dateTime);
		optional.setSelectedCountry("In");
		optional.setSelectedCity("Banaglore");
		Optional<ELCMECTrnASHICaseDetails> caseDetailsObj = Optional.of(optional);
		Mockito.when(caseDetailsRepository.findById(2)).thenReturn(caseDetailsObj);
		
		List<GenModelOption> countryOptions=new ArrayList<GenModelOption>();
		countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1)).thenReturn(countryOptions);

		List<GenModelOption> cities = Arrays.asList(new GenModelOption("1", "Bangalore"));
		Mockito.when(ashiService.getCitiesByCountryCode(Mockito.anyString())).thenReturn(cities);

		List<GenModelOption> categoryOptions=Arrays.asList(new GenModelOption("1", "category"));
		Mockito.when(concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN")).thenReturn(categoryOptions);
		Mockito.when(property.getUpdateLocationURL()).thenReturn("url");
		List<GenModelField> fields=new ArrayList<>();
		GenModelField placeOfIncident=new GenModelField( 18, "placeOfIncident", "Case Classification", caseDetailsObj.get().getPlaceOfIncident(), "",new ArrayList<>(), true);
		fields.add(placeOfIncident);
		GenModelField complaintCategory=new GenModelField( 18, Constants.COMPLAINT_CATEGORY, "Category Of Concern", "", "",categoryOptions, true);
		fields.add(complaintCategory);


		GenModel objExpected=new GenModel("Location and Category", fields, Arrays.asList(new CardViewAction("Save", Constants.POST, property.getUpdateLocationURL())));

		GenModel objActual=adminService.getLocationAndCategoryGenmodel(2);
		assertEquals(objExpected.getName(), objActual.getName());


	}
	
	@Test
	void updateLocationAndCategoryDetailsCaseNotRegistered() throws CustomException {
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(new GMFields());
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected=new Response(Message.CASENOTREGISTERED, "No case has registered with this id.");
		
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());


	}
	@Test
	void updateLocationAndCategoryDetails1() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setCountry("");
		caseDetails.setIncidentDate("07-Nov-1992");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));

		Response objExpected=new Response(Constants.FAILURE, "Please select country.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());


	}
	@Test
	void updateLocationAndCategoryDetails2() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setCountry("In");
		caseDetails.setBaseLocation("");
		caseDetails.setIncidentDate("07-Nov-1992");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));

		Response objExpected=new Response(Constants.FAILURE, "Please select base location.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void updateLocationAndCategoryDetails3() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setCountry("In");
		caseDetails.setBaseLocation("Bangalore");
		caseDetails.setComplaintCategory(0);
		caseDetails.setIncidentDate("07-Nov-1992");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));

		Response objExpected=new Response(Constants.FAILURE, "Please select valid complaint category.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void updateLocationAndCategoryDetails4() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setCountry("In");
		caseDetails.setBaseLocation("Bangalore");
		caseDetails.setComplaintCategory(1);
		caseDetails.setPlaceOfIncident("");
		caseDetails.setIncidentDate("07-Nov-1992");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));

		Response objExpected=new Response(Constants.FAILURE, "Please select case classification.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void updateLocationAndCategoryDetails5() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setIncidentDate("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));

		Response objExpected=new Response(Constants.FAILURE, "Please provide incident date.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void updateLocationAndCategoryDetails6() throws CustomException {
		GMFields caseDetails =new GMFields();
		caseDetails.setCountry("In");
		caseDetails.setBaseLocation("Bangalore");
		caseDetails.setComplaintCategory(1);
		caseDetails.setPlaceOfIncident("BTM");
		caseDetails.setIncidentDate("07-Nov-1992");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(new ELCMECTrnASHICaseDetails());

		Response objExpected=new Response(Message.SUCCESS, "Successfully updated.");
		Response objActual=adminService.updateLocationAndCategoryDetails(new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void addPreliminaryDetails() throws CustomException{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		List<GenModelOption> complainants=new ArrayList<>();
		complainants.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT, true));

		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(complainants);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		GenModel objExpected= new GenModel("Add Discussion Details", fields, actions);
		GenModel objActual=adminService.addPreliminaryDiscussionDetails(2);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void addPreliminaryDiscussionsDetails() throws CustomException{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		List<GenModelOption> complainants=new ArrayList<>();
		complainants.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT, true));

//		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(complainants);
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		GenModel objExpected= new GenModel("", fields, new ArrayList<>());
		GenModel objActual=adminService.addPreliminaryDiscussionDetails(2);
		assertEquals(objExpected.getName(), objActual.getName());

	}

	@Test
	void addPreliminaryDetailsDiscussion() throws CustomException{
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		GMFields caseDetails =new GMFields();
		caseDetails.setDiscussedOn("");
		caseDetails.setDiscussedWith("divya.ramisetty");
		caseDetails.setDiscussionSummary("meeting updated");
		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		String dmsFiles="Invalid file.";
//		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName(dmsFiles);
		obj.setUpdatedBy("796601");
//		Mockito.when(preliminaryDiscussionDetailsRepository.save(Mockito.any(ELCMECMstASHIPreliminaryDiscussionDetails.class))).thenReturn(obj);   
		Response objExpected=new Response("Please provide when discussion was happened.");

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void addPreliminaryDiscusionDetails1() throws CustomException{
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		GMFields caseDetails =new GMFields();
		caseDetails.setDiscussedOn("12/05/2020");
		caseDetails.setDiscussedWith("");
		caseDetails.setDiscussionSummary("meeting updated");
		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		String dmsFiles="Invalid file.";

		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName(dmsFiles);
		obj.setUpdatedBy("796601");

		Response objExpected=new Response("Please provide with whom discussion was happened.");

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void addPreliminaryDiscusionDetails2() throws CustomException{
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		GMFields caseDetails =new GMFields();
		caseDetails.setDiscussedOn("12/05/2020");
		caseDetails.setDiscussedWith("divya.ramisetty");
		caseDetails.setDiscussionSummary("");
		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		String dmsFiles="Invalid file.";

		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName(dmsFiles);
		obj.setUpdatedBy("796601");

		Response objExpected=new Response("Please provide summary of the discussion.");

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void addPreliminaryDiscusionDetails3() throws CustomException{
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		List<DocumentData> documents=new ArrayList<DocumentData>();
		documents.add(new DocumentData("filename", "base64file"));
		GMFields caseDetails =new GMFields();
		caseDetails.setDiscussedOn("12/05/2020");
		caseDetails.setDiscussedWith("divya.ramisetty");
		caseDetails.setDiscussionSummary("meeting updated");
		caseDetails.setDocuments(documents);


		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		String dmsFiles="Invalid file.";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIPreliminaryDiscussionFolder()).thenReturn("url");
		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName(dmsFiles);
		obj.setUpdatedBy("796601");
		Response objExpected=new Response(dmsFiles);

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void addPreliminaryDiscusionDetails4() throws CustomException{
		List<DocumentData> documents=new ArrayList<DocumentData>();
		documents.add(new DocumentData("filename", "base64file"));
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST, ""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		GMFields caseDetails =new GMFields();
		caseDetails.setDiscussedOn("12-DEC-2020");
		caseDetails.setDiscussedWith("divya.ramisetty");
		caseDetails.setDiscussionSummary("meeting updated");
		caseDetails.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		String dmsFiles="documents";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIPreliminaryDiscussionFolder()).thenReturn("url");
		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails(caseDetails, "796601", "GRB", dmsFiles);
		Mockito.when(preliminaryDiscussionDetailsRepository.save(Mockito.any(ELCMECMstASHIPreliminaryDiscussionDetails.class))).thenReturn(obj);   
		Response objExpected=new Response(Constants.SUCCESSHIDEFORM, "Successfully Added Discussion Details");

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	@Test
	void addPreliminaryDiscusionDetails6() throws CustomException{
		List<DocumentData> documents=new ArrayList<DocumentData>();
		documents.add(new DocumentData("filename", "base64file"));
		List<GenModelField> fields = new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		List<CardViewAction> actions = Arrays.asList(new CardViewAction("Add", Constants.POST,""), new CardViewAction(Constants.CANCEL, "", ""));
		GenModel genmodel= new GenModel("Add Discussion Details", fields, actions);
		GMFields caseDetails =new GMFields();
		caseDetails.setCaseid(45);
		caseDetails.setDiscussedOn("12-DEC-2020 12:10");
		caseDetails.setDiscussedWith("divya.ramisetty");
		caseDetails.setDiscussionSummary("meeting updated");
		caseDetails.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(genmodel, 0)).thenReturn(caseDetails);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		String dmsFiles="documents";

		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName(dmsFiles);
		obj.setUpdatedBy("796601");

		Response objExpected=new Response(Message.CASENOTREGISTERED);

		Response objActual=adminService.addPreliminaryDiscusionDetails(genmodel);
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void getPreliminaryDiscussionsForComplainant() throws CustomException{
		List<String> documents=new ArrayList<String>();
		documents.add("document1");
		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails=new ArrayList<>();
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(1234, "12/05/2020", "pavan kumar", "", "", documents));
		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		Mockito.when(property.getDownloadURL()).thenReturn("url");
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WE", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		List<Card> discussions = new ArrayList<>();
		List<CardViewField> fields = new ArrayList<>();
		fields.add(new CardViewField("Discussed On", "12/05/2020", 14));
		discussions.add(new Card("Discussion With Complainant", fields));
		CardView objExpected= new CardView("", discussions);
		CardView objActual=adminService.getPreliminaryDiscussions(1, 1);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getPreliminaryDiscussionsPositiveTestCase() throws CustomException{
		List<String> documents=new ArrayList<String>();
		documents.add("Mango");   
		documents.add("Apple");  
		documents.add("Banana");
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails= new ArrayList<>();
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(1,"12/03/2020 14:52","shashank","xyz","pqr",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(2,"12/04/2020 14:52","shobhit","abc","def",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(3,"12/05/2020 14:52","rajeev","xyz","pqr",documents));
		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		String addPreliminaryDiscussionMID="";
		String viewAllPreliminaryDiscussionMID="";
		Mockito.when(commonservice.getUIModuleId("VAPD")).thenReturn(viewAllPreliminaryDiscussionMID);
		Mockito.when(commonservice.getUIModuleId("ADPD")).thenReturn(addPreliminaryDiscussionMID);
		Mockito.when(property.getDownloadURL()).thenReturn("abc{0}{1}{3}");
//		Mockito.when(property.getDownloadAllURL()).thenReturn("abc{0}{1}{3}");
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		CardView objExpected= new CardView("",discussions,"Discussion With complainant",123,actions);
		CardView objActual=adminService.getPreliminaryDiscussions(123,1);
		assertEquals(objExpected.getName(), objActual.getName()); 
	}
	
	@Test
	void getPreliminaryDiscussionsPositiveTestCase1() throws CustomException{
		List<String> documents=new ArrayList<String>();
		documents.add("Mango");   
		documents.add("Apple");  
		documents.add("Banana");
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails= new ArrayList<>();
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(1,"12/03/2020 14:52","shashank","xyz","pqr",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(2,"12/04/2020 14:52","shobhit","abc","def",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(3,"12/05/2020 14:52","rajeev","xyz","pqr",documents));
		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		String addPreliminaryDiscussionMID="";
		String viewAllPreliminaryDiscussionMID="";
		Mockito.when(commonservice.getUIModuleId("VAPD")).thenReturn(viewAllPreliminaryDiscussionMID);
		Mockito.when(commonservice.getUIModuleId("ADPD")).thenReturn(addPreliminaryDiscussionMID);
		Mockito.when(property.getDownloadURL()).thenReturn("abc{0}{1}{3}");
//		Mockito.when(property.getDownloadAllURL()).thenReturn("abc{0}{1}{3}");

		CardView objExpected= new CardView("",discussions,"Discussion With complainant",123,actions);
		CardView objActual=adminService.getPreliminaryDiscussions(123,0);
		assertEquals(objExpected.getName(), objActual.getName()); 
	}
	
	@Test
	void getPreliminaryDiscussionsPositiveTestCase2() throws CustomException{
		List<String> documents=new ArrayList<String>();
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails= new ArrayList<>();
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(1,"12/03/2020 14:52","shashank","xyz","pqr",documents));

		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		String addPreliminaryDiscussionMID="";
		String viewAllPreliminaryDiscussionMID="";
		Mockito.when(commonservice.getUIModuleId("VAPD")).thenReturn(viewAllPreliminaryDiscussionMID);
		Mockito.when(commonservice.getUIModuleId("ADPD")).thenReturn(addPreliminaryDiscussionMID);
		CardView objExpected= new CardView("",discussions,"Discussion With complainant",123,actions);
		CardView objActual=adminService.getPreliminaryDiscussions(123,0);
		assertEquals(objExpected.getName(), objActual.getName());
	}   
	
	@Test
	void getPreliminaryDiscussionsPositiveTestCase3() throws CustomException{
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails=new ArrayList<>();

		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		String addPreliminaryDiscussionMID="";
		String viewAllPreliminaryDiscussionMID="";
		Mockito.when(commonservice.getUIModuleId("VAPD")).thenReturn(viewAllPreliminaryDiscussionMID);
		Mockito.when(commonservice.getUIModuleId("ADPD")).thenReturn(addPreliminaryDiscussionMID);
		CardView objExpected= new CardView("",discussions,"Discussion With complainant",123,actions);
		CardView objActual=adminService.getPreliminaryDiscussions(123,0);
		assertEquals(objExpected.getName(), objActual.getName());
	} 
	
	@Test
	void getPreliminaryDiscussionsPositiveTestCase4() throws CustomException{
		List<String> documents=new ArrayList<String>();
		documents.add("Mango");   
		documents.add("Apple");  
		documents.add("Banana");
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails= new ArrayList<>();
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(1,"12/03/2020 14:52","shashank","xyz","pqr",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(2,"12/04/2020 14:52","shobhit","abc","def",documents));
		preliminaryDiscussionDetails.add(new PreliminaryDiscussionDetails(3,"12/05/2020 14:52","rajeev","xyz","pqr",documents));
		Mockito.when(preliminaryDiscussionDetailsRepository.findByIntCaseID(Mockito.anyInt())).thenReturn(preliminaryDiscussionDetails);
		String addPreliminaryDiscussionMID="";
		String viewAllPreliminaryDiscussionMID="";
		Mockito.when(commonservice.getUIModuleId("VAPD")).thenReturn(viewAllPreliminaryDiscussionMID);
		Mockito.when(commonservice.getUIModuleId("ADPD")).thenReturn(addPreliminaryDiscussionMID);
		Mockito.when(property.getDownloadURL()).thenReturn("abc{0}{1}{3}");
//		Mockito.when(property.getDownloadAllURL()).thenReturn("abc{0}{1}{3}");
 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		CardView objExpected= new CardView("",discussions,"Discussion With complainant",123,actions);
		CardView objActual=adminService.getPreliminaryDiscussions(123,1);
		assertEquals(objExpected.getName(), objActual.getName()); 
	}
	
	@Test
	void getInboxActionFormsForSLAPositive1() throws CustomException {
		List<GenModelField> sLAFieldList = new ArrayList<>();

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		sLAFieldList.add(comments);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("1", "Others")));
		
		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Mockito.when(property.getSlaExtensionActionURL()).thenReturn("abc{0}{1}{3}");
		
		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(Constants.SUBMIT, "POST", ""));
		actions.add(new CardViewAction(Constants.CANCEL, "POST", ""));
		
		GenModel objExpected=new GenModel("SLA Extension", sLAFieldList, actions);
		
		GenModel objActual=adminService.getInboxActionForms(1,"SLA");

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getInboxActionFormsForSLAPositive2() throws CustomException {
		List<GenModelField> sLAFieldList = new ArrayList<>();

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		sLAFieldList.add(comments);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("1", "Others")));
		
		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(1);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Optional<ELCMECtrnASHISLAAuditTrial> slaExtensionDetails = Optional.of(new ELCMECtrnASHISLAAuditTrial(1, 1, 1, 30, "remarks", "1030816", dateTime, "IC", 1, dateTime, "", "WI", "reason", ""));
		Mockito.when(slaAuditTrialRepository.findBySlaIdAndStatus(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaExtensionDetails);
		
		Mockito.when(property.getSlaExtensionActionURL()).thenReturn("abc{0}{1}{3}");
		
		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(Constants.SUBMIT, "POST", ""));
		actions.add(new CardViewAction(Constants.CANCEL, "POST", ""));
		
		GenModel objExpected=new GenModel("SLA Extension", sLAFieldList, actions);
		
		GenModel objActual=adminService.getInboxActionForms(1,"SLA");

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getInboxactionFormForInterimRelief() throws CustomException {
		List<GenModelField> interimReliefList = new ArrayList<>();

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		interimReliefList.add(comments);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		interimRelief.get().setReliefs("WFH,Leave");
		interimRelief.get().setRemarks("remarks");
		Mockito.when(interimReliefRepository.findByCaseIdAndFlgReliefAndFlgActionTaken(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(interimRelief);

		Mockito.when(property.getInterimReliefActionURL()).thenReturn("abc{0}{1}{3}");
		
		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(Constants.SUBMIT, "POST", ""));
		actions.add(new CardViewAction(Constants.CANCEL, "POST", ""));
		GenModel objExpected=new GenModel("Interim Relief", interimReliefList, actions);
		GenModel objActual=adminService.getInboxActionForms(2,"IRA");

		assertEquals(objExpected.getName(), objActual.getName());


	}
	
	@Test
	void getInboxActionForConciliationInitiation() throws CustomException {
		List<GenModelField> conciliationReportList = new ArrayList<>();

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		conciliationReportList.add(comments);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(property.getInitiateConciliationURL()).thenReturn("url");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "CIA", "comments", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(Constants.SUBMIT, "POST", ""));
		actions.add(new CardViewAction(Constants.CANCEL, "POST", ""));
		GenModel objExpected =new GenModel("", conciliationReportList, actions);
		GenModel objActual=adminService.getInboxActionForms(3,"CIA");

		assertEquals(objExpected.getName(), objActual.getName());


	}
	
	@Test
	void getInboxActionForConciliationReportApproval() throws CustomException {
		List<GenModelField> conciliationReportList = new ArrayList<>();

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		conciliationReportList.add(comments);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(property.getInitiateConciliationURL()).thenReturn("url");
		Mockito.when(property.getDownloadURL()).thenReturn("url");
		
		Optional<ELCMECTrnASHIConciliationReportDetails> report = Optional.of(new ELCMECTrnASHIConciliationReportDetails());
		report.get().setAgreementDocs("doc1,doc2");
		Mockito.when(conciliationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);

		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(Constants.SUBMIT, "POST", ""));
		actions.add(new CardViewAction(Constants.CANCEL, "POST", ""));
		GenModel objExpected =new GenModel("", conciliationReportList, actions);
		GenModel objActual=adminService.getInboxActionForms(3,"CRA");

		assertEquals(objExpected.getName(), objActual.getName());


	}
	
	@Test
	void getInboxActionFormsNegative() throws CustomException {
		GenModel objExpected=new GenModel();
		GenModel objActual=adminService.getInboxActionForms(1,"abc");

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void takeActionOnInterimReliefNegative1() throws CustomException {
		GMFields fields = new GMFields();
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected=new Response(Message.CASENOTREGISTERED);
		Response objActual=adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void takeActionOnInterimReliefNegative2() throws CustomException {
		GMFields fields = new GMFields();
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected=new Response("Kindly provide comments");
		Response objActual=adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void takeActionOnInterimReliefNegative3() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected=new Response("Invalid action.");
		Response objActual=adminService.takeActionOnInterimRelief("invalid action", new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void takeActionOnInterimReliefNegative4() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected=new Response("Interim relief not submitted yet");
		Response objActual=adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void takeActionOnInterimReliefNegative5() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		interimRelief.get().setFlgActionTaken(1);
		interimRelief.get().setApprovalStatus(Constants.REJECTED);
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);
		
		Response objExpected=new Response("Already " + Constants.REJECTED);
		Response objActual=adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void takeActionOnInterimReliefNegative6() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		interimRelief.get().setFlgActionTaken(0);
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);
		
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel()),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));
	}
	
	@Test
	void takeActionOnInterimReliefNegative7() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		interimRelief.get().setFlgActionTaken(0);
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);
		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = Optional.of(new ELCMECTrnASHIActionDetails());
		assigneeDetails.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(assigneeDetails);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("grbids","icids");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel()),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
	}
	
	@Test
	void takeActionOnInterimReliefPositive() throws CustomException {
		GMFields fields = new GMFields();
		fields.setComments("comments");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		interimRelief.get().setFlgActionTaken(0);
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);
		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = Optional.of(new ELCMECTrnASHIActionDetails());
		assigneeDetails.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(assigneeDetails);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("grbids","icids");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected=new Response(Constants.SUCCESSHIDEFORM, Message.SUCCESSFULLY_NEW + Constants.APPROVED);
		Response objActual=adminService.takeActionOnInterimRelief(Constants.APPROVED, new GenModel());

		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void removeEmployee() throws CustomException{
		long date = 0;
		CaseEmployeeDetails caseDetails=new CaseEmployeeDetails("796601","divya.ramisetty","Divya Ramisetty", "GDLYOH", "", "", new java.sql.Date(date), "", "Systems Engineer", "GDLYOHIS", "INFSYS", "Hyderabad", "", "", "Sruthy Puthillath");
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, caseDetails,"A", "GRB"));
		ELCMECMstASHICaseEmployeeDetails updatedEmployeeDetails=employeeDetails.get();
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		Mockito.when(caseEmployeeDetailsRepository.save(updatedEmployeeDetails)).thenReturn(updatedEmployeeDetails);
		caseEmployeeDetailsRepository.save(updatedEmployeeDetails);

		Response objExpected=new Response(Message.SUCCESS, "Successfully removed ");

		Response objActual=adminService.removeEmployee(1234);
		assertEquals(objExpected.getType(), objActual.getType());

	}
	
	@Test
	void removeEmployeeFlgValid() throws CustomException{
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = Optional.of(new ELCMECMstASHICaseEmployeeDetails(2, "name","A"));
		ELCMECMstASHICaseEmployeeDetails updatedEmployeeDetails=employeeDetails.get();
		Mockito.when(caseEmployeeDetailsRepository.findById(1234)).thenReturn(employeeDetails);
		Mockito.when(caseEmployeeDetailsRepository.save(updatedEmployeeDetails)).thenReturn(updatedEmployeeDetails);
		caseEmployeeDetailsRepository.save(updatedEmployeeDetails);

		Response objExpected=new Response(Message.SUCCESS, "Successfully removed ");

		Response objActual=adminService.removeEmployee(1234);
		assertEquals(objExpected.getType(), objActual.getType());

	}
	
	@Test
	void removeEmployeeNegative() throws CustomException{

		Response objExpected=new Response("Details not found.");

		Response objActual=adminService.removeEmployee(1234);
		assertEquals(objExpected.getType(), objActual.getType());

	}
	
	@Test
	void addEmployeeGenModelNegative() throws CustomException {
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));


		GenModel objExpected= new GenModel("", fieldList, actionList);

		GenModel objActual=adminService.addEmployeeGenModel(1,"B");
		assertEquals(objExpected.getName(), objActual.getName());


	}
	@Test
	void addEmployeeGenModel() throws CustomException {

		Mockito.when(property.getEmployeeSearchURL()).thenReturn("url");
		Mockito.when(property.getAddEmployeeURL()).thenReturn("url");
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));


		GenModel objExpected= new GenModel("Add Co-Complainant", fieldList, actionList);

		GenModel objActual=adminService.addEmployeeGenModel(1,"A");
		assertEquals(objExpected.getName(), objActual.getName());
	}
	@Test
	void addEmployeeGenModelForRespondent() throws CustomException {

		Mockito.when(property.getEmployeeSearchURL()).thenReturn("url");
		Mockito.when(property.getAddEmployeeURL()).thenReturn("url");
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));


		GenModel objExpected= new GenModel("Add Respondent", fieldList, actionList);

		GenModel objActual=adminService.addEmployeeGenModel(1,"R");
		assertEquals(objExpected.getName(), objActual.getName());
	}
	@Test
	void addEmployeeGenModelForWitness() throws CustomException {

		Mockito.when(property.getEmployeeSearchURL()).thenReturn("url");
		Mockito.when(property.getAddEmployeeURL()).thenReturn("url");
		List<GenModelField> fieldList=new ArrayList<>();
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fieldList.add(caseidField);
		List<CardViewAction> actionList=new ArrayList<>();
		actionList.add(new CardViewAction(Constants.CANCEL, "", ""));


		GenModel objExpected= new GenModel("Add Witness", fieldList, actionList);

		GenModel objActual=adminService.addEmployeeGenModel(1,"W");
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void addEmployeePositiveTestCase1() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setRespondentsInfy("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		Optional<ELCMECMstASHICaseEmployeeDetails> details = Optional.of(new ELCMECMstASHICaseEmployeeDetails());
		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActor(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(details);

		Response objExpectedResponse=new Response(Constants.SUCCESSHIDEFORM, "Successfully added " + Constants.RESPONDENT);

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	
	@Test
	void addEmployeePositiveTestCase2() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setWitnesses("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		List<ELCMECMstASHICaseEmployeeDetails> duplicateResponse = Arrays.asList(new ELCMECMstASHICaseEmployeeDetails());
		duplicateResponse.get(0).setActor("W");
		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList())).thenReturn(duplicateResponse);
		
		Response objExpectedResponse=new Response(Constants.FAILURE,  "Id surajkumar.dewangan has already been added as Witness");

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	
	@Test
	void addEmployeePositiveTestCase3() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		Response objExpectedResponse=new Response(Constants.FAILURE,  "Invalid input");

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	
	@Test
	void addEmployeePositiveTestCase4() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setWitnesses("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(false, "Invalid employee");
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		Response objExpectedResponse=new Response(Constants.FAILURE,  "Invalid employee");

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	
	@Test
	void addEmployeePositiveTestCase5() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setRespondentsInfy("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		Optional<ELCMECMstASHICaseEmployeeDetails> details = Optional.empty();
		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActor(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(details);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(Arrays.asList(new CaseEmployeeDetails()));
		Response objExpectedResponse=new Response(Constants.SUCCESSHIDEFORM, "Successfully added " + Constants.RESPONDENT);

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	
	@Test
	void addEmployeePositiveTestCase6() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setRespondentsInfy("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		Optional<ELCMECMstASHICaseEmployeeDetails> details = Optional.empty();
		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActor(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(details);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(Arrays.asList());
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.addEmployee(new GenModel()),
				"Details for id surajkumar.dewangan" + Constants.UNAVAILABLE
				);

		assertTrue(thrown.getMessage().contains("Details for id surajkumar.dewangan" + Constants.UNAVAILABLE));


	}
	
	@Test
	void addEmployeePositiveTestCase7() throws CustomException {
		GMFields caseDetails =new GMFields(); 
		caseDetails.setCocomplainants("1030816");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(GenModel.class), Mockito.anyInt())).thenReturn(caseDetails); 
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);

		Mockito.when(caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		Response objExpectedResponse=new Response(Constants.SUCCESSHIDEFORM, "Successfully added Co-Complainant");

		Response objActual=adminService.addEmployee(new GenModel());

		assertEquals(objExpectedResponse.getType(), objActual.getType());
		assertEquals(objExpectedResponse.getContent(), objActual.getContent());


	}
	@Test
	void viewPreviousComplaintsPositive() throws CustomException {

		List<CardViewAction> actions=Arrays.asList(new CardViewAction("View All Details", "4123", "caseid=2"));
		List<CardViewField>  fields=Arrays.asList(new CardViewField("Case No", "2",14 , new ArrayList<>()));

		Card cards=new Card("", "","2", false, actions, new ArrayList<>(), fields, "");
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(cards);

		java.sql.Date joinedDate = null;
		Optional<HRISMstEmployee> objExpected =Optional.of(new HRISMstEmployee("796601", "divya", "empBandCode", joinedDate, "company", "Previous cases", "currentRoleCapability")); 

		Mockito.when(hrisMstEmployeeRepository.findById("796601")).thenReturn(objExpected);

		CardView objActual=adminService.viewPreviousComplaints("A","796601");
		assertEquals(objExpected.get().getConfirmedStatus(), objActual.getName());

	}
	@Test
	void viewPreviousComplaintsNegative() throws CustomException {

		List<CardViewAction> actions=Arrays.asList(new CardViewAction("View All Details", "4123", "caseid=2"));
		List<CardViewField>  fields=Arrays.asList(new CardViewField("Case No", "2",14 , new ArrayList<>()));

		Card cards=new Card("", "","2", false, actions, new ArrayList<>(), fields, "");
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(cards);

		CardView objExpected=new CardView("Previous cases", "",cardList); 

		Mockito.when(caseDetailsRepository.findPreviousCaseByActorAndEmpno("1030816","A")).thenReturn(cardList);
		CardView objActual=adminService.viewPreviousComplaints("A","1030816");
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void getActionsTestCase1() throws Exception{
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		List<ELCMECMstReachWorkFlow> workflows = Arrays.asList(new ELCMECMstReachWorkFlow());
		workflows.get(0).setActionLabel("actionLabel");
		workflows.get(0).setUiModuleId(1234);
		workflows.get(0).setType("popup");
		Mockito.when(workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveOrderByActionLabelAsc(2, actionObj.get().getStatus().trim(), 1)).thenReturn(workflows);
		
		GenModel objExpected = new GenModel("", new ArrayList<>(), Arrays.asList(new CardViewAction()));
		GenModel objActual = adminService.getActions(1234);
		
		assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test
	void getActionsTestCase2() throws Exception{
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		List<ELCMECMstReachWorkFlow> workflows = Arrays.asList(new ELCMECMstReachWorkFlow(), new ELCMECMstReachWorkFlow());
		workflows.get(0).setActionLabel("");
		workflows.get(1).setActionLabel(null);
		Mockito.when(workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveOrderByActionLabelAsc(2, actionObj.get().getStatus().trim(), 1)).thenReturn(workflows);
		
		GenModel objExpected = new GenModel("", new ArrayList<>(), Arrays.asList());
		GenModel objActual = adminService.getActions(1234);
		
		assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test
	void getActionsTestCase3() throws Exception{
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.empty(); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		GenModel objExpected = new GenModel("", new ArrayList<>(), Arrays.asList());
		GenModel objActual = adminService.getActions(1234);
		
		assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test 
	void getAccordionsTestCase() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WI", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief= Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailsGenmodelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getInterimReliefLabelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getInvestigationTypeGenmodelURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(4, objActual.getAccordions().size());
	}

	@Test 
	void getAccordionsTestCase1() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WI", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailsGenmodelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getInterimReliefGenmodelURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getInvestigationTypeGenmodelURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(4, objActual.getAccordions().size());
	}

	@Test 
	void getAccordionsTestCase2() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "CIA", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief= Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getInterimReliefLabelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getConciliationGenmodelURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(4, objActual.getAccordions().size());
	}

	@Test 
	void getAccordionsTestCase3() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WIF", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief= Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailsGenmodelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getInterimReliefLabelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getIssueSummonGenmodelURL()).thenReturn("abc{0}");
		Mockito.when(property.getSummonsCardURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(4, objActual.getAccordions().size());
	}
	@Test 
	void getAccordionsTestCase4() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WCC", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.FORMAL);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief= Optional.of(new ELCMECTrnASHIInterimReliefDetails());
		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(interimRelief);

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getInterimReliefLabelURL()).thenReturn("abc{0}"); 
		Mockito.when(property.getSummonsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getCommentLabelURL()).thenReturn("abc{0}");
		Mockito.when(property.getFormalReportChecklistGenModelURL()).thenReturn("abc{0}");
		Mockito.when(property.getFindingGenModelURL()).thenReturn("abc{0}");
		Mockito.when(property.getRecommendationCardsURL()).thenReturn("abc{0}");
		Mockito.when(property.getFormalReportDetailsURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(6, objActual.getAccordions().size());
	}
	@Test 
	void getAccordionsTestCase5() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WEC", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		Mockito.when(interimReliefRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());

		Mockito.when(property.getInputFromComplainantsCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getFirstContactMailCardURL()).thenReturn("abc{0}");
		Mockito.when(property.getConciliationLabelViewURL()).thenReturn("abc{0}");
		Mockito.when(property.getCommentLabelURL()).thenReturn("abc{0}");

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(3, objActual.getAccordions().size());
	}

	@Test 
	void getAccordionsTestCase6() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "ABC", "", "self", dateTime, "DMSFileName")); 
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);

		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(0, objActual.getAccordions().size());
	}

	@Test 
	void getAccordionsTestCase7() throws Exception{
		List<Accordion> accordions = new ArrayList<>();
		accordions.add(new Accordion("",new ArrayList<>()));

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		AccordionView objActual = adminService.getAccordions(123);
		assertEquals(0, objActual.getAccordions().size());
	}
	
	@Test
	void updateCaseStatusGenmodelPositiveTestCase()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String actionLabel = "";
		String message = "";
		String actions = "CLN";
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		GenModelField messagefield=new GenModelField( 14, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);
		Mockito.when(property.getUpdateCaseStatusURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("", fields, Arrays.asList(new CardViewAction(1, "No", "", "", ""), new CardViewAction(1, actionLabel, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(1), actions), Constants.SERVICEURL)));
		GenModel objActual = adminService.updateCaseStatusGenmodel(1,actions);
		assertEquals(objExpected.getName(), objActual.getName());

	}

	@Test
	void updateCaseStatusGenmodelPositiveTestCase1()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String actionLabel = "";
		String message = "";
		String actions = "DM";
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		GenModelField messagefield=new GenModelField( 14, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);
		Mockito.when(property.getUpdateCaseStatusURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("", fields, Arrays.asList(new CardViewAction(1, "No", "", "", ""), new CardViewAction(1, actionLabel, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(1), actions), Constants.SERVICEURL)));
		GenModel objActual = adminService.updateCaseStatusGenmodel(1,actions);
		assertEquals(objExpected.getName(), objActual.getName());	
	}

	@Test
	void updateCaseStatusGenmodelPositiveTestCase2()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String actionLabel = "";
		String message = "";
		String actions = "OI";
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		GenModelField messagefield=new GenModelField( 14, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);
		Mockito.when(property.getUpdateCaseStatusURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("", fields, Arrays.asList(new CardViewAction(1, "No", "", "", ""), new CardViewAction(1, actionLabel, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(1), actions), Constants.SERVICEURL)));
		GenModel objActual = adminService.updateCaseStatusGenmodel(1,actions);
		assertEquals(objExpected.getName(), objActual.getName());	
	}

	@Test
	void updateCaseStatusGenmodelPositiveTestCase3()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String actionLabel = "";
		String message = "";
		String actions = "CLN";
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		GenModelField messagefield=new GenModelField( 14, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);
		Mockito.when(property.getUpdateCaseStatusURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("", fields, Arrays.asList(new CardViewAction(1, "No", "", "", ""), new CardViewAction(1, actionLabel, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(1), actions), Constants.SERVICEURL)));
		GenModel objActual = adminService.updateCaseStatusGenmodel(1,actions);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	void updateCaseStatusGenmodelPositiveTestCase4()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String actionLabel = "";
		String message = "";
		String actions = "abc";
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		GenModelField messagefield=new GenModelField( 14, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);
		Mockito.when(property.getUpdateCaseStatusURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("", fields, Arrays.asList(new CardViewAction(1, "No", "", "", ""), new CardViewAction(1, actionLabel, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(1), actions), Constants.SERVICEURL)));
		GenModel objActual = adminService.updateCaseStatusGenmodel(1,actions);
		assertEquals(objExpected.getName(), objActual.getName());	
	}

	@Test
	void updateCaseStatusTestCase1()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(new GMFields(), fields);

		Response objExpected = new Response("Please provide comments");
		Response objActual1 = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		Response objActual2 = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		
		assertEquals(objExpected.getType(), objActual1.getType());
		assertEquals(objExpected.getContent(), objActual1.getContent());
		assertEquals(objExpected.getType(), objActual2.getType());
		assertEquals(objExpected.getContent(), objActual2.getContent());
	}

	@SuppressWarnings("unchecked")
	@Test
	void updateCaseStatusTestCase2()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHIActionDetails> actionObj1 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "CLN", "", "self", dateTime, "DMSFileName"));
		Optional<ELCMECTrnASHIActionDetails> actionObj2 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "DM", "", "self", dateTime, "DMSFileName"));
		Optional<ELCMECTrnASHIActionDetails> actionObj3 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "OI", "", "self", dateTime, "DMSFileName"));

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj1, actionObj2, actionObj3);

		Response objExpected1 = new Response("Unable to take action. Current case status is "+actionObj1.get().getStatusDesc());
		Response objExpected2 = new Response("Unable to take action. Current case status is "+actionObj2.get().getStatusDesc());
		Response objExpected3 = new Response("Unable to take action. Current case status is "+actionObj3.get().getStatusDesc());
		
		Response objActual1 = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		Response objActual2 = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		Response objActual3 = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		
		assertEquals(objExpected1.getType(), objActual1.getType());
		assertEquals(objExpected1.getContent(), objActual1.getContent());
		assertEquals(objExpected2.getType(), objActual2.getType());
		assertEquals(objExpected2.getContent(), objActual2.getContent());
		assertEquals(objExpected3.getType(), objActual3.getType());
		assertEquals(objExpected3.getContent(), objActual3.getContent());
	}
	
	@Test
	void updateCaseStatusTestCase3()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());

		String dmsFiles="";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");

		Response objExpected = new Response(Message.CASENOTREGISTERED);
		Response objActual = adminService.updateCaseStatus(1,"","",new GenModel());
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void updateCaseStatusTestCase4()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "WG", "", "self", dateTime, "DMSFileName"));
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		String dmsFiles="Invalid file. ";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");

		Response objExpected = new Response(dmsFiles);
		Response objActual = adminService.updateCaseStatus(1,"DM","",new GenModel());
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void updateCaseStatusTestCase5()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Optional<ELCMECTrnASHICaseDetails> actionObj = Optional.of(new ELCMECTrnASHICaseDetails());
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(actionObj);

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		String dmsFiles="doc1.pdf";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		this.updateCaseAndActionDetailsWithNextStatusMock("WE");

		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", "abc");
		Response objActual = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());	
		assertEquals(objExpected.getContent(), objActual.getContent());	

	}
	
	@Test
	void updateCaseStatusTestCase6()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Optional<ELCMECTrnASHICaseDetails> actionObj = Optional.of(new ELCMECTrnASHICaseDetails());
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(actionObj);

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		String dmsFiles="doc1.pdf";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		this.updateCaseAndActionDetailsNegativeMock();

		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		Response objActual = adminService.updateCaseStatus(1,"CLN","",new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());	
		assertEquals(objExpected.getContent(), objActual.getContent());	

	}
	
	@Test
	void updateCaseStatusTestCase7()  throws Exception{
		GMFields fields =new GMFields();
		fields.setComments("sample string");

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("abc");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Optional<ELCMECTrnASHICaseDetails> actionObj = Optional.of(new ELCMECTrnASHICaseDetails());
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(actionObj);

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		String dmsFiles="doc1.pdf";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		this.updateCaseAndActionDetailsWithoutNextStatusMock();

		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", "abc");
		Response objActual = adminService.updateCaseStatus(1,"","",new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());	
		assertEquals(objExpected.getContent(), objActual.getContent());	

	}
	
	void updateCaseAndActionDetailsWithNextStatusMock(String nextStatus) {
		
		Optional<ELCMECTrnASHIActionDetails> actionObj1 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", nextStatus, "", "self", dateTime, "DMSFileName"));
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj1);
		
		Optional<ELCMECMstReachWorkFlow> workflow = Optional.of(new ELCMECMstReachWorkFlow());
		workflow.get().setFromRole("fromRole");
		workflow.get().setToRole("toRole");
		workflow.get().setCurrentStatus("currentStatus");
		workflow.get().setNextStatus(nextStatus);
		workflow.get().setMessage("message");
		workflow.get().setMailEventCode("mailEventCode");
		Mockito.when(workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveAndNextStatus(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(workflow);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj2 = Optional.of(new ELCMECTrnASHIActionDetails(1, 1, "role", "comments", "status", "assigneeEmpNo", 0, "dmsFileName", 0, "createdBy", "modifiedBy", dateTime, dateTime, "assigneeLocation", "", ""));
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(actionObj2);
		
	}
	
	void updateCaseAndActionDetailsWithoutNextStatusMock() throws CustomException {
		
		Optional<ELCMECTrnASHIActionDetails> actionObj1 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "WI", "", "self", dateTime, "DMSFileName"));
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj1);
		
		Optional<ELCMECMstReachWorkFlow> workflow = Optional.of(new ELCMECMstReachWorkFlow());
		workflow.get().setFromRole("fromRole");
		workflow.get().setToRole("toRole");
		workflow.get().setCurrentStatus("currentStatus");
		workflow.get().setNextStatus("nextStatus");
		workflow.get().setMessage("message");
		workflow.get().setMailEventCode("mailEventCode");
		Mockito.when(workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActive(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(workflow);
		
		
		Optional<ELCMECTrnASHIActionDetails> actionObj2 = Optional.of(new ELCMECTrnASHIActionDetails(1, 1, "role", "comments", "status", "assigneeEmpNo", 0, "dmsFileName", 0, "createdBy", "modifiedBy", dateTime, dateTime, "assigneeLocation", "", ""));
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(actionObj2);
		
	}
	
	void updateCaseAndActionDetailsNegativeMock() throws CustomException {
		
		Optional<ELCMECTrnASHIActionDetails> actionObj1 = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "WI", "", "self", dateTime, "DMSFileName"));
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj1);
		
		//Mockito.when(workFlowRepository.findByCurrentStatusAndFlgActive(Mockito.anyString(), Mockito.anyInt())).thenReturn(Optional.empty());
		
	}
	

	@Test
	void updateCaseAndActionDetailsNegativeTest() throws CustomException {

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		UpdateCaseStatusReturn objExpected = new UpdateCaseStatusReturn(false);
		UpdateCaseStatusReturn objActual1 = adminService.updateCaseAndActionDetails(new ELCMECTrnASHICaseDetails(), "", "", "", "", "assignedEmpNo", "assignedLocation");
		
		
		assertEquals(objExpected.isSuccess(), objActual1.isSuccess());
		assertEquals(objExpected.getMessage(), objActual1.getMessage());
		
	}

	@Test
	void getAssignCaseGenmodelPositiveTestCase1()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WG");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		Mockito.when(commonservice.getCAMSRoles(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(new ArrayList<>());

		Mockito.when(property.getContextURL()).thenReturn("abc{0}");
		Mockito.when(property.getContextMembersURL()).thenReturn("abc{0}");
		Mockito.when(property.getAssignCaseURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("Assign Case", fields, new ArrayList<>());
		GenModel objActual = adminService.getAssignCaseGenmodel(1);
		
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(5, objActual.getFields().size());
	}
	
	@Test
	void getAssignCaseGenmodelPositiveTestCase2()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		Mockito.when(commonservice.getCAMSRoles(Mockito.anyString(), Mockito.anyString(), Mockito.anyList())).thenReturn(new ArrayList<>());

		Mockito.when(property.getAssignCaseURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("Assign Case", fields, new ArrayList<>());
		GenModel objActual = adminService.getAssignCaseGenmodel(1);
		
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(3, objActual.getFields().size());
	}
	
	@Test
	void getAssignCaseGenmodelNegativeTestCase()  throws Exception{
		List<GenModelField> fields = new ArrayList<>();

		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

		Mockito.when(property.getAssignCaseURL()).thenReturn("abc{0}");

		GenModel objExpected = new GenModel("Assign Case", fields, new ArrayList<>());
		GenModel objActual = adminService.getAssignCaseGenmodel(1);
		
		assertEquals(objExpected.getName(), objActual.getName());
		assertTrue(objActual.getFields().isEmpty());
	}


	@Test
	void assignCaseTestCase1() throws Exception {
		GMFields fields = new GMFields();

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase2() throws Exception {
		GMFields fields = new GMFields();

		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		Response objExpected = new Response("Please select role");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase3() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("IC");
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		Response objExpected = new Response("Please select location");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase4() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("IC");
		fields.setAssignedLocation("Hyderabad");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		Response objExpected = new Response("Please select IC member");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase5() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("IC");
		fields.setAssignedLocation("Hyderabad");
		fields.setAssignedTo("1030816");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		CaseDetailsValidationResponse icResponse = new CaseDetailsValidationResponse(false, "Invalid employee");
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(icResponse);
		
		Response objExpected = new Response("Invalid employee");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase6() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("IC");
		fields.setAssignedLocation("Hyderabad");
		fields.setAssignedTo("1030816");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		CaseDetailsValidationResponse icResponse = new CaseDetailsValidationResponse(true);
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(icResponse);
		
		Response objExpected = new Response("Please provide comments");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase7() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("IC");
		fields.setAssignedLocation("Hyderabad");
		fields.setAssignedTo("1030816");
		fields.setComments("comment");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		CaseDetailsValidationResponse icResponse = new CaseDetailsValidationResponse(true);
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(icResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WI", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setStatusDesc("with IC");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Response objExpected = new Response("Case is already with IC");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase8() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("GRB");
		fields.setComments("comment");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		CaseDetailsValidationResponse icResponse = new CaseDetailsValidationResponse(true);
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(icResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WE", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setStatusDesc("with ER Head");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		this.updateCaseAndActionDetailsWithNextStatusMock("WE");
		this.insertSLADetailsMock();
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", "1234");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void assignCaseTestCase9() throws Exception {
		GMFields fields = new GMFields();
		fields.setAssignedRole("GRB");
		fields.setComments("comment");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = Optional.of(new ELCMECTrnASHICaseDetails());
		caseDetails.get().setStatus("WE");
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(caseDetails);
		
		CaseDetailsValidationResponse icResponse = new CaseDetailsValidationResponse(true);
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(icResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WE", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setStatusDesc("with ER Head");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		this.updateCaseAndActionDetailsNegativeMock();

		
		Response objExpected = new Response("Can't assign case to GRB");
		Response objActual = adminService.assignCase("1030816", new GenModel());
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	void insertSLADetailsMock() throws CustomException {
		Optional<ELCMECMstSysParams> sysParam = Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("28");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(sysParam);

		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());
	}


	@Test
	void seekInputGenmodelTestCase() throws Exception {
		List<GenModelField> fields = new ArrayList<>();
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		List<GenModelOption> complainants= new ArrayList<>();
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(),Mockito.anyList())).thenReturn(complainants);

		GenModel objExpected = new GenModel("Inputs from Complainant", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getSeekInputsURL(), Constants.SERVICEURL),new CardViewAction(1, Constants.CANCEL, "", "", "")));
		GenModel objActual = adminService.seekInputGenmodel(1);
		assertEquals(objExpected.getName(), objActual.getName());
	}

	@Test
	void seekInputGenmodelTestCase1() throws Exception {
		List<GenModelField> fields = new ArrayList<>();
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);


		GenModel objExpected = new GenModel("Inputs from Complainant", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getSeekInputsURL(), Constants.SERVICEURL),new CardViewAction(1, Constants.CANCEL, "", "", "")));
		GenModel objActual = adminService.seekInputGenmodel(1);
		assertEquals(objExpected.getName(), objActual.getName());
	}



	@Test
	void seekInputTestCase() throws Exception {
		GMFields fields = new GMFields();

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(false);

		Response objExpected =new Response(Message.CASENOTREGISTERED);
		Response objActual = adminService.seekInput(new GenModel(),"string");
		
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}

	@Test
	void seekInputTestCase1() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Response objExpected =new Response("Please select complainant");
		Response objActual = adminService.seekInput(new GenModel(),"string");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}

	@Test
	void seekInputTestCase2() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("shashank");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);

		CaseDetailsValidationResponse complainantResponse = new CaseDetailsValidationResponse(false, "Invalid employee");

		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(complainantResponse);

		Response objExpected =new Response("Invalid employee");
		Response objActual = adminService.seekInput(new GenModel(),"string");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}

	@Test
	void seekInputTestCase3() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("shashank");
		fields.setComments(null);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);

		CaseDetailsValidationResponse complainantResponse = new CaseDetailsValidationResponse(true);
		complainantResponse.setStatus(true);
		complainantResponse.setMessage(Message.SUCCESS);
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(complainantResponse);

		Response objExpected =new Response("Please enter your query");
		Response objActual = adminService.seekInput(new GenModel(),"string");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}

	@Test
	void seekInputTestCase4() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("shashank");
		fields.setComments("abcde");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);

		CaseDetailsValidationResponse complainantResponse = new CaseDetailsValidationResponse(true, Arrays.asList(new ViewCurrEmpAllDetails("mailid", "empno", "empName")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(complainantResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		Mockito.when(property.getAppCode()).thenReturn("appcode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventIdFYI");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(10);
		Mockito.when(property.getFromId()).thenReturn("emailprotst@infosys.com");
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));

		Response objExpected =new Response(Constants.SUCCESSHIDEFORM, "Successfully seeked input from complainant mailid");
		Response objActual = adminService.seekInput(new GenModel(),"shashank.jain18@infosys.com");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void seekInputTestCase5() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("shashank");
		fields.setComments("abcde");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);

		CaseDetailsValidationResponse complainantResponse = new CaseDetailsValidationResponse(true, Arrays.asList(new ViewCurrEmpAllDetails("mailid", "empno", "empName")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(complainantResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		Mockito.when(property.getAppCode()).thenReturn("appcode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventIdFYI");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(10);
		Mockito.when(property.getFromId()).thenReturn("emailprotst@infosys.com");
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.seekInput(new GenModel(),"shashank.jain18@infosys.com"),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
	}
	
	@Test
	void seekInputTestCase6() throws Exception {
		GMFields fields = new GMFields();
		fields.setComplainant("shashank");
		fields.setComments("abcde");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);

		CaseDetailsValidationResponse complainantResponse = new CaseDetailsValidationResponse(true, Arrays.asList(new ViewCurrEmpAllDetails("mailid", "empno", "empName")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(complainantResponse);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(null);


		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.seekInput(new GenModel(),"shashank.jain18@infosys.com"),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));
	}
	
	@Test
	void communicationHistoryTest() throws CustomException {
		
		Timestamp createdDate =  new Timestamp(0);
		List<ELCMECMstASHICommunicationDetails> communications = new ArrayList<>();
		communications.add(new ELCMECMstASHICommunicationDetails(2,"","","","","",createdDate));
		communications.add(new ELCMECMstASHICommunicationDetails(3,"","","","","",createdDate));
		communications.add(new ELCMECMstASHICommunicationDetails(4,"","","","","",createdDate));
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(communications);
		
		List<Card> comms = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("description");
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		CardView objExpected = new CardView("", comms, "", 2, actions);
		
		CardView objActual = adminService.communicationHistory(2,1);
       	assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void communicationHistoryTest1() throws CustomException {
		
		List<ELCMECMstASHICommunicationDetails> communications = new ArrayList<>();
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(communications);
		
		List<Card> comms = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("description");
		
		CardView objExpected = new CardView("", comms, "", 2, actions);
		
		CardView objActual = adminService.communicationHistory(2,2);
       	assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	void communicationHistoryTest2() throws CustomException {
		
		Timestamp createdDate =  new Timestamp(0);
		List<ELCMECMstASHICommunicationDetails> communications = new ArrayList<>();
		communications.add(new ELCMECMstASHICommunicationDetails(2,"","","","","",createdDate));
		communications.add(new ELCMECMstASHICommunicationDetails(3,"","","","","",createdDate));
		communications.add(new ELCMECMstASHICommunicationDetails(4,"","","","","",createdDate));
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(communications);
		
		List<Card> comms = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("description");
		
		CardView objExpected = new CardView("", comms, "", 2, actions);
		
		CardView objActual = adminService.communicationHistory(2,2);
       	assertEquals(objExpected.getName(), objActual.getName());

	}
	
	
	@Test
	void communicationHistoryTest3() throws CustomException {
		
		Timestamp createdDate =  new Timestamp(0);
		List<ELCMECMstASHICommunicationDetails> communications = new ArrayList<>();
		communications.add(new ELCMECMstASHICommunicationDetails(2,"","","comment","respondedBy","",createdDate));
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(2)).thenReturn(communications);
		
		List<Card> comms = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("description");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WI", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
			
		communications.get(0).setFlgResponded(1);
		communications.get(0).setUpdatedDate(createdDate);
		communications.get(0).setResponse("Response");

		CardView objExpected = new CardView("", comms, "", 2, actions);
		
		CardView objActual = adminService.communicationHistory(2,1);
       	assertEquals(objExpected.getName(), objActual.getName());

	}

	@Test
	void getInterimReliefGenmodelTest() throws CustomException {
		
		List<GenModelOption> optionsObj = new ArrayList<GenModelOption>();
		optionsObj.add(0,new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));
		
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(Mockito.anyInt(), Mockito.anyString())).thenReturn(optionsObj);
		
		List<GenModelField> fields = new ArrayList<>();
		List<GenModelOption> flgReliefOptions=new ArrayList<>();
		flgReliefOptions.add(new GenModelOption(1, "Yes"));
		flgReliefOptions.add(new GenModelOption(2, "No"));
		GenModelField flgRelief=new GenModelField( 18, "flgRelief", "Interim Relief Required?", "", "",flgReliefOptions, true);

		fields.add(flgRelief);
		
		GenModel objExpected=new GenModel(Constants.INTERIM_RELIEF, fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, "URL", Constants.SERVICEURL)));
		
		Mockito.when(property.getFileValidationRegex()).thenReturn("${filevalidation.regex}");
		Mockito.when(property.getFileValidationTypes()).thenReturn("${filevalidation.types}");
		Mockito.when(property.getInterimReliefSubmitURL()).thenReturn("${url.admin.ashi.investigation.interimrelief.submit}");
		

    	GenModel objActual=adminService.getInterimReliefGenmodel(2);
       	assertEquals(objExpected.getName(), objActual.getName());
		
	}
	
	@Test
	void addInterimReliefTest() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("yes");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		List<DocumentData> documents=new ArrayList<DocumentData>();
	    documents.add(new DocumentData("filename", "base64file"));
		fields.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		
		String dmsFiles="";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInterimReliefFolder()).thenReturn("folder");
		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = Optional.of(new ELCMECTrnASHIActionDetails());
		assigneeDetails.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(assigneeDetails);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("grbids","icids");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
				
		Response objExpected=new Response("Successfully added interim relief details.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest1() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("Remarks");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(false);
		
		Response objExpected=new Response(Message.CASENOTREGISTERED);
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
	
	}
	
	@Test
	void addInterimReliefTest2() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("Remarks");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "CLN", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Response objExpected=new Response("Unable to take action. Current case status is "+actionObj.get().getStatusDesc());
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest3() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("Remarks");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
			
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(true);
		
		Response objExpected=new Response("Already added interim relief details");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest4() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("");
		fields.setRemarks("Remarks");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		
		Response objExpected=new Response("Please select an option for Interim relief required? field.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest5() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("yes");
		fields.setRemarks("Remarks");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
	
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		
		Response objExpected=new Response("Please select atleast an option from given interim relief options or provide other relief details.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest6() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
			
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		
		Response objExpected=new Response("Please provide your remarks.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest7() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("yes");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		List<DocumentData> documents=new ArrayList<DocumentData>();
		documents.add(new DocumentData("filename", "base64file"));
		fields.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		String dmsFiles="Invalid file. Unable to upload";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInterimReliefFolder()).thenReturn("folder");
				
		Response objExpected=new Response(dmsFiles);
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest8() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		List<DocumentData> documents=new ArrayList<DocumentData>();
	    documents.add(new DocumentData("filename", "base64file"));
		fields.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		

		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = Optional.of(new ELCMECTrnASHIActionDetails());
		assigneeDetails.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(assigneeDetails);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("grbids","icids");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected=new Response("Successfully added interim relief details.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void addInterimReliefTest9() throws CustomException {
		
		List<GenModelField> fieldList=new ArrayList<>();
    	GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
   		caseidField.setEditable(false);
   		fieldList.add(caseidField);
   		List<CardViewAction> actionList=new ArrayList<>();
   		actionList.add(new CardViewAction(Constants.CANCEL, "", "cancel"));
   		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("yes");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		List<DocumentData> documents=new ArrayList<DocumentData>();
	    //documents.add(new DocumentData("filename", "base64file"));
		fields.setDocuments(documents);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(true);
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(interimReliefRepository.existsByCaseId(fields.getCaseid())).thenReturn(false);
		

		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = Optional.of(new ELCMECTrnASHIActionDetails());
		assigneeDetails.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(assigneeDetails);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("grbids","icids");
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected=new Response("Successfully added interim relief details.");
	
		GenModel genmodel= new GenModel("Add Interim Relief", fieldList, actionList);

		Response objActual=adminService.addInterimRelief(genmodel);
       	assertEquals(objExpected.getContent(), objActual.getContent());
		
	}
	
	@Test
	void getInterimReliefTestCase() throws CustomException {
		
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("yes");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		Timestamp dateTime=new Timestamp(0);
		String dmsFiles="files";
		Optional<ELCMECTrnASHIInterimReliefDetails> relief = Optional.of(new ELCMECTrnASHIInterimReliefDetails(fields, "", dateTime, dmsFiles));
		Mockito.when(interimReliefRepository.findByCaseId(2)).thenReturn(relief);
		
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Interim relief required? ", "Yes", 14));
		fieldList.add(new CardViewField("Relief options", relief.get().getReliefs(), 120));
		fieldList.add(new CardViewField(Constants.REMARKS, relief.get().getRemarks(), 14));
		fieldList.add(new CardViewField(Constants.STATUS, "Submitted to GRB for approval", 14));
		fieldList.add(new CardViewField(Constants.DOCUMENTS, "", 88));
		String[] documents = relief.get().getDmsFiles().split(",");
		for(String document : documents) {
		fieldList.add(new CardViewField(document.trim(), MessageFormat.format("URL", "IR", relief.get().getSerialNo(), document.trim()), 35));
		}
		fieldList.add(new CardViewField(Constants.DOWNLOADALL, MessageFormat.format("URL", "IR", relief.get().getSerialNo(), Constants.ALL), 87));
		
		
		Mockito.when(property.getDownloadURL()).thenReturn("URL");
		
		LabelView objExpected = new LabelView(Constants.INTERIM_RELIEF,fieldList);
		
		LabelView objActual = adminService.getInterimRelief(2);
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		
	}
	
	@Test
	void getInterimReliefTestCase1() throws CustomException {
		
		List<String> location=new ArrayList<>();
		location.add("Bangalore");
		location.add("Hyderabad");
		
		List<String> status=new ArrayList<>();
		status.add("with GRB");
		status.add("IC");
		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setRole("GRB");	
		fields.setCompany("INFSYS");
		fields.setCountry("In");
		fields.setLocation(location);
		fields.setStatus(status);
		fields.setFlgRelief("no");
		fields.setRemarks("Remarks");
		fields.setReliefs("not null");
		
		Timestamp dateTime=new Timestamp(0);
		String dmsFiles="";
		Optional<ELCMECTrnASHIInterimReliefDetails> relief = Optional.of(new ELCMECTrnASHIInterimReliefDetails(fields, "", dateTime, dmsFiles));
		Mockito.when(interimReliefRepository.findByCaseId(2)).thenReturn(relief);
		
		List<CardViewField> fieldList=new ArrayList<>();
		fieldList.add(new CardViewField("Interim relief required? ", "No", 14));
		fieldList.add(new CardViewField(Constants.REMARKS, relief.get().getRemarks(), 14));
		relief.get().setFlgActionTaken(1);
		relief.get().setApprovalStatus("Status");
		relief.get().setApproverRemarks("remark");
		fieldList.add(new CardViewField(Constants.STATUS, WordUtils.capitalize(relief.get().getApprovalStatus().toLowerCase()) + "by GRB", 14));
		fieldList.add(new CardViewField("Approval remarks", relief.get().getApproverRemarks(), 14));
		
		
		LabelView objExpected = new LabelView(Constants.INTERIM_RELIEF,fieldList);
		
		LabelView objActual = adminService.getInterimRelief(2);
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		
	}
	
	@Test
	void getInterimReliefTestCase2() throws CustomException {
		
		Optional<ELCMECTrnASHIInterimReliefDetails> relief = Optional.empty(); 
		Mockito.when(interimReliefRepository.findByCaseId(2)).thenReturn(relief);
		
		List<CardViewField> fieldList=new ArrayList<>();
		
		LabelView objExpected = new LabelView(Constants.INTERIM_RELIEF,fieldList);
		
		LabelView objActual = adminService.getInterimRelief(2);
       	assertEquals(objExpected.getName(), objActual.getName());
       	assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
		
	}

	@Test
	void getFirstContactGenmodelTest() throws CustomException {
		List<GenModelField> fields = new ArrayList<>();
		

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		
		List<GenModelOption> mailToOptions=new ArrayList<>();
		mailToOptions.add(new GenModelOption(Constants.COMPLAINANT, Constants.COMPLAINANT + "(s)"));
		mailToOptions.add(new GenModelOption(Constants.RESPONDENT, Constants.RESPONDENT + "(s)"));
		GenModelField mailTo=new GenModelField( 18, "mailTo", "Mail To", "", "",mailToOptions, true);

		fields.add(mailTo);
		Mockito.when(property.getSendFirtContactMailsURL()).thenReturn("${url.admin.ashi.investigation.sendfirtcontactmails}");
		
		GenModel objExpected = new GenModel("First contact mails", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, "${url.admin.ashi.investigation.sendfirtcontactmails}", Constants.SERVICEURL)));
		
		GenModel objActual = adminService.getFirstContactGenmodel(2);
       	assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getFirstContactMailsDetailsTest() throws CustomException {
		
		List<Card> cards = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.existsById(2)).thenReturn(true);
		
		List<ELCMECTrnASHIFirstContactMailsDetails> mails = new ArrayList<>();
		Mockito.when(firstContactMailsRepository.findByCaseIdOrderBySerialNoDesc(2)).thenReturn(mails);
		
		cards.add(new Card(new ArrayList<>(), Arrays.asList(new CardViewField("No mail sent yet.", "", 12))));
		
		CardView objExpected = new CardView("", cards);
		
		CardView objActual = adminService.getFirstContactMailsDetails(2, 1);
       	assertEquals(objExpected.getName(), objActual.getName());
       	assertEquals(objExpected.getCards().size(), objActual.getCards().size());
       	assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test
	void getFirstContactMailsDetailsTest1() throws CustomException {
		
		List<Card> cards = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.existsById(2)).thenReturn(true);
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		List<ELCMECTrnASHIFirstContactMailsDetails> mails = new ArrayList<>();
		mails.add(new ELCMECTrnASHIFirstContactMailsDetails(2, "A", "", "", dateTime));
		mails.add(new ELCMECTrnASHIFirstContactMailsDetails(2, "R", "", "", dateTime));
		mails.add(new ELCMECTrnASHIFirstContactMailsDetails(2, "R", "", "", dateTime));
		Mockito.when(firstContactMailsRepository.findByCaseIdOrderBySerialNoDesc(2)).thenReturn(mails);
		
		for(ELCMECTrnASHIFirstContactMailsDetails mail : mails) {
			List<CardViewField> fields = new ArrayList<>();
			fields.add(new CardViewField("Issued On", new SimpleDateFormat(Constants.DATETIME_FORMAT).format(mail.getIssuedDate()), 14));
			fields.add(new CardViewField("Mail Sent To", "Complainant"+"s", 14));
			fields.add(new CardViewField("Updated By", mail.getRole().trim()+" ("+mail.getIssuedBy().trim()+")", 14));
			fields.add(new CardViewField("Description", mail.getDescription(), 14));
			
			cards.add(new Card(new ArrayList<>(), fields));
		}
		
		CardView objExpected = new CardView("", cards);
		
		CardView objActual = adminService.getFirstContactMailsDetails(2, 1);
       	assertEquals(objExpected.getName(), objActual.getName());
       	assertEquals(2, objActual.getCards().size());
	}
	
	@Test
	void getFirstContactMailsDetailsTest2() throws CustomException {
		
		List<Card> cards = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.existsById(2)).thenReturn(false);
		
		CardView objExpected = new CardView("", cards);
		
		CardView objActual = adminService.getFirstContactMailsDetails(2, 1);
       	assertEquals(objExpected.getName(), objActual.getName());
       	assertEquals(objExpected.getCards().size(), objActual.getCards().size());
       	assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test
	void sendFirstContactMailsTest1() throws CustomException {
   		
   		GMFields fields =new GMFields();

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);	
		Mockito.when(caseDetailsRepository.existsById(fields.getCaseid())).thenReturn(false);
			
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.sendFirstContactMails(new GenModel());
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void sendFirstContactMailsTest2() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.COMPLAINANT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(new ArrayList<>());
				
		Response objExpected = new Response("No "+fields.getMailTo()+"(s) found to trigger mails.");
		
		Response objActual = adminService.sendFirstContactMails(new GenModel());
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void sendFirstContactMailsTest3() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.RESPONDENT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816",""));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.sendFirstContactMails(new GenModel()),
				"Empty recipeints."
				);

		assertTrue(thrown.getMessage().contains("Empty recipeints."));
		
		
	}
	
	@Test
	void sendFirstContactMailsTest4() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo("any");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);	
		
		Response objExpected = new Response("Please select valid option");
		
		Response objActual = adminService.sendFirstContactMails(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void sendFirstContactMailsTest5() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.RESPONDENT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816","Suraj"));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeEmpNo("123456");
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		//CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewAllEmpDetails("surajkumar.dewangan", "1030816", "Suraj")));
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(false, "Invalid employee");
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.sendFirstContactMails(new GenModel()),
				"Invalid employee"
				);

		assertTrue(thrown.getMessage().contains("Invalid employee"));
	}
	
	@Test
	void sendFirstContactMailsTest6() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.RESPONDENT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816","Suraj"));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeEmpNo("123456");
		actionObj.get().setAssigneeLocation("");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.sendFirstContactMails(new GenModel()),
				"IC mapped location not found."
				);

		assertTrue(thrown.getMessage().contains("IC mapped location not found."));
	}
	
	@Test
	void sendFirstContactMailsTest7() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.RESPONDENT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816","Suraj"));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.sendFirstContactMails(new GenModel()),
				"Action details not found."
				);

		assertTrue(thrown.getMessage().contains("Action details not found."));
	}
	
	@Test
	void sendFirstContactMailsTest8() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.COMPLAINANT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816","Suraj"));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeEmpNo("123456");
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));

		
		Response objExpected = new Response(Message.SUCCESS, "Successfully sent emails to "+fields.getMailTo()+"(s)");
		
		Response objActual = adminService.sendFirstContactMails(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void sendFirstContactMailsTest9() throws CustomException {
   		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setMailTo(Constants.RESPONDENT);

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		List<GenModelOption> employees = new ArrayList<GenModelOption>();
		employees.add(new GenModelOption("1030816","Suraj"));
		employees.add(new GenModelOption("1030816","Suraj"));
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(employees);
		
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeEmpNo("123456");
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.sendFirstContactMails(new GenModel()),
				fields.getMailTo() +"(s) "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(fields.getMailTo() +"(s) "+Message.MAIL_NOT_TRIGGERED));
	}
	
	@Test 
	void getInvestigationTypeGenmodelTest() throws CustomException {
		
		List<GenModelField> fields = new ArrayList<>();
		
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", 2, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		
		List<GenModelOption> investigationTypes=new ArrayList<>();
		investigationTypes.add(new GenModelOption(1, Constants.CONCILIATION));
		investigationTypes.add(new GenModelOption(0, Constants.PROCEED_FI));
		GenModelField investigationTypeField=new GenModelField( 18, "investigationType", "Choose Investigation Type", "", "",investigationTypes, true);

		fields.add(investigationTypeField);
		Mockito.when(property.getChooseInvestigationTypeURL()).thenReturn("URL");
		
		GenModel objExpected = new GenModel("Choose Investigation Type", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, "URL", Constants.SERVICEURL),new CardViewAction(1, "Clear", "", "", "Clear")));
		
		GenModel objActual = adminService.getInvestigationTypeGenmodel(2);
       	assertEquals(objExpected.getName(), objActual.getName());
       	assertEquals(objExpected.getFields().size(), objActual.getFields().size());
       	assertEquals(objExpected.getActions().size(), objActual.getActions().size());
	}
	
	@Test
	void chooseInvestigationTypeTest1() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
	
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void chooseInvestigationTypeTest2() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setInvestigationType("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please choose valid investigation type.");
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void chooseInvestigationTypeTest3() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setInvestigationType(Constants.CONCILIATION);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WIC", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);
		
		Response objExpected = new Response("Already selected investigation type - ");
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void chooseInvestigationTypeTest4() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setInvestigationType(Constants.PROCEED_FI);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
//		Optional<ELCMECTrnASHIInvestigationDetails> investigationDetails = Optional.of(new ELCMECTrnASHIInvestigationDetails());
//		investigationDetails.get().setInvestigationType(Constants.CONCILIATION);
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(investigationDetails);
		
		this.updateCaseAndActionDetailsWithNextStatusMock("CIR");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "Successfully updated investigation type.", "", "");
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void chooseInvestigationTypeTest5() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setInvestigationType(Constants.PROCEED_FI);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
//		
		this.updateCaseAndActionDetailsWithNextStatusMock("WIF");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "Successfully updated investigation type.", "", "");
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void chooseInvestigationTypeTest6() throws CustomException {
		
   		GMFields fields =new GMFields();
   		fields.setCaseid(2);
		fields.setInvestigationType(Constants.PROCEED_FI);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.chooseInvestigationType("1030816", new GenModel());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest1() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(0, objActual.getFields().size());
       	assertEquals(0, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest2() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(0, objActual.getFields().size());
       	assertEquals(0, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest3() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "WIC", "Comment", "self", dateTime, "DMSFileName"));
		actionObj.get().setStatusDesc("With IC");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		Mockito.when(property.getInitiateConciliationURL()).thenReturn("url");
		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(2, objActual.getFields().size());
       	assertEquals(1, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest4() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "CIA", "Comment", "self", dateTime, "DMSFileName"));
		actionObj.get().setStatusDesc("With GRB for conciliation approval");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		Mockito.when(property.getInitiateConciliationURL()).thenReturn("url");
		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(4, objActual.getFields().size());
       	assertEquals(2, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest5() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "PCR", "Comment", "self", dateTime, "DMSFileName"));
		actionObj.get().setStatusDesc("With IC");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(3, objActual.getFields().size());
       	assertEquals(0, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest6() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "CIR", "Comment", "self", dateTime, "DMSFileName"));
		actionObj.get().setStatusDesc("conciliation rejected");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(4, objActual.getFields().size());
       	assertEquals(1, objActual.getActions().size());
		
	}
	
	@Test
	void getInitiateConciliationGenmodelTest7() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1, "GRB", "CRR", "Comment", "self", dateTime, "DMSFileName"));
		actionObj.get().setStatusDesc("conciliation rejected");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);

		
		GenModel objActual = adminService.getInitiateConciliationGenmodel(2);
       	assertEquals(4, objActual.getFields().size());
       	assertEquals(1, objActual.getActions().size());
		
	}
	
	@Test
	void getConciliationReportTest1() throws CustomException {
		Mockito.when(conciliationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		LabelView actual = adminService.getConciliationReport(1);
		assertTrue(actual.getView().getFields().isEmpty());
	}
	
	@Test
	void getConciliationReportTest2() throws CustomException {
		Optional<ELCMECTrnASHIConciliationReportDetails> report = Optional.of(new ELCMECTrnASHIConciliationReportDetails());
		report.get().setConciliationReason("Reason");
		report.get().setKeyFindings("keyFindings");
		report.get().setRecommendations("recommendations");
		report.get().setAgreementDocs("doc1.pdf,doc2.pdf");
		report.get().setOtherDocs("doc1.pdf");
		Mockito.when(conciliationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);
		Mockito.when(property.getDownloadURL()).thenReturn("url");
		
		LabelView actual = adminService.getConciliationReport(1);
		assertEquals(8, actual.getView().getFields().size());
	}
	
	@Test
	void getConciliationReportTest3() throws CustomException {
		Optional<ELCMECTrnASHIConciliationReportDetails> report = Optional.of(new ELCMECTrnASHIConciliationReportDetails());
		report.get().setConciliationReason("Reason");
		report.get().setKeyFindings("keyFindings");
		report.get().setRecommendations("recommendations");
		Mockito.when(conciliationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);
		
		LabelView actual = adminService.getConciliationReport(1);
		assertEquals(3, actual.getView().getFields().size());
	}
	
	@Test
	void initiateConciliationTest1() throws CustomException {
		GMFields fields = new GMFields();
		fields.setRemarks("remark");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		this.updateCaseAndActionDetailsWithNextStatusMock("CIA");
		
		Response expected = new Response(Message.SUCCESSPROCEED, "message", "", "1234");
		
		Response actual = adminService.initiateConciliation("1030816", "CIA", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		assertEquals(expected.getValue(), actual.getValue());
	}
	
	@Test
	void initiateConciliationTest2() throws CustomException {
		GMFields fields = new GMFields();
		fields.setRemarks("remark");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response expected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response actual = adminService.initiateConciliation("1030816", "CIA", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		assertEquals(expected.getValue(), actual.getValue());
	}
	
	@Test
	void initiateConciliationTest3() throws CustomException {
		GMFields fields = new GMFields();
		fields.setRemarks("");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
	
		
		Response expected = new Response("Please provide remarks.");
		
		Response actual = adminService.initiateConciliation("1030816", "CIA", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		assertEquals(expected.getValue(), actual.getValue());
	}
	
	@Test
	void initiateConciliationTest4() throws CustomException {
		GMFields fields = new GMFields();
		fields.setRemarks("remark");
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");

		
		Response expected = new Response(Message.CASENOTREGISTERED);
		
		Response actual = adminService.initiateConciliation("1030816", "CIA", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		assertEquals(expected.getValue(), actual.getValue());
	}
	
	@Test
	void getConciliationConsentsTest1() throws CustomException {
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		consent_A.setFlgAccept(1);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		consent_R.setFlgAccept(1);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A, consent_R));
		
		CardView actual = adminService.getConciliationConsents(1);
		
		assertEquals(2, actual.getCards().size());
		assertEquals(3, actual.getCards().get(0).getFields().size());
		assertEquals(0, actual.getCards().get(0).getActions().size());

	}
	
	@Test
	void getConciliationConsentsTest2() throws CustomException {
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		consent_R.setFlgAccept(1);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A, consent_R));
		
		CardView actual = adminService.getConciliationConsents(1);
		
		assertEquals(2, actual.getCards().size());
		assertEquals(3, actual.getCards().get(0).getFields().size());
		assertEquals(0, actual.getCards().get(0).getActions().size());

	}
	
	@Test
	void getConciliationConsentsTest3() throws CustomException {
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A1 = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		consent_A1.setFlgAccept(1);
		ELCMECMstASHIConciliationConsentDetails consent_A2 = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		consent_A2.setFlgReject(1);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		consent_R.setFlgAccept(1);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A1, consent_A2, consent_R));
		
		CardView actual = adminService.getConciliationConsents(1);
		
		assertEquals(3, actual.getCards().size());
		assertEquals(3, actual.getCards().get(0).getFields().size());
		assertEquals(1, actual.getCards().get(1).getActions().size());

	}
	
	@Test
	void getConciliationConsentsTest4() throws CustomException {
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList());
		
		CardView actual = adminService.getConciliationConsents(1);
		
		assertEquals(1, actual.getCards().size());
		assertEquals(1, actual.getCards().get(0).getFields().size());

	}
	
	@Test
	void getConciliationConsentsTest5() throws CustomException {
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		CardView actual = adminService.getConciliationConsents(1);
		
		assertTrue(actual.getCards().isEmpty());

	}
	
	@Test
	void getPrepareConciliationReportTest1() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		consent_A.setFlgAccept(1);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		consent_R.setFlgAccept(1);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A, consent_R));
		
		GenModel actual = adminService.getPrepareConciliationReport(1);
		
		assertEquals(6, actual.getFields().size());
		assertEquals(2, actual.getActions().size());
	}
	
	@Test
	void getPrepareConciliationReportTest2() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		consent_A.setFlgReject(1);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		consent_R.setFlgAccept(1);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A, consent_R));
		
		GenModel actual = adminService.getPrepareConciliationReport(1);
		
		assertEquals(2, actual.getFields().size());
		assertEquals(1, actual.getActions().size());
	}
	
	@Test
	void getPrepareConciliationReportTest3() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent_A = new ELCMECMstASHIConciliationConsentDetails(1, "A", "suraj", "609648", dateTime);
		ELCMECMstASHIConciliationConsentDetails consent_R = new ELCMECMstASHIConciliationConsentDetails(1, "R", "dinesh", "609648", dateTime);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(consent_A, consent_R));
		
		GenModel actual = adminService.getPrepareConciliationReport(1);
		
		assertEquals("To proceed further status of all the consents should be either accepted or rejected.", actual.getId());
		assertTrue(actual.getFields().isEmpty());
	}
	
	@Test
	void getPrepareConciliationReportTest4() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList());
		
		GenModel actual = adminService.getPrepareConciliationReport(1);
		
		assertEquals("Conciliation has not initiated or approved yet.", actual.getId());
		assertTrue(actual.getFields().isEmpty());
	}
	
	@Test
	void getPrepareConciliationReportTest5() throws CustomException {
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		GenModel actual = adminService.getPrepareConciliationReport(1);
		
		assertEquals(Message.CASENOTREGISTERED, actual.getId());
		assertTrue(actual.getFields().isEmpty());
	}
	
	@Test
	void submitConciliationReportTest1() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");
		fields.setConciliationRecommendations("conciliationRecommendations");
		fields.setConciliationAggrementDocs(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));
		fields.setDocuments(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		String dmsFiles="doc1.pdf";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("folder");
		
		this.updateCaseAndActionDetailsWithNextStatusMock("CRA");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "Successfully submittted conciliation report.", "", "1234");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest2() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");
		fields.setConciliationRecommendations("conciliationRecommendations");
		fields.setConciliationAggrementDocs(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));
		fields.setDocuments(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("folder");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest3() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");
		fields.setConciliationRecommendations("conciliationRecommendations");
		fields.setConciliationAggrementDocs(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));
		fields.setDocuments(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn("doc1.pdf", dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("folder");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest4() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");
		fields.setConciliationRecommendations("conciliationRecommendations");
		fields.setConciliationAggrementDocs(Arrays.asList(new DocumentData("doc1.pdf", "agjbdayigbfyiagbdaui")));

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		String dmsFiles="doc1.pdf";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("folder");
		
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest5() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");
		fields.setConciliationRecommendations("conciliationRecommendations");
		fields.setConciliationAggrementDocs(Arrays.asList());

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response("Please upload conciliation agreement documents.");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest6() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");
		fields.setConciliationFindings("conciliationFindings");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response("Please provide your recommendations.");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest7() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setConciliationReason("conciliationReason");

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response("Please provide key findings abount the incident.");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest8() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response("Please provide reason for conciliation.");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest9() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(conciliationReportDetailsRepository.existsByCaseId(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Already submitted conciliation report");
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitConciliationReportTest10() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();

		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.submitConciliationReport("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseGenModelTest1()  throws Exception{
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Optional<ELCMECMstReachWorkFlow> workflow = Optional.of(new ELCMECMstReachWorkFlow());
		workflow.get().setFromRole("fromRole");
		workflow.get().setCurrentStatus("currentStatus");
		workflow.get().setNextStatus("CLF");
		workflow.get().setActionLabel("actionLabel");
		//Mockito.when(workFlowRepository.findByCurrentStatusAndFlgActiveAndUiModuleCodeEndingWith(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(workflow);

		GenModel objActual = adminService.moveCaseGenModel("action", 1);
		
		assertEquals(4, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void moveCaseGenModelTest2()  throws Exception{
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "CRA", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Optional<ELCMECMstReachWorkFlow> workflow = Optional.of(new ELCMECMstReachWorkFlow());
		workflow.get().setFromRole("fromRole");
		workflow.get().setCurrentStatus("CRA");
		workflow.get().setNextStatus("WEC");
		workflow.get().setActionLabel("actionLabel");
		//Mockito.when(workFlowRepository.findByCurrentStatusAndFlgActiveAndUiModuleCodeEndingWith(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(workflow);

		GenModel objActual = adminService.moveCaseGenModel("action", 1);
		
		assertEquals(4, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void moveCaseTest1() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setComments("comments");
		fields.setAction("CLF");
		fields.setDocuments(Arrays.asList(new DocumentData("file.pdf", "daubdajklbfuiabui")));
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		this.updateCaseAndActionDetailsWithNextStatusMock("CLF");
		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", "1234");
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseTest2() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setComments("comments");
		fields.setAction("WCC");
		fields.setDocuments(Arrays.asList());
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		this.updateCaseAndActionDetailsNegativeMock();
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseTest3() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setComments("comments");
		fields.setAction("CLF");
		fields.setDocuments(Arrays.asList(new DocumentData("file.pdf", "daubdajklbfuiabui")));
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseTest4() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setComments("comments");
		fields.setAction("CLF");
		fields.setDocuments(Arrays.asList());
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload closure documents.");
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseTest5() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		fields.setComments("");
		fields.setAction("CLF");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please provide your comments.");
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void moveCaseTest6() throws CustomException {
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.moveCase("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void getRecommendedActionsGenmodelTest1()  throws Exception{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		GenModel objActual = adminService.getRecommendedActionsGenmodel(1, 1, "");
		
		assertEquals(8, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void getRecommendedActionsGenmodelTest2()  throws Exception{
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("1", "suraj")));
		
		Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = Optional.of(new ELCMECMstASHIRecommendationsDetails());
		recommendedActionsObj.get().setCaseId(1);
		recommendedActionsObj.get().setActor("A");
		recommendedActionsObj.get().setMailId("surajkumar.dewangan");
		recommendedActionsObj.get().setSeverityLevel("1");
		recommendedActionsObj.get().setActions("Jail");
		Mockito.when(recommendationsDetailsRepository.findById(Mockito.anyInt())).thenReturn(recommendedActionsObj);
		
		GenModel objActual = adminService.getRecommendedActionsGenmodel(2, 1, "123");
		
		assertEquals(8, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void getRecommendedActionsGenmodelTest3()  throws Exception{
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("1", "suraj")));
		
		Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = Optional.of(new ELCMECMstASHIRecommendationsDetails());
		recommendedActionsObj.get().setCaseId(1);
		recommendedActionsObj.get().setActor("R");
		recommendedActionsObj.get().setMailId("surajkumar.dewangan");
		recommendedActionsObj.get().setSeverityLevel("1");
		recommendedActionsObj.get().setActions("Jail");
		Mockito.when(recommendationsDetailsRepository.findById(Mockito.anyInt())).thenReturn(recommendedActionsObj);
		
		GenModel objActual = adminService.getRecommendedActionsGenmodel(2, 1, "123");
		
		assertEquals(8, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void getRecommendedActionsGenmodelTest4()  throws Exception{
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("1", "suraj")));
		
		Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = Optional.of(new ELCMECMstASHIRecommendationsDetails());
		recommendedActionsObj.get().setCaseId(1);
		recommendedActionsObj.get().setActor("W");
		recommendedActionsObj.get().setMailId("surajkumar.dewangan");
		recommendedActionsObj.get().setSeverityLevel("1");
		recommendedActionsObj.get().setActions("Jail");
		Mockito.when(recommendationsDetailsRepository.findById(Mockito.anyInt())).thenReturn(recommendedActionsObj);
		
		GenModel objActual = adminService.getRecommendedActionsGenmodel(2, 1, "123");
		
		assertEquals(8, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void getRecommendedActionsGenmodelTest5()  throws Exception{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		GenModel objActual = adminService.getRecommendedActionsGenmodel(1, 1, "");
		
		assertEquals(0, objActual.getFields().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest1() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		fields.setComplainant("suraj");
		fields.setSeverityLevel("1");
		fields.setRecommendedActions("Jail");
		fields.setTransactionid("1234");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(recommendationsDetailsRepository.findBySerialNoAndCaseId(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIRecommendationsDetails()));
		
		ELCMECMstASHIRecommendationsDetails recommendation = new ELCMECMstASHIRecommendationsDetails();
		recommendation.setActor("S");
		recommendation.setMailId("suraj");
		Mockito.when(recommendationsDetailsRepository.save(Mockito.any())).thenReturn(recommendation);
		
		Response objExpected = new Response(Constants.SUCCESSHIDEFORM, "Successfully updated recommendations for " + "Stakeholder" + " " + "suraj");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest2() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		fields.setComplainant("suraj");
		fields.setSeverityLevel("1");
		fields.setRecommendedActions("Jail");
		fields.setTransactionid("1234");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(recommendationsDetailsRepository.findBySerialNoAndCaseId(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.INVALID_INPUT);
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest3() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		fields.setComplainant("suraj");
		fields.setSeverityLevel("1");
		fields.setRecommendedActions("Jail");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIRecommendationsDetails recommendation = new ELCMECMstASHIRecommendationsDetails();
		recommendation.setActor("Z");
		recommendation.setMailId("suraj");
		Mockito.when(recommendationsDetailsRepository.save(Mockito.any())).thenReturn(recommendation);
		
		Response objExpected = new Response(Constants.SUCCESSHIDEFORM, "Successfully updated recommendations for  suraj");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest4() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		fields.setComplainant("suraj");
		fields.setSeverityLevel("1");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select atleast one recommended action");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest5() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		fields.setComplainant("suraj");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select severity level");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest6() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.WITNESS);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select witness");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest7() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.RESPONDENT);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select respondent");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest8() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setActionAgainst(Constants.COMPLAINANT);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select complainant");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest9() throws CustomException {
		
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select action against");
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addOrUpdateRecommendedActionsTest10() throws CustomException {
		
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.addOrUpdateRecommendedActions(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void getRecommendedActionsTest1() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIRecommendationsDetails recommendation = new ELCMECMstASHIRecommendationsDetails();
		recommendation.setCaseId(1);
		recommendation.setActor("A");
		recommendation.setMailId("surajkumar.dewangan");
		recommendation.setSerialNo(1);
		recommendation.setActions("Jail");
		Mockito.when(recommendationsDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(recommendation));
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		Mockito.when(property.getRecommendationDeleteURL()).thenReturn("url");
		
		CardView objActual = adminService.getRecommendedActions(1, true);

		assertEquals(1, objActual.getCards().size());
		assertEquals(1, objActual.getActions().size());
		assertEquals(2, objActual.getCards().get(0).getFields().size());
		assertEquals(2, objActual.getCards().get(0).getActions().size());
	}
	
	@Test
	void getRecommendedActionsTest2() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIRecommendationsDetails recommendation = new ELCMECMstASHIRecommendationsDetails();
		recommendation.setCaseId(1);
		recommendation.setActor("A");
		recommendation.setMailId("surajkumar.dewangan");
		recommendation.setSerialNo(1);
		recommendation.setActions("Jail");
		Mockito.when(recommendationsDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList(recommendation));
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		CardView objActual = adminService.getRecommendedActions(1, false);

		assertEquals(1, objActual.getCards().size());
		assertEquals(0, objActual.getActions().size());
		assertEquals(2, objActual.getCards().get(0).getFields().size());
		assertEquals(0, objActual.getCards().get(0).getActions().size());
	}
	
	@Test
	void getRecommendedActionsTest3() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(recommendationsDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Arrays.asList());
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		CardView objActual = adminService.getRecommendedActions(1, false);

		assertEquals(1, objActual.getCards().size());
		assertEquals(0, objActual.getActions().size());
		assertEquals(1, objActual.getCards().get(0).getFields().size());

	}
	
	@Test
	void getRecommendedActionsTest4() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		CardView objActual = adminService.getRecommendedActions(1, false);

		assertEquals(0, objActual.getCards().size());
		assertEquals(0, objActual.getActions().size());

	}
	
	@Test
	void deleteRecommendedActionsTest1() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIRecommendationsDetails recommendation = new ELCMECMstASHIRecommendationsDetails();
		recommendation.setActor("A");
		recommendation.setMailId("suraj");
		Mockito.when(recommendationsDetailsRepository.findBySerialNoAndCaseId(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.of(recommendation));
		
		Response objExpected = new Response(Message.SUCCESS, "Successfully deleted recommendations for " + Constants.COMPLAINANT + " " + recommendation.getMailId());
		
		Response objActual = adminService.deleteRecommendedActions(1, 1);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void deleteRecommendedActionsTest2() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(recommendationsDetailsRepository.findBySerialNoAndCaseId(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.INVALID_INPUT);
		
		Response objActual = adminService.deleteRecommendedActions(1, 1);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void deleteRecommendedActionsTest3() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.deleteRecommendedActions(1, 1);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void getIssueSummonGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true, false);

		GenModel objActual1 = adminService.getIssueSummonGenmodel(1);
		GenModel objActual2 = adminService.getIssueSummonGenmodel(1);
		
		assertEquals(3, objActual1.getFields().size());
		assertEquals(1, objActual1.getActions().size());
		assertTrue(objActual2.getFields().isEmpty());
		assertTrue(objActual2.getActions().isEmpty());
	}
	
	@Test
	void issueSummonTest1() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest2() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select Issue Summons to");
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	
	@Test
	void issueSummonTest3() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo(Constants.COMPLAINANT);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select Summons With");
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest4() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo(Constants.WITNESS);
		fields.setSummonsWith("surajkumar.dewangan");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(summonsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstASHISummonsDetails()));
		
		Response objExpected = new Response("Already issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest5() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo(Constants.RESPONDENT);
		fields.setSummonsWith("surajkumar.dewangan");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(summonsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected = new Response(Message.SUCCESS, "Successfully issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest6() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo(Constants.COMPLAINANT);
		fields.setSummonsWith("surajkumar.dewangan");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(summonsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected = new Response(Message.SUCCESS, "Successfully issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest7() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo("Co-Complainant");
		fields.setSummonsWith("surajkumar.dewangan");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(summonsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected = new Response(Message.SUCCESS, "Successfully issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());
		
		Response objActual = adminService.issueSummon(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void issueSummonTest8() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSummonsTo(Constants.WITNESS);
		fields.setSummonsWith("surajkumar.dewangan");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(summonsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.issueSummon(new GenModel()),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
	}
	
	@Test
	void getIssuedSummonsTest1() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHISummonsDetails summon = new ELCMECMstASHISummonsDetails(1, "A", "suarj", "IC", "1030816", dateTime);
		Mockito.when(summonsDetailsRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(Arrays.asList(summon,summon,summon));
	
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		CardView objActual = adminService.getIssuedSummons(1, 1);

		assertEquals(2, objActual.getCards().size());
		assertEquals(3, objActual.getCards().get(0).getFields().size());

	}
	
	@Test
	void getIssuedSummonsTest2() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(summonsDetailsRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(Arrays.asList());
		
		CardView objActual = adminService.getIssuedSummons(1, 1);

		assertEquals(1, objActual.getCards().size());
		assertEquals(1, objActual.getCards().get(0).getFields().size());

	}
	
	@Test
	void getIssuedSummonsTest3() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		CardView objActual = adminService.getIssuedSummons(1, 1);

		assertEquals(0, objActual.getCards().size());

	}
	
	@Test
	void getEmployeesByActorTest1() throws CustomException {
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption()));
		
		List<GenModelOption> objActual1 = adminService.getEmployeesByActor(1, "A");
		List<GenModelOption> objActual2 = adminService.getEmployeesByActor(1, Constants.COMPLAINANT);
		List<GenModelOption> objActual3 = adminService.getEmployeesByActor(1, "R");
		List<GenModelOption> objActual4 = adminService.getEmployeesByActor(1, Constants.RESPONDENT);
		List<GenModelOption> objActual5 = adminService.getEmployeesByActor(1, "W");
		List<GenModelOption> objActual6 = adminService.getEmployeesByActor(1, Constants.WITNESS);
		List<GenModelOption> objActual7 = adminService.getEmployeesByActor(1, "S");

		assertEquals(1, objActual1.size());
		assertEquals(1, objActual2.size());
		assertEquals(1, objActual3.size());
		assertEquals(1, objActual4.size());
		assertEquals(1, objActual5.size());
		assertEquals(1, objActual6.size());
		assertEquals(0, objActual7.size());

	}
	
	@Test
	void getEmployeesByActorTest2() throws CustomException {
		List<GenModelOption> objActual7 = adminService.getEmployeesByActor(1, "S");
		assertEquals(0, objActual7.size());

	}
	
	@Test
	void getFormalReportGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECMstASHIFormalInvestigationReportDetails> report = Optional.of(new ELCMECMstASHIFormalInvestigationReportDetails());
		report.get().setSummary("summary");
		report.get().setOtherRecommendations("otherRecommendations");
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);
		
		GenModel objActual = adminService.getFormalReportGenmodel(1);
		
		assertEquals(4, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void getFormalReportGenmodelTest2()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		GenModel objActual = adminService.getFormalReportGenmodel(1);
		
		assertEquals(4, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void getFormalReportGenmodelTest3()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		GenModel objActual = adminService.getFormalReportGenmodel(1);
		
		assertEquals(0, objActual.getFields().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void submitFormalReportTest1() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFormalCaseSummary("formalCaseSummary");
		fields.setFormalInvestigationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitFormalReportTest2() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFormalCaseSummary("formalCaseSummary");
		fields.setFormalInvestigationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Mockito.when(commonservice.getUIModuleId(Mockito.anyString())).thenReturn("1234");
		
		this.updateCaseAndActionDetailsWithNextStatusMock("FRP");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "Successfully saved report.", "", "1234/0");
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitFormalReportTest3() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFormalCaseSummary("formalCaseSummary");
		fields.setFormalInvestigationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
				
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitFormalReportTest4() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFormalCaseSummary("formalCaseSummary");
		fields.setFormalInvestigationDocs(Arrays.asList());
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload case investigation documents");
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitFormalReportTest5() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please provide case summary");
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitFormalReportTest6() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.submitFormalReport("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void getFormalReportDetailsTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECMstASHIFormalInvestigationReportDetails> report = Optional.of(new ELCMECMstASHIFormalInvestigationReportDetails());
		report.get().setSummary("summary");
		report.get().setOtherRecommendations("otherRecommendations");
		report.get().setDmsInvestigationDocs("doc1.pdf,doc2.pdf");
		report.get().setFlgInvestigationPanelApproval(1);
		report.get().setDmsInvestigationPanelApprovals("doc1.pdf");
		report.get().setFlgPresidingOfficersApproval(1);
		report.get().setDmsPresidingOfficersApprovals("doc1.pdf");
		report.get().setFlgExtICMembersApproval(1);
		report.get().setDmsExtICMembersApprovals("doc1.pdf");
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);
		Mockito.when(property.getDownloadURL()).thenReturn("url");
		Mockito.when(property.getDownloadTemplateURL()).thenReturn("url");
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "FRP", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		LabelView objActual = adminService.getFormalReportDetails(1);
		
		assertEquals(12, objActual.getView().getFields().size());
		assertEquals(1, objActual.getView().getActions().size());
	}
	
	@Test
	void getFormalReportDetailsTest2()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECMstASHIFormalInvestigationReportDetails> report = Optional.of(new ELCMECMstASHIFormalInvestigationReportDetails());
		report.get().setSummary("summary");
		report.get().setOtherRecommendations("otherRecommendations");
		report.get().setInvestigationPanelReason("investigationPanelReason");
		report.get().setExtICMembersReason("extICMembersReason");
		report.get().setPresidingOfficersReason("presidingOfficersReason");
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(report);

		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WCC", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		LabelView objActual = adminService.getFormalReportDetails(1);
		
		assertEquals(5, objActual.getView().getFields().size());
		assertEquals(0, objActual.getView().getActions().size());
	}
	
	@Test
	void getCommentsLabelTest1()  throws Exception{
		
		List<ELCMECTrnASHIActionDetails> actionObj = Arrays.asList(new ELCMECTrnASHIActionDetails(1234, "GRB", "WCC", "comment", "self", dateTime, "")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndGreaterThanCaseActionId(Mockito.anyInt(), Mockito.anyString())).thenReturn(actionObj);
		
		LabelView objActual = adminService.getCommentsLabel(1);
		
		assertEquals(1, objActual.getView().getFields().size());
	}
	
	@Test
	void getCommentsLabelTest2()  throws Exception{
		
		List<ELCMECTrnASHIActionDetails> actionObj = Arrays.asList(new ELCMECTrnASHIActionDetails(1234, "GRB", "WGU", "", "self", dateTime, "DMSFileName")); 
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndGreaterThanCaseActionId(Mockito.anyInt(), Mockito.anyString())).thenReturn(actionObj);
		Mockito.when(property.getDownloadURL()).thenReturn("url");
		
		LabelView objActual = adminService.getCommentsLabel(1);
		
		assertEquals(2, objActual.getView().getFields().size());
	}
	
	@Test
	void getCommentsLabelTest3()  throws Exception{
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndGreaterThanCaseActionId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList());
		
		LabelView objActual = adminService.getCommentsLabel(1);
		
		assertEquals(0, objActual.getView().getFields().size());
	}
	
	@Test
	void getUploadApprovalsGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true, false);
		
		GenModel objActual1 = adminService.getUploadApprovalsGenmodel(1);
		GenModel objActual2 = adminService.getUploadApprovalsGenmodel(1);
		
		assertEquals(10, objActual1.getFields().size());
		assertEquals(2, objActual1.getActions().size());
		assertEquals(0, objActual2.getFields().size());
		assertEquals(0, objActual2.getActions().size());
	}
	
	@Test
	void submitApprovalsTest1() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIFormalInvestigationReportDetails()));
				
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest2() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIFormalInvestigationReportDetails()));
				
		this.updateCaseAndActionDetailsWithNextStatusMock("WI");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", null);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest3() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles, dmsFiles, Message.INVALID_FILE);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest4() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles, Message.INVALID_FILE);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest5() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest6() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		Mockito.when(formalInvestigationReportDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest7() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please provide reason for not uploading approvals from Investigation Panel.");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest8() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please provide reason for not uploading approvals from External IC Members.");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest9() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please provide reason for not uploading approvals from Presiding Officers.");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest10() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(1);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload approvals from Investigation Panel");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest11() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(0);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(1);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload approvals from Presiding Officers");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest12() throws CustomException {
		GMFields fields =new GMFields();
		fields.setFlgInvestigationPanelApproval(0);
		fields.setInvestigationPanelApprovals(Arrays.asList());
		fields.setInvestigationPanelReason("investigationPanelReason");
		fields.setFlgExtICMembersApproval(1);
		fields.setExtICMembersapprovals(Arrays.asList());
		fields.setExtICMembersReason("extICMembersReason");
		fields.setFlgPresidingOfficersApproval(0);
		fields.setPresidingOfficersApprovals(Arrays.asList());
		fields.setPresidingOfficersReason("presidingOfficersReason");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload approvals from External IC Members");
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void submitApprovalsTest13() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());

		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.submitApprovals("1030816", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void actionSLAExtensionTest1() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Optional<ELCMECMstSysParams> sysParam = Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("28");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(sysParam);
		
		Mockito.when(slaAuditTrialRepository.countBySlaId(Mockito.anyInt())).thenReturn(1);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected = new Response(Constants.SUCCESSPROCEED, "Successfully requested for SLA extension.", "", null);
		
		Response objActual = adminService.actionSLAExtension(false, true, "123", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());

	}
	
//	@Test
//	void actionSLAExtensionTest2() throws CustomException {
//		GMFields fields =new GMFields();
//		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
//		fields.setExtensionReason("extensionReason");
//		fields.setComments("comments");
//		
//		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
//		
//		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
//
//		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
//		slaDetails.get().setFlgSLAExtensionRequest(0);
//		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
//		
//		Optional<ELCMECMstSysParams> sysParam = Optional.of(new ELCMECMstSysParams());
//		sysParam.get().setParamValue("28");
//		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(sysParam);
//		
//		Mockito.when(slaAuditTrialRepository.countBySlaId(Mockito.anyInt())).thenReturn(1);
//		
//		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
//		actionObj.get().setAssigneeLocation("Hyderabad");
//		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
//		
//		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
//		
//		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
//		
//		CustomException thrown = assertThrows(
//				CustomException.class,
//				() -> adminService.actionSLAExtension(false, true, "123", new GenModel()),
//				Message.MAIL_NOT_TRIGGERED
//				);
//
//		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
//	}
	
	@Test
	void actionSLAExtensionTest2() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Optional<ELCMECMstSysParams> sysParam = Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("28");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(sysParam);
		
		Mockito.when(slaAuditTrialRepository.countBySlaId(Mockito.anyInt())).thenReturn(1);

		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.actionSLAExtension(false, true, "123", new GenModel()),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));

	}
	
	@Test
	void actionSLAExtensionTest3() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(dateTime));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Response objExpected = new Response("Invalid Extended date.");
		
		Response objActual = adminService.actionSLAExtension(false, true, "123", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());

	}
	
	@Test
	void actionSLAExtensionTest4() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Optional<ELCMECMstSysParams> sysParam = Optional.of(new ELCMECMstSysParams());
		sysParam.get().setParamValue("2");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(sysParam);
		
		Response objExpected = new Response("Extension can be requested for maximum " + 2 + " days only at a time.");
		
		Response objActual = adminService.actionSLAExtension(false, true, "123", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());

	}
	
	@Test
	void actionSLAExtensionTest5() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(1);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);

		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		Response objExpected = new Response("Already requested for SLA extension.");
		
		Response objActual = adminService.actionSLAExtension(false, true, "123", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());

	}
	
	@Test
	void actionSLAExtensionTest6() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		ELCMECtrnASHISLAAuditTrial slaAuditDetails = new ELCMECtrnASHISLAAuditTrial();
		slaAuditDetails.setStatus("");
		Mockito.when(slaAuditTrialRepository.findByExtensionId(Mockito.anyInt())).thenReturn(Optional.of(slaAuditDetails));
		
		Mockito.when(slaDetailsRepository.save(Mockito.any())).thenReturn(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected1 = new Response(Constants.SUCCESSPROCEED, Message.SUCCESSFULLY_NEW + Constants.APPROVED + " SLA extension.", "", null);
		
		Response objActual1 = adminService.actionSLAExtension(true, true, "123", new GenModel());

		assertEquals(objExpected1.getType(), objActual1.getType());
		assertEquals(objExpected1.getContent(), objActual1.getContent());



	}
	
	@Test
	void actionSLAExtensionTest7() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		ELCMECtrnASHISLAAuditTrial slaAuditDetails = new ELCMECtrnASHISLAAuditTrial();
		slaAuditDetails.setStatus("");
		Mockito.when(slaAuditTrialRepository.findByExtensionId(Mockito.anyInt())).thenReturn(Optional.of(slaAuditDetails));
		
		Mockito.when(slaDetailsRepository.save(Mockito.any())).thenReturn(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = Optional.of(new ELCMECTrnASHIActionDetails(1234, "GRB", "WG", "", "self", dateTime, "DMSFileName")); 
		actionObj.get().setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(Mockito.anyInt())).thenReturn(actionObj);
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> adminService.actionSLAExtension(true, false, "123", new GenModel()),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));


	}
	
	@SuppressWarnings("unchecked")
	@Test
	void actionSLAExtensionTest8() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		ELCMECtrnASHISLAAuditTrial slaAuditDetails1 = new ELCMECtrnASHISLAAuditTrial();
		slaAuditDetails1.setStatus(Constants.APPROVED);
		ELCMECtrnASHISLAAuditTrial slaAuditDetails2 = new ELCMECtrnASHISLAAuditTrial();
		slaAuditDetails2.setStatus(Constants.REJECTED);
		Mockito.when(slaAuditTrialRepository.findByExtensionId(Mockito.anyInt())).thenReturn(Optional.of(slaAuditDetails1), Optional.of(slaAuditDetails2));
		
		
		Response objExpected1 = new Response("Request has been already approved.");
		Response objExpected2 = new Response("Request has been already rejected.");
		
		Response objActual1 = adminService.actionSLAExtension(true, true, "123", new GenModel());
		Response objActual2 = adminService.actionSLAExtension(true, false, "123", new GenModel());

		assertEquals(objExpected1.getType(), objActual1.getType());
		assertEquals(objExpected1.getContent(), objActual1.getContent());
		assertEquals(objExpected2.getType(), objActual2.getType());
		assertEquals(objExpected2.getContent(), objActual2.getContent());



	}
	
	@Test
	void actionSLAExtensionTest9() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		Mockito.when(slaAuditTrialRepository.findByExtensionId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		
		Response objExpected = new Response("Extension request not found");
		
		Response objActual = adminService.actionSLAExtension(true, true, "123", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest10() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = Optional.of(new ELCMECtrnASHIConcernSLADetails(1, 30, "IC", dateTime, dateTime, ""));
		slaDetails.get().setFlgSLAExtensionRequest(0);
		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(slaDetails);
		
		
		Response objExpected = new Response(Message.INVALID_INPUT);
		
		Response objActual = adminService.actionSLAExtension(true, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest11() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("comments");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(slaDetailsRepository.findByCaseIdAndRole(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());
		
		
		Response objExpected = new Response("Unable to request");
		
		Response objActual = adminService.actionSLAExtension(true, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest12() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("extensionReason");
		fields.setComments("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
	
		Response objExpected = new Response("Please enter your comment.");
		
		Response objActual = adminService.actionSLAExtension(true, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest13() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate(new SimpleDateFormat(Constants.DATE_FORMAT).format(new Timestamp(System.currentTimeMillis() + 432000000)));
		fields.setExtensionReason("");
		fields.setComments("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);	
		
		Response objExpected = new Response("Please select extension reason");
		
		Response objActual = adminService.actionSLAExtension(false, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest14() throws CustomException {
		GMFields fields =new GMFields();
		fields.setSlaExtendDate("");
		fields.setExtensionReason("");
		fields.setComments("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
	
		Response objExpected = new Response("Please provide SLA extension date");
		
		Response objActual = adminService.actionSLAExtension(false, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void actionSLAExtensionTest15() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.actionSLAExtension(true, true, "", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());

	}
	
	@Test
	void addFindingsGenmodelTest1()  throws Exception{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList());
		
		GenModel objActual = adminService.addFindingsGenmodel(1, "", 1);
		
		assertEquals(3, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void addFindingsGenmodelTest2()  throws Exception{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("dab", "dain")));
		
		GenModel objActual = adminService.addFindingsGenmodel(1, "", 4);
		
		assertEquals(3, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void addFindingsGenmodelTest3()  throws Exception{
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true, false);
		
		GenModel objActual1 = adminService.addFindingsGenmodel(1, "", 2);
		GenModel objActual2 = adminService.addFindingsGenmodel(1, "", 2);
		GenModel objActual3 = adminService.addFindingsGenmodel(1, "", 5);
		
		assertEquals(7, objActual1.getFields().size());
		assertEquals(2, objActual1.getActions().size());
		assertEquals(0, objActual2.getFields().size());
		assertEquals(0, objActual2.getActions().size());
		assertEquals(0, objActual3.getFields().size());
		assertEquals(0, objActual3.getActions().size());
	}
	
	@Test
	void addFindingsGenmodelTest4()  throws Exception{
		Optional<ELCMECMstASHIAllegationsAndFindingsDetails> finding = Optional.of(new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation", "finding", "outcome", 0, "", "", dateTime, "", dateTime));
		Mockito.when(allegationsAndFindingsDetailsRepository.findById(Mockito.anyInt())).thenReturn(finding);
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("dab", "dain")));
		
		GenModel objActual = adminService.addFindingsGenmodel(1, "123", 3);
		
		assertEquals(7, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void addFindingsGenmodelTest5()  throws Exception{
		Optional<ELCMECMstASHIAllegationsAndFindingsDetails> finding = Optional.of(new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation", "finding", "outcome", 0, "", "", dateTime, "", dateTime));
		Mockito.when(allegationsAndFindingsDetailsRepository.findById(Mockito.anyInt())).thenReturn(finding);
		
		Mockito.when(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new GenModelOption("dab", "dain")));
		
		GenModel objActual = adminService.addFindingsGenmodel(1, "123", 3);
		
		assertEquals(7, objActual.getFields().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void addFindingsTest1() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(true, Arrays.asList(new  ViewCurrEmpAllDetails("surajkumar.dewangan", "1030816", "Suraj")));
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		Response objExpected = new Response(Constants.SUCCESSHIDEFORM, "Successfully added findings");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest2() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		CaseDetailsValidationResponse response =new CaseDetailsValidationResponse(false, "Invalid employee");
		Mockito.when(commonservice.validateEmployeeDetails(Mockito.anyString(),Mockito.anyString())).thenReturn(response);
		
		Response objExpected = new Response("Invalid employee");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest3() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(allegationsAndFindingsDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIAllegationsAndFindingsDetails()));
		
		Response objExpected = new Response(Constants.SUCCESSHIDEFORM, "Successfully updated finding");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest4() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(allegationsAndFindingsDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response("Unable to update");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest5() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select outcome");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest6() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please enter findings");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest7() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc(null);
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please enter Allegation description");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest8() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType("A");
		fields.setRecipient(Arrays.asList());
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select recipient");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest9() throws CustomException {
		GMFields fields =new GMFields();
		fields.setRecipientType(Constants.SELECT);
		fields.setRecipient(Arrays.asList("1030816"));
		fields.setFindings("findings");
		fields.setOutcome("outcome");
		fields.setAllegationDesc("allegationDesc");
		fields.setTransactionid("123");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Response objExpected = new Response("Please select recipient type");
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void addFindingsTest10() throws CustomException {
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.addFindings(new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void getFindingsTest1() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new Findings()));
		
		Mockito.when(property.getSendFindingsGenmodelURL()).thenReturn("url");
		
		InboxView objActual = adminService.getFindings(true, new FindingFilter(1, "A", "suraj"));

		assertEquals(1, objActual.getRow().size());
		assertEquals(2, objActual.getRow().get(0).getActions().size());
		assertEquals(2, objActual.getActions().size());
	}
	
	@Test
	void getFindingsTest2() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Findings finding = new Findings(1, "", "", "", 1);
		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(finding));
		
		InboxView objActual = adminService.getFindings(false, new FindingFilter(1, "A", "suraj"));

		assertEquals(1, objActual.getRow().size());
		assertEquals(0, objActual.getRow().get(0).getActions().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void getFindingsTest3() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList());
		
		InboxView objActual = adminService.getFindings(false, new FindingFilter(1, "suraj", "A"));

		assertEquals("No findings found for " + "A" + " " + "suraj", objActual.getName());

	}
	
	@Test
	void getFindingsTest4() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		InboxView objActual = adminService.getFindings(false, new FindingFilter(1, "", "A"));

		assertEquals("Please select recipient", objActual.getName());

	}
	
	@Test
	void getFindingsTest5() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		InboxView objActual = adminService.getFindings(false, new FindingFilter(1, "suraj", ""));

		assertEquals("Please select recipient type", objActual.getName());

	}
	
	@Test
	void getFindingsTest6() throws CustomException {

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);
		InboxView objActual = adminService.getFindings(false, new FindingFilter(1, "A", "suraj"));

		assertEquals(Message.CASENOTREGISTERED, objActual.getName());

	}
	
	@SuppressWarnings("unchecked")
	@Test
	void deleteFindingsTest1() throws CustomException {
		Mockito.when(allegationsAndFindingsDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIAllegationsAndFindingsDetails()), Optional.empty());
		
		Response objExpected1 = new Response(Message.SUCCESS, "Successfully deleted finding");
		Response objExpected2 = new Response("Unable to delete finding");
		
		Response objActual1 = adminService.deleteFindings(1);
		Response objActual2 = adminService.deleteFindings(1);

		assertEquals(objExpected1.getType(), objActual1.getType());
		assertEquals(objExpected1.getContent(), objActual1.getContent());
		assertEquals(objExpected2.getType(), objActual2.getType());
		assertEquals(objExpected2.getContent(), objActual2.getContent());

	}
	
	@Test
	void sendFindingsGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Findings finding = new Findings();
		finding.setAllegation("allegation");;
		finding.setFinding("finding");
		finding.setOutcome("outcome");
		finding.setEmpName("suraj");
		finding.setAssigneeLocation("Hyderabad");
		List<Findings> findings = Arrays.asList(finding);
		Mockito.when(allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(findings);
		
		Mockito.when(property.getSendFindingsURL()).thenReturn("url");
		
		GenModel objActual1 = adminService.sendFindingsGenmodel(1, "A", "suraj");
		GenModel objActual2 = adminService.sendFindingsGenmodel(1, "R", "suraj");
		
		assertEquals(1, objActual1.getFields().size());
		assertEquals(2, objActual1.getActions().size());
		assertEquals(1, objActual2.getFields().size());
		assertEquals(2, objActual2.getActions().size());
	}
	
	@Test
	void sendFindingsGenmodelTest2()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>());

		
		GenModel objActual = adminService.sendFindingsGenmodel(1, "A", "suraj");
		
		assertEquals(0, objActual.getFields().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void sendFindingsGenmodelTest3()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		GenModel objActual = adminService.sendFindingsGenmodel(1, "A", "suraj");
		
		assertEquals(0, objActual.getFields().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void sendFindingsTest1() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Findings finding = new Findings();
		finding.setAllegation("allegation");;
		finding.setFinding("finding");
		finding.setOutcome("outcome");
		finding.setEmpName("suraj");
		finding.setAssigneeLocation("Hyderabad");
		List<Findings> findings = Arrays.asList(finding);
		Mockito.when(allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(findings);
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Mockito.when(allegationsAndFindingsDetailsRepository.findBySerialNoIn(Mockito.anyList())).thenReturn(Arrays.asList(new ELCMECMstASHIAllegationsAndFindingsDetails()));
		
		Response objExpected = new Response(Constants.SUCCESSHIDEFORM, "Successfully sent findings to " + Constants.COMPLAINANT + " " + "suraj");
		
		Response objActual = adminService.sendFindings("1030816", 1, "A", "suraj");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void sendFindingsTest2() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Findings finding = new Findings();
		finding.setAllegation("allegation");;
		finding.setFinding("finding");
		finding.setOutcome("outcome");
		finding.setEmpName("suraj");
		finding.setAssigneeLocation("Hyderabad");
		List<Findings> findings = Arrays.asList(finding);
		Mockito.when(allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(findings);
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> adminService.sendFindings("1030816", 1, "R", "suraj"),
		"suraj" +" findings "+Message.MAIL_NOT_TRIGGERED
		);

		assertTrue(thrown.getMessage().contains("suraj" +" findings "+Message.MAIL_NOT_TRIGGERED));
	}
	
	@Test
	void sendFindingsTest3() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>());

		Response objExpected = new Response(Message.ERROR, "Finding details not found");
		
		Response objActual = adminService.sendFindings("1030816", 1, "A", "suraj");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void sendFindingsTest4() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(null);

		Response objExpected = new Response(Message.ERROR, "Mail content not found");
		
		Response objActual = adminService.sendFindings("1030816", 1, "A", "suraj");

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	

	@Test
	void consolidatedFindingsGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIAllegationsAndFindingsDetails finding1 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation1", "finding1", "outcome1", 1, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding2 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "R", "dinesh", "allegation2", "finding2", "outcome2", 0, "", "1030816", dateTime, "1030816", dateTime);
		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = Arrays.asList(finding1, finding2);
		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(Mockito.anyInt())).thenReturn(findings);
		
		GenModel objActual = adminService.consolidatedFindingsGenmodel(1);
		
		assertEquals(1, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void consolidatedFindingsGenmodelTest2()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIAllegationsAndFindingsDetails finding1 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation", "finding", "outcome", 1, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding2 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "R", "dinesh", "allegation", "finding", "outcome", 1, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding3 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "R", "dinesh", "allegation", "finding", "outcome", 0, "", "1030816", dateTime, "1030816", dateTime);
		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = Arrays.asList(finding1, finding2, finding3);
		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(Mockito.anyInt())).thenReturn(findings);
		
		GenModel objActual = adminService.consolidatedFindingsGenmodel(1);
		
		assertEquals(1, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void consolidatedFindingsGenmodelTest3()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIAllegationsAndFindingsDetails finding1 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation", "finding", "outcome", 1, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding2 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "dinesh", "allegation", "finding", "outcome", 0, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding3 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "R", "pavan", "allegation", "finding", "outcome", 0, "", "1030816", dateTime, "1030816", dateTime);
		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = Arrays.asList(finding1, finding2, finding3);
		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(Mockito.anyInt())).thenReturn(findings);
		
		GenModel objActual = adminService.consolidatedFindingsGenmodel(1);
		
		assertEquals(1, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void consolidatedFindingsGenmodelTest4()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIAllegationsAndFindingsDetails finding1 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "suraj", "allegation", "finding", "outcome", 1, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding2 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "A", "dinesh", "allegation", "finding", "outcome", 0, "", "1030816", dateTime, "1030816", dateTime);
		ELCMECMstASHIAllegationsAndFindingsDetails finding3 = new ELCMECMstASHIAllegationsAndFindingsDetails(1, 1, "R", "dinesh", "allegation", "finding", "outcome", 0, "", "1030816", dateTime, "1030816", dateTime);
		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = Arrays.asList(finding1, finding2, finding3);
		Mockito.when(allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(Mockito.anyInt())).thenReturn(findings);
		
		GenModel objActual = adminService.consolidatedFindingsGenmodel(1);
		
		assertEquals(1, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void consolidatedFindingsGenmodelTest5()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		GenModel objActual = adminService.consolidatedFindingsGenmodel(1);
		
		assertEquals(0, objActual.getFields().size());
		assertEquals(0, objActual.getActions().size());
	}
	
	@Test
	void getDownloadTemplateGenmodelTest1()  throws Exception{

		GenModel objActual = adminService.getDownloadTemplateGenmodel();
		
		assertEquals(2, objActual.getFields().size());
		assertEquals(1, objActual.getActions().size());
	}
	
	@Test
	void downloadTemplateTest1() throws CustomException {
		GMFields fields =new GMFields();
		fields.setTemplate("template");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		DMSModel doc = new DMSModel();
		doc.setDocumentName("documentName");
		doc.setDocumentBytes("documentBytes");
		Mockito.when(commonservice.dmsService(Mockito.any(), Mockito.anyString())).thenReturn(doc);
		//Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		DocumentData objExpected = new DocumentData(doc.getDocumentName(), doc.getDocumentBytes());
		
		DocumentData objActual = adminService.downloadTemplate(new GenModel());

		assertEquals(objExpected.getFilename(), objActual.getFilename());
		assertEquals(objExpected.getBase64file(), objActual.getBase64file());
	}
	
	@Test
	void downloadTemplateTest2() throws CustomException {
		GMFields fields =new GMFields();
		fields.setTemplate("");
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		DocumentData objExpected = new DocumentData(Message.ERROR, "Please select template.");
		
		DocumentData objActual = adminService.downloadTemplate(new GenModel());

		assertEquals(objExpected.getFilename(), objActual.getFilename());
		assertEquals(objExpected.getBase64file(), objActual.getBase64file());
	}
	
	@Test
	void getFormalReportCheckListGenmodelTest1()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndActor(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption("123", "suraj")));
		
		GenModel objActual1 = adminService.getFormalReportCheckListGenmodel(1);
		
		assertEquals(9, objActual1.getFields().size());
		assertEquals(1, objActual1.getActions().size());
	}
	
	@Test
	void getFormalReportCheckListGenmodelTest2()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndActor(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList());
		
		GenModel objActual2 = adminService.getFormalReportCheckListGenmodel(1);

		assertEquals(6, objActual2.getFields().size());
		assertEquals(1, objActual2.getActions().size());
	}
	
	@Test
	void getFormalReportCheckListGenmodelTest3()  throws Exception{
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		GenModel objActual1 = adminService.getFormalReportCheckListGenmodel(1);
		
		assertEquals(0, objActual1.getFields().size());
		assertEquals(0, objActual1.getActions().size());
	}
	
	@Test
	void updateFormalReportCheckListTest1() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(1));
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		ELCMECMstASHIRecommendationsDetails recom = new ELCMECMstASHIRecommendationsDetails();
		recom.setSerialNo(1);
		recom.setFlgImplemented(1);
		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndFlgImplemented(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Arrays.asList(recom));
		
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHIInvestigationDetails()));
		
		this.updateCaseAndActionDetailsWithNextStatusMock("CLF");
		
		Response objExpected = new Response(Message.SUCCESSPROCEED, "message", "", null);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	
	@Test
	void updateFormalReportCheckListTest2() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	
	@Test
	void updateFormalReportCheckListTest3() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles=Message.INVALID_FILE;
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn("filename", dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		Response objExpected = new Response(Message.INVALID_FILE);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest4() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(1));
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		ELCMECMstASHIRecommendationsDetails recom = new ELCMECMstASHIRecommendationsDetails();
		recom.setSerialNo(1);
		recom.setFlgImplemented(1);
		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndFlgImplemented(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Arrays.asList());
		
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHIInvestigationDetails()));
		
		this.updateCaseAndActionDetailsNegativeMock();
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest5() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(1));
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		ELCMECMstASHIRecommendationsDetails recom = new ELCMECMstASHIRecommendationsDetails();
		recom.setSerialNo(1);
		recom.setFlgImplemented(1);
		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndFlgImplemented(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Arrays.asList());
		
//		Mockito.when(investigationDetailsRepository.findByCaseId(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.UNABLE_TO_PROCEED);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest6() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(2));
		fields.setImplementationDocs(Arrays.asList(new DocumentData("filename", "base64file")));
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		String dmsFiles="filename";
		Mockito.when(commonservice.validateAndUploadDocumentsToDMS(Mockito.anyList(),Mockito.anyString())).thenReturn(dmsFiles);
		Mockito.when(property.getDmsASHIInvestigationDocsFolder()).thenReturn("");
		
		ELCMECMstASHIRecommendationsDetails recom = new ELCMECMstASHIRecommendationsDetails();
		recom.setSerialNo(1);
		recom.setFlgImplemented(0);
		Mockito.when(recommendationsDetailsRepository.findByCaseIdAndFlgImplemented(Mockito.anyInt(), Mockito.anyInt())).thenReturn(Arrays.asList(recom));
		
		Response objExpected = new Response("All the recommended actions must be implemented before closing the case.");
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest7() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(2));
		fields.setImplementationDocs(Arrays.asList());
		fields.setDocuments(Arrays.asList(new DocumentData("filename", "base64file")));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload Implementaion documents.");
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest8() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList());
		fields.setCheckedRecommendations(Arrays.asList(2));
		fields.setDocuments(Arrays.asList());
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Please upload Closure document.");
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest9() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(1);
		fields.setUncheckedRecommendations(Arrays.asList(1,2));
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("All the recommended actions must be implemented before closing the case.");
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest10() throws CustomException {
		
		GMFields fields =new GMFields();
		fields.setFlgBothPartiesClosure(0);
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHICaseDetails()));
		
		Response objExpected = new Response("Closure with both the parties is mandatory before closing the case.");
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void updateFormalReportCheckListTest11() throws CustomException {
		
		GMFields fields =new GMFields();
		
		Mockito.when(commonservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		Mockito.when(caseDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
		
		Response objExpected = new Response(Message.CASENOTREGISTERED);
		
		Response objActual = adminService.updateFormalReportCheckList("", new GenModel());

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void triggerEmployeeNotificationMailTest1() throws CustomException {
		
		Mockito.when(ashiCocomplainantsDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHICocomplainantsDetails(1, "suraj")));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new EmployeeDetails("suraj", "1030816", "suraj")));
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response objExpected = new Response(Message.SUCCESS, "Successfully triggered notification mail to the " + "Co-Complainant");
		
		Response objActual = adminService.triggerEmployeeNotificationMail(1, "T", 1);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void triggerEmployeeNotificationMailTest2() throws CustomException {
		ELCMECMstASHICaseEmployeeDetails details = new ELCMECMstASHICaseEmployeeDetails();
		details.setMailId("suraj");
		details.setEmpName("suraj");
		Mockito.when(caseEmployeeDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(details));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new EmployeeDetails("suraj", "1030816", "suraj")));
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		Response objExpected = new Response("Unable to send mail. Please try again.");
		
		Response objActual = adminService.triggerEmployeeNotificationMail(1, "R", 1);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
		assertEquals(objExpected.getValue(), objActual.getValue());
	}
	
	@Test
	void triggerMailsTest1() throws CustomException {
		ELCMECTrnASHIActionDetails details = new ELCMECTrnASHIActionDetails();
		details.setAssigneeLocation("Hyderabad");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(details));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(caseDetailsRepository.getDetailsForMail(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new MailEmployeeDetails("suraj", "suraj", "1030816", "dinesh", "Hyderabad", dateTime)));
		
		Mockito.when(commonservice.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("pavan@infosys.com");
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> adminService.triggerMails(1, "IC", Arrays.asList("ASHIDM"), "comment"),
		Message.MAIL_NOT_TRIGGERED
		);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));

	}
	
	@Test
	void triggerMailsTest2() throws CustomException {

		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> adminService.triggerMails(1, "IC", Arrays.asList("ASHIDM"), "comment"),
		Message.MAIL_DETAILS_NOTFOUND
		);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));

	}
	
	@Test
	void getMailContentsTest1() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(caseDetailsRepository.getDetailsForMail(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(Arrays.asList(new MailEmployeeDetails("suraj", "suraj", "1030816", "dinesh", "Hyderabad", dateTime)));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("pavan@infosys.com");
		
		List<MailContent> actual1 = adminService.getMailContents1(1, "ASHIWG", "Hyderabad", "comment");
		List<MailContent> actual2 = adminService.getMailContents1(1, "ASHIWI", "Hyderabad", "comment");

		assertEquals(1, actual1.size());
		assertEquals(1, actual2.size());

	}
	
	@Test
	void getMailContentsTest2() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));

		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("pavan@infosys.com");
		
		List<MailContent> actual1 = adminService.getMailContents1(1, "ASHIDMRI", "Hyderabad", "comment");
		List<MailContent> actual2 = adminService.getMailContents1(1, "ASHIDMRA", "Hyderabad", "comment");
		List<MailContent> actual3 = adminService.getMailContents1(1, "ASHIDMRR", "Hyderabad", "comment");
		List<MailContent> actual4 = adminService.getMailContents1(1, "ASHICIA", "Hyderabad", "comment");
		List<MailContent> actual5 = adminService.getMailContents1(1, "ASHICIR", "Hyderabad", "comment");
		List<MailContent> actual6 = adminService.getMailContents1(1, "ASHIPCR", "Hyderabad", "comment");
		List<MailContent> actual7 = adminService.getMailContents1(1, "ASHICRA", "Hyderabad", "comment");
		List<MailContent> actual8 = adminService.getMailContents1(1, "ASHICRR", "Hyderabad", "comment");
		List<MailContent> actual9 = adminService.getMailContents1(1, "ASHIWEC", "Hyderabad", "comment");
		List<MailContent> actual10 = adminService.getMailContents1(1, "ASHICANI", "Hyderabad", "comment");
		List<MailContent> actual11 = adminService.getMailContents2(1, "ASHICCEE", "Hyderabad", "comment");
		List<MailContent> actual12 = adminService.getMailContents2(1, "ASHIWGA", "Hyderabad", "comment");
		List<MailContent> actual13 = adminService.getMailContents2(1, "ASHIWER", "Hyderabad", "comment");
		List<MailContent> actual14 = adminService.getMailContents2(1, "ASHIWGU", "Hyderabad", "comment");
		List<MailContent> actual15 = adminService.getMailContents2(1, "ASHIWCC", "Hyderabad", "comment");
		List<MailContent> actual16 = adminService.getMailContents2(1, "ASHIRIF", "Hyderabad", "comment");
		List<MailContent> actual17 = adminService.getMailContents2(1, "ASHIRGF", "Hyderabad", "comment");
		List<MailContent> actual18 = adminService.getMailContents2(1, "ASHIPEF", "Hyderabad", "comment");
		List<MailContent> actual19 = adminService.getMailContents2(1, "ASHIPGF", "Hyderabad", "comment");

		assertEquals(1, actual1.size());
		assertEquals(1, actual2.size());
		assertEquals(1, actual3.size());
		assertEquals(1, actual4.size());
		assertEquals(1, actual5.size());
		assertEquals(1, actual6.size());
		assertEquals(1, actual7.size());
		assertEquals(1, actual8.size());
		assertEquals(1, actual9.size());
		assertEquals(1, actual10.size());
		assertEquals(1, actual11.size());
		assertEquals(1, actual12.size());
		assertEquals(1, actual13.size());
		assertEquals(1, actual14.size());
		assertEquals(1, actual15.size());
		assertEquals(1, actual16.size());
		assertEquals(1, actual17.size());
		assertEquals(1, actual18.size());
		assertEquals(1, actual19.size());

	}
	
	@Test
	void getMailContentsTest3() throws CustomException {

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		Mockito.when(caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(Arrays.asList(new EmployeeDetails("suraj", "1030816", "suraj")));
		
		Mockito.when(commonservice.getIdStringByRoleAndModule(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn("pavan@infosys.com");
		
		List<MailContent> actual = adminService.getMailContents2(1, "ASHICCEE", "Hyderabad", "comment");

		assertEquals(2, actual.size());

	}
	
}
