package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmecmstashicocomplainantsdetails")
public class ELCMECMstASHICocomplainantsDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="inttranid")
	private int tranId;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="flgaccept")
	private int flgAccept;
	
	@Column(name="flgreject")
	private int flgReject;
	
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="flgactive")
	private int flgActive;

	public ELCMECMstASHICocomplainantsDetails(int caseId, String mailId) {
		super();
		this.caseId = caseId;
		this.flgAccept = 0;
		this.flgReject = 0;
		this.mailId = mailId;
		this.flgActive = 1;
	}
	
	
}
