package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@Entity
@EqualsAndHashCode
@Table(name="viewcurrempalldetails")
public class ViewCurrEmpAllDetails {

	@Id
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="txtempname")
	private String empName;
	
	@Column(name="txtcurrentcityname")
	private String currentCity;
	
	@Column(name="txtdevcentrecode")
	private String devCentreCode;
	
	@Column(name="txtsbucode")
	private String sbuCode;
	
	@Transient
	private String role;

	public ViewCurrEmpAllDetails(String mailId, String empNo, String empName) {
		super();
		this.mailId = mailId!=null && !mailId.isEmpty()?mailId:"NA";
		this.empNo = empNo!=null && !empNo.isEmpty()?empNo:"NA";
		this.empName = empName!=null && !empName.isEmpty()?empName:"NA";
	}
	
	
}
