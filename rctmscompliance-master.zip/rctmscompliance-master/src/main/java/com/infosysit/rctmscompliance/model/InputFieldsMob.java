package com.infosysit.rctmscompliance.model;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InputFieldsMob {

	private String paramName;
	private int type;
	private boolean isRequired;
	private String errorMsg;
	private String displayMessage;
	private String name;
	private String placeholder;
	private String data;
	private boolean isDependent;
	private String dependentTo;
	private String url;
	private boolean isVisible;
	private int order;
	private String parentTo;
	private boolean parentView;
	private String viewUrl;
	private String maxCount;
	private String regex;
	private int length;
	private boolean isPastDateRestricted;
	private List<OptionsMob> options = new ArrayList<>();

}
