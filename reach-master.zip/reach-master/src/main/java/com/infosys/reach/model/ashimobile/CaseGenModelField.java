package com.infosys.reach.model.ashimobile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CaseGenModelField {
	private int type;
	private String name;
	private String label;
	private String displayName;
	private String existingData;
	private String data;
	private String placeHolder;
	private List<GenModelValidation> validations;
	private String dependantTo;
	private String dependantAction;
	private List<GenModelOption> options;
	@JsonProperty("isVisibleOnPageLoad")
	private boolean isVisibleOnPageLoad;

	public CaseGenModelField(int type, String name, String displayName, String data, boolean isVisibleOnPageLoad) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData = data;
		this.data = data;
		this.placeHolder = "";
		this.dependantTo = "";
		this.dependantAction = "";
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.options = new ArrayList<>();
		this.validations = new ArrayList<>();
	}

	public CaseGenModelField(int type, String name, String displayName, String data, String dependantTo,
			List<GenModelOption> options, boolean isVisibleOnPageLoad) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData = data;
		this.data = data;
		this.placeHolder = "";
		this.dependantTo = dependantTo;
		this.dependantAction = "";
		this.options = options;
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.validations = Arrays.asList(new GenModelValidation("0", "1",
				"Please select " + (displayName.isEmpty() ? name.toLowerCase() : displayName)));
	}

	public CaseGenModelField(int type, String name, String displayName, int data, String dependantTo,
			List<GenModelOption> options, boolean isVisibleOnPageLoad) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData= String.valueOf(data);
		this.data = String.valueOf(data);
		this.placeHolder = "";
		this.dependantTo = dependantTo;
		this.dependantAction = "";
		this.options = options;
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.validations = Arrays.asList(new GenModelValidation("0", "1",
				"Please select " + (displayName.isEmpty() ? name.toLowerCase() : displayName)));
	}

	public CaseGenModelField(int type, boolean isVisibleOnPageLoad, String name, String displayName, String data,
			String dependantTo, String label) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData = data;
		this.data = data;
		this.placeHolder = label;
		this.dependantTo = dependantTo;
		this.dependantAction = "";
		this.options = new ArrayList<>();
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.validations = new ArrayList<>();
	}

	public CaseGenModelField(int type, String name, String displayName, int data, String dependantTo, String label,
			boolean isVisibleOnPageLoad) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData= String.valueOf(data);
		this.data = String.valueOf(data);
		this.placeHolder = label;
		this.dependantTo = dependantTo;
		this.dependantAction = "";
		this.options = new ArrayList<>();
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.validations = new ArrayList<>();
	}

	public CaseGenModelField(int type, String name, String displayName, String dependantTo, String dependantAction,
			String label, boolean isVisibleOnPageLoad) {
		super();
		this.type = type;
		this.name = name;
		this.label = "";
		this.displayName = displayName;
		this.existingData = "";
		this.data = "";
		this.placeHolder = label;
		this.dependantTo = dependantTo;
		this.dependantAction = dependantAction;
		this.options = new ArrayList<>();
		this.isVisibleOnPageLoad = isVisibleOnPageLoad;
		this.validations = new ArrayList<>();
	}
	
	public CaseGenModelField(String name, String data) {
		super();
		this.name = name;
		this.data = data;
	}

}
