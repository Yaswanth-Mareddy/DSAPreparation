package com.infosys.hello.springboot.telemetry;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.sunbird.common.models.util.JsonKey;

import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryEvents;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;

@Component

public class ErrorEvent extends Event {

	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();

	public void setTelemetryData( String message, String statusCode, String methodName) {

		super.initializeRequestInfo();
		setEventData(statusCode, message, methodName);

	}

	public void setEventData(String statusCode, String message, String methodName) {

		// Send Telemetry events

		Map<String, Object> telemetryInfo = requestInfo.get(Event.messageId);

		Request telemetryRequest = new Request();

		// Setting the mandatory fields required for Error event( error , err_type and
		// stacktrace)

		Map<String, Object> telemetryParameters = new HashMap<>();
		telemetryParameters.put(JsonKey.ERROR, statusCode);
		telemetryParameters.put(JsonKey.ERR_TYPE, "SYSTEM");
		telemetryParameters.put(JsonKey.STACKTRACE, "Error in method: " + methodName + ", Message: " + message);

		String code = statusCode.subSequence(0, 3).toString();

		if (code.equals("400") || code.equals("403") || code.equals("404"))
			telemetryParameters.put(JsonKey.ERR_TYPE, "CONTENT");

		// telemetryParameters.put(JsonKey.LOG_LEVEL, JsonKey.INFO);

		telemetryRequest.setRequest(generateTelemetryRequest(TelemetryEvents.ERROR.getName(), telemetryParameters,
				(Map<String, Object>) telemetryInfo.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest);
	}

	private Map<String, Object> generateTelemetryRequest(String eventType, Map<String, Object> telemetryParameters,
			Map<String, Object> telemetryContext) {
		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.TELEMETRY_EVENT_TYPE, eventType);
		map.put(JsonKey.CONTEXT, telemetryContext);
		map.put(JsonKey.PARAMS, telemetryParameters);

		return map;
	}

}
