package com.infosysit.rctmscompliance.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.infosysit.rctmscompliance.controller.TokenValidator;
import com.infosysit.rctmscompliance.entity.CMSTrnAuditTrail;
import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.ActionItemMobile;
import com.infosysit.rctmscompliance.model.ActionItemPrevCommentAndDetails;
import com.infosysit.rctmscompliance.model.AuditParam;
import com.infosysit.rctmscompliance.model.CMSRemarkDTO;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserDateNotNull;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserFinal;
import com.infosysit.rctmscompliance.model.ComplianceEscalationDetails;
import com.infosysit.rctmscompliance.model.InputFieldsMob;
import com.infosysit.rctmscompliance.model.MobileControlModel;
import com.infosysit.rctmscompliance.model.OldAssigneeRem;
import com.infosysit.rctmscompliance.model.OptionsMob;
import com.infosysit.rctmscompliance.model.RCTMSActionItemDetails;
import com.infosysit.rctmscompliance.model.SubmitAndRejectResponse;
import com.infosysit.rctmscompliance.model.ViewActionItemMobModel;
import com.infosysit.rctmscompliance.repo.read.CMSMstComplianceDetailsRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSMstMobileControlsRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSTrnActionItemResponseRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSTrnActionItemTrackingRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSTrnAuditTrailRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSTrnComplianceInstanceRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSmstBISNoticeDetailsRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSmstBISfilterdetailsRepoRead;
import com.infosysit.rctmscompliance.repo.read.CMSmstfilterdetailsRepoRead;
import com.infosysit.rctmscompliance.repo.read.ViewCMSMstInboxDetailsWithEmpIDRepoRead;
import com.infosysit.rctmscompliance.repo.read.ViewCMSTrnEscalationDetailsRepoRead;
import com.infosysit.rctmscompliance.repo.read.ViewCurrEmpAllDetailsRepoRead;
import com.infosysit.rctmscompliance.repo.write.CMSTrnActionItemResponseRepoWrite;
import com.infosysit.rctmscompliance.repo.write.CMSTrnActionItemTrackingRepoWrite;
import com.infosysit.rctmscompliance.repo.write.CMSTrnAuditTrailRepoWrite;
import com.infosysit.rctmscompliance.repo.write.CMSTrnComplianceInstanceRepoWrite;
import com.infosysit.rctmscompliance.util.Constants;

@Service
public class ComplianceDetailsServiceImp implements ComplianceDetailsService {
		
	@Autowired
	private CMSMstComplianceDetailsRepoRead compDetailsRepoRead;
	
	@Autowired
	private ViewCMSTrnEscalationDetailsRepoRead escRepoRead;
	
	@Autowired
	private CMSTrnComplianceInstanceRepoRead compInstRepoRead;
	
	@Autowired
	private CMSTrnComplianceInstanceRepoWrite compInstRepoWrite;
	
	@Autowired
	private ViewCMSMstInboxDetailsWithEmpIDRepoRead inboxRepoRead;
	
	@Autowired
	private CMSTrnAuditTrailRepoRead auditRepoRead;
	
	@Autowired
	private CMSTrnAuditTrailRepoWrite auditRepoWrite;
	
	@Autowired
	private CMSMstMobileControlsRepoRead mobileControlRepoRead;
	
	@Autowired
	private CMSTrnActionItemTrackingRepoRead actionTrackingRepoRead;
	
	@Autowired
	private ViewCurrEmpAllDetailsRepoRead viewEmpRepoRead;
	
	@Autowired
	private CMSmstBISNoticeDetailsRepoRead bisNoticeDetailsRepoRead;
	
	@Autowired
	private CMSmstBISfilterdetailsRepoRead bisFilterdetailsRepoRead;
	
	@Autowired 
	CMSmstfilterdetailsRepoRead filterDetailsRepoRead;
	
	@Autowired
	CMSTrnActionItemResponseRepoWrite actionResponseRepoWrite;
	
	@Autowired
	CMSTrnActionItemTrackingRepoWrite actionTrackingRepoWrite;
	
	@Autowired
	CMSTrnActionItemResponseRepoRead actionResponseRepoRead; 
	
	@Autowired
	InbayServiceImp inbay;

	@Override
	public ComplianceDetailsForUserFinal getComplianceDetailsForUser(int intComplianceID, String dtAssignedDate) throws CustomException {
		
		List<ComplianceEscalationDetails> escDetails;
		ComplianceDetailsForUserDateNotNull compDetailsDateNotNull;
		ComplianceDetailsForUserFinal compDetailFinal;
		try {
			String ch="M:";
			String ch2="^";
			compDetailFinal = new ComplianceDetailsForUserFinal();
			if(compInstRepoRead.findComplianceId(intComplianceID, dtAssignedDate) != null) {
				compDetailsDateNotNull=compDetailsRepoRead.getComplianceDetailsForUserDateNotNull(intComplianceID, dtAssignedDate);
				if(compDetailsDateNotNull!=null) {
				int startIndexA=(compDetailsDateNotNull.getTxtAssigneeRemarks()!=null && compDetailsDateNotNull.getTxtAssigneeRemarks().indexOf(ch)>=0)?compDetailsDateNotNull.getTxtAssigneeRemarks().indexOf(ch)+2:0;
				int startIndexAR=(compDetailsDateNotNull.getTxtAssigneeAfterRejectRemark()!=null && compDetailsDateNotNull.getTxtAssigneeAfterRejectRemark().indexOf(ch)>=0)?compDetailsDateNotNull.getTxtAssigneeAfterRejectRemark().indexOf(ch)+2:0;
				int startIndexV=(compDetailsDateNotNull.getTxtVerifierApprovalRemarks()!=null && compDetailsDateNotNull.getTxtVerifierApprovalRemarks().indexOf(ch)>=0)?compDetailsDateNotNull.getTxtVerifierApprovalRemarks().indexOf(ch)+2:0;
				int startIndexVR=(compDetailsDateNotNull.getTxtVerifierRejectRemark()!=null && compDetailsDateNotNull.getTxtVerifierRejectRemark().indexOf(ch)>=0)?compDetailsDateNotNull.getTxtVerifierRejectRemark().indexOf(ch)+2:0;
				
				String assiRem=(compDetailsDateNotNull.getTxtAssigneeRemarks()!=null)?compDetailsDateNotNull.getTxtAssigneeRemarks().substring(startIndexA).replace("\r\n", "^"):"";
				String assiARejRem=(compDetailsDateNotNull.getTxtAssigneeAfterRejectRemark()!=null)?compDetailsDateNotNull.getTxtAssigneeAfterRejectRemark().substring(startIndexAR).replace("\r\n", "^").replace("\r\n\r\n", "\r\n"):"";
				String verApp=(compDetailsDateNotNull.getTxtVerifierApprovalRemarks()!=null)?compDetailsDateNotNull.getTxtVerifierApprovalRemarks().substring(startIndexV).replace("\r\n", "^"):"";
				String verRejRem=(compDetailsDateNotNull.getTxtVerifierRejectRemark()!=null)?compDetailsDateNotNull.getTxtVerifierRejectRemark().substring(startIndexVR).replace("\r\n", "^"):"";
				
				int endIndexA=(assiRem.contains(ch2))?assiRem.indexOf(ch2):assiRem.length();
				int endIndexAR=(assiARejRem.indexOf(ch2)>=0)?assiARejRem.indexOf(ch2):assiARejRem.length();
				int endIndexV=(verApp.indexOf(ch2)>=0)?verApp.indexOf(ch2):verApp.length();
				int endIndexVR=(verRejRem.indexOf(ch2)>=0)?verRejRem.indexOf(ch2):verRejRem.length();
				
				compDetailFinal.setCompName(compDetailsDateNotNull.getTxtComplianceName());
				compDetailFinal.setCompDesc(compDetailsDateNotNull.getTxtDescription());
				compDetailFinal.setAssigneeRemarks((assiRem.length()>0)?assiRem.substring(0, endIndexA):null);
				compDetailFinal.setVerifierApprovalRemarks((verApp.length()>0)?verApp.substring(0, endIndexV):null);
				compDetailFinal.setVerifierRejectRemarks((verRejRem.length()>0)?verRejRem.substring(0, endIndexVR):null);
				compDetailFinal.setAssigneeAfterRejectRemarks((assiARejRem.length()>0)?assiARejRem.substring(0, endIndexAR):null);
				compDetailFinal.setDtAssignedDate(compDetailsDateNotNull.getDtAssignedDate());
				compDetailFinal.setTxtAssignee(compDetailsDateNotNull.getTxtAssignee().trim());
				compDetailFinal.setTxtVerifier(compDetailsDateNotNull.getTxtVerifier().trim());
				compDetailFinal.setTxtOwner(compDetailsDateNotNull.getTxtOwner().trim());
				compDetailFinal.setDtDueDate(compDetailsDateNotNull.getDtDueDate());
				int intEscalatedLevel;
				intEscalatedLevel=compInstRepoRead.getEscalationLevel(intComplianceID, dtAssignedDate);
				if(intEscalatedLevel==0) {
					intEscalatedLevel=1;
				}
				escDetails=escRepoRead.getEscalationDetails(intComplianceID, dtAssignedDate,intEscalatedLevel);
				if(!escDetails.isEmpty())
					compDetailFinal.setCompEsc(escDetails);
				}	
				else
					compDetailFinal.setCompDesc("1");
			}
			else
				compDetailFinal.setCompDesc("0");
			return compDetailFinal;
		} catch (Exception e) {
				throw new CustomException("Error in ComplianceDetailsForUserFinal "+e.toString());
		}

	}
	
	@Override
	public int getComplianceID(String txtComplianceName) throws CustomException {

		return compDetailsRepoRead.getComplianceIDByComplianceName(txtComplianceName);
	}
	@Override
	public int createAudit(AuditParam param) throws CustomException {
		
		
		LocalDateTime nowAudit = LocalDateTime.now();  
		DateTimeFormatter formatAudit = DateTimeFormatter.ofPattern(Constants.DATETIMEFORMAT);  
	    String dtCurrentDateAudit = nowAudit.format(formatAudit); 
		int intAuditID=0;
		try {
			CMSTrnAuditTrail audit=new CMSTrnAuditTrail(intAuditID, param.getTxtEmpNo(), param.getTxtActor(), param.getTxtActivity(), param.getTxtStatus(), param.getTxtCategory(), 
					param.getTxtOlddata(), param.getTxtNewData(),param.getTxtOldRemark(),param.getTxtNewRemark(), param.getIntNodeID(), param.getDtAssignedDate(), 
					param.getTxtEmpNo(), dtCurrentDateAudit, null, dtCurrentDateAudit);
			
			CMSTrnAuditTrail auditCreated=auditRepoWrite.saveAndFlush(audit);
			intAuditID=auditCreated.getIntAuditID();
		} catch (Exception e) {
			
			throw new CustomException("Error in createAudit "+e.toString());
		}
		return intAuditID;
	}
	@Override
	public void updateAudit(int intAuditID, String txtStatus) throws CustomException {
		
		try {
			auditRepoWrite.updateAuditTrail(intAuditID, txtStatus);
		} catch (Exception e) {
			
			throw new CustomException("Remark/Status is updated but failed to update Audit Trail "+ e.toString());
		}
		
	}
	@Override
	@Transactional(rollbackFor = {CustomException.class,JsonProcessingException.class})
	public SubmitAndRejectResponse submitAssigneeRemark(CMSRemarkDTO remark) throws CustomException {
	    String dtCurrentDateA = returnCurrentDate();
	    int intAuditIDA=0;    
		try {
			
			int intComplianceIDA=remark.getIntComplianceID();
			OldAssigneeRem oldRem=compInstRepoRead.getOldAssigneeRem(remark.getIntComplianceID(), remark.getDtAssignedDate());
			String txtStatusA=oldRem.getTxtStatus();
			String txtOlddataA=auditRepoRead.getTxtOldDataForAudit(intComplianceIDA).toString();
			if(txtStatusA.equals(Constants.getComplianceStatus()[0])) 
				txtStatusA=Constants.getComplianceStatus()[2];
			else if(txtStatusA.equals(Constants.getComplianceStatus()[1]))
				txtStatusA=Constants.getComplianceStatus()[3];
			else
				return new SubmitAndRejectResponse("0", compInstRepoRead.getPendingWith(remark.getIntComplianceID(), remark.getDtAssignedDate()));
			if(oldRem.getIntNoOfCycles()==0) {
				AuditParam paramA1=new AuditParam(TokenValidator.getTokenEMPNO(), "Assignee", "Compliance submitted to verifier",Constants.AUDITSTATUSUNKOWN,Constants.AUDITCATEGORYCOMPLIANCE, txtOlddataA, 
						"Assignee Comment="+remark.getComments()+"||"+Constants.TXTNEWDATACONCAT+"", null, remark.getComments(), intComplianceIDA, remark.getDtAssignedDate());
				intAuditIDA=createAudit(paramA1);
				compInstRepoWrite.updateAssigneeRemarks(intComplianceIDA, remark.getDtAssignedDate(), txtStatusA, returnRemarkStampDate()+":"+remark.getComments()+((oldRem.getTxtAssigneeRemarks()!=null)?"\r\n"+oldRem.getTxtAssigneeRemarks():""), 
						" ", dtCurrentDateA, TokenValidator.getTokenEMPNO());
			}
			else if(oldRem.getIntNoOfCycles()>0) {			
				AuditParam paramA2=new AuditParam(TokenValidator.getTokenEMPNO(), "Assignee", "Compliance submitted to verifier",Constants.AUDITSTATUSUNKOWN,Constants.AUDITCATEGORYCOMPLIANCE, txtOlddataA, 
						"Assignee Comment=||"+Constants.TXTNEWDATACONCAT+"", null, "", intComplianceIDA, remark.getDtAssignedDate());
				intAuditIDA=createAudit(paramA2);
				compInstRepoWrite.updateAssigneeAfterRejectRemarks(intComplianceIDA, remark.getDtAssignedDate(), txtStatusA, returnRemarkStampDate()+":"+remark.getComments()+((oldRem.getTxtAssigneeAfterRejectRemark()!=null)?"\r\n"+oldRem.getTxtAssigneeAfterRejectRemark():""),
						" ", dtCurrentDateA, TokenValidator.getTokenEMPNO());
			}
			updateAudit(intAuditIDA, Constants.AUDITSTATUSPASS);
			return new SubmitAndRejectResponse("1",Constants.REMARKSUCCESS+Constants.VERIFIER);
		} catch (Exception e) {
			throw new CustomException("Error in submitAssigneeRemark "+e.toString());
		}	
	}
	@Override
	@Transactional(rollbackFor = {CustomException.class,JsonProcessingException.class})
	public SubmitAndRejectResponse submitVerifierRemark(CMSRemarkDTO remark) throws CustomException {
		int intComplianceIDV=0;
		String txtStatusV="";
		String dtCurrentDateV = returnCurrentDate();
	    int intAuditIDV=0;
		try {
			intComplianceIDV=remark.getIntComplianceID();
			OldAssigneeRem oldRem=compInstRepoRead.getOldAssigneeRem(remark.getIntComplianceID(), remark.getDtAssignedDate());
			txtStatusV=oldRem.getTxtStatus();
			String txtOlddataV=auditRepoRead.getTxtOldDataForAudit(intComplianceIDV).toString();
			if(txtStatusV.equals(Constants.getComplianceStatus()[2])) 
				txtStatusV=Constants.getComplianceStatus()[4];
			else if(txtStatusV.equals(Constants.getComplianceStatus()[3]))
				txtStatusV=Constants.getComplianceStatus()[5];
			else
				return new SubmitAndRejectResponse("0", compInstRepoRead.getPendingWith(remark.getIntComplianceID(), remark.getDtAssignedDate()));
			AuditParam paramV=new AuditParam(TokenValidator.getTokenEMPNO(), "Verfier", "Compliance submitted to Owner for Closure",Constants.AUDITSTATUSUNKOWN,Constants.AUDITCATEGORYCOMPLIANCE, txtOlddataV, 
					"Verifier Comment="+remark.getComments()+"||"+Constants.TXTNEWDATACONCAT+"", null, remark.getComments(), intComplianceIDV, remark.getDtAssignedDate());
			intAuditIDV=createAudit(paramV);
			compInstRepoWrite.updateVerfierRemarks(intComplianceIDV, remark.getDtAssignedDate(), txtStatusV, returnRemarkStampDate()+":"+remark.getComments()+((oldRem.getTxtVerifierApprovalRemarks()!=null)?"^"+oldRem.getTxtVerifierApprovalRemarks():""), 
					" ", dtCurrentDateV, TokenValidator.getTokenEMPNO());
			updateAudit(intAuditIDV, Constants.AUDITSTATUSPASS);
			return new SubmitAndRejectResponse("1",Constants.REMARKSUCCESS+Constants.OWNER);	
		} catch (Exception e) {
			throw new CustomException("Erro in submitVerifierRemark "+e.toString());
		}	
	}
	@Override
	@Transactional(rollbackFor = {CustomException.class,JsonProcessingException.class})
	public SubmitAndRejectResponse submitVerifierRejectRemark(CMSRemarkDTO remark) throws CustomException {
		int intComplianceIDVR=0;
		String txtStatusVR="";
		String dtCurrentDateVR = returnCurrentDate();
	    int intAuditIDVR=0;
		try {
			intComplianceIDVR=remark.getIntComplianceID();
			OldAssigneeRem oldRem=compInstRepoRead.getOldAssigneeRem(remark.getIntComplianceID(), remark.getDtAssignedDate());
			txtStatusVR=oldRem.getTxtStatus();
			if(txtStatusVR.equals(Constants.getComplianceStatus()[2])) 
				txtStatusVR=Constants.getComplianceStatus()[0];
			else if(txtStatusVR.equals(Constants.getComplianceStatus()[3]))
				txtStatusVR=Constants.getComplianceStatus()[1];
			else
				return new SubmitAndRejectResponse("0", compInstRepoRead.getPendingWith(remark.getIntComplianceID(), remark.getDtAssignedDate()));
			String txtOlddata=auditRepoRead.getTxtOldDataForAudit(intComplianceIDVR).toString();
			AuditParam paramVR=new AuditParam(TokenValidator.getTokenEMPNO(), "Verfier", "Compliance Rejected by verifier",Constants.AUDITSTATUSUNKOWN,Constants.AUDITCATEGORYCOMPLIANCE, txtOlddata, 
					"Verifier Rejection Comment="+remark.getComments()+"||"+Constants.TXTNEWDATACONCAT+"", null, remark.getComments(), intComplianceIDVR, remark.getDtAssignedDate());
			intAuditIDVR=createAudit(paramVR);
			compInstRepoWrite.updateVerifierRejectRemark(intComplianceIDVR, remark.getDtAssignedDate(), txtStatusVR, returnRemarkStampDate()+":"+remark.getComments()+((oldRem.getTxtVerifierRejectRemark()!=null)?"^"+oldRem.getTxtVerifierRejectRemark():""), " ", dtCurrentDateVR, TokenValidator.getTokenEMPNO());
			updateAudit(intAuditIDVR, Constants.AUDITSTATUSPASS);
			return new SubmitAndRejectResponse("1","Compliance is rejected and assigned to "+Constants.ASSIGNEE);
		}catch (Exception e) {
			throw new CustomException("Error in submitVerifierRejectRemark "+e.toString());
		}	
	}
	@Override
	@Transactional(rollbackFor = {CustomException.class,JsonProcessingException.class})
	public SubmitAndRejectResponse submitOwnerRemark(CMSRemarkDTO remark) throws CustomException {
		int intComplianceIDO=0;
		String txtStatusO="";
	    String dtCurrentDateO = returnRemarkStampDate();
	    int intAuditIDO=0;
		try {
			intComplianceIDO=remark.getIntComplianceID();
			txtStatusO=inboxRepoRead.getStatus(intComplianceIDO, remark.getDtAssignedDate());
			String txtOlddataO=auditRepoRead.getTxtOldDataForAudit(intComplianceIDO).toString();
			String txtOldRemarkO=null;
			String txtActorO="Owner";
			if(txtStatusO.equals(Constants.getComplianceStatus()[4]))
				txtStatusO=Constants.getComplianceStatus()[6];
			else if(txtStatusO.equals(Constants.getComplianceStatus()[5]))
				txtStatusO=Constants.getComplianceStatus()[7];
			else
				return new SubmitAndRejectResponse("0", compInstRepoRead.getPendingWith(remark.getIntComplianceID(), remark.getDtAssignedDate()));
			AuditParam paramO=new AuditParam(TokenValidator.getTokenEMPNO(), txtActorO, "Closing of Compliance",Constants.AUDITSTATUSUNKOWN,Constants.AUDITCATEGORYCOMPLIANCE, txtOlddataO, 
					"Owner Comment="+remark.getComments()+"||"+Constants.TXTNEWDATACONCAT+"", txtOldRemarkO, remark.getComments(), intComplianceIDO, remark.getDtAssignedDate());
			intAuditIDO=createAudit(paramO);
			compInstRepoWrite.updateOwnerRemarks(intComplianceIDO, remark.getDtAssignedDate(), txtStatusO, dtCurrentDateO+":"+remark.getComments(), 
					" ", dtCurrentDateO, TokenValidator.getTokenEMPNO());
			updateAudit(intAuditIDO, Constants.AUDITSTATUSPASS);
			return new SubmitAndRejectResponse("1",Constants.COMPCLOSESUCCESS);
		} catch (Exception e) {
			throw new CustomException("Error in submitOwnerRemark "+e.toString());
		}
	}
	@Override
	public String returnCurrentDate() throws CustomException {
		try {
			LocalDateTime now = LocalDateTime.now();
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
			return now.plusHours(5).plusMinutes(30).format(format);
		} catch (Exception e) {
			throw new CustomException("Error in returnCurrentDate "+e.toString());
		}
	}
	
	@Override
	public String returnRemarkStampDate() throws CustomException {
		try {
			LocalDateTime now1 = LocalDateTime.now();
			DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss a");  
			return now1.plusHours(5).plusMinutes(30).format(format1);
		} catch (Exception e) {
			throw new CustomException("Error in returnRemarkStampDate "+e.toString());
		}
	}
	
	@Override
	public List<String> getReason(String txtFinding) throws CustomException{
		try {
			return bisFilterdetailsRepoRead.getReason(txtFinding);
		}
		catch(Exception e) {
			throw new CustomException("Error in getReason "+e.toString());
		}
	}
	
	@Override
	public ViewActionItemMobModel getActionItemDetails(int intActionItemId) throws CustomException {

		List<InputFieldsMob> inputModel=new ArrayList<>();
		ViewActionItemMobModel actionItemMob=null;
		try {
			List<MobileControlModel> mobileControls = mobileControlRepoRead.getMobileControls("view action item details",1);
			RCTMSActionItemDetails actionItem = actionTrackingRepoRead.getActionItemDetails(intActionItemId);
			int noticeReference=bisNoticeDetailsRepoRead.getNoticedetailsBISActionitems(actionItem.getTxtReferenceNumber());
			boolean isNoticePresent=(noticeReference>0)?Constants.TRUE:Constants.FALSE;
			for (MobileControlModel control : mobileControls) {
				switch (control.getTxtParamName()) {
				case "intActionItemId": 
					inputModel.add(populateInputFieldsModel(null, control, null,isNoticePresent,String.valueOf(actionItem.getIntActionItemId())));
					break;
				case "application": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtApplicationName()), null,isNoticePresent,trimData(actionItem.getTxtApplicationName())));
					break;
				case "assignee": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtActionItemAssignee()), null,isNoticePresent,trimData(viewEmpRepoRead.getEmployeeMailId(actionItem.getTxtActionItemAssignee()))));
					break;
				case "actionDescription": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtactionitemdescription()), null,isNoticePresent,trimData(actionItem.getTxtactionitemdescription())));
					break;
				case "maker": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtMakerEmpNo()), null,isNoticePresent,trimData(viewEmpRepoRead.getEmployeeMailId(actionItem.getTxtMakerEmpNo()))));
					break;
				case "checker": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtCheckerEmpNo()), null,isNoticePresent,trimData(viewEmpRepoRead.getEmployeeMailId(actionItem.getTxtCheckerEmpNo()))));
					break;
				case "dueDate": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getDtActionItemDueDate()), null,isNoticePresent,Constants.formatDate(trimData(actionItem.getDtActionItemDueDate()))));
					break;
				case "status": 
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtActionItemStatus()), null,isNoticePresent,trimData(actionItem.getTxtActionItemStatus())));
					break;
				case "finding": 
					String findingPlaceHolder=getPlaceHolder(actionItem.getTxtFindings());
					inputModel.add(populateInputFieldsModel(findingPlaceHolder, isActionItemDropDownVisible(control, isNoticePresent),bisFilterdetailsRepoRead.getFindings(),isNoticePresent,findingPlaceHolder));
					break;
				case "reason": 
					String reasonPlaceholder=getPlaceHolder(actionItem.getTxtReason());
					inputModel.add(populateInputFieldsModel(reasonPlaceholder, isActionItemDropDownVisible(control, isNoticePresent), null,isNoticePresent,reasonPlaceholder));
					break;
				case "correctiveAction": 
					String correctiveActionPlace=getPlaceHolder(actionItem.getTxtCorrectiveAction());
					inputModel.add(populateInputFieldsModel(correctiveActionPlace, isActionItemDropDownVisible(control, isNoticePresent), filterDetailsRepoRead.getCorrectiveaction(),isNoticePresent,correctiveActionPlace));
					break;
				case "remediation": 
					String remediationPlace=getPlaceHolder(actionItem.getTxtRemediation());
					inputModel.add(populateInputFieldsModel(remediationPlace, isActionItemDropDownVisible(control, isNoticePresent), filterDetailsRepoRead.getRemediation(),isNoticePresent,remediationPlace));
					break;
				case "assigneeComments": 
					if(actionItem.getTxtActionItemAssignee().equalsIgnoreCase(actionItem.getTxtActionItemOwner()))
						control.setTxtIsVisible(Constants.STRINGFALSE);
					inputModel.add(populateInputFieldsModel(null, control, null,isNoticePresent,getActionItemLatestComments(actionItem.getTxtActionItemAssigneeComments())));
					break;
				case "rejectComments":
					inputModel.add(populateInputFieldsModel(null, isTextBoxVisible(control,actionItem.getTxtOwnerRejectComments()), null,isNoticePresent,getActionItemLatestComments(actionItem.getTxtOwnerRejectComments())));
					break;
				case "closingComments": 
					if(actionItem.getTxtActionItemStatus().equalsIgnoreCase("With Assignee") && !actionItem.getTxtActionItemAssignee().equalsIgnoreCase(actionItem.getTxtActionItemOwner()))
						control.setTxtIsVisible(Constants.STRINGFALSE);
					inputModel.add(populateInputFieldsModel(null, control, null,isNoticePresent,null));
					break;
				default:
					break;
					
				}
			}
			actionItemMob =new ViewActionItemMobModel(getButtonsForViewActionItem(actionItem.getTxtActionItemStatus(), actionItem.getTxtActionItemAssignee(),
					actionItem.getTxtActionItemOwner()), inputModel);
			
		} catch (Exception e) {
			throw new CustomException("Error in getActionItemDetails "+e.toString());
		}
		return actionItemMob;
	}
	
	public String submitRemark(ViewActionItemMobModel actionItemMobModel,String action)throws CustomException{
		
		String exeStatus=null;
		String submitComment=null;
		String rejectComment=null;
		String closingComments=null;
		String txtFindings=null;
		String txtReason=null;
		String txtCorrectiveAction=null;
		String txtRemediation=null;
		int intActionItemId=0;
		List<InputFieldsMob> inputFlds=new ArrayList<>(actionItemMobModel.getInputFields());
		for(InputFieldsMob fld : inputFlds) {
			switch (fld.getParamName()) {
			case "intActionItemId": 
				intActionItemId=Integer.valueOf(fld.getData());
				break;
			case "assigneeComments": 
				submitComment=trimData(fld.getData());
				break;
			case "rejectComments": 
				rejectComment=trimData(fld.getData());
				break;
			case "closingComments": 
				closingComments=trimData(fld.getData());
				break;
			case "finding": 
				txtFindings=trimData(fld.getData());
				break;
			case "reason": 
				txtReason=trimData(fld.getData());
				break;
			case "correctiveAction": 
				txtCorrectiveAction=trimData(fld.getData());
				break;
			case "remediation": 
				txtRemediation=trimData(fld.getData());
				break;
			default:
				break;
			}
		}
		ActionItemPrevCommentAndDetails prevComment = actionResponseRepoRead.getOldComments(intActionItemId);
		try {
			if(action.equalsIgnoreCase(Constants.ACTIONITEMACTIONSUBMIT)) {
				actionResponseRepoWrite.submitToOwner(attachTimeStampAndPrevComments(submitComment, prevComment.getTxtAssigneeComments()), TokenValidator.getTokenEMPNO(), txtFindings, txtReason, txtCorrectiveAction, txtRemediation, intActionItemId);
				actionTrackingRepoWrite.changeActionItemStatus(intActionItemId, Constants.ACTIONITEMOWNERSTATUS);
				inbay.deleteActionItem(String.valueOf(intActionItemId), prevComment.getTxtAssignee());
				inbay.insertActionItem(intActionItemId, prevComment.getTxtOwner());
				exeStatus="action item submitted to owner";
			}
			else if(action.equalsIgnoreCase(Constants.ACTIONITEMACTIONREJECT)) {
				actionResponseRepoWrite.rejectActionItem(attachTimeStampAndPrevComments(rejectComment, prevComment.getTxtRejectComments()), TokenValidator.getTokenEMPNO(), txtFindings, txtReason, txtCorrectiveAction, txtRemediation, intActionItemId);
				actionTrackingRepoWrite.changeActionItemStatus(intActionItemId, Constants.ACTIONITEMASSIGNEESTATUS);
				actionResponseRepoWrite.changeNoOfCycles(intActionItemId, prevComment.getNoOfCycles()+1);
				inbay.deleteActionItem(String.valueOf(intActionItemId), prevComment.getTxtOwner());
				inbay.insertActionItem(intActionItemId, prevComment.getTxtAssignee());
				exeStatus="action item rejected and sent to assignee";
				
			}
			else {
				actionResponseRepoWrite.closeActionItem(attachTimeStampAndPrevComments(closingComments, prevComment.getTxtCloseComments()), TokenValidator.getTokenEMPNO(), txtFindings, txtReason, txtCorrectiveAction, txtRemediation, intActionItemId);
				actionTrackingRepoWrite.changeActionItemStatus(intActionItemId, Constants.getComplianceStatus()[6]);
				inbay.deleteActionItem(String.valueOf(intActionItemId), prevComment.getTxtOwner());
				exeStatus="action item closed";
			}
		} catch (Exception e) {
			throw new CustomException("Error in submitRemark "+e.toString());

		}
		return exeStatus;
	}
	
	@Override
	public boolean checkIfActionItemExists(int intActionItemId)throws CustomException{
		try {
			return (actionTrackingRepoRead.isActionItemExists(intActionItemId)>0)?Constants.TRUE:Constants.FALSE;
		} catch (Exception e) {
			throw new CustomException("Error in checkIfActionItemExists "+e.toString());
		}
	}
	
	@Override
	public String getPlaceHolder(String value) throws CustomException{
		try {
			return (value!=null && !value.isEmpty())?value.trim():Constants.SELECT;
		}
		catch (Exception e) {
			throw new CustomException("Error in getPlaceHolder "+e.toString());
		}
	}
	
	
	
	@Override
	public MobileControlModel isActionItemDropDownVisible(MobileControlModel control,boolean isNoticePresent) throws CustomException {
		try {
			if(!isNoticePresent)
				control.setTxtIsVisible(Constants.STRINGFALSE);
			return control;
		} catch (Exception e) {
			throw new CustomException("Error in isActionItemDropDownVisible "+e.toString());
		}
	}
	
	@Override
	public String attachTimeStampAndPrevComments(String newComment,String oldComment) throws CustomException {
		try {
			return (oldComment != null && !oldComment.isEmpty())?oldComment+"^"+returnRemarkStampDate()+":"+newComment:returnRemarkStampDate()+":"+newComment;
		} catch (Exception e) {
			throw new CustomException("Error in attachTimeStampAndPrevComments "+e.toString());
		}
	}
	@Override
	public MobileControlModel isTextBoxVisible(MobileControlModel control,String data)throws CustomException{
		try {
			if(data == null || data.isEmpty())
				control.setTxtIsVisible(Constants.STRINGFALSE);
			return control;
		} catch (Exception e) {
			throw new CustomException("Error in isTextBoxVisible "+e.toString());
		}
	}
	
	@Override
	public String trimData(String data) throws CustomException{
		try {
			if(data != null && !data.isEmpty())
				return data.trim();
			return data;
		} catch (Exception e) {
			throw new CustomException("Error in trimData "+e.toString());
		}
			
	}
	@Override
	public String getActionItemLatestComments(String comment) throws CustomException {
		String startIndexChar="M:";
		if(comment !=null && !comment.isEmpty())
		{
			int endIndex=(comment.lastIndexOf(startIndexChar)>=0)?comment.lastIndexOf(startIndexChar)+2:0;
			return comment.substring(endIndex);	
		}
		return comment;
	}
	@Override
	public List<ActionItemMobile> getButtonsForViewActionItem(String status, String assignee,String owner)throws CustomException{
		try {
			List<ActionItemMobile> buttons = new ArrayList<>();
			if (assignee.equalsIgnoreCase(owner)) {
				buttons.add(new ActionItemMobile(Constants.SUBMIT, "Close", Constants.OWNERCLOSE));
			} else {
				if(status.trim().equalsIgnoreCase("With Assignee"))
					buttons.add(new ActionItemMobile(Constants.SUBMIT, Constants.SUBMIT, Constants.ASSIGNEESUBMIT));
				else {
					buttons.add(new ActionItemMobile(Constants.SUBMIT, "Close", Constants.OWNERCLOSE));
					buttons.add(new ActionItemMobile(Constants.SUBMIT, "Reject", Constants.OWNERRJECT));
				}
			}
			return buttons;
		} catch (Exception e) {
			throw new CustomException("Error in getButtonsForViewActionItem "+e.toString());
		}
	}
	@Override
	public InputFieldsMob populateInputFieldsModel(String txtPlaceholder, MobileControlModel control,List<String> optionsList,boolean isNoticePresent,String data) throws CustomException {
		List<OptionsMob> optionsModel = null;
		try {
			if (control.getOptions() == 1 && isNoticePresent && optionsList != null && !optionsList.isEmpty()) {
				optionsModel = new ArrayList<>();
				for (String opt : optionsList) {
					OptionsMob controlOptions = new OptionsMob(opt, opt);
					optionsModel.add(controlOptions);
				}
			}
			return new InputFieldsMob(control.getTxtParamName(), control.getIntType(),
					(control.getTxtIsRequired().equalsIgnoreCase(Constants.STRINGTRUE)) ? Constants.TRUE : Constants.FALSE,
					control.getTxtErrorMsg(), control.getTxtDisplayMessage(), null, txtPlaceholder,data,
					(control.getTxtIsDependent().trim().equalsIgnoreCase(Constants.STRINGTRUE)) ? Constants.TRUE : Constants.FALSE,
					control.getTxtDependentTo(), control.getTxtUrl(),
					(control.getTxtIsVisible().equalsIgnoreCase(Constants.STRINGTRUE)) ? Constants.TRUE : Constants.FALSE, control.getIntOrder(), null,
					false, null, null, null, control.getIntLength(),
					(control.getTxtIsPastDateRestricted().equalsIgnoreCase(Constants.STRINGTRUE)) ? Constants.TRUE : Constants.FALSE, optionsModel);
		} catch (Exception e) {
			throw new CustomException("Error in populateInputFieldsModel "+e.toString());
		}
	}
	
}
