package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.ashi.GMFields;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="elcmecmstashiallegationsandfindingsdetails")
public class ELCMECMstASHIAllegationsAndFindingsDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtactor")
	private String actor;

	@Column(name="txtmailid")
	private String mailId;

	@Column(name="txtallegation")
	private String allegation;

	@Column(name="txtfindings")
	private String finding;

	@Column(name="txtoutcome")
	private String outcome;

	@Column(name="flgsentfindings")
	private int flgSentFindings;

	@Column(name="txtdmsacknowledgementfiles")
	private String dmsAcknowledgementFiles;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="dtcreateddate")
	private Timestamp createdDate;

	@Column(name="txtupdatedby")
	private String updatedBy;

	@Column(name="dtupdateddate")
	private Timestamp updatedDate;

	public ELCMECMstASHIAllegationsAndFindingsDetails(GMFields fields, String recipientType, String recipient, String createdBy,
			Timestamp createdDate) {
		super();
		this.caseId = fields.getCaseid();
		this.actor = recipientType;
		this.mailId = recipient;
		this.allegation = fields.getAllegationDesc();
		this.finding = fields.getFindings();
		this.outcome = fields.getOutcome();
		this.flgSentFindings = 0;
		this.dmsAcknowledgementFiles = "";
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public ELCMECMstASHIAllegationsAndFindingsDetails(ELCMECMstASHIAllegationsAndFindingsDetails finding, GMFields fields, String updatedBy, Timestamp updatedDate) {
		super();
		this.serialNo = finding.getSerialNo();
		this.caseId = finding.getCaseId();
		this.actor = finding.getActor();
		this.mailId = finding.getMailId();
		this.allegation = fields.getAllegationDesc();
		this.finding = fields.getFindings();
		this.outcome = fields.getOutcome();
		this.flgSentFindings = 0;
		this.dmsAcknowledgementFiles = "";
		this.createdBy = finding.getCreatedBy();
		this.createdDate = finding.getCreatedDate();
		this.updatedBy = updatedBy;
		this.updatedDate = updatedDate;
	}

	
	




}
