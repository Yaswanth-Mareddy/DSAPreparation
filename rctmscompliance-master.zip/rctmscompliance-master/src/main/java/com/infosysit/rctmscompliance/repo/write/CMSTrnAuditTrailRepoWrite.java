package com.infosysit.rctmscompliance.repo.write;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnAuditTrail;

@Repository
public interface CMSTrnAuditTrailRepoWrite extends JpaRepository<CMSTrnAuditTrail, Integer> {
	
	
	@Modifying
	@Query(value="UPDATE CMSTrnAuditTrail AT SET AT.txtStatus = :txtStatus WHERE AT.intAuditID= :intAuditID ")
	public void updateAuditTrail(@Param("intAuditID") int intAuditID,@Param("txtStatus") String txtStatus);
}
