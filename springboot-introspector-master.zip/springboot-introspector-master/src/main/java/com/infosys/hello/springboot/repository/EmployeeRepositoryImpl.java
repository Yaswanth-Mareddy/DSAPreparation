package com.infosys.hello.springboot.repository;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Repository;

import com.infosys.hello.springboot.model.Employee;

@Repository
public class EmployeeRepositoryImpl implements EmployeeRepository {

	@Value("${redis.key}")
	private String KEY;
	private RedisTemplate<String, Object> redisTemplate;
	private HashOperations<String, Integer, Employee> hashOperations;

	@Autowired
	public EmployeeRepositoryImpl(RedisTemplate<String, Object> redis) {
		this.redisTemplate = redis;
	}

	@PostConstruct
	private void init() {
		this.hashOperations = redisTemplate.opsForHash();
	}

	@Override
	public Map<Integer, Employee> findAll() {
		return hashOperations.entries(KEY);
	}

	@Override
	public Employee find(int id) {
		return hashOperations.get(KEY, id);
	}

	@Override
	public void save(Employee employee) {
		hashOperations.put(KEY, employee.getId(), employee);
	}

	@Override
	public void update(Employee employee) {
		hashOperations.put(KEY, employee.getId(), employee);
	}

	@Override
	public void delete(int id) {
		hashOperations.delete(KEY, id);
	}

}
