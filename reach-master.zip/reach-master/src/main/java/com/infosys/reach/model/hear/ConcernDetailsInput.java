package com.infosys.reach.model.hear;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ConcernDetailsInput {

	private int moduleId;
	private String company;
	private String countryCode;
	
}
