package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSmstfilterdetails;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSmstfilterdetailsRepoRead extends JpaRepository<CMSmstfilterdetails, Integer>{

	@Query(value = CustomQueries.GETCORRECTIVEACTION)
	List<String> getCorrectiveaction();
	
	@Query(value = CustomQueries.GETREMEDIATION)
	List<String> getRemediation();
	
	
}
