package com.infosys.reach.model.generic;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode
public class GenModelOption {

	private String key;
    private String value;
    @JsonProperty("isSelected")
    private boolean isSelected;
    
	public GenModelOption(String key, String value) {
		super();
		this.key = key.trim();
		this.value = value.trim();
		this.isSelected = false;
	}
    
	public GenModelOption(int key, String value) {
		super();
		this.key = String.valueOf(key);
		this.value = value.trim();
		this.isSelected = false;
	}
	
	public GenModelOption(int transactionid, String mailid, String actions) {
		super();
		this.key = String.valueOf(transactionid);
		this.value = "<b>" + mailid.trim() + "</b>" + " - " + actions.trim();
		this.isSelected = false;
	}
}
