package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstEmployeeCaseDetails;

public interface ELCMECMstEmployeeCaseDetailsRepository extends JpaRepository<ELCMECMstEmployeeCaseDetails, Integer> {

}
