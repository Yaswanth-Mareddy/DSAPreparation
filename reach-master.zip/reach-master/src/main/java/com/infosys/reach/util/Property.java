package com.infosys.reach.util;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Getter;

@Component
@Getter
public class Property {
	//common
	@Value("${flgtestmail}")
	private boolean flgTriggerMail;
	
	@Value("${testtoid}")
	private String testToId;
	
	//HEAR
	@Value("${url.hear}")
	private String hearURL;

	@Value("${hear.fromid}")
	private String hearFromId;

	@Value("${mailer.hear.appcode}")
	private String hearMailerAappCode;

	@Value("${mailer.hear.eventid}")
	private String hearMailerEventId;

	@Value("${mailer.templateid.fyi}")
	private int hearMailerTemplateId;
	
	//DISC
	
	@Value("${url.disc}")
	private String discURL;
	
	@Value("${disc.fromid}")
	private String discFromId;

	@Value("${mailer.disc.appcode}")
	private String discMailerAppCode;

	@Value("${mailer.disc.eventid}")
	private String discMailerEventId;

	//ASHI
	
	@Value("${url.download}")
	private String downloadURL;

	@Value("${url.downloadall}")
	private String downloadAllURL;

	@Value("${url.baselocationbycountrycode}")
	private String baselocationbycountrycodeURL;

	@Value("${filevalidation.regex}")
	private String fileValidationRegex;

	@Value("${filevalidation.types}")
	private String fileValidationTypes;

	@Value("${dms.folder.interimrelief}")
	private String dmsASHIInterimReliefFolder;
	
	@Value("${dms.appname}")
	private String dmsApplicationName;

	@Value("${dms.docpath}")
	private String dmsDocumentPath;

	@Value("${dms.appid}")
	private String dmsApplicationID;

	@Value("${dms.storageurl}")
	private String dmsStorageURL;
	
	@Value("${dms.officialdocpath}")
	private String dmsOfficialDocumentPath;

	@Value("${dms.folder.casedoc}")
	private String dmsASHICaseDocFolder;
	
	@Value("${dms.folder.preliminarydiscussion}")
	private String dmsASHIPreliminaryDiscussionFolder;
	
	@Value("${dms.folder.investigation}")
	private String dmsASHIInvestigationDocsFolder;

	@Value("${url.filevalidation}")
	private String fileValidationURL;

	@Value("${url.mailerassist}")
	private String mailerAssistURL;

	@Value("${url.dp.status}")
	private String dpStatusURL;

	@Value("${url.dp.content}")
	private String dpConsentURL;

	@Value("${url.dp.updatestatus}")
	private String dpUpdateStatusURL;

	@Value("${url.cams.context}")
	private String camsContextURL;
	
	@Value("${url.cams.usercontext}")
	private String camsUserContextURL;

	@Value("${url.cams.roles}")
	private String camsRolesURL;

	@Value("${url.dmsdownload}")
	private String dmsDownloadURL;

	@Value("${url.dmsupload}")
	private String dmsUploadURL;

	@Value("${hear.dp.parentid}")
	private String hearParentId;

	@Value("${hear.dp.childid}")
	private String hearChildId;

	@Value("${ashi.dp.parentid}")
	private String ashiParentId;

	@Value("${ashi.dp.childid}")
	private String ashiChildId;

	@Value("${tempstoragepath}")
	private String tempStoragePath;

	@Value("${url.all}")
	private String allURL;

	@Value("${url.initiatedbyme}")
	private String initiatedByMeURL;

	@Value("${url.initiatedbygrb}")
	private String initiatedByGRBURL;

	@Value("${url.cocomplainant}")
	private String coComplainantURL;

	@Value("${cams.appcode}")
	private String camsAppCode;

	@Value("${url.cocomplainant.response.accept}")
	private String cocomplainantAcceptURL;

	@Value("${url.cocomplainant.response.reject}")
	private String cocomplainantRejectURL;
	
	@Value("${url.consent.response.accept}")
	private String consentAcceptURL;

	@Value("${url.consent.response.reject}")
	private String consentRejectURL;

	@Value("${url.submitcase}")
	private String submitcaseURL;

	@Value("${url.uploadevidence}")
	private String uploadEvidenceURL;

	@Value("${infydomain}")
	private String infyDomain;

	@Value("${ashi.fromid}")
	private String fromId;

	@Value("${ashi.grbid}")
	private String grbId;

	@Value("${mailer.ashi.appcode}")
	private String appCode;

	@Value("${mailer.ashi.eventid.fyi}")
	private String eventIdFYI;

	@Value("${mailer.ashi.eventid.fya}")
	private String eventIdFYA;

	@Value("${mailer.templateid.fyi}")
	private int templateIdFYI;

	@Value("${mailer.templateid.fya}")
	private int templateIdFYA;
	
	@Value("${mailer.ashi.eventid.fya2}")
	private String eventIdFYA2;

	@Value("${mailer.templateid.fya2}")
	private int templateIdFYA2;

	@Value("${mailer.ashi.eventid.fyaa.transactionname}")
	private String transactionNameFYA2;

	@Value("${url.employeesearch}")
	private String employeeSearchURL;

	@Value("${url.addevidence}")
	private String evidenceGenModelURL;
	
	@Value("${url.employeesearchnew}")
	private String employeeSearchMobileURL;

	@Value("${url.baselocationbycountrycodenew}")
	private String baselocationbycountrycodeMobileURL;

	@Value("${url.submitcasenew}")
	private String submitcaseMobileURL;

	@Value("${url.cocomplainantnew.response.accept}")
	private String acceptMobileURL;

	@Value("${url.cocomplainantnew.response.reject}")
	private String rejectMobileURL;

	@Value("${url.mobile.all}")
	private String allMobileURL;

	@Value("${url.mobile.initiatedbyme}")
	private String initiatedByMeMobileURL;

	@Value("${url.mobile.initiatedbygrb}")
	private String initiatedByGRBMobileURL;

	@Value("${url.mobile.cocomplainant}")
	private String coComplainantMobileURL;
	
	//ASHI Admin
	@Value("${url.admin.ashi.cams.context}")
	private String contextURL;
	
	@Value("${url.admin.ashi.cams.contextmembers}")
	private String contextMembersURL;

	@Value("${url.admin.ashi.inbox.genmodelfiltered}")
	private String inboxGMFilteredURL;

	@Value("${url.admin.ashi.inbox.inlinefilter.genmodel}")
	private String inboxILFilterGenModelURL;

	@Value("${url.admin.ashi.inbox.inlinefiltered}")
	private String inboxILFilteredURL;
	
	@Value("${url.admin.ashi.casesummary.location.genmodel}")
	private String locationGenmodelURL;

	@Value("${url.admin.ashi.casesummary.location.update}")
	private String updateLocationURL;

	@Value("${url.admin.ashi.casesummary.employeelabel}")
	private String employeeLabelURL;
	
	@Value("${url.admin.ashi.casesummary.addemployee}")
	private String addEmployeeURL;
	
	@Value("${url.admin.ashi.casesummary.addpreliminarydiscussion}")
	private String addPreliminaryDiscussionURL;
	
	@Value("${url.admin.ashi.casesummary.preliminarydiscussioncards}")
	private String preliminaryDiscussionCardsURL;
	
	@Value("${url.admin.ashi.casesummary.removeemployee}")
	private String removeEmployeeURL;
	
	@Value("${url.admin.ashi.updatecasestatus}")
	private String updateCaseStatusURL;
	
	@Value("${url.admin.ashi.assigncase}")
	private String assignCaseURL;
	
	@Value("${url.admin.ashi.investigation.seekinputs}")
	private String seekInputsURL;
	
	@Value("${url.admin.ashi.investigation.sendfirtcontactmails}")
	private String sendFirtContactMailsURL;
	
	@Value("${url.admin.ashi.investigation.inputfromcomplainants}")
	private String inputFromComplainantsCardURL;
	
	@Value("${url.admin.ashi.investigation.firstcontactmail.cardview}")
	private String firstContactMailCardURL;
	
	@Value("${url.admin.ashi.investigation.firstcontactmail.genmodel}")
	private String firstContactMailsGenmodelURL;
	
	@Value("${url.admin.ashi.investigation.interimrelief.labelview}")
	private String interimReliefLabelURL;
	
	@Value("${url.admin.ashi.investigation.interimrelief.genmodel}")
	private String interimReliefGenmodelURL;
	
	@Value("${url.admin.ashi.investigation.interimrelief.submit}")
	private String interimReliefSubmitURL;
	
	@Value("${url.admin.ashi.investigation.conciliation.labelview}")
	private String conciliationLabelViewURL;
	
	@Value("${url.admin.ashi.investigation.conciliation.genmodel}")
	private String conciliationGenmodelURL;
	
	@Value("${url.admin.ashi.movecasegenmodel}")
	private String moveCaseGenmodelURL;
	
	@Value("${url.admin.ashi.movecase}")
	private String moveCaseURL;
	
	@Value("${url.admin.ashi.investigation.conciliation.submitreport}")
	private String submitConciliationReportURL;
	
	@Value("${url.admin.ashi.investigation.conciliation.initiate}")
	private String initiateConciliationURL;
	
	@Value("${url.admin.ashi.investigation.typegenmodel}")
	private String investigationTypeGenmodelURL;
	
	@Value("${url.admin.ashi.investigation.choosetype}")
	private String chooseInvestigationTypeURL;
	
	@Value("${url.admin.ashi.investigation.commentlabel}")
	private String commentLabelURL;

	@Value("${url.admin.ashi.investigation.interimrelief.action}")
	private String interimReliefActionURL;
	
	@Value("${url.admin.ashi.genmodeloptions}") 
	private String genmodelOptionsByGroupIdURL;
	
	@Value("${url.admin.ashi.investigation.issuesummons}") 
	private String issueSummonURL;

	@Value("${url.admin.ashi.investigation.summon.cardview}") 
	private String summonsCardURL;

	@Value("${url.admin.ashi.investigation.summon.genmodel}") 
	private String issueSummonGenmodelURL;
	
	@Value("${url.admin.ashi.caseemployees}") 
	private String employeeOptionURL;
	
	@Value("${url.admin.ashi.investigation.finding.delete}") 
	private String findingDeleteURL;
	
	@Value("${url.admin.ashi.investigation.finding.search}") 
	private String findingSearchURL;
	
	@Value("${url.admin.ashi.investigation.finding.addorupdate}") 
	private String findingAddOrUpdateURL;
	
	@Value("${url.admin.ashi.investigation.finding.genmodel}") 
	private String findingGenModelURL;
	
	@Value("${url.admin.ashi.investigation.recommendation.delete}") 
	private String recommendationDeleteURL;
	
	@Value("${url.admin.ashi.investigation.recommendation.addorupdate}") 
	private String recommendationAddOrUpdateURL;
	
	@Value("${url.admin.ashi.investigation.recommendation.card}") 
	private String recommendationCardsURL;
	
	@Value("${url.admin.ashi.investigation.uploadapprovals}") 
	private String uploadApprovalsURL;
	
	@Value("${url.admin.ashi.investigation.formalreport.save}") 
	private String saveFormalReportURL;
	
	@Value("${url.admin.ashi.investigation.formalreport.details}") 
	private String formalReportDetailsURL;
	
	@Value("${url.admin.ashi.investigation.formalreport.download}") 
	private String downloadformalReportURL;
	
	@Value("${url.admin.ashi.investigation.formal.checklist.genmodel}") 
	private String formalReportChecklistGenModelURL;
	
	@Value("${url.admin.ashi.investigation.formal.checklist.save}") 
	private String formalReportChecklistSaveURL;
	
	@Value("${url.admin.ashi.downloadtemplate}") 
	private String downloadTemplateURL;
	
	@Value("${url.admin.ashi.slaextension.action}") 
	private String slaExtensionActionURL;
	
	@Value("${url.admin.ashi.sendfindingsgenmodel}") 
	private String sendFindingsGenmodelURL;
	
	@Value("${url.admin.ashi.sendfindings}") 
	private String sendFindingsURL;
	
	@Value("${url.admin.ashi.consolidatedfindings}") 
	private String consolidatedFindingsURL;
	
	@Value("${url.admin.ashi.casesummary.notify}") 
	private String notifyEmployeeURL;
	
	@Value("${url.communication.reply}") 
	private String communicationReplyURL;
	
	@Value("${url.admin.ashi.investigation.chargesheet.save}") 
	private String saveChargeSheetURL;
	
}
