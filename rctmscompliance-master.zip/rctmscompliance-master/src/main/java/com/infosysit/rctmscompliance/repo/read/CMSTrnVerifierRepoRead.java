package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnVerifier;

@Repository
public interface CMSTrnVerifierRepoRead extends JpaRepository<CMSTrnVerifier, Integer> {

}
