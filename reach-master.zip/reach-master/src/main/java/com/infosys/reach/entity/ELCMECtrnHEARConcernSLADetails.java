package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmectrnhearconcernsladetails")
public class ELCMECtrnHEARConcernSLADetails {

	@Id
	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtrole")
	private String role;

	@Column(name="intsladays")
	private int slaDays;

	@Column(name="dtslastartdate")
	private Timestamp slaStartDate;
	
	@Column(name="dtslaenddate")
	private Timestamp slaEndDate;

	@Column(name="flgactive")
	private int flgactive;

	@Column(name="flgslaextensionrequest")
	private int flgSLAExtensionRequest;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="txtmodifiedby")
	private String modifiedBy;

	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtmodifiedon")
	private String modifiedOn;

	public ELCMECtrnHEARConcernSLADetails(int caseId, int slaDays, Timestamp currentDateTime,
			Timestamp slaEndDate, String createdBy) {
		super();
		this.caseId = caseId;
		this.role = "CH";
		this.slaDays = slaDays;
		this.slaStartDate = currentDateTime;
		this.slaEndDate = slaEndDate;
		this.flgactive = 1;
		this.flgSLAExtensionRequest = 0;
		this.createdBy = createdBy;
		this.modifiedBy = "";
		this.createdOn = currentDateTime;
		this.modifiedOn = "";
	}
	
	
}
