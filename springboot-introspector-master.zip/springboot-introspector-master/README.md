# Springboot-introspector

**Greetings from the EA Team.**

We have come up with an Introspect reference application/project for Spring Boot Microservices with Java. 
The reference application/project incorporates Best Practices of Spring Boot, Open API Design Specifications, Project Structure and Components. 
This provides application teams a Trusted and  Proven, technical approaches and frameworks for adoption and implementation of solutions in 
Open Source Stack.

# Purpose
The purpose of this reference application is to provide developers with project structure, design patterns and guidelines, best practices and resusable components 
for building Spring Boot Microservices. 
It also highlights the various design decisions taken with respect to different microservice types and their realizations. 

# Audience
This document is intended to serve as a base for the design and development teams 
Following are the primary audience of this document:
-	Applications Design Team
-	Applications Development Team
-	Architecture Team

# Software Prerequisites
Your Desktop/Laptop must be ready with following operating system and software before you start with Spring Boot microservice design and development.

- Operating System :  Windows 8/Windows 8.1, Windows 10 (OR) Linux (OR) Mac
- IDE	Spring Tool Suite 4.8 : Java SDK	Java SE 8 or above version Software Development Kit.
- Project Template : Maven 3.0  
- Framework	: Spring Framework 5.0 on JDK 8 & 9
- Micro services : Spring boot 5.0
- Languages : Java 8 or above 
- Spring Data :	Data JPA and Hibernate
- Rest client tool :	Postman or soap UI
- Unit test :	Junit and Mockito
- Web Container :	Tomcat or Pivotal (is part of STS editor)

# Steps to create spring boot microservices project
Steps:  
- Use Spring Initializr (http://start.spring.io)  
 (or)
- Use Spring Starter project from spring tool suite IDE

	
# Components

- Different [packages](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/tree/develop/src/main/java/com/infosys/hello/springboot) have been created for Controller, Services, Repositories, Entities, DTO.
- Connecting to Relational databases like [PostgreSQL](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/controller/CustomerController.java), MySQL, Microsoft SQL Server and NoSQL database like [MongoDB](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/controller/ProjectController.java).
- [Redis](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/controller/EmployeeController.java) caching for in-memory key value store.
- Component for decoding the [JWT](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/controller/CustomerController.java) token to provide the logged in user details.
- [Validation](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/controller/ValidatorController.java) of the request at entity/method level for incoming requests.
- Global [Exception](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/tree/develop/src/main/java/com/infosys/hello/springboot/exception) Handling
- Allowing Cross Origin Request from different domain configuration at application level ([CORS](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/application/GreetingsApplication.java)).
- [Telemetry](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/tree/develop/src/main/java/com/infosys/hello/springboot/telemetry) for capturing user behavior, errors and audit events using customized SDK built on top of Sunbird SDK
- Test project using Junit Mockito for Unit Testing.
- Service to service calls using [Feign](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/java/com/infosys/hello/springboot/api/EmployeeServiceClient.java) declarative client.
- Configuration for different [profiles](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/tree/develop/src/main/resources) for different environments – Dev, Staging and Production.
- Deploy services as [Docker](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/-/blob/master/DockerFile) images on premise as well as in Azure Cloud.
- Resilience/Circuit breaker pattern against cascading failures at different levels using [Hystrix](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/-/blob/swagger-3/Documents/Hystrix%20Implementation%20manual.docx).
- K8 Configure Liveness, Readiness and Startup [Probes](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/-/blob/master/k8-compose-test.yml)
- Distributed tracing using [Sleuth](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/pom.xml).
- Managing secrets in vault and allow applications to access in transparent way using [Spring Cloud Vault](https://infosystechnologies.sharepoint.com/:f:/s/EnterpriseArchitecture/EkJCJsIkJv5IudznyJ5-EOsBqFK34GVG-CN926bXt2renw?e=IregvS).
- Monitoring services using [Prometheus](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/blob/develop/src/main/resources/prometheus.yml) (including container monitoring) is in progress.
- Documentation of REST APIs using [Swagger OpenAPI 3](https://infygit.ad.infosys.com/ea/springboot/springboot-introspector/-/blob/swagger-3/Documents/Swagger%20OpenAPI%203%20Implementation%20manual.docx). 


Refer [spring boot components](http://infygit.ad.infosys.com/ea/springboot/springboot-introspector/wikis/pages) for more details

# Documents / Reference
- [Spring Boot Microservice - Developer Guidelines](https://infosystechnologies.sharepoint.com/:w:/s/MicroservicesInfosysIT/EYx3qE7hjadAmmhg1RzBCekB2gYYEEEMpjQm4e_8lB_pmA?e=pW4Qzx)    
- [Java Coding Standards](http://infygit.ad.infosys.com/ea/springboot/springboot-documents/blob/master/Java%20Coding%20Standards.doc)   
- [REST API Best Practices](http://infygit.ad.infosys.com/ea/springboot/springboot-documents/blob/master/RestAPI-BestPractices.pptx)   

