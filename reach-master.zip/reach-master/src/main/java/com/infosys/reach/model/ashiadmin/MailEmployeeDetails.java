package com.infosys.reach.model.ashiadmin;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class MailEmployeeDetails {

	private String mailId;
	private String empName;
	private String empNo;
	private String assigneeMailId;
	private String assigneeLocation;
	private String slaEndDate;
	
	
	public MailEmployeeDetails(String mailId, String empName, String empNo, String assigneeMailId,
			String assigneeLocation, Date slaEndDate) {
		super();
		this.mailId = mailId;
		this.empName = empName;
		this.empNo = empNo;
		this.assigneeMailId = assigneeMailId;
		this.assigneeLocation = assigneeLocation;
		this.slaEndDate = slaEndDate!=null ? new SimpleDateFormat(Constants.DATE_FORMAT).format(slaEndDate) : "";
	}
	
	
	
}
