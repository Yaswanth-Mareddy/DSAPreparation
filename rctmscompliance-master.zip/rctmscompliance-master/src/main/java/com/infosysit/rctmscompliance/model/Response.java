package com.infosysit.rctmscompliance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.infosysit.rctmscompliance.util.Constants;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@JsonInclude(value = Include.NON_DEFAULT)
public class Response {

	private String type;
	private String content;
	private String htmlContent;
	private String value;
	
	public Response(String type, String content) {
		super();
		this.type = type;
		this.content = content;
		this.htmlContent = "";
	}
	
	public Response(String msg) {
		super();
		this.type = Constants.FAILURE;
		this.content = msg;
	}

}
