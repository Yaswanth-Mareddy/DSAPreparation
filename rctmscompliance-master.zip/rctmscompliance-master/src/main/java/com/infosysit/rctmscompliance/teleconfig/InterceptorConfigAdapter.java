package com.infosysit.rctmscompliance.teleconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.infosysit.rctmscompliance.controller.RctmsInterceptor;


@Component
public class InterceptorConfigAdapter implements WebMvcConfigurer {
	

	@Autowired
	private RctmsInterceptor rctmsInterceptor;
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		//register controller interceptor 
		registry.addInterceptor(rctmsInterceptor);
	}
}
