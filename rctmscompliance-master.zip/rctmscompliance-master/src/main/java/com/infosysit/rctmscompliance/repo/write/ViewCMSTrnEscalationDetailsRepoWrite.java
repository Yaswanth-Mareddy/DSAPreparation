package com.infosysit.rctmscompliance.repo.write;


import org.springframework.data.jpa.repository.JpaRepository;

import com.infosysit.rctmscompliance.entity.ViewCMSTrnEscalationDetails;

public interface ViewCMSTrnEscalationDetailsRepoWrite extends JpaRepository<ViewCMSTrnEscalationDetails, Integer> {
	
}
