package com.infosysit.rctmscompliance.util;

public class InfraConstants {
	private InfraConstants() {
		
	}
    // <summary>
    /// Domain prefix
    /// </summary>
    public static final String INFOSYSDOMAINPREFIXITL = "ITLINFOSYS\\";

    /// <summary>
    /// Domain prefix
    /// </summary>
    public static final String INFOSYSDOMAINSUFFIX = "@INFOSYS.COM";

    /// <summary>
    /// Domain prefix
    /// </summary>
    public static final String INFOSYSDOMAINSUFFIXAD = "@AD.INFOSYS.COM";

}
