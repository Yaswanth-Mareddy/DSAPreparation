package com.infosys.reach.model.ashiadmin;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class PreliminaryDiscussionDetails {
	
	private int transactionid;
	private String createdOn;
	private String discussedWith;
	private String role;
	private String discussionSummary;
	private List<String> documents;
	
	
	public PreliminaryDiscussionDetails(int serialNo, Date createdOn, String discussedWith, String role, String discussionSummary,
			String documents) {
		super();
		this.transactionid = serialNo;
		this.createdOn = new SimpleDateFormat(Constants.DATE_FORMAT).format(createdOn);
		this.discussedWith = discussedWith.trim();
		this.role = role.trim();
		this.discussionSummary = discussionSummary.trim();
		this.documents = documents!=null && !documents.isEmpty() ? Arrays.asList(documents.split(",")) : new ArrayList<>();
	}
	
	
	

}
