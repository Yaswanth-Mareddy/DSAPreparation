package com.infosys.reach;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



//@EnableDiscoveryClient
@SpringBootApplication
public class ReachApplication {

	public static void main(String[] args) {
	
		SpringApplication.run(ReachApplication.class, args);
	}

}
