package com.infosys.reach.service;


import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.reach.entity.ELCMECMstHearEmployeeCaseDetails;
import com.infosys.reach.entity.ELCMECMstHearTaggedEmpDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnHearActionDetails;
import com.infosys.reach.entity.ELCMECTrnHearCaseDetails;
import com.infosys.reach.entity.ELCMECTrnHearEmpGeneralDetails;
import com.infosys.reach.entity.ELCMECtrnHEARConcernSLADetails;
import com.infosys.reach.entity.HRISTrnEmpLocation;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailInfo;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.PlaceHolder;
import com.infosys.reach.model.hear.CaseDetailsValidationResponse;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.model.hear.HearAccess;
import com.infosys.reach.model.hear.HearCaseDetails;
import com.infosys.reach.model.hear.HearCaseResponse;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.hear.Policy;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstHearEmployeeCaseDetailsRepository;
import com.infosys.reach.repository.ELCMECMstHearTaggedEmpDetailsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECMstUnitHearRepository;
import com.infosys.reach.repository.ELCMECTrnHearActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnHearCaseDetailsRepo;
import com.infosys.reach.repository.ELCMECTrnHearEmpGeneralDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECtrnHEARConcernSLADetailsRepository;
import com.infosys.reach.repository.GENMstCityRepository;
import com.infosys.reach.repository.GenMstInfosysEstablishmentsRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.repository.HRISTrnEmpLocationRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.util.Constants;





@Service
public class HearServiceImpl implements HearService{
	
	private Timestamp currentDateTime=new Timestamp(ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli() + 19800000);

	private String currentCountry=null;
	
	@Autowired
	private Property property;

	@Autowired
	private CommonServiceImpl commonService;


	@Autowired
	private ViewCurrEmpAllDetailsRepository viewAllEmpDetailsRepository;

	@Autowired
	private ELCMECTrnHearCaseDetailsRepo hearCaseDetailsRepo;

	@Autowired
	private ELCMECTrnHearEmpGeneralDetailsRepository elcmecTrnHearEmpGeneralDetailsRepository;

	@Autowired
	private GenMstInfosysEstablishmentsRepository genMstInfosysEstablishmentsRepository;

	@Autowired
	private HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Autowired
	private ELCMECMstHearEmployeeCaseDetailsRepository hearEmployeeCaseDetailsRepository;

	@Autowired
	private ELCMECMstHearTaggedEmpDetailsRepository hearTaggedEmpDetailsRepository;

	@Autowired
	private ELCMECTrnHearActionDetailsRepository hearActionDetailsRepository;

	@Autowired
	private ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;

	@Autowired
	private ELCMECtrnHEARConcernSLADetailsRepository  hearConcernSLADetailsRepository;

	@Autowired
	private ELCMECMstConcernModulesDetailsRepository concernModulesDetailsRepository;

	@Autowired
	private ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Autowired
	private GENMstCityRepository cityRepository;

	@Autowired
	private HRISTrnEmpLocationRepository empLocationRepository;

	@Autowired
	private GenMstMailConfigHeaderRepository mailConfigHeaderRepository;

	@Autowired
	private ELCMECMstUnitHearRepository unitHearRepository;



	@Override
	@Transactional(rollbackFor = Exception.class)
	public HearCaseResponse initiateHearCase(String reporteeEmpNo, String reporteeMailId, String reporteeEmpName, HearCaseDetails caseDetails,List<String> taggedEmpMailIdList) throws CustomException {
		int caseId=0;
		ELCMECTrnHearCaseDetails elcmecTrnHearCaseDetails=new ELCMECTrnHearCaseDetails(caseDetails, reporteeEmpNo, currentDateTime);
		ELCMECTrnHearCaseDetails reportedCaseDetails = hearCaseDetailsRepo.save(elcmecTrnHearCaseDetails);
		caseId=reportedCaseDetails.getCaseId();
		ELCMECTrnHearEmpGeneralDetails hearEmpGeneralDetails=new ELCMECTrnHearEmpGeneralDetails(caseId, reporteeEmpNo, caseDetails, currentDateTime);
		elcmecTrnHearEmpGeneralDetailsRepository.save(hearEmpGeneralDetails);

		String countryCode = genMstInfosysEstablishmentsRepository.findSapCountryCode(currentCountry);
		
		List<ELCMECMstHearEmployeeCaseDetails> hearEmployeeCaseDetailsList=new ArrayList<>();
		
		if(!StringUtils.isBlank(caseDetails.getRespondentEmpNo())) {
			List<CaseEmployeeDetails> respondentCaseDetailsObj=hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getRespondentEmpNo());
			if(respondentCaseDetailsObj.isEmpty())
				throw new CustomException(Message.SOMETHING_WENT_WRONG);

			ELCMECMstHearEmployeeCaseDetails respondentCaseDetails = new ELCMECMstHearEmployeeCaseDetails(caseId, respondentCaseDetailsObj.get(0), countryCode,"R", caseDetails.getSelectedCountry(), caseDetails.getSelectedCity());
			hearEmployeeCaseDetailsList.add(respondentCaseDetails);
		}
		List<CaseEmployeeDetails> accusedCaseDetailsObj=hrisMstEmployeeRepository.findCaseEmployeeDetails(reporteeEmpNo);
		if(accusedCaseDetailsObj.isEmpty())
			throw new CustomException(Message.SOMETHING_WENT_WRONG);

		ELCMECMstHearEmployeeCaseDetails accusedCaseDetails = new ELCMECMstHearEmployeeCaseDetails(caseId, accusedCaseDetailsObj.get(0), countryCode,"A", caseDetails.getSelectedCountry(), caseDetails.getSelectedCity());
		hearEmployeeCaseDetailsList.add(accusedCaseDetails);
		
		hearEmployeeCaseDetailsRepository.saveAll(hearEmployeeCaseDetailsList);
		
		
		for(String mailId:taggedEmpMailIdList) {
				if(mailId!=null && !mailId.isEmpty()) {
					ELCMECMstHearTaggedEmpDetails hearTaggedEmpDetails=new ELCMECMstHearTaggedEmpDetails(caseId, mailId);
					hearTaggedEmpDetailsRepository.save(hearTaggedEmpDetails);
				}	
			}


		//dmsfilename is null
		ELCMECTrnHearActionDetails hearActionDetails=new ELCMECTrnHearActionDetails(caseId, caseDetails.getComments(), reporteeEmpNo, currentDateTime);
		hearActionDetailsRepository.save(hearActionDetails);
		
		int slaDays=0;
		Optional<ELCMECMstSysParams> sysParam = elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("CH", "SLA");
		
		if(sysParam.isPresent()) {
			slaDays=Integer.parseInt(sysParam.get().getParamValue());
		}
		
		Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
		ELCMECtrnHEARConcernSLADetails hearConcernSLADetails=new ELCMECtrnHEARConcernSLADetails(caseId, slaDays, currentDateTime, slaEndDateTime, reporteeEmpNo);
		hearConcernSLADetailsRepository.save(hearConcernSLADetails);


		//trigger mail
		String category=concernModulesDetailsRepository.findCategoryByCaseId(caseId).trim();

		MailContent reporteesMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCI");
		String reporteesMailSubject=reporteesMailInfo.getSubject().replace(Constants.APPEALNOPH, String.valueOf(caseId)).replace(Constants.CATEGORYNAME, category);
		String reporteesMailBody=reporteesMailInfo.getBody().replace(Constants.EMPRAISEDPH, reporteeEmpName).replace(Constants.APPEALNOPH, String.valueOf(caseId)).replace(Constants.CATEGORYNAME, category);
		reporteesMailInfo.setBody(reporteesMailBody);
		reporteesMailInfo.setSubject(reporteesMailSubject);

		String reporteesMailId=reporteeMailId + property.getInfyDomain();


		MailInfo reporteesMailInfoObj=new MailInfo(property.getHearMailerAappCode(), property.getHearMailerEventId(), property.getHearMailerTemplateId(), property.getHearFromId(), reporteesMailId, "");
		PlaceHolder[] reporteesPlaceHolders = {(new PlaceHolder("Subject", reporteesMailInfo.getSubject())),new PlaceHolder("Body", reporteesMailInfo.getBody())};

		MailerAssistRequest reporteesMailObj=new MailerAssistRequest(reporteesMailInfoObj, reporteesPlaceHolders);
		MailerAssistResponse reporteesMailerResponse = commonService.triggerMail(reporteesMailObj);
		if(reporteesMailerResponse.getCode()!=0)
			throw new CustomException("Reportees " + Message.MAIL_NOT_TRIGGERED + reporteesMailerResponse.getMessage());


		MailContent corporateHearMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("HEARMOCH");
		String corporateHearSubject=corporateHearMailInfo.getSubject().replace(Constants.APPEALNOPH, String.valueOf(caseId)).replace(Constants.CATEGORYNAME, category);
		String corporateHearBody=corporateHearMailInfo.getBody().replace(Constants.EMPRAISEDPH, reporteeEmpName).replace("#ReqNo#", String.valueOf(caseId)).replace("#EmpID#", reporteeEmpNo).replace(Constants.CATEGORYNAME, category).replace("#Link#", property.getHearURL());
		corporateHearMailInfo.setBody(corporateHearBody);
		corporateHearMailInfo.setSubject(corporateHearSubject);

		List<String> unitHearMailIDs=unitHearRepository.findUnitHearMailIds();
		StringBuilder unitHearToIds=new StringBuilder();
		for(String id:unitHearMailIDs) {
			if(unitHearToIds.length()==0)
				unitHearToIds.append(id.trim()).append(property.getInfyDomain());
			else
				unitHearToIds.append(",").append(id.trim()).append(property.getInfyDomain());
		}

		MailInfo unitHearMailInfoObj=new MailInfo(property.getHearMailerAappCode(), property.getHearMailerEventId(), property.getHearMailerTemplateId(), property.getHearFromId(), unitHearToIds.toString(), "");
		PlaceHolder[] unitHearPlaceHolders = {(new PlaceHolder("Subject", corporateHearMailInfo.getSubject())),new PlaceHolder("Body", corporateHearMailInfo.getBody())};

		MailerAssistRequest unitHearMailObj=new MailerAssistRequest(unitHearMailInfoObj, unitHearPlaceHolders);
		MailerAssistResponse mailerResponse = commonService.triggerMail(unitHearMailObj);
		if(mailerResponse.getCode()!=0)
			throw new CustomException("Unit Hear " + Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());

		return new HearCaseResponse(caseId,"Done! Your appeal is submitted under "+category+" category with Appeal id "+caseId+".");
	}

	private CaseDetailsValidationResponse validateCaseDetailsFirst(String reporteeEmpNo, HearCaseDetails caseDetails) {
		if(!this.checkHearAccess(reporteeEmpNo).isHasAccess())
			return new CaseDetailsValidationResponse(false,"You don't have access to use hear.");

		if(caseDetails.getModuleId()!=3)
			return new CaseDetailsValidationResponse(false,"Module id should be 3 only");

		if(caseDetails.getFlgManager()!=0 && caseDetails.getFlgManager()!=1)
			return new CaseDetailsValidationResponse(false, "FlgManager should be 1 or 0");

		if((caseDetails.getManagerReason()!=null && !caseDetails.getManagerReason().isEmpty()) && caseDetails.getFlgManager()==1)	
			return new CaseDetailsValidationResponse(false, "ManagerReason should be empty if FlgManager is 1");

		if((caseDetails.getManagerReason()==null || caseDetails.getManagerReason().isEmpty()) && caseDetails.getFlgManager()==0)	
			return new CaseDetailsValidationResponse(false, "ManagerReason is required if FlgManager is 0");

		if(caseDetails.getFlgReviewer()!=0 && caseDetails.getFlgReviewer()!=1)
			return new CaseDetailsValidationResponse(false, "FlgReviewer should be 1 or 0");

		if((caseDetails.getReviewerReason()!=null && !caseDetails.getReviewerReason().isEmpty()) && caseDetails.getFlgReviewer()==1)	
			return new CaseDetailsValidationResponse(false, "ReviewerReason should be empty if FlgReviewer is 1");
		
		return new CaseDetailsValidationResponse(true);
	}
	
	private CaseDetailsValidationResponse validateCaseDetailsSecond(String reporteeEmpNo, String reporteeMailID, HearCaseDetails caseDetails) {

		if((caseDetails.getReviewerReason()==null || caseDetails.getReviewerReason().isEmpty()) && caseDetails.getFlgReviewer()==0)	
			return new CaseDetailsValidationResponse(false, "ReviewerReason is required if FlgReviewer is 0");

		if(caseDetails.getFlgUnitHR()!=0 && caseDetails.getFlgUnitHR()!=1)
			return new CaseDetailsValidationResponse(false, "FlgUnitHR should be 1 or 0");

		if((caseDetails.getUnitHRReason()!=null && !caseDetails.getUnitHRReason().isEmpty()) && caseDetails.getFlgUnitHR()==1)	
			return new CaseDetailsValidationResponse(false, "UnitHRReason should be empty if FlgUnitHR is 1");

		if((caseDetails.getUnitHRReason()==null || caseDetails.getUnitHRReason().isEmpty()) && caseDetails.getFlgUnitHR()==0)	
			return new CaseDetailsValidationResponse(false, "UnitHRReason is required if FlgUnitHR is 0");

		if(caseDetails.getEmpManager()==null || caseDetails.getEmpManager().isEmpty())
			return new CaseDetailsValidationResponse(false,"Manager's mailid can't be empty");
		
		if(caseDetails.getEmpManager().trim().equals(reporteeEmpNo) || caseDetails.getEmpManager().trim().equalsIgnoreCase(reporteeMailID))
			return new CaseDetailsValidationResponse(false,"Manager's id cannot be same as reportees mailid");

		
		Optional<ViewCurrEmpAllDetails> managerDetails = viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpManager().trim());
		if(!managerDetails.isPresent())
			return new CaseDetailsValidationResponse(false,"Manager's mailid is invalid");
		caseDetails.setEmpManager(managerDetails.get().getMailId());
		
		return new CaseDetailsValidationResponse(true);
	}
	
	private CaseDetailsValidationResponse validateCaseDetailsThird(String reporteeEmpNo, String reporteeMailID, HearCaseDetails caseDetails) {
		if(caseDetails.getEmpReviewer()==null || caseDetails.getEmpReviewer().isEmpty())
			return new CaseDetailsValidationResponse(false,"Reviewer's mailid can't be empty");

		if(caseDetails.getEmpReviewer().trim().equals(reporteeEmpNo) || caseDetails.getEmpReviewer().trim().equalsIgnoreCase(reporteeMailID))
			return new CaseDetailsValidationResponse(false,"Reviewer's id cannot be same as reportees mailid");

		Optional<ViewCurrEmpAllDetails> reviewerDetails = viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getEmpReviewer().trim());
		if(!reviewerDetails.isPresent())
			return new CaseDetailsValidationResponse(false,"Reviewer's mailid is invalid");
		caseDetails.setEmpReviewer(reviewerDetails.get().getMailId());
		
		if(caseDetails.getRespondentEmpNo()!=null && !caseDetails.getRespondentEmpNo().isEmpty()) {
			if(caseDetails.getRespondentEmpNo().trim().equals(reporteeEmpNo) || caseDetails.getRespondentEmpNo().trim().equalsIgnoreCase(reporteeMailID))
				return new CaseDetailsValidationResponse(false,"Respondent's id cannot be same as reportees mailid");

			Optional<ViewCurrEmpAllDetails> respondentDetails = viewAllEmpDetailsRepository.findByEmpNoOrMailId(caseDetails.getRespondentEmpNo().trim());
			if(!respondentDetails.isPresent())
				return new CaseDetailsValidationResponse(false,"Respondent's mailid is invalid");
			caseDetails.setRespondentEmpNo(respondentDetails.get().getEmpNo());
		}
		
		return new CaseDetailsValidationResponse(true);
	}
	
	private CaseDetailsValidationResponse validateCaseDetailsFourth(String reporteeEmpNo, String reporteeMailID, HearCaseDetails caseDetails, List<String> taggedEmpMailIdList) {
		
		if(caseDetails.getTaggedEmpMailId()!=null && !caseDetails.getTaggedEmpMailId().isEmpty()) {
			String[] employeesList=caseDetails.getTaggedEmpMailId().split(",");
			StringBuilder taggedEmpMailIdString=new StringBuilder();
			for(String empId:employeesList) {
				if(empId.trim().equals(reporteeEmpNo) || empId.trim().equalsIgnoreCase(reporteeMailID))
					return new CaseDetailsValidationResponse(false,"Tagged employee id '"+empId+"' cannot be same as reportees mailid");
				Optional<ViewCurrEmpAllDetails> taggedEmpDetails = viewAllEmpDetailsRepository.findByEmpNoOrMailId(empId.trim());
				if(!taggedEmpDetails.isPresent())
					return new CaseDetailsValidationResponse(false,"Tagged employee id '"+empId+"' is invalid");
				if(taggedEmpMailIdString.length()==0)
					taggedEmpMailIdString.append(taggedEmpDetails.get().getMailId());
				else
					taggedEmpMailIdString.append(", ").append(taggedEmpDetails.get().getMailId());
				taggedEmpMailIdList.add(taggedEmpDetails.get().getMailId());
			}
			caseDetails.setTaggedEmpMailId(taggedEmpMailIdString.toString());
		}
		
		return new CaseDetailsValidationResponse(true);
	}
	
	@Override
	public CaseDetailsValidationResponse validateCaseDetails(String reporteeEmpNo, String reporteeMailID, HearCaseDetails caseDetails){
		
		CaseDetailsValidationResponse validationFirst=this.validateCaseDetailsFirst(reporteeEmpNo, caseDetails);
		if(!validationFirst.isStatus())
			return validationFirst;

		CaseDetailsValidationResponse validationSecond=this.validateCaseDetailsSecond(reporteeEmpNo, reporteeMailID, caseDetails);
		if(!validationSecond.isStatus())
			return validationSecond;
		
		CaseDetailsValidationResponse validationThird=this.validateCaseDetailsThird(reporteeEmpNo, reporteeMailID, caseDetails);
		if(!validationThird.isStatus())
			return validationThird;
		List<String> taggedEmpMailIdList=new ArrayList<>();
		CaseDetailsValidationResponse validationFourth=this.validateCaseDetailsFourth(reporteeEmpNo, reporteeMailID, caseDetails,taggedEmpMailIdList);
		if(!validationFourth.isStatus())
			return validationFourth;

		if(caseDetails.getSelectedCountry()==null || caseDetails.getSelectedCountry().isEmpty())
			return new CaseDetailsValidationResponse(false,"Selected country is required");

		if(caseDetails.getSelectedCity()==null || caseDetails.getSelectedCity().isEmpty())
			return new CaseDetailsValidationResponse(false,"Selected city is required");

		if(caseDetails.getComments()==null || caseDetails.getComments().isEmpty())
			return new CaseDetailsValidationResponse(false,"Comment is required");

		return new CaseDetailsValidationResponse(true,"Validated",caseDetails,taggedEmpMailIdList);
	}


	@Override
	public List<Categories> getConcernModuleDetails(int moduleId, String company, String countryCode) {
		List<Categories> categories;
		if(moduleId==3) {
			if(company!=null && !company.isEmpty())
				categories = concernModulesDetailsRepository.findDistinctByModuleIdAndCompany(moduleId, company);
			else
				categories = concernModulesDetailsRepository.findDistinctByModuleIdAndCompany(moduleId, "INFSYS");
		}

		else {
			if(company!=null && !company.isEmpty() && countryCode!=null && !countryCode.isEmpty())
				categories = concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(moduleId, company, countryCode);
			else
				categories = concernModulesDetailsRepository.findDistinctByModuleIdAndCompanyAndCountryCode(moduleId, "INFSYS","IN");
		}

		return categories;
	}

	@Override
	public List<Countries> getCountriesByModuleId(int moduleId) {
		return reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnable(moduleId, 1);
	}

	@Override
	public List<Cities> getCitiesByCountryCode(String countryCode) {
		List<Cities> citiesList=cityRepository.getCitiesByCountryCode(countryCode);
		if(countryCode.trim().equalsIgnoreCase("IN") && !citiesList.isEmpty())
			citiesList.add(new Cities(0,"MYSORE-GEC"));
		return citiesList;
	}

	@Override
	public HearAccess checkHearAccess(String empNo) {

		String baseLocation=genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(empNo);
		Optional<HRISTrnEmpLocation> empLocationObj=empLocationRepository.findByEmpNo(empNo);

		if(empLocationObj.isPresent()) {

			String currentLocation=empLocationObj.get().getCurrentCountryCode();

			if(baseLocation!=null && !baseLocation.isEmpty() && currentLocation!=null && !currentLocation.isEmpty() && (baseLocation.trim().equalsIgnoreCase("INDIA") && currentLocation.trim().equalsIgnoreCase("IN"))) {

				DPServiceOutput consentStatus;
				try {
					consentStatus = commonService.dpService("Hear","STATUS");
					if(!consentStatus.getContent().isEmpty()) {
						currentCountry=baseLocation.trim();
						return new HearAccess(true,consentStatus.getContent());
					}
					else
						return new HearAccess(true,consentStatus.getContent());
				} catch (CustomException e) {
					return new HearAccess(false,"");
				}
			}			
		}

		return new HearAccess(false,"");
	}


	@Override
	public Policy getHearPolicy() {
		return new Policy();
	}



}


