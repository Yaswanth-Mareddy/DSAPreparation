package com.infosys.hello.springboot.validation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.hello.springboot.dto.ValidatorDTO;
import com.infosys.hello.springboot.exception.ErrorDetails;
import com.infosys.hello.springboot.service.ValidatorService;

public class ValidatorControllerTests extends AbstractTest {
	
	@MockBean
	ValidatorService validationService;
	
	@Override
	@Before
	public void setUp() {
	    super.setUp();
	}
	
	@Test
	public void savePositiveTest() throws Exception{
		ValidatorDTO obj = new ValidatorDTO();
		obj.setName("john");
		obj.setAge(23);
		obj.setPhoneNumber("123");
		String uri = "/save";
		
		String responseExpected = "obj saved successfully";
		
		Mockito.when(validationService.save(Mockito.any(ValidatorDTO.class)))
										.thenReturn(responseExpected);
		
		String objJson = super.mapToJson(obj);
		
		RequestBuilder request = MockMvcRequestBuilders.post(uri)
													   .accept(MediaType.APPLICATION_JSON_VALUE)
													   .content(objJson)
													   .contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		String responseActual = result.getResponse().getContentAsString();
		
		assertTrue(responseExpected.equals(responseActual));
	}
	
	@Test
	public void saveNegativeTest() throws Exception{
		ValidatorDTO obj = new ValidatorDTO();
		obj.setName(null);
		obj.setAge(23);
		obj.setPhoneNumber("123");
		
		String uri = "/save";
		
		ErrorDetails errorExpected = new ErrorDetails("Validation Failed",
				  "DefaultMessageSourceResolvable: codes [objDTO.name,name]; arguments []; default message [name]]; default message [must not be null]");

		
		String objJson = super.mapToJson(obj);
		
		RequestBuilder request = MockMvcRequestBuilders.post(uri)
													   .accept(MediaType.APPLICATION_JSON_VALUE)
													   .content(objJson)
													   .contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		String content = result.getResponse().getContentAsString();
		
		ErrorDetails errorActual = super.mapFromJson(content, ErrorDetails.class);
		
		assertTrue(errorExpected.getMessage().equals(errorActual.getMessage()));
	}
	
	@Test
	public void getObjectPositiveTest() throws Exception{
		
		String uri = "/user";
		
		ValidatorDTO objExpected = new ValidatorDTO();
		objExpected.setName("John");
		objExpected.setAge(23);
		objExpected.setPhoneNumber("123");
		
		Mockito.when(validationService.getObj("John")).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get(uri)
													   .param("name", "John")
													   .accept(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);

		
		String content = result.getResponse().getContentAsString();
		
		ValidatorDTO objActual = super.mapFromJson(content, ValidatorDTO.class);
		
		assertTrue(objExpected.getName().equals(objActual.getName()));
	}
	
	
	@Test
	public void getObjectNegativeTest() throws Exception{
		
		String uri = "/user";
		
		ErrorDetails errorExpected = new ErrorDetails("Validation Failed",
				  									  "getObject.name: must not be empty");

		
		RequestBuilder request = MockMvcRequestBuilders.get(uri)
													   .param("name", "")
													   .accept(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();
		
		ErrorDetails errorActual = super.mapFromJson(content, ErrorDetails.class);
		
		assertTrue(errorExpected.getDetails().equals(errorActual.getDetails()));
	}
}
