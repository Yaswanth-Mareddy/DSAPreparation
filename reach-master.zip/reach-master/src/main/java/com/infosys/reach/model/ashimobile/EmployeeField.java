package com.infosys.reach.model.ashimobile;




import com.infosys.reach.model.common.EmployeeDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeField {
	private String empName;
	private String empNo;
	private String mailId;
	public EmployeeField(EmployeeDetails details) {
		super();
		this.empName = details.getName().trim();
		this.empNo = details.getEmpNo().trim();
		this.mailId = details.getMailId().trim();
	}
	
	
}
