package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="genmstempdetails")
public class GenMstEmpDetails {

	@Id
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtducode_new")
	private String duCode;
}
