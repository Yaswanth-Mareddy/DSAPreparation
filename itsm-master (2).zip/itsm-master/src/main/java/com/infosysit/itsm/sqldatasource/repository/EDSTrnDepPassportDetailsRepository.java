package com.infosysit.itsm.sqldatasource.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.itsm.model.EDSTrnDepPassportDetailsModel;
import com.infosysit.itsm.sqldatasource.entity.EDSTrnDepPassportDetails;
import com.infosysit.itsm.util.QueryConstants;

public interface EDSTrnDepPassportDetailsRepository extends JpaRepository<EDSTrnDepPassportDetails, Integer> {
	
	@Query(value=QueryConstants.GETDEPENDENTPASSPORTDETAILS)
	List<EDSTrnDepPassportDetailsModel> getDependentPassportDetails(@Param("txtEmpNo") String txtEmpNo);
	

}
