package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.ViewCMSMstInboxDetailsWithEmpID;
import com.infosysit.rctmscompliance.model.ComplianceInbox;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface ViewCMSMstInboxDetailsWithEmpIDRepoRead extends JpaRepository<ViewCMSMstInboxDetailsWithEmpID, Integer>{
	
	@Query(value=CustomQueries.CMSGETDATAFORINBOX+"where view.txtPendingwith = :txtEmpNo")
	public List<ComplianceInbox> viewComplianceinboxPendingWithEmp(@Param("txtEmpNo") String txtEmpNo);
	
	@Query(value=CustomQueries.CMSGETDATAFORINBOX+"where view.txtPendingwith = :txtEmpNo and view.txtStatus = :txtStatus")
	public List<ComplianceInbox> viewComplianceinboxPendingWithEmpByStatus(@Param("txtEmpNo") String txtEmpNo,@Param("txtStatus") String txtStatus);
	
	@Query(value=CustomQueries.CMSGETDATAFORINBOX+"where view.txtAssignee = :txtEmpNo or view.txtVerifier = :txtEmpNo or view.txtOwner = :txtEmpNo")
	public List<ComplianceInbox> viewComplianceinboxAllWithEmp(@Param("txtEmpNo") String txtEmpNo);
	
	@Query(value=CustomQueries.CMSGETDATAFORINBOX+"where view.txtStatus = :txtStatus and (view.txtAssignee = :txtEmpNo or view.txtVerifier = :txtEmpNo or view.txtOwner = :txtEmpNo)")
	public List<ComplianceInbox> viewComplianceinboxAllWithEmpByStatus(@Param("txtEmpNo") String txtEmpNo,@Param("txtStatus") String txtStatus);

	@Query(value="select distinct v.dtAssignedDate from ViewCMSMstInboxDetailsWithEmpID as v where v.intComplianceID= :intComplianceID")
	public String getAssignedDate(@Param("intComplianceID") int intComplianceID);
	
	@Query(value="select view.txtStatus from  ViewCMSMstInboxDetailsWithEmpID view where view.intComplianceID= :intComplianceID and view.dtAssignedDate= :dtAssignedDate")
	public String getStatus(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
	
}
