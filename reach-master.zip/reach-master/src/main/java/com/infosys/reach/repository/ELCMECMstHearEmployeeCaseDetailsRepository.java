package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstHearEmployeeCaseDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstHearEmployeeCaseDetailsRepository extends JpaRepository<ELCMECMstHearEmployeeCaseDetails,Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECMstHearEmployeeCaseDetails> S save(S entity);
}
