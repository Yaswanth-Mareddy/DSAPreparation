package com.infosys.reach.model.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AccordionModel {

	private int order;
	private String status;
	private String heading;
	private String apiType;
	private String value;
	private String type;
}
