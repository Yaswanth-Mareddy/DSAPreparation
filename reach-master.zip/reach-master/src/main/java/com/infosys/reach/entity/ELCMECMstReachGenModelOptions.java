package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmecmstreachgenmodeloptions")
public class ELCMECMstReachGenModelOptions {

	@Id
	@Column(name="intserialno")
	private int serialNo;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="txtgroupid")
	private String groupId;
	
	@Column(name="txtkey")
	private String key;
	
	@Column(name="txtvalue")
	private String value;
	
	@Column(name="flgactive")
	private int flgActive;
}
