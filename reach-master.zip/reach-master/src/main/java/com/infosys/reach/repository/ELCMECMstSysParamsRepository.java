package com.infosys.reach.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstSysParamsRepository extends JpaRepository<ELCMECMstSysParams, String> {
	
	@TrackExecutionTime
	Optional<ELCMECMstSysParams> findByParamIdAndContextOrderByParamValueDesc(String paramId,String context);
	
	@TrackExecutionTime
	Optional<ELCMECMstSysParams> findByParamIdAndContextAndParamValue(String paramId, String context, String moduleid);


}
