package com.infosys.reach.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.reach.controller.Session;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ComplaintDetails;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.CaseGenModelField;
import com.infosys.reach.model.ashimobile.CaseGenModelForm;
import com.infosys.reach.model.ashimobile.CaseGenModelFormData;
import com.infosys.reach.model.ashimobile.ComplaintField;
import com.infosys.reach.model.ashimobile.EmployeeCard;
import com.infosys.reach.model.ashimobile.EmployeeCardView;
import com.infosys.reach.model.ashimobile.EmployeeField;
import com.infosys.reach.model.ashimobile.EvidenceCard;
import com.infosys.reach.model.ashimobile.EvidenceCardView;
import com.infosys.reach.model.ashimobile.EvidenceField;
import com.infosys.reach.model.ashimobile.MobileComplaintInboxView;
import com.infosys.reach.model.ashimobile.MobileInboxAction;
import com.infosys.reach.model.ashimobile.MobileInboxView;
import com.infosys.reach.model.ashimobile.MobileRow;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@Service
@Transactional(rollbackFor = CustomException.class)
public class ASHIMobileServiceImpl implements ASHIMobileService {

	@Autowired
	private Property property;
	
	@Autowired
	private ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;

	@Autowired
	private ELCMECMstASHICaseEmployeeDetailsRepository ashiCaseEmployeeDetailsRepository;

	@Autowired
	private ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;

	@Autowired
	private ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Autowired
	private ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;

	@Autowired
	private ASHIServiceImpl ashiService;
	

	@Override
	public CaseFormGenModel initiateCaseForm() throws CustomException {

		
		List<CaseGenModelForm> genModelFormList = new ArrayList<>();
		List<CaseGenModelForm> accordionFormList = new ArrayList<>();

		// Respondent section
		List<CaseGenModelField> respondentFieldList = new ArrayList<>();
		List<GenModelOption> respondentTypeOptions = new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee", true));
		respondentTypeOptions.add(new GenModelOption(0, Constants.OTHERS));
		CaseGenModelField complaintAgainst = new CaseGenModelField(47, "respondentType", "", 1, "",
				respondentTypeOptions, true);
		
		complaintAgainst.setLabel("Respondent (Complaint against ) is an");
		respondentFieldList.add(complaintAgainst);

		CaseGenModelField isIdentityKnown = new CaseGenModelField(45, "isRespondentKnown",
				"I know the identity of the respondent", 0, "respondentType|1", "", true);
		respondentFieldList.add(isIdentityKnown);

		CaseGenModelField respondentInfy = new CaseGenModelField(46, "respondentsInfy", "", "isRespondentKnown",
				property.getEmployeeSearchMobileURL(), "", false);
		respondentInfy.setLabel("Respondent (Complaint Against)");
		respondentInfy.setPlaceHolder(Message.EMPID_OR_EMPNO);
		respondentFieldList.add(respondentInfy);

		CaseGenModelField respondentOther = new CaseGenModelField(0, "respondentsOther", "", "respondentType|0", "",
				"Enter names or identity of respondents separated by comma.", false);
		respondentOther.setLabel("Respondent (Complaint Against)");
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new CaseGenModelForm(respondentFieldList));

		// Location section

		List<CaseGenModelField> locationFieldList = new ArrayList<>();

		List<GenModelOption> countryOptions = reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1);

		String defaultCountry = "";
		String defaultCity = "";
		for (GenModelOption country : countryOptions) {
			if (country.getKey().equalsIgnoreCase("IN"))
				defaultCountry = country.getValue();
		}
		defaultCountry = defaultCountry.isEmpty() ? countryOptions.get(0).getValue() : defaultCountry;

		List<GenModelOption> cities = ashiService.getCitiesByCountryCode(defaultCountry);
		for (GenModelOption city : cities) {
			if (city.getKey().equals("3"))
				defaultCity = city.getValue();
		}
		defaultCity = defaultCity.isEmpty() ? cities.get(0).getValue() : defaultCity;

		CaseGenModelField country = new CaseGenModelField(11, "country", "Country", defaultCountry, "", countryOptions,
				true);
		locationFieldList.add(country);

		CaseGenModelField city = new CaseGenModelField(11, "baseLocation", "Base Location", defaultCity, "country",
				new ArrayList<>(), true);
		city.setDependantAction(property.getBaselocationbycountrycodeMobileURL());
		locationFieldList.add(city);

		genModelFormList.add(new CaseGenModelForm(locationFieldList));

		// Complaint Details section
		List<CaseGenModelField> descriptionFieldList = new ArrayList<>();

		CaseGenModelField description = new CaseGenModelField(1, "description", "Description", "", "",
				"Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new CaseGenModelForm(descriptionFieldList));

		// Cocomplainant section
		List<CaseGenModelField> cocomplainantFieldList = new ArrayList<>();
		CaseGenModelField cocomplainant = new CaseGenModelField(46, "cocomplainants", "", "", property.getEmployeeSearchMobileURL(),
				Message.EMPID_OR_EMPNO, true);
		cocomplainant.setLabel("Tag Other Complainants");
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new CaseGenModelForm(cocomplainantFieldList));

		// Witnesses section
		List<CaseGenModelField> witnessesFieldList = new ArrayList<>();

		CaseGenModelField witnesses = new CaseGenModelField(46, "witnesses", "", "", property.getEmployeeSearchMobileURL(),
				Message.EMPID_OR_EMPNO, true);
		witnesses.setLabel("Tag Witnesses");
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new CaseGenModelForm(witnessesFieldList));

		// Stakeholder section
		
		List<CaseGenModelField> stakeholderFieldList = new ArrayList<>();

		CaseGenModelField isStakeHolder = new CaseGenModelField(45, Constants.ISSTAKEHOLDER,
				"Reported to any other stakeholder before raising the case", 0, "", "", true);
		isStakeHolder.setLabel("Stakeholders");
		stakeholderFieldList.add(isStakeHolder);

		List<GenModelOption> stakeholderOptions = genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "SHR");

		CaseGenModelField stakeholderRole = new CaseGenModelField(11, "stakeholderRole", "Stakeholder Role",
				stakeholderOptions.get(0).getValue(), Constants.ISSTAKEHOLDER, stakeholderOptions, false);
		stakeholderRole.setPlaceHolder("Choose Stakeholder");
		stakeholderRole.setLabel("Stakeholders");
		stakeholderFieldList.add(stakeholderRole);

		CaseGenModelField stakeholder = new CaseGenModelField(46, "stakeholder", "", Constants.ISSTAKEHOLDER,
				property.getEmployeeSearchMobileURL(), Message.EMPID_OR_EMPNO, false);
		stakeholder.setLabel("Stakeholder");
		stakeholderFieldList.add(stakeholder);

		accordionFormList.add(new CaseGenModelForm(stakeholderFieldList));


		List<CardViewAction> actions = new ArrayList<>();

		actions.add(new CardViewAction(1, "Initiate Complaint", "POST", property.getSubmitcaseMobileURL(), "submit"));
		actions.add(new CardViewAction(1, "Cancel", "", "", "cancel"));

		CaseGenModelFormData g1 = new CaseGenModelFormData(genModelFormList);

		CaseGenModelFormData g2 = new CaseGenModelFormData("More Details On The Complaint (Optional)",
				accordionFormList);

		return new CaseFormGenModel("Initiate Case Form", "", g1, g2, actions);
	}

	@Override
	public MobileComplaintInboxView getComplaintDetails(int caseId) throws CustomException {

		List<ComplaintDetails> complaintDetailsWithRespondents=caseDetailsRepository.findComplaintDetailsByCaseId(caseId);

		if (!complaintDetailsWithRespondents.isEmpty()) {
			ComplaintField complaint = new ComplaintField(caseId, complaintDetailsWithRespondents.get(0).getRespondentType(),complaintDetailsWithRespondents.get(0));
			return new MobileComplaintInboxView(Constants.CASE_DETAILS, "", Constants.INBOXVIEW, complaint);
		} 
		
		else {
			return new MobileComplaintInboxView(Constants.CASE_DETAILS, "", Constants.INBOXVIEW, null);
		}
	}

	@Override
	public EmployeeCardView getCaseEmployeeDetails(int caseId) throws CustomException {
		List<EmployeeCard> cards = new ArrayList<>();

		if (!caseDetailsRepository.existsById(caseId))
			return new EmployeeCardView("Employee details", cards);

		List<EmployeeDetails> respondentsDetails = ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId,
				Arrays.asList("R"));
		if (!respondentsDetails.isEmpty()) {
			List<EmployeeField> fields = new ArrayList<>();
			for (EmployeeDetails details : respondentsDetails) {

				fields.add(new EmployeeField(details));
			}
			cards.add(new EmployeeCard("Respondents", fields));
		} else {
			cards.add(new EmployeeCard("Respondents", new ArrayList<>()));
		}
		List<EmployeeDetails> witnessesDetails = ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId,
				Arrays.asList("W"));
		if (!witnessesDetails.isEmpty()) {
			List<EmployeeField> fields = new ArrayList<>();
			for (EmployeeDetails details : witnessesDetails) {
				fields.add(new EmployeeField(details));
			}
			cards.add(new EmployeeCard("Witnesses", fields));
		} else {
			cards.add(new EmployeeCard("Witnesses", new ArrayList<>()));
		}
		
		List<EmployeeDetails> cocomplainantsDetails=ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId, Arrays.asList("A","T"));
		cocomplainantsDetails.removeIf(c -> c.getEmpNo().trim().equals(Session.getTokenEMPNO()));
		if (!cocomplainantsDetails.isEmpty()) {
			List<EmployeeField> fields = new ArrayList<>();
			for (EmployeeDetails details : cocomplainantsDetails) {
				fields.add(new EmployeeField(details));
			}
			cards.add(new EmployeeCard("Co-Complainants", fields));
		} else {
			cards.add(new EmployeeCard("Co-Complainants", new ArrayList<>()));
		}
		return new EmployeeCardView("Employee details", cards);
	}

	@Override
	public EvidenceCardView getEvidences(int caseId) throws CustomException {
		List<EvidenceCard> cards = new ArrayList<>();
		if (caseDetailsRepository.existsById(caseId)) {
			Optional<ELCMECTrnASHIActionDetails> evidenceString = ashiActionDetailsRepository
					.findevidencesByCaseId(caseId);
			if (evidenceString.isPresent() && evidenceString.get().getDmsFileName() != null && !evidenceString.get().getDmsFileName().isEmpty()) {
				String[] evidencesList = evidenceString.get().getDmsFileName().split(",");
				List<EvidenceField> fields = new ArrayList<>();
				for (String evidence : evidencesList) {
					fields.add(new EvidenceField(evidence.trim(),""));
				}
				cards.add(new EvidenceCard(fields));
			} else {
				cards.add(new EvidenceCard(new ArrayList<>()));
			}

		}
		return new EvidenceCardView("Case evidences", cards);
	}

	private MobileInboxView getMobileInboxModelForRows(List<InboxCaseDetails> caseDetails, String inboxName) {
		List<MobileRow> rowList = new ArrayList<>();
		if (!caseDetails.isEmpty()) {
			for (InboxCaseDetails details : caseDetails) {
				rowList.add(new MobileRow(details, new ArrayList<>()));
			}

			return new MobileInboxView(inboxName, "", Constants.INBOXVIEW, rowList);
		} else {
			return new MobileInboxView(inboxName, "", Constants.INBOXVIEW, rowList);
		}
	}
	@Override
	public MobileInboxView getCasesInitiatedByMe(String id) throws CustomException {
		List<InboxCaseDetails> caseDetails = caseDetailsRepository.findMyCases(id, Arrays.asList("Self"));
		return this.getMobileInboxModelForRows(caseDetails, "Tab - Initiated by me");
		
	}

	@Override
	public MobileInboxView getCasesInitiatedByGRB(String id) throws CustomException {
		List<InboxCaseDetails> caseDetails = caseDetailsRepository.findMyCases(id, Arrays.asList("GRB"));
		return this.getMobileInboxModelForRows(caseDetails, "Tab - Initiated by GRB");

	}

	@Override
	public MobileInboxView getAllCases(String id) throws CustomException {
		List<InboxCaseDetails> caseDetails = caseDetailsRepository.findMyCases(id, Arrays.asList("Self","GRB"));
		return this.getMobileInboxModelForRows(caseDetails, "Tab - All");
		
	}

	@Override
	public MobileInboxView getCasesInitiatedByCoComplainant(String id) throws CustomException {
		List<InboxCaseDetails> caseDetails = caseDetailsRepository.findTaggedCases(id);
		List<MobileRow> rowList = new ArrayList<>();
		if (!caseDetails.isEmpty()) {
			for (InboxCaseDetails details : caseDetails) {
				List<MobileInboxAction> actions = new ArrayList<>();
				if (details.getMessage().equals("NOT ACCEPTED")) {
					actions.add(new MobileInboxAction("Accept", "POST", property.getAcceptMobileURL() + details.getTransId(),
							"Are you sure you want to be tagged as a co-complainant?"));
					actions.add(new MobileInboxAction("Reject", "POST", property.getRejectMobileURL() + details.getTransId(),
							"Are you sure you do not want to be tagged as a co-complainant?"));
				}
				rowList.add(new MobileRow(details, actions));
			}

			return new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);
		} 
		else
			return new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);
	}

	@Override
	public List<TabView> getInboxTabs() throws CustomException {
		List<TabView> tabs = new ArrayList<>();

		tabs.add(new TabView("All", property.getAllMobileURL()));
		tabs.add(new TabView("Initiated by Me", property.getInitiatedByMeMobileURL()));
		tabs.add(new TabView("As a Co-Complainant", property.getCoComplainantMobileURL()));
		tabs.add(new TabView("Initiated by GRB", property.getInitiatedByGRBMobileURL()));
		return tabs;
	}

}
