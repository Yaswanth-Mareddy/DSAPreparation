package com.infosys.reach.model.ashi;

import java.util.ArrayList;
import java.util.List;

import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.model.generic.DocumentData;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ValidatedCaseDetails {
	private boolean isGRB=false;
	private int raisingFor;
	private int respondentType;
	private int isRespondentKnown;
	private int complainantType;
	private int isComplainantKnown;
	private String complainantsOther;
	private List<ViewCurrEmpAllDetails> complainantsInfy;
	private String respondentsOther;
	private List<ViewCurrEmpAllDetails> respondentsInfy;
	private String country;
	private String baseLocation;
	private String description;
	private List<ViewCurrEmpAllDetails> cocomplainants;
	private List<ViewCurrEmpAllDetails> witnesses;
	private int isStakeHolder;
	private String stakeholderRole;
	private List<ViewCurrEmpAllDetails> stakeholder;
	private List<DocumentData> evidences;
	private int complaintCategory;
	private String placeOfIncident;
	private ViewCurrEmpAllDetails caseInitiator;
	private String folder;
	private List<String> validatedEvidences;
	private String strRespondentType;
	private String createdApp;
	
	
	public ValidatedCaseDetails(GMFields caseDetails, boolean isGRB, String appType) {
		super();
		this.isGRB = isGRB;
		this.raisingFor = caseDetails.getRaisingFor();
		this.respondentType = caseDetails.getRespondentType();
		this.isRespondentKnown = caseDetails.getIsRespondentKnown();
		this.complainantType = caseDetails.getComplainantType();
		this.isComplainantKnown = caseDetails.getIsComplainantKnown();
		this.complainantsOther = caseDetails.getComplainantsOther();
		this.respondentsOther = caseDetails.getRespondentsOther();
		this.country = caseDetails.getCountry();
		this.baseLocation = caseDetails.getBaseLocation();
		this.description = caseDetails.getDescription();
		this.isStakeHolder = caseDetails.getIsStakeHolder();
		this.stakeholderRole = caseDetails.getStakeholderRole();
		this.complaintCategory = caseDetails.getComplaintCategory();
		this.placeOfIncident = caseDetails.getPlaceOfIncident();
		this.respondentsInfy = new ArrayList<>();
		this.complainantsInfy = new ArrayList<>();
		this.witnesses = new ArrayList<>();
		this.cocomplainants = new ArrayList<>();
		this.folder = "";
		this.validatedEvidences = new ArrayList<>();
		this.strRespondentType = caseDetails.getRespondentType()==1?"Infoscion":"Other";
		this.createdApp = appType.equals("MOBILE")?"InfyMe Mobile":"Employee Hub";
	}

	
	
	

}
