package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnActionItemResponse;
import com.infosysit.rctmscompliance.model.ActionItemPrevCommentAndDetails;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSTrnActionItemResponseRepoRead extends JpaRepository<CMSTrnActionItemResponse, Integer> {

	@Query(value=CustomQueries.GETPREVCOMMENTS)
	public ActionItemPrevCommentAndDetails getOldComments(@Param("intActionItemId") int intActionItemId);
	
}
