package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GenModelField {
	
    private int order;
    private int type;
    private String name;
    private String displayName;
    private Object data;
    private String hintMessage;
    private String errorMessage;
    private String placeHolder;
    @JsonProperty("isRequired")
    private boolean isRequired;
    private List<GenModelLabel> labels;
    private List<GenModelValidation> validations;
    @JsonProperty("isdependant")
    private boolean isdependant;
    private String dependantTo;
    private String dependantAction;
    @JsonProperty("isEditable")
    private boolean isEditable;
    private List<GenModelOption> options;
    @JsonProperty("isHidden")
    private boolean isHidden;
    @JsonProperty("isVisibleOnPageLoad")
    private boolean isVisibleOnPageLoad;
    private String dependantField;
    private String dependantActionAPIType;
    
	
	public GenModelField(int type,String name, String displayName, Object data, boolean isHidden, boolean isVisibleOnPageLoad) {
		this(0, type, name, displayName, data, "", "", "", false, new ArrayList<>(), new ArrayList<>(), false, "", "", true, new ArrayList<>(), isHidden, isVisibleOnPageLoad, "", "");
	}

	
	public GenModelField(int type, String name, String displayName, Object data, String dependantTo,List<GenModelOption> options,boolean isVisibleOnPageLoad) {
		this(0, type, name, displayName, data, "", "", "", false, new ArrayList<>(), Arrays.asList(new GenModelValidation("0", "1", "Please select "+(displayName.isEmpty()?name.toLowerCase():displayName))), !dependantTo.isEmpty(), dependantTo, "", true, options, false, isVisibleOnPageLoad, "", "");
	}
	
	public GenModelField(int type, String name, String displayName, String dependantTo,String dependantAction,boolean isVisibleOnPageLoad) {
		this(0, type, name, displayName, Constants.SELECT, "", "", "", false, new ArrayList<>(), new ArrayList<>(), true, dependantTo, dependantAction, true, new ArrayList<>(), false, isVisibleOnPageLoad, "", "");
	}
	
	public GenModelField(int type, String name, String displayName, Object data, String dependantTo,String label,boolean isVisibleOnPageLoad) {
		this(0, type, name, displayName, data, "", "", "", false, label.isEmpty()?new ArrayList<>():Arrays.asList(new GenModelLabel(label)), new ArrayList<>(), !dependantTo.isEmpty(), dependantTo, "", true, new ArrayList<>(), false, isVisibleOnPageLoad, "", "");
	}
	
	public GenModelField(int type, String name, String displayName, String dependantTo, String dependantAction, String label,boolean isVisibleOnPageLoad) {
		this(0, type, name, displayName, "", "", "", "", false, label.isEmpty()?new ArrayList<>():Arrays.asList(new GenModelLabel(label)), new ArrayList<>(), !dependantTo.isEmpty(), dependantTo, dependantAction, true, new ArrayList<>(), false, isVisibleOnPageLoad, "", "");
	}

	public GenModelField(int type, String name, String displayName, Object data, String dependantAction, String label, List<GenModelValidation> validations) {
		this(0, type, name, displayName, data, "", "", "", false, label.isEmpty()?new ArrayList<>():Arrays.asList(new GenModelLabel(label)), validations, false, "", dependantAction, true, new ArrayList<>(), false, true, "", "");
	}
	
	public GenModelField(int type, String name, String displayName, Object data, String dependantTo,boolean isdependant, boolean isVisibleOnPageLoad, List<GenModelValidation> validations) {
		this(0, type, name, displayName, data, "", "", "", false, new ArrayList<>(), validations, isdependant, dependantTo, "", true, new ArrayList<>(), false, isVisibleOnPageLoad, "", "");
	}
       
    
	public void setData(List<GenModelOption> options, String str) {
		List<String> recommendations= new ArrayList<>();
		
		for(GenModelOption option : options) {
			if(str.contains(option.getValue().trim()))
				recommendations.add(option.getKey().trim());
		}
		
		this.data = recommendations;
	}
	
	public GenModelField(int type, String name, Object data, List<GenModelOption> options) {
		this(0, type, name, "", data, "", "", "", false, new ArrayList<>(), new ArrayList<>(), false, "", "", true, options, false, true, "", "");
	}
    
}
