package com.infosysit.itsm;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.mockito.internal.stubbing.answers.AnswersWithDelay;
import org.mockito.internal.stubbing.answers.Returns;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosysit.itsm.service.ITSMServiceImpl;


 class ITSMControllerTests extends AbstractTest {
	
	@MockBean
	ITSMServiceImpl service;
	
	@Override
	@BeforeEach
	public void setUp() {
		super.setUp();
		}

	@Test
	 void decisionAnalysisPositiveTestsCase() throws Exception {
		
		boolean objExpected = true;
		Mockito.when(service.decisionAnalysis()).thenReturn(true);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/api/v1/ITSM/DecisionAnalysis").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);
		
		String content = result.getResponse().getContentAsString();
		
		boolean objActual= super.mapFromJson(content, boolean.class);
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void decisionAnalysisNegativeTestsCase() throws Exception {
		
		boolean objExpected = true;
		Mockito.when(service.decisionAnalysis()).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/api/v1/ITSM/DecisionAnalysis").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);
		
	}
	
	@Test
	 void autoResponsePositiveTestsCase() throws Exception {
		
		boolean objExpected = true;
		Mockito.when(service.autoResponse()).thenReturn(true);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/api/v1/ITSM/AutoResponse").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);
		
		String content = result.getResponse().getContentAsString();
		
		boolean objActual= super.mapFromJson(content, boolean.class);
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseNegativeTestsCase() throws Exception {
		
		boolean objExpected = true;
		Mockito.when(service.autoResponse()).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/api/v1/ITSM/AutoResponse").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);
		
	}
	
	@Test
	 void defaultFallbackPositiveTestsCase() throws Exception {
		String objExpected = "true";
		
		Mockito.doAnswer( new AnswersWithDelay( 1,  new Returns(true)) ).when(service).autoResponse();

		RequestBuilder request = MockMvcRequestBuilders.post("/api/v1/ITSM/AutoResponse").header("Authorization", "Bearer "+token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);
		
		String objActual = result.getResponse().getContentAsString();
	
		assertEquals(objExpected, objActual);
		
		
	}

}
