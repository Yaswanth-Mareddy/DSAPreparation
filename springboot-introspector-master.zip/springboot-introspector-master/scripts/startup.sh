#!/bin/bash
nohup java -jar target/springboot-introspector-0.1.0-SNAPSHOT.jar &
echo $! > target/pid.file
