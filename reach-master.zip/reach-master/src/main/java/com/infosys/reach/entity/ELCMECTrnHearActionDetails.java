package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmectrnhearactiondetails")
public class ELCMECTrnHearActionDetails {

	@Id
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtcomments")
	private String comments;
	
	@Column(name="txtrole")
	private String role;
	
	@Column(name="txtstatus")
	private String status;
		
	@Column(name="flgsentforopinion")
	private int flgSentForOpinion;
	
	@Column(name="txtassigneeempno")
	private String assigneeEmpNo;
	
	@Column(name="txtdmsfilename")
	private String dmsFileName;

	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="flgreassign")
	private int flgReAssign;	

	@Column(name="dtcreatedon")
	private Timestamp createdOn;
		
	@Column(name="txtmodifiedby")
	private String modifiedBy;

	public ELCMECTrnHearActionDetails(int caseId, String comments, String createdBy,
			Timestamp createdOn) {
		super();
		this.caseId = caseId;
		this.role = "CIN";
		this.comments = comments;
		this.status = "CH";
		this.assigneeEmpNo = "";
		this.flgSentForOpinion = 0;
		this.dmsFileName = null;
		this.flgReAssign = 0;
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
	}
	
	
}
