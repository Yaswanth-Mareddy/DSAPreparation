package com.infosys.reach.entity;



import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.joda.time.format.DateTimeFormat;

import com.infosys.reach.model.ashi.GMFields;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmecmstashipreliminarydiscussiondetails")
public class ELCMECMstASHIPreliminaryDiscussionDetails {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtupdatedby")
	private String updatedBy;
	
	@Column(name="txtdiscussedwith")
	private String discussedWith;
	
	@Column(name="txtdiscussionsummary")
	private String discussionSummary;
	
	@Column(name="dtcreatedate")
	private Timestamp createdDate;
	
	@Column(name="txtrole")
	private String role;
	
	@Column(name="txtdmsfilename")
	private String dmsFileName;

	public ELCMECMstASHIPreliminaryDiscussionDetails(GMFields fields, String updatedBy, String role, String dmsFileName) {
		super();
		this.caseId = fields.getCaseid();
		this.updatedBy = updatedBy;
		this.discussedWith = fields.getDiscussedWith();
		this.discussionSummary = fields.getDiscussionSummary();
		this.createdDate = new Timestamp(DateTimeFormat.forPattern("dd-MMM-yyyy").parseMillis(fields.getDiscussedOn()));
		this.role = role;
		this.dmsFileName = dmsFileName;
	}
	
	
	
}
