package com.infosys.reach.model.disciplinary;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CaseDetails {

	private String appCode;
	private String empNo;
	private String incidentDate;
	private int categoryId;
	private int subcategoryId;
	private String country;
	private String currentLocation;
	private String unitHRMailId;
	private String description;
	private String dmsFilenames;
	
}
