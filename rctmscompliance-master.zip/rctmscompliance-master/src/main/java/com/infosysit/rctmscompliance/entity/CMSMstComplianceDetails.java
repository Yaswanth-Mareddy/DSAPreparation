package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstcompliancedetails")
public class CMSMstComplianceDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="txtcompliancename")
	private String txtComplianceName;
	
	@Column(name="txtdescription")
	private String txtDescription;
	
	@Column(name="intcompgroupid")
	private int intCompGroupID;
	
	@Column(name="intlocationid")
	private int intLocationID;
	
	@Column(name="dtduedate")
	private String dtDueDate;
	
	@Column(name="dtenddate")
	private String dtEndDate;
	
	@Column(name="intfrequencyid")
	private int intFrequencyID;
	
	@Column(name="intdaysbeforestart")
	private int intDaysBeforeStart;
	
	@Column(name="intreminderinterval")
	private int intReminderInterval;
	
	@Column(name="intnodeid")
	private int intNodeID;
	
	@Column(name="flgisnewlycreated")
	private String flgIsNewlyCreated;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="intdept")
	private int intDept;
	
	@Column(name="txttype")
	private String txtType;
}
