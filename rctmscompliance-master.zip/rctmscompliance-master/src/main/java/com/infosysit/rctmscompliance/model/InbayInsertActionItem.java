package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InbayInsertActionItem {

	private String strApplicationCode;
	private int intAppCatID;
	private String strAppTransactionID;
	private String strEmpNo;
	private String strAppTransactionURL;
	private String strTransactionTitle;
	private String strTransactionDescription;
	private String dtSubmission;
	private String dtExpired;
	private String strApplicationInfoJSON;
}
