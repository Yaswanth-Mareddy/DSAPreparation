package com.infosys.reach.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.service.ASHIAdminServiceImpl;
import com.infosys.reach.service.ASHIMobileServiceImpl;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.service.DisciplinaryServiceImpl;
import com.infosys.reach.service.HearServiceImpl;
import com.infosys.reach.util.Message;

public class Logging {
	
	@Autowired
	protected ReachInterceptor telemetry;
	
	@Autowired
	protected CommonServiceImpl commonService;
	
	@Autowired
	protected ASHIMobileServiceImpl ashiMobileService;

	@Autowired
	protected ASHIServiceImpl ashiWebService;
	
	@Autowired
	protected HearServiceImpl hearMobileService;
	
	@Autowired
	protected DisciplinaryServiceImpl discMobileService;
	
	@Autowired
	protected ASHIAdminServiceImpl ashiAdminService;

	protected ResponseEntity<Object> registerExceptionLogs(Exception e){
		telemetry.setExeceptionEventData(e);
		return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, Message.SOMEERROROCCURED)));
	}
	
	protected Object registerLogs(boolean isSuccess, Object object, String successAuditMessage, String errorAuditMessage) {
		if(isSuccess) {
			telemetry.setLogEventData(Message.SUCCESSFULLY+successAuditMessage);
			return object;	
		}
		else {
			telemetry.setLogEventData(Message.ERROR+" "+errorAuditMessage);
			return Arrays.asList(new Response(Message.ERROR, errorAuditMessage));
		}
	}
	
	protected void deleteFilesFromTempPath(String folder, List<String> validatedEvidences) {
		try {
			String message = commonService.deleteFolder(folder, validatedEvidences);
			telemetry.setLogEventData(message);
		} catch (CustomException e) {
			telemetry.setExeceptionEventData(e);
		}
		
	}
	
	protected ResponseEntity<Object> registerMobileExceptionLogs(Exception e){
		telemetry.setExeceptionEventData(e);
		
		return new ResponseEntity<>(new Response(Message.ERROR, Message.SOMEERROROCCURED), HttpStatus.BAD_REQUEST);
	}

	protected ResponseEntity<Object> registerMobileLogs(boolean isSuccess, Object object, String successAuditMessage, String errorAuditMessage) {
		if(isSuccess) {
			
			telemetry.setLogEventData(Message.SUCCESSFULLY+successAuditMessage);
			
			return new ResponseEntity<>(object, HttpStatus.OK);	
			
		}
		else {
			
			telemetry.setLogEventData(Message.ERROR+" "+errorAuditMessage);
			
			return new ResponseEntity<>(new Response(Message.ERROR, errorAuditMessage), HttpStatus.OK);
			
		}
	}
	
	protected ResponseEntity<Object> registerAuthorizationLogs(){
		telemetry.setLogEventData(Message.ERROR + " " + Session.getAuthorizedMessage());
		
		return new ResponseEntity<>(Arrays.asList(new Response(Message.ERROR, Session.getAuthorizedMessage())), HttpStatus.OK);
	}
}
