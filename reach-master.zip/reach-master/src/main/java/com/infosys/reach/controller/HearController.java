package com.infosys.reach.controller;


import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.hear.CaseDetailsValidationResponse;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.model.hear.ConcernDetailsInput;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.model.hear.HearAccess;
import com.infosys.reach.model.hear.HearCaseDetails;
import com.infosys.reach.model.hear.HearCaseResponse;
import com.infosys.reach.model.hear.Policy;
import com.infosys.reach.model.hear.SubmitCaseOutput;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;



/**
 * @author surajkumar.dewangan
 *
 */
@RestController
@Api(tags="Hear Module : InfyMe Mobile")
@RequestMapping("/v2/api")
public class HearController extends Logging{
	


	/**
	 * This method returns categories by module id, company and country code
	 * @param concernDetailsInput
	 * @return Categories model
	 * @throws Exception
	 */
	@ApiOperation(value="Fetch hear categories",tags="Hear Module : InfyMe Mobile")
	@PostMapping(value="/categorydisplay", produces="application/json")
	public ResponseEntity<Object> getCategories(@RequestBody(required = true) ConcernDetailsInput concernDetailsInput) {
		try {

			List<Categories> categories=hearMobileService.getConcernModuleDetails(concernDetailsInput.getModuleId(), concernDetailsInput.getCompany(), concernDetailsInput.getCountryCode());
			if(!categories.isEmpty()) {
				telemetry.setLogEventData("SUCCESSFULLY fetched categories");
				return new ResponseEntity<>(categories,HttpStatus.OK);
			}

			else {
				telemetry.setLogEventData(Message.NO_DATA_FOUND);
				return new ResponseEntity<>(new Response(Message.NO_DATA_FOUND),HttpStatus.OK);
			}
		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new Response(Message.SOMEERROROCCURED),HttpStatus.BAD_REQUEST);
		}
	}


	/**
	 * This method is used to submit case initiated by an employee
	 * @param caseDetails
	 * @return ResponseEntity<SubmitCaseOutput>
	 * @throws Exception
	 */
	@ApiOperation(value="Submit Hear case",tags="Hear Module : InfyMe Mobile")
	@PostMapping(value="/employee/submitcase", produces="application/json")
	public ResponseEntity<SubmitCaseOutput> initiateHearCase(@RequestBody HearCaseDetails caseDetails){

		try{
			CaseDetailsValidationResponse validationResponse=hearMobileService.validateCaseDetails(Session.getTokenEMPNO(), AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), caseDetails);

			if(validationResponse.isStatus()) {
				HearCaseResponse caseId=hearMobileService.initiateHearCase(Session.getTokenEMPNO(), AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), Session.getTokenEMPNAME(), validationResponse.getCaseDetails(),validationResponse.getTaggedEmpMailIdList());


				telemetry.setLogEventData("SUCCESSFULLY submitted case");
				return new ResponseEntity<>(new SubmitCaseOutput(caseId.getCaseId(),caseId.getMessage(),"SUCCESS"),HttpStatus.OK);


			}

			else {
				telemetry.setLogEventData(Constants.FAILURE+validationResponse.getMessage());
				return new ResponseEntity<>(new SubmitCaseOutput(0,validationResponse.getMessage(),Constants.FAILURE.trim()),HttpStatus.OK);
			}
		}
		catch(CustomException e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new SubmitCaseOutput(0,Message.SOMETHING_WENT_WRONG,Constants.FAILURE),HttpStatus.BAD_REQUEST);
		}

	}


	/**
	 * This method is used to fetch countries by module id
	 * @param moduleId
	 * @return List<Countries>
	 * @throws Exception
	 */
	@ApiOperation(value="Fetch Hear enabled countries",tags="Hear Module : InfyMe Mobile")
	@GetMapping(value="/countriesbymoduleid", produces="application/json")
	public ResponseEntity<Object> getCountriesByModuleId(@RequestParam(name = "moduleId",required = true) int moduleId){
		try {
			List<Countries> countryDetails= hearMobileService.getCountriesByModuleId(moduleId);
			if(!countryDetails.isEmpty()) {
				telemetry.setLogEventData("SUCCESSFULLY fetched countries");
				return new ResponseEntity<>(countryDetails,HttpStatus.OK);
			}

			else {
				String message = "No country found.";
				telemetry.setLogEventData(message);
				return new ResponseEntity<>(new Response(message),HttpStatus.BAD_REQUEST);
			}
		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new Response(Message.SOMEERROROCCURED),HttpStatus.BAD_REQUEST);
		}
	}



	/**
	 * This method is used to fetch locations based on country
	 * @param countryCode
	 * @return List<Cities>
	 * @throws Exception
	 */
	@ApiOperation(value="Fetch locations for Hear enabled country",tags="Hear Module : InfyMe Mobile")
	@GetMapping(value="/locationbasedoncountry", produces="application/json")
	public ResponseEntity<Object> getCitiesByCountryCode(@RequestParam(name = "countryCode",required = true) String countryCode){
		try {
			List<Cities> countryDetails= hearMobileService.getCitiesByCountryCode(countryCode);
			if(!countryDetails.isEmpty()) {
				telemetry.setLogEventData("SUCCESSFULLY fetched cities");
				return new ResponseEntity<>(countryDetails,HttpStatus.OK);
			}

			else {
				String msg = "No city found.";
				telemetry.setLogEventData(msg);
				return new ResponseEntity<>(new Response(msg),HttpStatus.BAD_REQUEST);
			}
		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			
			return new ResponseEntity<>(new Response(Message.SOMEERROROCCURED),HttpStatus.BAD_REQUEST);
		
		}
	}

	/**
	 * This method returns Policy content for Hear Module 
	 * @return Policy model
	 */
	@ApiOperation(value="Fetch Hear policy",tags="Hear Module : InfyMe Mobile")
	@GetMapping(value="/policy", produces="application/json")
	public ResponseEntity<Object> getHearModulePolicy(){
		try {
			Policy policy=hearMobileService.getHearPolicy();
			telemetry.setLogEventData("SUCCESSFULLY fetched hear module policy");
			return new ResponseEntity<>(policy,HttpStatus.OK);

		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new Response(Message.SOMEERROROCCURED),HttpStatus.BAD_REQUEST);
		}
	}

	/**
	 * This method check whether employee has access to hear module or not
	 * @return HearAccess model
	 */
	@ApiOperation(value="Check Hear access",tags="Hear Module : InfyMe Mobile")
	@GetMapping(value="/employee/checkaccess", produces="application/json")
	public ResponseEntity<Object> checkHearAccess(){
		try {
			String empNo=Session.getTokenEMPNO();
			HearAccess accessObj=hearMobileService.checkHearAccess(empNo);
			if(accessObj.isHasAccess()) {
				telemetry.setLogEventData("SUCCESSFULLY checked hear access");
				return new ResponseEntity<>(accessObj,HttpStatus.OK);
			}

			else {
				telemetry.setLogEventData(accessObj.toString());
				return new ResponseEntity<>(accessObj,HttpStatus.OK);
			}
		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new Response(Message.SOMEERROROCCURED),HttpStatus.BAD_REQUEST);
		}
	}


}


