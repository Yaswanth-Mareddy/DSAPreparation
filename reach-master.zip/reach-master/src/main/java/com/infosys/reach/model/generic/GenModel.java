package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = Include.NON_DEFAULT)
public class GenModel {

	private String name;
	private String id;
	private List<GenModelFormObj> forms;
	private List<GenModelField> fields;
	private List<CardViewAction> actions;
	private String transactionID;
	
	public GenModel(String name, String id, List<GenModelFormObj> form,
			List<CardViewAction> actions) {
		this(name, id, form, new ArrayList<>(), actions, null);
	}
	
	public GenModel(String name, String id, List<GenModelField> fields) {
		this(name, id, new ArrayList<>(), fields, new ArrayList<>(), null);
	}
	
	public GenModel(String name, List<GenModelField> fields,
			List<CardViewAction> actions) {
		this(name, "", new ArrayList<>(), fields, actions, null);
	}
	
	public GenModel(String name, List<GenModelField> fields, List<CardViewAction> actions, int transactionID) {
		this(name, "", new ArrayList<>(), fields, actions, String.valueOf(transactionID));
	}
	
}
