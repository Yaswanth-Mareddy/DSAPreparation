package com.infosysit.rctmscompliance.repo.write;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnComplianceInstance;
import com.infosysit.rctmscompliance.entity.ComplianceInstanceCompPKey;

@Repository
public interface CMSTrnComplianceInstanceRepoWrite extends JpaRepository<CMSTrnComplianceInstance, ComplianceInstanceCompPKey>{
	
	@Modifying
	@Query(value="Update CMSTrnComplianceInstance CI set CI.txtStatus= :txtStatus,CI.txtAssigneeRemarks= :txtAssigneeRemarks,CI.txtAttachmentList= :txtAttachmentList,"
			+ "CI.dtActualFilingDate= :dtCurrentDate,CI.dtAssignedDtVerifier= :dtCurrentDate,CI.dtLastModified= :dtCurrentDate,CI.txtLastModifiedBy= :txtLastModifiedBy "
			+ "where CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateAssigneeRemarks(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,
			@Param("txtAssigneeRemarks") String txtAssigneeRemarks,@Param("txtAttachmentList") String txtAttachmentList,@Param("dtCurrentDate") String dtCurrentDate,
			@Param("txtLastModifiedBy") String txtLastModifiedBy);
	
	@Modifying
	@Query(value="Update CMSTrnComplianceInstance CI set CI.txtStatus= :txtStatus,CI.txtAssigneeAfterRejectRemark= :txtAssigneeAfterRejectRemark,CI.txtAttachmentList= :txtAttachmentList,"
			+ "CI.dtActualFilingDate= :dtCurrentDate,CI.dtAssignedDtVerifier= :dtCurrentDate,CI.dtLastModified= :dtCurrentDate,CI.txtLastModifiedBy= :txtLastModifiedBy "
			+ "where CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateAssigneeAfterRejectRemarks(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,
			@Param("txtAssigneeAfterRejectRemark") String txtAssigneeAfterRejectRemark,@Param("txtAttachmentList") String txtAttachmentList,/*@Param("dtActualFilingDate") String dtActualFilingDate,*/@Param("dtCurrentDate") String dtCurrentDate,
			@Param("txtLastModifiedBy") String txtLastModifiedBy);
	
	@Modifying
	@Query(value="Update CMSTrnComplianceInstance CI set CI.txtStatus= :txtStatus,CI.dtLastModified= :dtCurrentDate,CI.txtLastModifiedBy= :txtLastModifiedBy where CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateRecall(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,@Param("dtCurrentDate") String dtCurrentDate,
			@Param("txtLastModifiedBy") String txtLastModifiedBy);
	
	@Modifying
	@Query(value="Update CMSTrnComplianceInstance CI set CI.txtStatus= :txtStatus,CI.txtVerifierApprovalRemarks= :txtRemarks,CI.txtAttachmentListVerifier= :txtAttachmentList,"
			+ "CI.dtAssignedDtAssignee= :dtCurrentDate,CI.dtLastModified= :dtCurrentDate,CI.txtLastModifiedBy= :txtLastModifiedBy "
			+ "where CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateVerfierRemarks(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,
			@Param("txtRemarks") String txtRemarks,@Param("txtAttachmentList") String txtAttachmentList,@Param("dtCurrentDate") String dtCurrentDate,
			@Param("txtLastModifiedBy") String txtLastModifiedBy);
	
	@Modifying
	@Query(value="UPDATE CMSTrnComplianceInstance As CI SET CI.txtStatus = :txtStatus, CI.intNoOfCycles = CI.intNoOfCycles + 1, txtVerifierRejectRemark = :txtRemarks, txtAttachmentListVerifier = :txtAttachmentList," + 
			"CI.dtAssignedDtAssignee = :dtCurrentDate, CI.dtLastModified = :dtCurrentDate, CI.txtLastModifiedBy = :txtEmpNo WHERE CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateVerifierRejectRemark(@Param("intComplianceID")int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,@Param("txtRemarks") String txtRemarks,
			@Param("txtAttachmentList") String txtAttachmentList,@Param("dtCurrentDate") String dtCurrentDate,@Param("txtEmpNo") String txtEmpNo);
	
	@Modifying
	@Query(value="Update CMSTrnComplianceInstance CI set CI.txtStatus= :txtStatus,CI.txtOwnerRemarks= :txtRemarks,CI.txtAttachmentListOwner= :txtAttachmentList,"
			+ "CI.dtLastModified= :dtCurrentDate,CI.txtLastModifiedBy= :txtLastModifiedBy "
			+ "where CI.compPKey.intComplianceID = :intComplianceID AND CI.compPKey.dtAssignedDate = :dtAssignedDate")
	void updateOwnerRemarks(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("txtStatus") String txtStatus,
			@Param("txtRemarks") String txtRemarks,@Param("txtAttachmentList") String txtAttachmentList,@Param("dtCurrentDate") String dtCurrentDate,
			@Param("txtLastModifiedBy") String txtLastModifiedBy);
}
