package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="hristrnemplocation")
public class HRISTrnEmpLocation {
	
	@Id
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="txtcurrentcityname")
	private String currentCityName;
	
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtcurrentcountrycode")
	private String currentCountryCode;
}
