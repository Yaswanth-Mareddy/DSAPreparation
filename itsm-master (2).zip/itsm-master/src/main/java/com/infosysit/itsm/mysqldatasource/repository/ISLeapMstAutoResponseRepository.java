package com.infosysit.itsm.mysqldatasource.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.itsm.model.ISLeapAutoResponseModel;
import com.infosysit.itsm.mysqldatasource.entity.ISLeapMstAutoResponse;
import com.infosysit.itsm.util.QueryConstants;

public interface ISLeapMstAutoResponseRepository extends JpaRepository<ISLeapMstAutoResponse, Integer> {
	
	@Query(value=QueryConstants.GETRESOLUTIONDETAILS)
	ISLeapAutoResponseModel getResolutionDetails(@Param("txtRuleNo") String txtRuleNo);
	

}