package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.HRISTrnEmpLocation;
import com.infosys.reach.util.TrackExecutionTime;

public interface HRISTrnEmpLocationRepository extends JpaRepository<HRISTrnEmpLocation, String> {
	
	@TrackExecutionTime
	Optional<HRISTrnEmpLocation> findByEmpNo(String empNo);

}
