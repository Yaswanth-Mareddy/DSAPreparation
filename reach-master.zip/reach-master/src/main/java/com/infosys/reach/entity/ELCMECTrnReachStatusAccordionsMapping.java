package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;

@Getter
@Entity
@Table(name="elcmectrnreachstatusaccordionsmapping")
public class ELCMECTrnReachStatusAccordionsMapping {

	@Id
	@Column(name="intmappingid")
	private int mappingId;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="status")
	private String status;
	
	@Column(name="intaccordionid")
	private int accordionId;
	
	@Column(name="intactionid")
	private int actionId;

	@Column(name="flgactive")
	private int flgActive;
	
	@Column(name="intorder")
	private int order;


}
