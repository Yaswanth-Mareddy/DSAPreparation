package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECtrnASHISLAAuditTrial;

public interface ELCMECtrnASHISLAAuditTrialRepository extends JpaRepository<ELCMECtrnASHISLAAuditTrial, Integer> {
	
	int countBySlaId(int slaId);
	
	Optional<ELCMECtrnASHISLAAuditTrial> findBySlaIdAndStatus(int slaId, String status);
	
	Optional<ELCMECtrnASHISLAAuditTrial> findByExtensionId(int extensionId);

}
