package com.infosys.reach.controller;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.sunbird.common.models.util.JsonKey;
import org.sunbird.common.request.ExecutionContext;
import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryEvents;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;
import org.sunbird.telemetry.util.TelemetryUtil;

import com.infosys.reach.teleconfig.TelemetryConfig;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Message;



@Component
//Intercepting every request here and sending Log event data to telemetry service
//This class handles Log event data
@SuppressWarnings("unchecked")
public class ReachInterceptor implements HandlerInterceptor {

	@Value("${telemetry_env}")
	public String env;
	@Value("${telemetry_actor_type}")
	public String actorType;
	@Value("${telemetry_actor_id}")
	public String actorId;
	@Value("${telemetry_log_type}")
	public String logType;
	
	@Autowired
	TelemetryConfig telemetryConfig;



	private Map<String, Map<String, Object>> requestInfo = new HashMap<>();
	private String messageId;
	private String methodURL;
	private String methodAPIType;
	private int statusCode;

	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		request.getUserPrincipal();
		initializeRequestInfo(request);
		return true;
	}


	private  void initializeRequestInfo(HttpServletRequest request) {

		ExecutionContext context = ExecutionContext.getCurrent();

		methodAPIType = request.getMethod();

		methodURL = request.getRequestURI();

		messageId = ExecutionContext.getRequestId();

		if (StringUtils.isBlank(messageId)) {
			UUID uuid = UUID.randomUUID();
			messageId = uuid.toString();
		}

		ExecutionContext.setRequestId(messageId);

		Map<String, Object> reqContext = new HashMap<>();

		String channel = telemetryConfig.getContext().getChannel();

		reqContext.put(JsonKey.CHANNEL, channel);

		reqContext.put(JsonKey.ENV, env);
		reqContext.put(JsonKey.ACTOR_ID, actorId);
		reqContext.put(JsonKey.ACTOR_TYPE, actorType);

		context.setRequestContext(reqContext);

		context.getGlobalContext().put(JsonKey.PDATA_ID, telemetryConfig.getContext().getpData().getId());

		context.getGlobalContext().put(JsonKey.PDATA_PID, telemetryConfig.getContext().getpData().getPid());

		context.getGlobalContext().put(JsonKey.PDATA_VERSION, telemetryConfig.getContext().getpData().getVersion());

		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.CONTEXT, TelemetryUtil.getTelemetryContext());

		Map<String, Object> additionalInfo = new HashMap<>();
		additionalInfo.put(JsonKey.URL, methodURL);
		additionalInfo.put(JsonKey.METHOD, methodAPIType);

		map.put(JsonKey.ADDITIONAL_INFO, additionalInfo);

		if (requestInfo == null) {
			requestInfo = new HashMap<>();
		}

		if (StringUtils.isBlank(messageId)) {
			messageId = JsonKey.DEFAULT_CONSUMER_ID;
		}
		requestInfo.put(messageId, map);
	}

	
	/*
	 * postHandle method
	 */
	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		
		statusCode = response.getStatus();

	}


	public void setLogEventData(String message) {

		Map<String, Object> telemetryInfo2 = requestInfo.get(messageId);

		Request telemetryRequest2 = new Request();

		// Setting fields for logging information
		Map<String, Object> telemetryParameters2 = new HashMap<>();
		telemetryParameters2.put(JsonKey.LOG_TYPE, JsonKey.API_CALL);
		telemetryParameters2.put(JsonKey.LOG_LEVEL, "Trace");
		telemetryParameters2.put(JsonKey.USER_NAME, AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()));
		telemetryParameters2.put(JsonKey.METHOD, methodAPIType);
		telemetryParameters2.put(JsonKey.METHOD_NAME, methodURL);
		telemetryParameters2.put(JsonKey.MESSAGE,message);
		telemetryParameters2.put(JsonKey.PDATA_ID, telemetryConfig.getContext().getpData().getPid()); 

		telemetryRequest2.setRequest(generateTelemetryRequest(TelemetryEvents.LOG.getName(), telemetryParameters2,
				(Map<String, Object>) telemetryInfo2.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest2);
	}

	public void setExeceptionEventData(Exception e) {

		String message = MessageFormat.format(", Exception Message : {0} at {1}",e.getMessage(),Arrays.asList(e.getStackTrace()).stream().filter(a -> a.getClassName().contains("com.infosys.reach.service")).findFirst().orElse(Arrays.asList(e.getStackTrace()).stream().filter(a -> a.getClassName().contains("com.infosys.reach.controller")).findFirst().orElse(e.getStackTrace()[0])));
		Map<String, Object> telemetryInfo3 = requestInfo.get(messageId);

		Request telemetryRequest3 = new Request();

		Map<String, Object> telemetryParameters3 = new HashMap<>();
		telemetryParameters3.put(JsonKey.ERROR, String.valueOf(statusCode));
		telemetryParameters3.put(JsonKey.ERR_TYPE, "SYSTEM");
		telemetryParameters3.put(JsonKey.USER_NAME, AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()));
		telemetryParameters3.put(JsonKey.METHOD, methodAPIType);
		telemetryParameters3.put(JsonKey.METHOD_NAME, methodURL);
		telemetryParameters3.put(JsonKey.STACKTRACE, message);


		if (statusCode==400 || statusCode==403 || statusCode==404)
			telemetryParameters3.put(JsonKey.ERR_TYPE, "CONTENT");

		if (!Arrays.asList(Message.INVALIDTOKEN, Message.UNAUTHORIZED, Message.JWTEXPIRED).contains(e.getMessage()))
			telemetryRequest3.setRequest(generateTelemetryRequest(TelemetryEvents.ERROR.getName(), telemetryParameters3,
				(Map<String, Object>) telemetryInfo3.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest3);
	}


	private Map<String, Object> generateTelemetryRequest(String eventType, Map<String, Object> telemetryParameters,
			Map<String, Object> telemetryContext) {
		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.TELEMETRY_EVENT_TYPE, eventType);
		map.put(JsonKey.CONTEXT, telemetryContext);
		map.put(JsonKey.PARAMS, telemetryParameters);

		return map;
	}
}

