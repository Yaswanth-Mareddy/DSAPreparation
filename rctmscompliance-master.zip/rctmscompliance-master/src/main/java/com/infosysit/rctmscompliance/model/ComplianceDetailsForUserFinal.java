package com.infosysit.rctmscompliance.model;

import java.util.List;

import com.infosysit.rctmscompliance.exception.CustomException;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComplianceDetailsForUserFinal {

	private String compName;
	private String compDesc;
	private String assigneeRemarks;
	private String verifierApprovalRemarks;
	private String assigneeAfterRejectRemarks;
	private String verifierRejectRemarks;
	private String ownerRemarks;
	private String dtAssignedDate;
	private String compEsc="";
	private String txtAssignee;
	private String txtVerifier;
	private String txtOwner;
	private String dtDueDate;
	

	public void setCompEsc(List<ComplianceEscalationDetails> compEsca) throws CustomException {
			this.compEsc=compEsc.concat(compEsca.get(0).returnAsString());
	}
		
}
