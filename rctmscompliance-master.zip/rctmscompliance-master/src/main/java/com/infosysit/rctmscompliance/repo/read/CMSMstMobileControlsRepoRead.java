package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSMstMobileControls;
import com.infosysit.rctmscompliance.model.MobileControlModel;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSMstMobileControlsRepoRead extends JpaRepository<CMSMstMobileControls, String> {
	
	@Query(value=CustomQueries.GETMOBILECONTROLS)
	List<MobileControlModel> getMobileControls(@Param("txtPageName") String txtPageName,@Param("flgActive") int flgActive);

}
