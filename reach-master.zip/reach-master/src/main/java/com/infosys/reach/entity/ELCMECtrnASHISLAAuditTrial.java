package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.ashi.GMFields;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="elcmectrnashislaaudittrial")
public class ELCMECtrnASHISLAAuditTrial {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intextensionid")
	private int extensionId;

	@Column(name="intslaid")
	private int slaId;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="intdays")
	private int days;

	@Column(name="txtremarks")
	private String remarks;

	@Column(name="txtmodifiedby")
	private String modifiedBy;

	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;

	@Column(name="txtrole")
	private String role;

	@Column(name="intnooftime")
	private int noOfTime;

	@Column(name="dtslaextensiondate")
	private Timestamp slaExtensionDate;

	@Column(name="txtmodifiedname")
	private String modifiedName;

	@Column(name="txtstatus")
	private String status;

	@Column(name="txtreason")
	private String reason;

	@Column(name="txtactor")
	private String actor;

	public ELCMECtrnASHISLAAuditTrial(int slaId, GMFields fields, int days, int noOfTime,
			Timestamp slaExtensionDate) {
		super();
		this.slaId = slaId;
		this.caseId = fields.getCaseid();
		this.days = days;
		this.remarks = fields.getComments();
		this.role = "IC";
		this.noOfTime = noOfTime;
		this.slaExtensionDate = slaExtensionDate;
		this.status = "Requested";
		this.reason = fields.getExtensionReason();
		this.actor = "";
	}
	
	
}
