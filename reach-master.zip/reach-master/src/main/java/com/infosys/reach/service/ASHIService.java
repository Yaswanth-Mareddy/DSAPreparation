package com.infosys.reach.service;

import java.util.List;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ASHIAccess;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CommunicationModel;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.common.MailApprovalRequest;
import com.infosys.reach.model.common.MailApprovalResponse;

public interface ASHIService {

	public Response initiateASHICase(ValidatedCaseDetails caseDetails) throws CustomException;
	public CaseDetailsValidationResponse validateCaseDetails(String caseInitiator, GMFields caseDetails, String appType) throws CustomException;
	public Response updateCocomplainantResponse(int transactionId, int response) throws CustomException;
	public LabelView getComplaintDetails(int caseId) throws CustomException;
	public CardView getCaseEmployeeDetails(int caseId) throws CustomException;
	public CardView getEvidences(int caseId) throws CustomException;
	public Response uploadEvidence(GenModel evidenceGenModel, String folder, List<String> validatedEvidences) throws CustomException;
	public GenModel initiateCaseForm() throws CustomException;
	public List<GenModelOption> getCitiesByCountryCode(String countryCode) throws CustomException;
	public ASHIAccess checkHearAccess(String empNo) throws CustomException;
	public GenModel getHearPolicy() throws CustomException; 
	public List<TabView> getInboxTabs() throws CustomException;
	public InboxView  getTaggedCases(String id) throws CustomException;
	public InboxView getCasesInitiatedByMe(String empNo, String mailId) throws CustomException;
	public InboxView getCasesInitiatedByGRB(String empNo, String mailId) throws CustomException;
	public InboxView getAllCases(String empNo, String mailId) throws CustomException;
	public GenModel consentGenModel()throws CustomException;
	public boolean isLoggedInUserAdmin() throws CustomException;
	public List<String> getAdmins() throws CustomException;
	public GenModel addEvidenceGenModel(int caseId) throws CustomException;
	public Response saveUserConsentApproval(GenModel genmodel) throws CustomException;
	public DocumentData getASHIPolicyPDF() throws CustomException;
	public Response updateConsentResponse(int transactionId, int response) throws CustomException;
	public InboxView  getCasesAsRespondent(String id) throws CustomException;
	public CommunicationModel getCommunicationHistory(int caseid, String mailId);
	public Response postCommunicationResponse(String mailid, GenModel genmodel) throws CustomException ;
	public MailApprovalResponse mailBasedApprovalConciliationConsent(MailApprovalRequest request) throws CustomException;
}