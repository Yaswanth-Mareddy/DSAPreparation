package com.infosys.reach.model.ashi;


import java.text.SimpleDateFormat;
import java.util.Date;

import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InboxCaseDetails {

	private int caseId;
	private String reportedOn;
	private String managedBy;
	private String status;
	private String message;
	private int transId;
	
	public InboxCaseDetails(int caseId, Date reportedOn, String managedBy, String status, int transId, int action) {
		super();
		this.caseId = caseId;
		this.reportedOn = new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn);
		this.managedBy = managedBy.trim();
		this.status = status.trim();
		this.transId = transId;
		this.message = action==1?"ACCEPTED":"NOT ACCEPTED";
	}
	
	public InboxCaseDetails(int caseId, Date reportedOn, String status, int transId, int action) {
		super();
		this.caseId = caseId;
		this.reportedOn = new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn);
		this.managedBy = "IC";
		this.status = status.trim();
		this.transId = transId;
		this.message = action==1?"ACCEPTED":"NOT ACCEPTED";
	}
	
	public InboxCaseDetails(int caseId, Date reportedOn, String managedBy, String status) {
		super();
		this.caseId = caseId;
		this.reportedOn = new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn);
		this.managedBy = managedBy.trim();
		this.status = status.trim();
	}
	

	public InboxCaseDetails(int caseId, String reportedOn, String managedBy, String status) {
		super();
		this.caseId = caseId;
		this.reportedOn = reportedOn;
		this.managedBy = managedBy;
		this.status = status;
	}
}
