package com.infosys.hello.springboot.controller;

import com.infosys.hello.springboot.service.GreetingsService;
import com.infosys.hello.springboot.telemetry.AuditEvent;
import com.netflix.hystrix.contrib.javanica.annotation.*;

import lombok.extern.slf4j.Slf4j;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import com.infosys.hello.springboot.model.Greeting;

@EnableHystrix
@EnableHystrixDashboard
@EnableCircuitBreaker
@RestController
@RequestMapping("/springboot/v1")
@Slf4j

// Sending Audit Telemetry Event just before completion of the request. 
// This class handles Audit Event data to telemetry service in case no exception occurs 
// "GreetingsInterceptor" class is being used to send Log Event for every request
// "CustomException Handler is being used for sending Error event in case any exception occurs

// Telemetry events are being handled only for this class.
// To send Audit event data , Autowire "AuditTelemetry" class and use "setTelemetryData" method with appropriate parameters

public class GreetingsController{

	@Autowired
	GreetingsService greetingService;
	
	@Autowired
	AuditEvent auditTelemetry;

	@RequestMapping(value = "/greetings", method=RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<Greeting> greeting(
			@RequestParam(value="content", required=false) String content) {

		//log.debug("method = greeting, type = api, content = {}", content);


		Greeting greeting = greetingService.getGreetings(content);
		auditTelemetry.setTelemetryData("Audit Message");
		return new ResponseEntity<Greeting>(greeting, HttpStatus.OK);

	}
	
	
	@GetMapping("/hystrixmethod")
	@HystrixCommand(fallbackMethod="fallbackMethod",commandProperties={
			@HystrixProperty(name = "circuitBreaker.requestVolumeThreshold", value =
                  "50"),
			//the number of requests that it needs to see
			@HystrixProperty(name = "circuitBreaker.errorThresholdPercentage", value =
                  "50"),
			//the percentage of failure for breaking circuit
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds",
                  value = "1000"),
			//wait time before breaking circuit
			@HystrixProperty(name = "metrics.rollingStats.timeInMilliseconds", value = "60000")
			//for how long the circuit will be open
			})
	 	public String testHystrix() {
		//this method is supposed to call another service which should return a simple string. 
		//If the service is down , it will open the circuit and redirect to fallback.
		RestTemplate restTemplate = new RestTemplate();
	    URI uri = URI.create("http://localhost:8080");
	    return restTemplate.getForObject(uri, String.class);
	  }

	public String fallbackMethod() {
	    return "Circuit has been broken and fallback initiated";
	  }

}
