package com.infosys.reach.util;

public class Message {
	private Message() {
		
	}
	public static final String UNAUTHORIZED="Authorization is required";
	public static final String INVALIDTOKEN="Invalid token";
	public static final String JWTEXPIRED="Token has expired.";
	public static final String SOMETHING_WENT_WRONG="Something went wrong";
	public static final String SCHEDULED="Successfully Scheduled.";
	public static final String UNAVAILABLE="Unavailable";
	public static final String INVALID_EMPLOYEE="Invalid Employee ID.";
	public static final String ERROR="error";
	public static final String SUCCESS="success";
	public static final String SUCCESSPROCEED="successproceed";
	public static final String SOMEERROROCCURED="some error occured";
	public static final String MAIL_NOT_TRIGGERED="Mail has not triggered, Reason : ";
	public static final String NO_DATA_FOUND="No Data Found";
	public static final String NO_CASE_REPORTED="No case reported";
	public static final String SUCCESSFULLY="Success ";
	public static final String SUCCESSFULLY_NEW="Successfully ";
	public static final String EXCEPTION="Exception message is: ";
	public static final String NOCASEFOUND="No case found";
	public static final String NOACCESS="You don't have access to this application.";
	public static final String NOTAVAILABLE="Details Not Available";
	public static final String NOFILE="No evidence found.";
	public static final String CASENOTREGISTERED="No case has registered with this id.";
	public static final String FILESIZE="File size upto 5 MB and type JPG,JPEG,MSG,PDF,TIFF,PNG,MSG are accepted.";
	public static final String FILETYPES="Only JPG,JPEG,PDF,TIFF,PNG,MSG files are accepted.";
	public static final String DESCRIPTIONLENGTH="Incident description should be of minimum 200 characters.";
	public static final String EMPID_OR_EMPNO="Enter Email ID or Employee Number";
	public static final String INVALID_INPUT="Invalid input.";
	public static final String INVALID_FILE="Invalid file.";
	public static final String UNABLE_TO_PROCEED="Unable to proceed";
	public static final String SOMEERROROCCUREDMAIL="Some error occured while processing your request. Please try again.";
	
	public static final String FILENAME_ERRORMESSAGE = "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1";
	public static final String FILENAMELENGTH_ERRORMESSAGE = "Filename is too long. Please rename.";
	public static final String FILESIZE_ERRORMESSAGE = "Exceeding file size limit";
	public static final String FILESIZE_LIMIT = "5000|KB";
	public static final String CONCLUSION_PLACEHOLDER = "Write your conclusion statements and recommendations here…";
	public static final String MAIL_DETAILS_NOTFOUND = "Details for mail not found";
	public static final String ACCESSDENIED="You don't have permission to access this data.";
	public static final String ACCESSGRANTED="Access granted";
}
