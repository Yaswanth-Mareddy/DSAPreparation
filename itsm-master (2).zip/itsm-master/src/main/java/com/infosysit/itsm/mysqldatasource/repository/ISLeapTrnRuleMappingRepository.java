package com.infosysit.itsm.mysqldatasource.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.itsm.mysqldatasource.entity.ISLeapTrnRuleMapping;
import com.infosysit.itsm.util.QueryConstants;

public interface ISLeapTrnRuleMappingRepository extends JpaRepository<ISLeapTrnRuleMapping, Integer> {
	
	@Query(value=QueryConstants.GETRULEUSINGTICKETNUMBER)
	String getRuleUsingTickerNumber(@Param("txtAhdTicket") String txtAhdTicket);
	

}
