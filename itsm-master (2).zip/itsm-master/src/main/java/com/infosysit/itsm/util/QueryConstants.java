package com.infosysit.itsm.util;

public class QueryConstants {
	private QueryConstants() {
		
	}
	public static final String GETICMOPENTICKETSDETAILS="select new com.infosysit.itsm.model.ISLeapTicket(caller,number,shortdescription,category,createdDate,sysId,madesla) from ICMTickets where  state='Open' and sop='Travel missing dependent details'";
	
	public static final String GETDEPENDENTPASSPORTDETAILS="select new com.infosysit.itsm.model.EDSTrnDepPassportDetailsModel(a.txtEmpNo,a.intSerialNo,b.txtRelationDesc,a.txtPassPortNo) from EDSTrnDepPassportDetails a inner join EDSMstRelation b on a.intSerialNo=b.intRelSeqNo where txtEmpNo=:txtEmpNo";

	public static final String UPDATEICMTICKETSUSINGNUMBER="update ICMTickets set resolutionSteps=:resolutionSteps,state='Resolved' where number=:number";
	
	public static final String GETICMOPENTICKETSNUMBERS="select number from ICMTickets where  sop='Auto closure response transfer' and state='Open'";

	public static final String GETRULEUSINGTICKETNUMBER="select txtRuleNo from ISLeapTrnRuleMapping where txtAhdTicket=:txtAhdTicket";

	public static final String GETRESOLUTIONDETAILS="select  new com.infosysit.itsm.model.ISLeapAutoResponseModel(txtStatusCode,txtSuggestion,txtTransfer,txtNewCategoryName,txtNewDeptName) from ISLeapMstAutoResponse where txtRuleNo=:txtRuleNo";

	public static final String UPDATEICMTICKETSNOTREQUIRED="update ICMTickets set state='Acknowledged',resolutionSteps=:resolutionSteps,subcategory=:subCategory where number=:number";

	public static final String UPDATEICMTICKETSREQUIRED="update ICMTickets set state='Transfer_Required',resolutionSteps=:resolutionSteps,subcategory=:subCategory where number=:number";

}
