package com.infosys.reach;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.model.ashi.ComplaintDetails;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.CaseGenModelField;
import com.infosys.reach.model.ashimobile.CaseGenModelForm;
import com.infosys.reach.model.ashimobile.CaseGenModelFormData;
import com.infosys.reach.model.ashimobile.ComplaintField;
import com.infosys.reach.model.ashimobile.EmployeeCard;
import com.infosys.reach.model.ashimobile.EmployeeCardView;
import com.infosys.reach.model.ashimobile.EmployeeField;
import com.infosys.reach.model.ashimobile.EvidenceCard;
import com.infosys.reach.model.ashimobile.EvidenceCardView;
import com.infosys.reach.model.ashimobile.EvidenceField;
import com.infosys.reach.model.ashimobile.MobileComplaintInboxView;
import com.infosys.reach.model.ashimobile.MobileInboxAction;
import com.infosys.reach.model.ashimobile.MobileInboxView;
import com.infosys.reach.model.ashimobile.MobileRow;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.service.ASHIMobileServiceImpl;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@ExtendWith(MockitoExtension.class)
class ASHIMobileServiceTests {
	private Timestamp dateTime = new Timestamp(System.currentTimeMillis());
	
	@InjectMocks
	ASHIMobileServiceImpl service;
	
	@Mock
	ASHIServiceImpl ashiService;
	
	@Mock
	Property mockproperty;
	
	@Mock
	ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Mock
	ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;
	
	@Mock
	ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;
	
	@Mock
	ELCMECMstASHICaseEmployeeDetailsRepository ashiCaseEmployeeDetailsRepository;
	
	@Mock
	ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;
	
	@Test
	void initiateCaseForm1() throws Exception {
		List<CaseGenModelForm> genModelFormList = new ArrayList<>();
		List<CaseGenModelForm> accordionFormList = new ArrayList<>();

		// Respondent section
		List<CaseGenModelField> respondentFieldList = new ArrayList<>();
		List<GenModelOption> respondentTypeOptions = new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee", true));
		respondentTypeOptions.add(new GenModelOption(0, Constants.OTHERS));
		CaseGenModelField complaintAgainst = new CaseGenModelField(47, "respondentType", "", 1, "",
				respondentTypeOptions, true);
		
		complaintAgainst.setLabel("Respondent (Complaint against ) is an");
		respondentFieldList.add(complaintAgainst);

		CaseGenModelField isIdentityKnown = new CaseGenModelField(45, "isRespondentKnown",
				"I know the identity of the respondent", 0, "respondentType|1", "", true);
		respondentFieldList.add(isIdentityKnown);

		CaseGenModelField respondentInfy = new CaseGenModelField(46, "respondentsInfy", "", "isRespondentKnown",
				"EmployeeSearchMobileURL", "", false);
		respondentInfy.setLabel("Respondent (Complaint Against)");
		respondentInfy.setPlaceHolder(Message.EMPID_OR_EMPNO);
		respondentFieldList.add(respondentInfy);

		CaseGenModelField respondentOther = new CaseGenModelField(0, "respondentsOther", "", "respondentType|0", "",
				"Enter names or identity of respondents separated by comma.", false);
		respondentOther.setLabel("Respondent (Complaint Against)");
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new CaseGenModelForm(respondentFieldList));

		// Location section

		List<CaseGenModelField> locationFieldList = new ArrayList<>();

		List<GenModelOption> countryOptions = new ArrayList<>();
		countryOptions.add(new GenModelOption("IN", "INDIA"));

		CaseGenModelField country = new CaseGenModelField(11, "country", "Country", "INDIA", "", countryOptions,
				true);
		locationFieldList.add(country);

		CaseGenModelField city = new CaseGenModelField(11, "baseLocation", "Base Location", "BANGALORE", "country",
				new ArrayList<>(), true);
		city.setDependantAction("BaselocationbycountrycodeURL");
		locationFieldList.add(city);

		genModelFormList.add(new CaseGenModelForm(locationFieldList));

		// Complaint Details section
		List<CaseGenModelField> descriptionFieldList = new ArrayList<>();

		CaseGenModelField description = new CaseGenModelField(1, "description", "Description", "", "",
				"Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new CaseGenModelForm(descriptionFieldList));

		// Cocomplainant section
		List<CaseGenModelField> cocomplainantFieldList = new ArrayList<>();
		CaseGenModelField cocomplainant = new CaseGenModelField(46, "cocomplainants", "", "", "EmployeeSearchMobileURL",
				Message.EMPID_OR_EMPNO, true);
		cocomplainant.setLabel("Tag Other Complainants");
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new CaseGenModelForm(cocomplainantFieldList));

		// Witnesses section
		List<CaseGenModelField> witnessesFieldList = new ArrayList<>();

		CaseGenModelField witnesses = new CaseGenModelField(46, "witnesses", "", "", "EmployeeSearchMobileURL",
				Message.EMPID_OR_EMPNO, true);
		witnesses.setLabel("Tag Witnesses");
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new CaseGenModelForm(witnessesFieldList));

		// Stakeholder section
		
		List<CaseGenModelField> stakeholderFieldList = new ArrayList<>();

		CaseGenModelField isStakeHolder = new CaseGenModelField(45, Constants.ISSTAKEHOLDER,
				"Reported to any other stakeholder before raising the case", 0, "", "", true);
		isStakeHolder.setLabel("Stakeholders");
		stakeholderFieldList.add(isStakeHolder);

		List<GenModelOption> stakeholderOptions = new ArrayList<>();
		stakeholderOptions.add(new GenModelOption("TL", "Technology Lead"));

		CaseGenModelField stakeholderRole = new CaseGenModelField(11, "stakeholderRole", "Stakeholder Role",
				stakeholderOptions.get(0).getValue(), Constants.ISSTAKEHOLDER, stakeholderOptions, false);
		stakeholderRole.setPlaceHolder("Choose Stakeholder");
		stakeholderRole.setLabel("Stakeholders");
		stakeholderFieldList.add(stakeholderRole);

		CaseGenModelField stakeholder = new CaseGenModelField(46, "stakeholder", "", Constants.ISSTAKEHOLDER,
				"EmployeeSearchMobileURL", Message.EMPID_OR_EMPNO, false);
		stakeholder.setLabel("Stakeholder");
		stakeholderFieldList.add(stakeholder);

		accordionFormList.add(new CaseGenModelForm(stakeholderFieldList));


		List<CardViewAction> actions = new ArrayList<>();

		actions.add(new CardViewAction(1, "Initiate Complaint", "POST", "SubmitcaseMobileURL", "submit"));
		actions.add(new CardViewAction(1, "Cancel", "", "", "cancel"));

		CaseGenModelFormData g1 = new CaseGenModelFormData(genModelFormList);

		CaseGenModelFormData g2 = new CaseGenModelFormData("More Details On The Complaint (Optional)",
				accordionFormList);
		
		List<GenModelOption> cities = new ArrayList<>();
		cities.add(new GenModelOption("3", "BANGALORE"));
		
		Mockito.when(mockproperty.getEmployeeSearchMobileURL()).thenReturn("EmployeeSearchMobileURL");
		Mockito.when(mockproperty.getBaselocationbycountrycodeMobileURL()).thenReturn("BaselocationbycountrycodeURL");
		Mockito.when(mockproperty.getSubmitcaseMobileURL()).thenReturn("SubmitcaseMobileURL");
		Mockito.when(ashiService.getCitiesByCountryCode(Mockito.anyString())).thenReturn(cities);
		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(Mockito.anyInt(), Mockito.anyInt())).thenReturn(countryOptions);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(Mockito.anyInt(), Mockito.anyString())).thenReturn(stakeholderOptions);
		
		CaseFormGenModel expected = new CaseFormGenModel("Initiate Case Form", "", g1, g2, actions);
		
		CaseFormGenModel actual = service.initiateCaseForm();
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getGenModel().getFormdata().size(), actual.getGenModel().getFormdata().size());
		assertEquals(expected.getAccordion().getFormdata().size(), actual.getAccordion().getFormdata().size());
		assertEquals(expected.getActions().size(), actual.getActions().size());
	}
	
	@Test
	void initiateCaseForm2() throws Exception {
		List<CaseGenModelForm> genModelFormList = new ArrayList<>();
		List<CaseGenModelForm> accordionFormList = new ArrayList<>();

		// Respondent section
		List<CaseGenModelField> respondentFieldList = new ArrayList<>();
		List<GenModelOption> respondentTypeOptions = new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee", true));
		respondentTypeOptions.add(new GenModelOption(0, Constants.OTHERS));
		CaseGenModelField complaintAgainst = new CaseGenModelField(47, "respondentType", "", 1, "",
				respondentTypeOptions, true);
		
		complaintAgainst.setLabel("Respondent (Complaint against ) is an");
		respondentFieldList.add(complaintAgainst);

		CaseGenModelField isIdentityKnown = new CaseGenModelField(45, "isRespondentKnown",
				"I know the identity of the respondent", 0, "respondentType|1", "", true);
		respondentFieldList.add(isIdentityKnown);

		CaseGenModelField respondentInfy = new CaseGenModelField(46, "respondentsInfy", "", "isRespondentKnown",
				"EmployeeSearchMobileURL", "", false);
		respondentInfy.setLabel("Respondent (Complaint Against)");
		respondentInfy.setPlaceHolder(Message.EMPID_OR_EMPNO);
		respondentFieldList.add(respondentInfy);

		CaseGenModelField respondentOther = new CaseGenModelField(0, "respondentsOther", "", "respondentType|0", "",
				"Enter names or identity of respondents separated by comma.", false);
		respondentOther.setLabel("Respondent (Complaint Against)");
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new CaseGenModelForm(respondentFieldList));

		// Location section

		List<CaseGenModelField> locationFieldList = new ArrayList<>();

		List<GenModelOption> countryOptions = new ArrayList<>();
		countryOptions.add(new GenModelOption("US", "USA"));

		CaseGenModelField country = new CaseGenModelField(11, "country", "Country", "US", "", countryOptions,
				true);
		locationFieldList.add(country);

		CaseGenModelField city = new CaseGenModelField(11, "baseLocation", "Base Location", "HYDERABAD", "country",
				new ArrayList<>(), true);
		city.setDependantAction("BaselocationbycountrycodeURL");
		locationFieldList.add(city);

		genModelFormList.add(new CaseGenModelForm(locationFieldList));

		// Complaint Details section
		List<CaseGenModelField> descriptionFieldList = new ArrayList<>();

		CaseGenModelField description = new CaseGenModelField(1, "description", "Description", "", "",
				"Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new CaseGenModelForm(descriptionFieldList));

		// Cocomplainant section
		List<CaseGenModelField> cocomplainantFieldList = new ArrayList<>();
		CaseGenModelField cocomplainant = new CaseGenModelField(46, "cocomplainants", "", "", "EmployeeSearchMobileURL",
				Message.EMPID_OR_EMPNO, true);
		cocomplainant.setLabel("Tag Other Complainants");
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new CaseGenModelForm(cocomplainantFieldList));

		// Witnesses section
		List<CaseGenModelField> witnessesFieldList = new ArrayList<>();

		CaseGenModelField witnesses = new CaseGenModelField(46, "witnesses", "", "", "EmployeeSearchMobileURL",
				Message.EMPID_OR_EMPNO, true);
		witnesses.setLabel("Tag Witnesses");
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new CaseGenModelForm(witnessesFieldList));

		// Stakeholder section
		
		List<CaseGenModelField> stakeholderFieldList = new ArrayList<>();

		CaseGenModelField isStakeHolder = new CaseGenModelField(45, Constants.ISSTAKEHOLDER,
				"Reported to any other stakeholder before raising the case", 0, "", "", true);
		isStakeHolder.setLabel("Stakeholders");
		stakeholderFieldList.add(isStakeHolder);

		List<GenModelOption> stakeholderOptions = new ArrayList<>();
		stakeholderOptions.add(new GenModelOption("TL", "Technology Lead"));

		CaseGenModelField stakeholderRole = new CaseGenModelField(11, "stakeholderRole", "Stakeholder Role",
				stakeholderOptions.get(0).getValue(), Constants.ISSTAKEHOLDER, stakeholderOptions, false);
		stakeholderRole.setPlaceHolder("Choose Stakeholder");
		stakeholderRole.setLabel("Stakeholders");
		stakeholderFieldList.add(stakeholderRole);

		CaseGenModelField stakeholder = new CaseGenModelField(46, "stakeholder", "", Constants.ISSTAKEHOLDER,
				"EmployeeSearchMobileURL", Message.EMPID_OR_EMPNO, false);
		stakeholder.setLabel("Stakeholder");
		stakeholderFieldList.add(stakeholder);

		accordionFormList.add(new CaseGenModelForm(stakeholderFieldList));


		List<CardViewAction> actions = new ArrayList<>();

		actions.add(new CardViewAction(1, "Initiate Complaint", "POST", "SubmitcaseMobileURL", "submit"));
		actions.add(new CardViewAction(1, "Cancel", "", "", "cancel"));

		CaseGenModelFormData g1 = new CaseGenModelFormData(genModelFormList);

		CaseGenModelFormData g2 = new CaseGenModelFormData("More Details On The Complaint (Optional)",
				accordionFormList);
		
		List<GenModelOption> cities = new ArrayList<>();
		cities.add(new GenModelOption("7", "HYDERABAD"));
		
		Mockito.when(mockproperty.getEmployeeSearchMobileURL()).thenReturn("EmployeeSearchMobileURL");
		Mockito.when(mockproperty.getBaselocationbycountrycodeMobileURL()).thenReturn("BaselocationbycountrycodeURL");
		Mockito.when(mockproperty.getSubmitcaseMobileURL()).thenReturn("SubmitcaseMobileURL");
		Mockito.when(ashiService.getCitiesByCountryCode(Mockito.anyString())).thenReturn(cities);
		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(Mockito.anyInt(), Mockito.anyInt())).thenReturn(countryOptions);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(Mockito.anyInt(), Mockito.anyString())).thenReturn(stakeholderOptions);
		
		CaseFormGenModel expected = new CaseFormGenModel("Initiate Case Form", "", g1, g2, actions);
		
		CaseFormGenModel actual = service.initiateCaseForm();
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getGenModel().getFormdata().size(), actual.getGenModel().getFormdata().size());
		assertEquals(expected.getAccordion().getFormdata().size(), actual.getAccordion().getFormdata().size());
		assertEquals(expected.getActions().size(), actual.getActions().size());
	}
	
	@Test
	void getComplaintDetailsTestCase() throws Exception{
		List<ComplaintDetails> complaintDetailsWithRespondents= new ArrayList<>();
		complaintDetailsWithRespondents.add(new ComplaintDetails(1,"respondentType","managedBy","status","12-01-2021","location","descp"));
		Mockito.when(caseDetailsRepository.findComplaintDetailsByCaseId(Mockito.anyInt())).thenReturn(complaintDetailsWithRespondents);		

		ComplaintField complaint = new ComplaintField(1, complaintDetailsWithRespondents.get(0).getRespondentType(),complaintDetailsWithRespondents.get(0));
		MobileComplaintInboxView expected = new MobileComplaintInboxView(Constants.CASE_DETAILS, "", Constants.INBOXVIEW, complaint);
		MobileComplaintInboxView actual = service.getComplaintDetails(1);
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getRow().getLocation(), actual.getRow().getLocation());	
	}

	@Test
	void getComplaintDetailsTestCase1() throws Exception{
		List<ComplaintDetails> complaintDetailsWithRespondents= new ArrayList<>();
		Mockito.when(caseDetailsRepository.findComplaintDetailsByCaseId(Mockito.anyInt())).thenReturn(complaintDetailsWithRespondents);		

		MobileComplaintInboxView expected = new MobileComplaintInboxView(Constants.CASE_DETAILS, "", Constants.INBOXVIEW, null);
		MobileComplaintInboxView actual = service.getComplaintDetails(1);
		
		assertEquals(expected.getName(), actual.getName());
		assertNull(actual.getRow());	
	}
	
	@Test
	void getCaseEmployeeDetailsTestCase1() throws Exception{
		List<EmployeeCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(false);

		EmployeeCardView expected = new EmployeeCardView("Employee details", cards);
		EmployeeCardView actual = service.getCaseEmployeeDetails(1);
		assertEquals(expected.getName(), actual.getName());
		assertTrue(actual.getCards().isEmpty());
	}

	@Test
	void getCaseEmployeeDetailsTestCase2() throws Exception{

		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(true);

		List<EmployeeDetails> employeeDetails=Arrays.asList(new EmployeeDetails("mailId","empNo","name"));
		Mockito.when(ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(employeeDetails);
		
		List<EmployeeCard> cards=new ArrayList<>();
		List<EmployeeField> fields=Arrays.asList(new EmployeeField(employeeDetails.get(0)));

		cards.add(new EmployeeCard(Constants.RESPONDENTS, fields));
		cards.add(new EmployeeCard(Constants.WITNESSES, fields));
		cards.add(new EmployeeCard("Co-Complainants", fields));

		
		EmployeeCardView expected = new EmployeeCardView("Employee details", cards);
		EmployeeCardView actual = service.getCaseEmployeeDetails(1);
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
		assertEquals(expected.getCards().get(0).getHeading(), actual.getCards().get(0).getHeading());
		assertEquals(expected.getCards().get(0).getFields().size(), actual.getCards().get(0).getFields().size());
	}

	@Test
	void getCaseEmployeeDetailsTestCase3() throws Exception{
		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(true);
		Mockito.when(ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(new ArrayList<>());
		
		List<EmployeeCard> cards=new ArrayList<>();

		cards.add(new EmployeeCard(Constants.RESPONDENTS, new ArrayList<>()));
		cards.add(new EmployeeCard(Constants.WITNESSES, new ArrayList<>()));
		cards.add(new EmployeeCard("Co-Complainants", new ArrayList<>()));

		
		EmployeeCardView expected = new EmployeeCardView("Employee details", cards);
		EmployeeCardView actual = service.getCaseEmployeeDetails(1);
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
		assertEquals(expected.getCards().get(0).getHeading(), actual.getCards().get(0).getHeading());
		assertTrue(actual.getCards().get(0).getFields().isEmpty());
		assertTrue(actual.getCards().get(1).getFields().isEmpty());
		assertTrue(actual.getCards().get(2).getFields().isEmpty());
	}
	
	@Test
	void getEvidencesTestCase1() throws Exception{
		List<EvidenceCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,"filename1,filename2"));
		evidenceString.get().setCaseActionId(1);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);

		List<EvidenceField> fields = new ArrayList<>();
		fields.add(new EvidenceField("filename1",""));
		fields.add(new EvidenceField("filename2",""));
		
		cards.add(new EvidenceCard(fields));

		EvidenceCardView expected = new EvidenceCardView("Case evidences", cards);
		EvidenceCardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}
	
	@Test
	void getEvidencesTestCase2() throws Exception{
		List<EvidenceCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,""));
		evidenceString.get().setCaseActionId(1);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);

		List<EvidenceField> fields = new ArrayList<>();
		
		cards.add(new EvidenceCard(fields));

		EvidenceCardView expected = new EvidenceCardView("Case evidences", cards);
		EvidenceCardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}
	
	@Test
	void getEvidencesTestCase3() throws Exception{
		List<EvidenceCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,null));
		evidenceString.get().setCaseActionId(1);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);

		List<EvidenceField> fields = new ArrayList<>();
		
		cards.add(new EvidenceCard(fields));

		EvidenceCardView expected = new EvidenceCardView("Case evidences", cards);
		EvidenceCardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}
	
	@Test
	void getEvidencesTestCase4() throws Exception{
		List<EvidenceCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.empty();
		
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);
		
		cards.add(new EvidenceCard(new ArrayList<>()));

		EvidenceCardView expected = new EvidenceCardView("Case evidences", cards);
		EvidenceCardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}
	
	@Test
	void getEvidencesTestCase5() throws Exception{
		List<EvidenceCard> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		EvidenceCardView expected = new EvidenceCardView("Case evidences", cards);
		EvidenceCardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertTrue(actual.getCards().isEmpty());
	}
	
	@Test
	void getCasesInitiatedByMeTest() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		caseDetailsList.add(new InboxCaseDetails(1, "08-Feb-2021", "GRB", "WG"));
		
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(), Mockito.anyList())).thenReturn(caseDetailsList);
		
		List<MobileRow> rowList = new ArrayList<>();
		rowList.add(new MobileRow(caseDetailsList.get(0), new ArrayList<>()));
		
		MobileInboxView expected = new MobileInboxView("Tab - Initiated by me", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getCasesInitiatedByMe("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		
	}
	
	@Test
	void getCasesInitiatedByGRBTest() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(), Mockito.anyList())).thenReturn(caseDetailsList);
		
		List<MobileRow> rowList = new ArrayList<>();
		
		MobileInboxView expected = new MobileInboxView("Tab - Initiated by GRB", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getCasesInitiatedByGRB("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertTrue(actual.getRow().isEmpty());
		
	}
	
	@Test
	void getAllCasesTest() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(), Mockito.anyList())).thenReturn(caseDetailsList);
		
		List<MobileRow> rowList = new ArrayList<>();
		
		MobileInboxView expected = new MobileInboxView("Tab - All", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getAllCases("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertTrue(actual.getRow().isEmpty());
		
	}
	
	@Test
	void getCasesInitiatedByCoComplainantTest1() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		caseDetailsList.add(new InboxCaseDetails(1, new Date(), "GRB", "WG", 7, 0));
		
		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetailsList);
		Mockito.when(mockproperty.getAcceptMobileURL()).thenReturn("AcceptMobileURL?transactionid=");
		Mockito.when(mockproperty.getRejectMobileURL()).thenReturn("RejectMobileURL?transactionid=");
		
		List<MobileRow> rowList = new ArrayList<>();
		List<MobileInboxAction> actions = new ArrayList<>();
		actions.add(new MobileInboxAction("Accept", "POST", "AcceptMobileURL" + caseDetailsList.get(0).getTransId(),
				"Are you sure you want to be tagged as a co-complainant?"));
		actions.add(new MobileInboxAction("Reject", "POST", "RejectMobileURL" + caseDetailsList.get(0).getTransId(),
				"Are you sure you do not want to be tagged as a co-complainant?"));
		rowList.add(new MobileRow(caseDetailsList.get(0), actions));
		
		MobileInboxView expected = new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getCasesInitiatedByCoComplainant("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		assertEquals(expected.getRow().get(0).getActions().size(), actual.getRow().get(0).getActions().size());
		
	}
	
	@Test
	void getCasesInitiatedByCoComplainantTest2() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		caseDetailsList.add(new InboxCaseDetails(1, new Date(), "GRB", "WG", 7, 1));
		
		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetailsList);
		
		List<MobileRow> rowList = new ArrayList<>();
		List<MobileInboxAction> actions = new ArrayList<>();
		rowList.add(new MobileRow(caseDetailsList.get(0), actions));
		
		MobileInboxView expected = new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getCasesInitiatedByCoComplainant("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		assertTrue(actual.getRow().get(0).getActions().isEmpty());
		
	}
	
	@Test
	void getCasesInitiatedByCoComplainantTest3() throws Exception {
		
		List<InboxCaseDetails> caseDetailsList = new ArrayList<>();
		
		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetailsList);
		
		List<MobileRow> rowList = new ArrayList<>();
		
		MobileInboxView expected = new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);
		
		MobileInboxView actual = service.getCasesInitiatedByCoComplainant("1030816");
		
		assertEquals(expected.getName(), actual.getName());
		assertTrue(actual.getRow().isEmpty());
		
	}
	
	@Test
	void getInboxTabs() throws Exception {
		
		List<TabView> expected = new ArrayList<>();

		expected.add(new TabView("All", "AllMobileURL"));
		expected.add(new TabView("Initiated by Me", "InitiatedByMeMobileURL"));
		expected.add(new TabView("As a Co-Complainant", "CoComplainantMobileURL"));
		expected.add(new TabView("Initiated by GRB", "InitiatedByGRBMobileURL"));
		
		Mockito.when(mockproperty.getAllMobileURL()).thenReturn("AllMobileURL");
		Mockito.when(mockproperty.getInitiatedByMeMobileURL()).thenReturn("InitiatedByMeMobileURL");
		Mockito.when(mockproperty.getCoComplainantMobileURL()).thenReturn("CoComplainantMobileURL");
		Mockito.when(mockproperty.getInitiatedByGRBMobileURL()).thenReturn("InitiatedByGRBMobileURL");
		
		List<TabView> actual = service.getInboxTabs();
		
		assertEquals(expected.size(), actual.size());
		
	}

}
