package com.infosysit.rctmscompliance.util;


/**
 * @author surajkumar.dewangan store all custom messages of the project to avoid
 *         repeated declaration message should be static and final
 *
 */
public class Message {
	private Message() {

	}

	public static final String UNAUTHORIZED = "Authorization is required";
	public static final String INVALIDTOKEN = "Invalid token";
	public static final String JWTEXPIRED = "Token has expired.";
	public static final String SUCCESSFULLY = "success";
	public static final String SOMEERROROCCURED = "some error occured";
	public static final String ERROR = "error";
	public static final String TIMEOUT = "Timeout";
	public static final String ACTIONFAILURE = "Failed in Updating Remark";
	public static final String ACTIONSUCCESS = "SUCCESSFULLY Completed PIA Request Action";
	public static final String FALLBACK = "fallback";
	public static final String USERDIR = "user.dir";
	public static final String EMPID_OR_EMPNO = "Enter Email ID or Employee Number";
	public static final String SUCCESSRELOAD = "successreload";
	public static final String NAVIGATEWITHMESSAGE = "navigatewithmessage";
	public static final String INBOXFAILURE = "No compliances fetched with selected filter";
	
}
