package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.disciplinary.CaseDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name="elcmectrnreachcasedetails")
public class ELCMECTrnReachCaseDetails
{
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="intcategoryid")
	private int categoryId;
	
	@Column(name="intsubcategoryid")
	private int subCategoryId;
	
	@Column(name="txtrespondentempno")
	private String respondentEmpNo;
	
	@Column(name="txtstatus")
	private String status;
	
	@Column(name="intfasttrack")
	private int fasttrack;
	
	@Column(name="txtcreatedapp")
	private String createdApp;
	
	@Column(name="txtcreatedappreqid")
	private String createdAppReqId;
	
	@Column(name="txtcomplainantempno")
	private String complainantEmpNo1;
	
	@Column(name="txtcomplainantempno2")
	private String complainantEmpNo2;
	
	@Column(name="txtcomplainantempno3")
	private String complainantEmpNo3;
	
	@Column(name="dtcasecloseddate")
	private Timestamp caseClosedDate;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="txtmodifiedby")
	private String modifiedBy;
	
	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;
	
	@Column(name="txtreferenceno")
	private String referenceNo;
	
	@Column(name="dtincidentdate")
	private Timestamp incidentDate;

	public ELCMECTrnReachCaseDetails(CaseDetails caseDetails, String respondentEmpNo, Timestamp incidentDate, String createdBy, Timestamp createdOn) {
		super();
		this.moduleId = 4;
		this.categoryId = caseDetails.getCategoryId();
		this.subCategoryId = caseDetails.getSubcategoryId();
		this.respondentEmpNo = respondentEmpNo;
		this.status = "IM";
		this.fasttrack = 0;
		this.createdApp = caseDetails.getAppCode();
		this.createdAppReqId = "";
		this.complainantEmpNo1 = "";
		this.complainantEmpNo2 = "";
		this.complainantEmpNo3 = "";
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
		this.incidentDate = incidentDate;
	}
	
}
