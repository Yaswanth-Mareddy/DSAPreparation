package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.controller.Session;
import com.infosys.reach.model.ashi.GMFields;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmecmstashirecommendationsdetails")
public class ELCMECMstASHIRecommendationsDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtactor")
	private String actor;
	
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="txtseveritylevel")
	private String severityLevel;
	
	@Column(name="txtactions")
	private String actions;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="dtcreateddate")
	private Timestamp createdDate;
	
	@Column(name="txtupdatedby")
	private String updatedBy;
	
	@Column(name="dtupdateddate")
	private Timestamp updatedDate;
	
	@Column(name="flgimplemented")
	private int flgImplemented;
	
	@Column(name="txtremarks")
	private String remarks;

	public ELCMECMstASHIRecommendationsDetails(GMFields fields, String actor, Timestamp createdDate) {
		super();
		this.caseId = fields.getCaseid();
		this.actor = actor;
		if(actor.equals("A"))
			this.mailId = fields.getComplainant();
		else if(actor.equals("R"))
			this.mailId = fields.getRespondent();
		else if(actor.equals("W"))
			this.mailId = fields.getWitness();
		this.severityLevel = fields.getSeverityLevel();
		this.actions = fields.getRecommendedActions();
		this.createdBy = Session.getTokenEMPNO();
		this.createdDate = createdDate;
		this.remarks = fields.getRemarks();
	}
	
	
}
