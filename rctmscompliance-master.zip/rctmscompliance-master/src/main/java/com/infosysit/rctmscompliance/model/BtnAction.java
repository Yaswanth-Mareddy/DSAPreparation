package com.infosysit.rctmscompliance.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class BtnAction {
	private int intComplianceID;
	private String dtAssignedDate;
	
	@JsonProperty(value="Comments")
	private String comments= "{1}";
}
