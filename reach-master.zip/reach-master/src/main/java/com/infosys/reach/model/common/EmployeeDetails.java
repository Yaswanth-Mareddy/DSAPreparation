package com.infosys.reach.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(Include.NON_NULL)
public class EmployeeDetails {

	private String mailId;
	private String empNo;
	private String name;

	public EmployeeDetails(String mailId, String empNo, String name) {
		super();
		this.mailId = mailId==null?"NA":mailId.trim();
		this.empNo = empNo==null?"NA":empNo.trim();
		this.name = name==null?"NA":name.trim();
	}
	
	public EmployeeDetails(String mailId, String empNo) {
		super();
		this.mailId = mailId==null?"NA":mailId.trim();
		this.empNo = empNo==null?"NA":empNo.trim();
	}
	
	
}
