package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnASHIConciliationReportDetails;

public interface ELCMECTrnASHIConciliationReportDetailsRepository
		extends JpaRepository<ELCMECTrnASHIConciliationReportDetails, Integer> {

	boolean existsByCaseId(int caseId);
	
	Optional<ELCMECTrnASHIConciliationReportDetails> findByCaseId(int caseid);
	
}
