package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnHearActionDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnHearActionDetailsRepository extends JpaRepository<ELCMECTrnHearActionDetails, Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnHearActionDetails> S save(S entity);
}
