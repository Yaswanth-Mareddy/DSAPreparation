package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class GenModelFormData {

	private String heading;
	private List<GenModelForm> formdata;
	
	
	public GenModelFormData() {
		super();
		this.heading = "";
		this.formdata = new ArrayList<>();
	}

	public GenModelFormData(List<GenModelForm> formdata) {
		super();
		this.heading = "";
		this.formdata = formdata;
	}
	
	
}
