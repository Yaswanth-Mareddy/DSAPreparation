package com.infosysit.rctmscompliance.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComplianceConfigurableDetails {

	private String txtName;
	private String txtValue;
	private String intIdentity;
}
