package com.infosys.hello.springboot.dto;

import java.math.BigDecimal;
import java.util.Date;

import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Future;
import javax.validation.constraints.FutureOrPresent;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Negative;
import javax.validation.constraints.NegativeOrZero;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.PastOrPresent;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;
import javax.validation.constraints.PositiveOrZero;
import javax.validation.constraints.Size;

public class ValidatorDTO {
	
	private static final int NAME_MIN_VAL = 2;
	private static final int NAME_MAX_VAL = 15;
	
	private static final int AGE_MIN_VAL = 18;
	private static final int AGE_MAX_VAL = 50;
	
	private static final String EMAIL_PATTERN = "(\\w+).(\\w+)@infosys.com";
	
	private static final String LARGE_VAL= "30.00";
	private static final String SMALL_VAL= "5.00";
	
	private static final int PRICE_INTEGER = 3;
	private static final int PRICE_FRACTION = 2; 
	
	@NotNull
	@NotEmpty
	@Size(min=NAME_MIN_VAL, max=NAME_MAX_VAL)
	private String name;
	
	@Min(AGE_MIN_VAL)
	@Max(AGE_MAX_VAL)
	private Integer age;
	
	@NotBlank
	private String phoneNumber;
	
	@Pattern(regexp = EMAIL_PATTERN)
	private String email;
	
	@DecimalMax(LARGE_VAL)
	private BigDecimal largeVal;
	
	@DecimalMin(SMALL_VAL)
	private BigDecimal smallVal;
	
	@Digits(integer=PRICE_INTEGER, fraction=PRICE_FRACTION)
	private BigDecimal price;

	@Negative
	private Integer negativeVal;
	
	@NegativeOrZero
	private Integer negativeOrZeroVal;
	
	@Positive
	private Integer positiveVal;
	
	@PositiveOrZero
	private Integer positiveOrZeroVal;
	
	@Future
	private Date futureDate;
	
	@FutureOrPresent
	private Date futureOrPresentDate;
	
	@PastOrPresent
	private Date pastOrPresentDate;
		

	public Date getFutureDate() {
		return futureDate;
	}

	public void setFutureDate(Date futureDate) {
		this.futureDate = futureDate;
	}

	public Date getFutureOrPresentDate() {
		return futureOrPresentDate;
	}

	public void setFutureOrPresentDate(Date futureOrPresentDate) {
		this.futureOrPresentDate = futureOrPresentDate;
	}

	public Date getPastOrPresentDate() {
		return pastOrPresentDate;
	}

	public void setPastOrPresentDate(Date pastOrPresentDate) {
		this.pastOrPresentDate = pastOrPresentDate;
	}
	
	
	
	public Integer getPositiveVal() {
		return positiveVal;
	}

	public void setPositiveVal(Integer positiveVal) {
		this.positiveVal = positiveVal;
	}

	public Integer getPositiveOrZeroVal() {
		return positiveOrZeroVal;
	}

	public void setPositiveOrZeroVal(Integer positiveOrZeroVal) {
		this.positiveOrZeroVal = positiveOrZeroVal;
	}

	public Integer getNegativeVal() {
		return negativeVal;
	}

	public void setNegativeVal(Integer negativeVal) {
		this.negativeVal = negativeVal;
	}

	public Integer getNegativeOrZeroVal() {
		return negativeOrZeroVal;
	}

	public void setNegativeOrZeroVal(Integer negativeOrZeroVal) {
		this.negativeOrZeroVal = negativeOrZeroVal;
	}

	public BigDecimal getLargeVal() {
		return largeVal;
	}

	public void setLargeVal(BigDecimal largeVal) {
		this.largeVal = largeVal;
	}

	public BigDecimal getSmallVal() {
		return smallVal;
	}

	public void setSmallVal(BigDecimal smallVal) {
		this.smallVal = smallVal;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
