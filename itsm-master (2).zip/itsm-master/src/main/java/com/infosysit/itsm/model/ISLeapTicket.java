package com.infosysit.itsm.model;

import java.util.Date;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
public class ISLeapTicket {
	private String caller;
	private String number;
	private String shortdescription;
	private String category;
	private Date createdDate;
	private String sysId;
	private Integer madesla;
	public ISLeapTicket( String caller,String number,String shortdescription,String category,Date createdDate,String sysId, Integer madesla) {
		super();
		this.caller=caller;
		this.number=number;
		this.shortdescription=shortdescription;
		this.category=category;
		this.createdDate=createdDate;
		this.sysId=sysId;
		this.madesla=madesla;
	}
}
