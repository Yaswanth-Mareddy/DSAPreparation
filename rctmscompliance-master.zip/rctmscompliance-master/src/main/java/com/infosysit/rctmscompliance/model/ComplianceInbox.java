package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ComplianceInbox {
	
	private String txtComplianceName;
	private String   dtAssignedDate;
	private String txtGroupName;
	private String txtLocation;
	private String txtDept;
	private String   dtDueDate;
	private String txtFrequency;
	private String txtStatus;
	private String txtAssignee;
	private String txtVerifier;
	private String txtOwner;
	private int    intComplianceID;
	private String   dtActualFilingDate;
	private String txtPendingwith;
	private String assignee;
	private String verifier;
	private String owner;
	private String pendingwith;
	
}
