package com.infosys.hello.springboot.exception;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.infosys.hello.springboot.telemetry.ErrorEvent;


@ControllerAdvice

// This is a CustomException Handler where all any exception is handled here
// Also sending Error Event data to telemetry service in case of any exception.
// Custom Exception here uses class ErrorDetails class .

public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	ErrorEvent errorTelemetry;

	
	@Override
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		ErrorDetails errorDetails = new ErrorDetails("Validation Failed", ex.getBindingResult().toString());
		errorTelemetry.setTelemetryData( "Validation Failed", HttpStatus.BAD_REQUEST.toString(),new Object(){}.getClass().getEnclosingMethod().getName());

		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
		ErrorDetails errorDetails = new ErrorDetails(ex.getMessage(), request.getDescription(false));
		logger.error("StackTrace: " + this.getStackTrace(ex));
		errorTelemetry.setTelemetryData( "Send ErrorMessage according to Exception", HttpStatus.INTERNAL_SERVER_ERROR.toString(),new Object(){}.getClass().getEnclosingMethod().getName());
		return new ResponseEntity<>(errorDetails, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	/**
	 * This method used to fetch the Stack trace of the Exception object.
	 * 
	 * @param ex - Exception object
	 * @return String - This returns Stack trace of the Exception.
	 */
	public String getStackTrace(Exception ex) {
		if (ex == null) {
			throw new IllegalArgumentException("Excption == null");
		}
		StringWriter stringWriter = new StringWriter();
		try {
			PrintWriter printWriter = new PrintWriter(stringWriter);
			try {
				ex.printStackTrace(printWriter);
				return stringWriter.toString();
			} finally {
				printWriter.close();
			}
		} finally {
			try {
				stringWriter.close();
			} catch (Exception e) {

			}

		}
	}

}
