package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstASHICommunicationDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstASHICommunicationDetailsRepository extends JpaRepository<ELCMECMstASHICommunicationDetails, Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECMstASHICommunicationDetails> S save(S entity);


	@TrackExecutionTime
	List<ELCMECMstASHICommunicationDetails> findByCaseIdOrderBySerialNoDesc(int caseid);}
