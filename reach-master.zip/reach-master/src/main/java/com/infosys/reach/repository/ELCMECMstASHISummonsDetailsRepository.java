package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstASHISummonsDetails;

public interface ELCMECMstASHISummonsDetailsRepository extends JpaRepository<ELCMECMstASHISummonsDetails, Integer> {

	List<ELCMECMstASHISummonsDetails> findByCaseIdOrderBySerialNoDesc(int caseid);
	
	List<ELCMECMstASHISummonsDetails> findByCaseIdOrderBySerialNoAsc(int caseid);
	
	Optional<ELCMECMstASHISummonsDetails> findByCaseIdAndActorAndMailId(int caseid, String actor, String mailId);
}
