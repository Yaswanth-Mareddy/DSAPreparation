package com.infosys.reach.util;

public class Constants {
	
	private Constants() {
		
	}
	
	public static final String CASEID="caseid";
	public static final String TRANSACTIONID="transactionid";
	public static final String CONTENTTYPE="Content-Type";
	public static final String JSON="application/json";
	public static final String AUTHORIZATION="Authorization";
	public static final String POST="POST";
	public static final String GET="GET";
	public static final String FAILURE="FAILURE ";
	public static final String INVALID=" is invalid.";
	public static final String OTHERS="Others";
	public static final String WITNESSES="Witnesses";
	public static final String RESPONDENTS="Respondents";
	public static final String EVIDENCES="evidences";
	public static final String ACCEPT="Accept";
	public static final String UPDATE="Update";
	public static final String CHECK="Check";

	
	
	public static final String CASE_ID="caseId";
	public static final String REDIRECTID="redirectid";
	public static final String NAVIGATE="navigate";
	public static final String INBOXVIEW="inboxview";
	public static final String UNAVAILABLE=" is unavailable";
	public static final String CASE_DETAILS="Complaint details";
	public static final String CASEEMPLOYEE_DETAILS="Employee details";
	public static final String CONTEXT="CONTEXT";
	public static final String USERCONTEXT="USERCONTEXT";
	public static final String UPLOAD="UPLOAD";
	public static final String DOWNLOAD="DOWNLOAD";
	public static final String DATETIME_FORMAT="dd-MMM-yyyy HH:mm";
	public static final String DATE_FORMAT="dd-MMM-yyyy";
	public static final String DATE_FORMAT_NEW="dd MMM yyyy";
	public static final String DAYS="{0} Days (Till {1})";
	public static final String REASON="Reason";
	public static final String ANY_OTHER_RECOMMENDATION="Any other recommendations";
	
	//Labels
	public static final String MANAGEDBYLABEL="Managed By";
	public static final String REPORTEDONLABEL="Reported On";
	public static final String CASENUMBERLABEL="Case Number";
	public static final String STATUSLABEL="Status";
	public static final String SELECT="Select";
	public static final String REMARKS="Remarks";
	public static final String COMMENTS="Comments";
	public static final String COMMENTS_PH="Enter your comments here";
	public static final String REASON_PH="Please enter the reason here…";
	
	//Mails
	public static final String SUBJECTPH="Subject";
	public static final String BODYPH="Body";
	public static final String RECIPIENTFYA_PH="Recipient";
	public static final String ACTORNAME_PH="ActorName";
	public static final String ID_PH="ID";
	public static final String DESCRIPTION_PH="description";
	public static final String CASEIDPH="#CaseId#";
	public static final String EMPNAME_PH="#EmpName#";
	public static final String EMPNO_PH="#EmpNo#";
	public static final String APPEALNOPH="#AppealNo#";
	public static final String EMPRAISEDPH="#EmpRaised#";
	public static final String CATEGORYNAME="#CategoryName#";
	public static final String RECIPIENTTYPE_PH="#RecipientType#";
	public static final String RECIPIENT_PH="#Recipient#";
	public static final String SNO_PH="#SNo#";
	public static final String ALLEGATION_PH="#Allegation#";
	public static final String FINDING_PH="#Finding#";
	public static final String OUTCOME_PH="#Outcome#";
	public static final String ROWS_PH="#Rows#";
	public static final String STATUS_PH="#Status#";
	public static final String ICLOCATION_PH="#ICLocation#";
	public static final String SLAENDDATE_PH="#SLAEndDate#";
	public static final String KEYWORD_PH="#Keyword#";
	public static final String REASON_PH_MAIL="#Reason#";
	public static final String LINK_PH="#Link#";
	public static final String REQNO_PH="#ReqNo#";
	public static final String EMPRAISED_PH="#EmpRaised#";
	public static final String EMP_PH="#Emp#";
	public static final String EMPDOJ_PH="#EmpDOJ#";
	public static final String EMPDESIGNATION_PH="#EmpDesignation#";
	public static final String EMPLOCATION_PH="#EmpLocation#";
	public static final String EMPMAILID_PH="#EmpMailId#";
	public static final String EMPUNIT_PH="#EmpUnit#";
	public static final String EVENTDATE_PH="#EventDate#";
	public static final String EVENT_PH="#Event#";
	public static final String REMARKS_PH="#Remarks#";
	public static final String DOCUMENTS_PH="#Documents#";

	
	//new mail place holders
	public static final String CASEID_PH = "#CaseId#";
	public static final String INITIATORNAME_PH = "#InitiatorName#";
	public static final String COMPLAINANTNAME_PH = "#ComplainantName#";
	public static final String COMPLAINANTEMPNO_PH = "#ComplainantEmpNo#";
	public static final String COMPLAINANTSNAME_PH = "#ComplainantsName#";
	public static final String RESPONDENTNAME_PH = "#RespondentName#";
	public static final String RESPONDENTEMPNO_PH = "#RespondentEmpNo#";
	public static final String RESPONDENTSNAME_PH = "#RespondentsName#";
	public static final String ICMAILID_PH = "#ICMailId#";
	public static final String COMMENT_PH = "#Comment#";
	public static final String SLAEXTENSIONDAYS_PH = "#SLAExtensionDays#";
	public static final String SLACURRENTDAYS_PH = "#SLACurrentDays#";
	public static final String SLAREVISED_PH = "#RevisedSLA#";
	public static final String QUERY_PH = "#Query#";
	public static final String RESPONSE_PH = "#Response#";
	public static final String TABLE_PH = "#Table#";
	public static final String ACTION_PH = "#Action#";
	public static final String ACTOR_PH = "#Actor#";
	
	//Keywords
	public static final String AGAINST_KW = "against";
	
	//case details
	public static final String COMPLAINT_CATEGORY="complaintCategory";
	public static final String CHOOSE="Choose ";
	public static final String RESPONDENT="Respondent";
	public static final String COMPLAINANT="Complainant";
	public static final String COMPLAINANTS="Complainants";
	public static final String WITNESS="Witness";
	public static final String ISSTAKEHOLDER="isStakeHolder";
	public static final String CO_COMPLAINANT="Co-complainant";
	public static final String STAKEHOLDER="Stakeholder";
	public static final String CASE_INITIATOR="Case-initiator";
	public static final String DESCRIPTION="Description";
	public static final String ACTOR="actor";
	public static final String ROLE="Role";
	public static final String COMPANY="Company";
	public static final String COUNTRY="Country";
	public static final String LOCATION="Location";
	public static final String MODULES="Modules";
	public static final String STATUS="Status";
	public static final String OUTPUT="Output";
	public static final String INTERIM_RELIEF="Interim Relief";
	public static final String ASSIGN_CASE="Assign Case";
	public static final String DISMISS_CASE="Dismiss Case";
	public static final String CLOSE_CASE="Close Case";
	public static final String REFER_BACK_CASE="Refer Back To ";
	public static final String SEND_TO_ERH="Send To ER Head";
	public static final String REASON_FOR_CONCILIATION="Reason for conciliation";
	public static final String RECIPIENT_TYPE="recipientType";
	

	public static final String VIEW_ALL = "View All";
	public static final String DOCUMENTS="Documents";
	public static final String DOWNLOADALL="Download All";
	public static final String CLOSURE_DOCUMENTS="Closure Documents";
	public static final String ALL="ALL";
	public static final String ACTION = "action";
	public static final String BUTTON = "button";
	public static final String IMAGE = "image";
	
	
	public static final String CARDVIEW = "cardview";
	public static final String CARDVIEW_TYPE22 = "CardViewType22";
	public static final String GENMODEL = "genmodel";
	public static final String LABELVIEW = "labelview";
	public static final String LABELVIEW_TYPE1 = "LabelViewType1";
	
	public static final String GRB_COMMENT="GRB Comments";
	public static final String ERH_COMMENT="ER Head Comments";
	public static final String INVESTIGATION_TYPE="Choose Investigation Type";
	public static final String INVESTIGATION_TYPE_NAME="investigationType";
	public static final String PROCEED_FI="Proceed with IC Investigation";
	public static final String CONCILIATION="Conciliation";
	public static final String FORMAL="Formal";
	public static final String ISSUE_SUMMONS="Issue Summons";
	
	
	

	//Action
	public static final String ADD_EVIDENCE="Add Evidence";
	public static final String SERVICEURL = "serviceurl";
	public static final String CANCEL="Cancel";
	public static final String CANCELMODELPOPUP="cancelmodelpopup";
	public static final String GENERICMODELPOPUP = "genericmodelpopup";
	public static final String GENMODELPOPUP = "genmodelpopup";
	public static final String SUBMIT="Submit";
	public static final String APPROVE="Approve";
	public static final String REJECT="Reject";
	public static final String APPROVED="Approved";
	public static final String REJECTED="Rejected";
	public static final String POPOVERFORM="popoverform";
	public static final String SUCCESSHIDEFORM="successhideform";
	public static final String SUCCESSPROCEED="successproceed";
	public static final String NO_DATA="nodata";
	public static final String BACK_TO_CASE_SUMMARY = "Back to case summary";
	
	public static final String YES_NO = "?|Yes|No";
	
	public static final String SEND_FINDING = "<h3 class=\"DSA_wb_h3Header\">Send Findings to #RecipientType#</h3>\r\n" + 
			"<p class=\"padB32 padT32\">Following content will be mailed to the recipient for confirmation.</p>\r\n" + 
			"<p class=\"padB8\">Dear #Recipient#,</p>\r\n" + 
			"<p class=\"padB8\">This is with reference to the complaint that has been reported #Keyword# you and the subsequent investigation taken up by the Internal Committee (“IC”) - #ICLocation#, due to the nature of complaint. The fact finding process has been completed with the respective/ involved parties.</p>\r\n" + 
			"<p class=\"padB32\">Please note that below attached are the key findings and as per the IC process, we are sharing these key findings with you so that you have an opportunity to go through the points and revert with your response to the below findings.</p>\r\n" + 
			TABLE_PH + 
			"<p class=\"padB8 padT8\">Kindly confirm your response by responding over email <> to this ID only, within two working days.</p>\r\n" + 
			"<p>Post the acknowledgement the IC will take the case for closure.</p>";
	
	public static final String SEND_FINDING_TABLE = "<table class=\"DSA_wb_custom-table\"><thead><tr><th>S.No.</th><th>Allegation</th><th>Findings</th><th>Outcome</th></tr></thead>\r\n" + 
			"<tbody>#Rows#</tbody></table>";
	
	public static final String SEND_FINDING_ROW = "<tr><td>#SNo#</td><td>#Allegation#</td><td>#Finding#</td><td>#Outcome#</td></tr>";
	
	public static final String CONSOLIDATED_FINDING_CAPTION = "";
			
	public static final String CONSOLIDATED_FINDING_BLOCK = "<p class=\"padB16 DSA_wb_mainBodyTxt2\"><span class=\"web-GreyLight\">#RecipientType#:</span><span class=\"pad8 marR32 web-GreyDarkest\">#Recipient#</span><span class=\"marL32 padL32 web-GreyLight\">Status:</span><span class=\"padL8\">#Status#</span></p>\r\n" + 
						SEND_FINDING_TABLE + "<hr _ngcontent-fdy-c61=\"\" class=\"marB24 DSA_horSeperator ng-star-inserted\">\r\n";
	
	public static final String CONSOLIDATED_FINDING = "<div class=\"padB16 table-titleArea\"><h3 class=\"DSA_wb_h2Header web-GreyDarkest\">Allegations and Findings</h3></div>\r\n";
	
	public static final String REPORT_EMPLOYEE_TABLE = "<tr><td>#SNo#</td><td>#EmpName#</td>\r\n" + 
			"<td>#EmpNo#</td>\r\n" + 
			"<td>#EmpUnit#</td>\r\n" + 
			"<td>#EmpDOJ#</td>\r\n" + 
			"<td>#EmpDesignation#</td>\r\n" + 
			"<td>#EmpLocation#</td></tr>";
	
	public static final String REPORT_WITNESS_TABLE = "<tr><td>#SNo#</td><td>#EmpName#</td><td>#EmpNo#</td></tr>";
	
	public static final String REPORT_FINDINGS_TABLE = "<table><caption>#Actor# : #EmpMailId#</caption><thead><tr><th>S.No.</th><th>Allegation</th><th>Finding</th><th>Outcome</th></tr></thead>#Rows#</table>";
			
	public static final String REPORT_FINDINGS_ROW = 	"<tbody><tr>\r\n" + 
	"<td>#SNo#</td>\r\n" + 
	"<td>#Allegation#</td>\r\n" +
	"<td>#Finding#</td>\r\n" + 
	"<td>#Outcome#</td></tr>" +
	"</tbody>";
	
	public static final String REPORT_ACTIONS_TABLE = "<tr>\r\n" + 
	"<td>#SNo#</td>\r\n" + 
	"<td>#Actor#</td>\r\n" + 
	"<td>#EmpMailId#</td>\r\n" + 
	"<td><ul>\r\n" + 
	"#Actions#\r\n" + 
	"</ul></td><td>#Remarks#</td></tr>";
	
	public static final String REPORT_ACTION_TAG = "<li>#Action#</li>";
	
	public static final String REPORT_EVENT_TABLE = "<tr><td>#SNo#</td><td>#EventDate#</td><td>#Event#</td><td>#Remarks#</td><td>#Documents#</td></tr>";
	
	public static final String REPORT_TEMPLATE = "<!DOCTYPE html>\r\n" + 
			"<html>\r\n" + 
			"<head>\r\n" + 
			"<style>\r\n" + 
			"table, th, td {\r\n" + 
			"  border: 1px solid black;\r\n" + 
			"  border-collapse: collapse;\r\n" + 
			"}\r\n" + 
			"th, td {\r\n" + 
			"  padding: 5px;\r\n" + 
			"}\r\n" + 
			"caption {\r\n" + 
			"padding: 5px;\r\n" + 
			"text-align: left;\r\n" + 
			"font-weight: bold;\r\n" +
			"}" +
			".paraNote {\r\n" + 
			"color:red;\r\n" + 
			"font-size:12px;\r\n" + 
			"margin-top:10px;\r\n" + 
			"}" +
			"</style>\r\n" + 
			"</head>\r\n" + 
			"<body style=\"padding:10px\">\r\n" + 
			"<h2 style=\"text-align: center;\">REPORT OF THE INTERNAL COMPLAINTS COMMITTEE</h2>\r\n" + 
			"<h3 style=\"text-align: center;\">#Location#</h3>\r\n" + 
			"<p><b>Case No : #CaseId#</b></p>\r\n" + 
			"<p><b>Incident Date : #IncidentDate#</b></p>#ClosureDate#\r\n" + 
			"<p><b><u>1. Details of the complainant(s):</u></b></p>\r\n" + 
			"<table><thead><tr><th>S.No.</th><th>Employee Name</th><th>Employee Number</th><th>Unit</th><th>Date of Joining</th><th>Process/Designation/Job Level</th><th>Location</th></tr></thead><tbody>" + 
			"#ComplainantTable#</tbody></table>\r\n" + 
			"<p><b><u>2. Details of the respondent(s):</u></b></p>\r\n" + 
			"<table><thead><tr><th>S.No.</th><th>Employee Name</th><th>Employee Number</th><th>Unit</th><th>Date of Joining</th><th>Process/Designation/Job Level</th><th>Location</th></tr></thead>\r\n" + 
			"<tbody>" + 
			"#RespondentTable#\r\n" + 
			"</tbody></table>\r\n" + 
			"<p><b><u>3.Complaint Details:</u></b></p>\r\n" + 
			"<table><tbody><tr><td><b>Case Summary</b></td><td>#ComplaintSummary#</td></tr>\r\n" + 
			"<tr><td><b>Incident Location</b></td><td>#IncidentLocation#</td></tr>\r\n" +
			"<tr><td><b>Category Of Concern</b></td><td>#Category#</td></tr>\r\n" +
			"<tr><td><b>Case Classification</b></td><td>#Classification#</td></tr>\r\n" +
			"<tr><td><b>Evidence(s)</b></td><td>#Evidence#</td></tr></tbody></table>" +
			"<p><b><u>4. Details of the witness(s):</u></b></p>\r\n" + 
			"<table><thead><tr><th>S.No.</th><th>Employee Name</th><th>Employee Number</th></tr></thead>\r\n" + 
			"<tbody>\r\n" + 
			"#WitnessTable#\r\n" + 
			"</tbody>\r\n" + 
			"</table>\r\n" + 
			"<p><b><u>5. IC's Findings:</u></b></p>\r\n" + 
			"#FindingsTable#\r\n" + 
			"<p><b><u>6. Recommendations of IC:</u></b></p>\r\n" + 
			"<table>\r\n" + 
			"<thead><tr><th>S.No.</th><th>Actor</th><th>Mail ID</th><th>Recommended Actions</th><th>Remarks</th></tr></thead><tbody>\r\n" + 
			"#ActionsTable#\r\n" + 
			"</tbody></table>\r\n" + 
			"<p><b><u>7.Other Report Details:</u></b></p>\r\n" + 
			"<table><tbody><tr><td><b>Summary of the investigation</b></td><td>#InvestigationSummary#</td></tr>\r\n" + 
			"<tr><td><b>Other recommendations</b></td><td>#OtherRecommendations#</td></tr>\r\n" +
			"<tr><td><b>Investigation Documents</b></td><td>#InvestigationDocs#</td></tr></tbody></table>" +
			"<p><b><u>Timeline & Events of the Investigation:</u></b></p>\r\n" + 
			"<table>\r\n" + 
			"<thead><tr><th>S.No.</th><th>Date</th><th>Event</th><th>Remarks (if any)</th><th>Documents</th></tr></thead>\r\n" + 
			"<tbody>\r\n" + 
			"#EventTable#\r\n" + 
			"</tbody>\r\n" + 
			"</table>\r\n" + 
			"<p class=\"paraNote\">Note: Kindly check attachments for evidences/documents.</p>" +
			"</body>\r\n" + 
			"</html>";
	
	public static final String BR_TAG="<br></br>";
	
}
