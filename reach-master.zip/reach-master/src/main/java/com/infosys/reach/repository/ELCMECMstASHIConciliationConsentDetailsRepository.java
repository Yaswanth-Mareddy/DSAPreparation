package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstASHIConciliationConsentDetails;

public interface ELCMECMstASHIConciliationConsentDetailsRepository extends JpaRepository<ELCMECMstASHIConciliationConsentDetails, Integer> {

	List<ELCMECMstASHIConciliationConsentDetails> findByCaseId(int caseid);
	
	Optional<ELCMECMstASHIConciliationConsentDetails> findBySerialNo(int serialNo);
	
	Optional<ELCMECMstASHIConciliationConsentDetails> findByCaseIdAndActorAndMailIdAndFlgAcceptAndFlgReject(int caseid, String actor, String mailId, int flgAccept, int flgReject);
	
	Optional<ELCMECMstASHIConciliationConsentDetails> findByCaseIdAndMailId(int caseid, String mailId);
}
