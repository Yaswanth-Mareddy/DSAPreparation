package com.infosys.reach.service;

import java.util.List;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.EmployeeCardView;
import com.infosys.reach.model.ashimobile.EvidenceCardView;
import com.infosys.reach.model.ashimobile.MobileComplaintInboxView;
import com.infosys.reach.model.ashimobile.MobileInboxView;

public interface ASHIMobileService {

	public MobileComplaintInboxView getComplaintDetails(int caseId) throws CustomException;

	public EmployeeCardView getCaseEmployeeDetails(int caseId) throws CustomException;

	public EvidenceCardView getEvidences(int caseId) throws CustomException;

	public CaseFormGenModel initiateCaseForm() throws CustomException;

	public MobileInboxView getCasesInitiatedByMe(String id) throws CustomException;
	
	public MobileInboxView getCasesInitiatedByCoComplainant(String id) throws CustomException;
	
	public List<TabView> getInboxTabs()  throws CustomException;
	
	public MobileInboxView getCasesInitiatedByGRB(String id) throws CustomException;
	
	public MobileInboxView getAllCases(String id) throws CustomException;

}
