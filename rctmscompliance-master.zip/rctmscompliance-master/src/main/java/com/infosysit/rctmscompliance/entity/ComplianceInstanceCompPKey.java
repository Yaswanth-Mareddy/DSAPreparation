package com.infosysit.rctmscompliance.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@Embeddable
public class ComplianceInstanceCompPKey implements Serializable{
	
	private static final long serialVersionUID = 195154807111992L;
	
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
}
