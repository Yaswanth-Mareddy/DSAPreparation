package com.infosys.reach.model.ashiadmin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.infosys.reach.entity.ELCMECMstReachWorkFlow;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter
public class UpdateCaseStatusReturn {

	private boolean isSuccess;
	private String message;
	private String assigneeLocation;
	private List<String> mailEventCode;
	
	public UpdateCaseStatusReturn(boolean isSuccess, ELCMECMstReachWorkFlow workflow, String assigneeLocation) {
		super();
		this.isSuccess = isSuccess;
		this.message = workflow.getMessage();
		this.assigneeLocation = StringUtils.isBlank(assigneeLocation)  ? assigneeLocation : "";
		this.mailEventCode = StringUtils.isBlank(workflow.getMailEventCode()) ? new ArrayList<>() : Arrays.asList(workflow.getMailEventCode().split(","));
	}
	
	public UpdateCaseStatusReturn(boolean isSuccess) {
		super();
		this.isSuccess = isSuccess;
		this.message = "";
		this.assigneeLocation = "";
		this.mailEventCode = new ArrayList<>();
	}
	
	
	
	
}
