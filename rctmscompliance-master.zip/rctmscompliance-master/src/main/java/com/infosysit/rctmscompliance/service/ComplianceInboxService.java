package com.infosysit.rctmscompliance.service;

import java.util.List;

import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.ComplianceInbox;

public interface ComplianceInboxService {

	public List<ComplianceInbox> viewComplianceInbox(String txtEmpNo,String txtStatus,String txtpendingstatus) throws CustomException;
}
