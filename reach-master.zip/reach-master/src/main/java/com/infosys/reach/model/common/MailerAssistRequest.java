package com.infosys.reach.model.common;


import com.infosys.reach.model.generic.NonGrpPlaceHolder;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MailerAssistRequest {
	private MailInfo mailInfo;
	private PlaceHolder[] placeHolders;
	private NonGrpPlaceHolder nonGrpPlaceHolder;
	
	public MailerAssistRequest(MailInfo mailInfo, PlaceHolder[] placeHolders) {
		super();
		this.mailInfo = mailInfo;
		this.placeHolders = placeHolders;
		this.nonGrpPlaceHolder = new NonGrpPlaceHolder();
	}
	
	

}
