package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.GenMstMailConfigHeader;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface GenMstMailConfigHeaderRepository extends JpaRepository<GenMstMailConfigHeader, String> {
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETMAILINFO)
	MailContent findSubjectAndBodyByApplicationCode(@Param("eventCode") String eventCode);

}
