package com.infosysit.itsm.sqldatasource.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="edstrndeppassportdetails")
public class EDSTrnDepPassportDetails {
	@Id
	@Column(name="txtEmpNo")
	private String txtEmpNo;
	
	@Column(name="intSerialNo")
	private int intSerialNo;
	
	@Column(name="intRelSerialNo")
	private int intRelSerialNo;
	
	@Column(name="txtNameInPassPort")
	private String txtNameInPassPort;
	
	@Column(name="txtPassPortNo")
	private String txtPassPortNo;
	
	@Column(name="txtIssuingOffice")
	private String txtIssuingOffice;
	
	@Column(name="dtIssuedDate")
	private Date dtIssuedDate;
	
	@Column(name="dtExpiryDate")
	private Date dtExpiryDate;
	
	@Column(name="dtLastModified")
	private Date dtLastModified;
	
	
	@Column(name="txtCountryCode")
	private String txtCountryCode;
	
	@Column(name="txtECRequired")
	private String txtECRequired;
	
	@Column(name="txtPptAddLine1")
	private String txtPptAddLine1;
	
	@Column(name="txtPptAddLine2")
	private String txtPptAddLine2;
	
	@Column(name="txtPptAddArea")
	private String txtPptAddArea;
	
	@Column(name="txtPptAddCity")
	private String txtPptAddCity;
	
	@Column(name="txtPptAddState")
	private String txtPptAddState;
	
	@Column(name="txtPptAddCountry")
	private String txtPptAddCountry;
	
	@Column(name="txtPptAddPinCode")
	private String txtPptAddPinCode;
	
	@Column(name="txtPptAddPhone")
	private String txtPptAddPhone;
	
	@Column(name="txtDownloadOrUpdate")
	private char txtDownloadOrUpdate;
	
	@Column(name="txtModifiedBy")
	private String txtModifiedBy;
	
	@Column(name="txtLastNameInPassPort")
	private String txtLastNameInPassPort;
	
	@Column(name="txtMiddleNameInPassPort")
	private String txtMiddleNameInPassPort;
	
	
	
}
