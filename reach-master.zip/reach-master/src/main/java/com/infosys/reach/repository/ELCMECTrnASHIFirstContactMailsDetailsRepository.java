package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnASHIFirstContactMailsDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnASHIFirstContactMailsDetailsRepository extends JpaRepository<ELCMECTrnASHIFirstContactMailsDetails, Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnASHIFirstContactMailsDetails> S save(S entity);
	
	@TrackExecutionTime
	List<ELCMECTrnASHIFirstContactMailsDetails> findByCaseIdOrderBySerialNoDesc(int caseid);

}
