package com.infosysit.itsm.mysqldatasource.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


	@Setter
	@Entity
	@Table(name="icm_tickets")
	public class ICMTickets {
		@Id
		@Column(name="number")
		private String number;
		
		@Column(name="shortdescription")
		private String shortdescription;
		
		@Column(name="assignmentgroup")
		private String assignmentGroup;
		
		@Column(name="assignedto")
		private String assignedTo;
		
		@Column(name="caller")
		private String caller;
		
		@Column(name="category")
		private String category;
		
		@Column(name="projectId")
		private int projectId;
		
		@Column(name="createdby")
		private String createdBy;
		
		@Column(name="closecode")
		private String closecode;
		
		@Column(name="closedby")
		private String closedBy;
		
		@Column(name="configurationItem")
		private String configurationItem;
		
		@Column(name="closenotes")
		private String closenotes;
		
		@Column(name="closedDate")
		private Date closedDate;
		
		@Column(name="comments")
		private String comments;
		
		@Column(name="createdDate")
		private Date createdDate;
		
		@Column(name="duedate")
		private Date dueDate;
		
		@Column(name="description")
		private String description;
		
		@Column(name="duration")
		private int duration;
		
		@Column(name="impact")
		private String impact;
		
		@Column(name="incidentstate")
		private String incidentState;
		
		@Column(name="madesla")
		private int madesla;
		
		@Column(name="openedDate")
		private Date openedDate;
		
		@Column(name="openedby")
		private String openedBy;
		
		@Column(name="priority")
		private String priority;
		
		@Column(name="resolved")
		private int resolved;
		
		@Column(name="resolvedby")
		private String resolvedBy;
		
		@Column(name="resourcepath")
		private String resourcePath;
		
		@Column(name="resolvedDate")
		private Date resolvedDate;
		
		@Column(name="reopenedDate")
		private Date reopenedDate;
		
		@Column(name="state")
		private String state;
		
		@Column(name="severity")
		private String severity;
		
		@Column(name="subcategory")
		private String subcategory;
		
		@Column(name="sysId")
		private String sysId;
		
		@Column(name="sladueDate")
		private Date slaDueDate;
		
		@Column(name="timeworked")
		private Date timeWorked;
		
		@Column(name="updatedby")
		private String updatedBy;
		
		@Column(name="updatedDate")
		private Date updatedDate;
		
		@Column(name="incidentsubstate")
		private String incidentSubstate;
		
		@Column(name="firstServiceCommunicationDate")
		private String firstServiceCommunicationDate;
		
		@Column(name="assignedDate")
		private String assignedDate;
		
		@Column(name="resolutionCategory")
		private String resolutionCategory;
		
		@Column(name="resolutionSteps")
		private String resolutionSteps;
		
		@Column(name="additionalComments")
		private String additionalComments;
		
		@Column(name="resolveTime")
		private String resolveTime;
		
		@Column(name="geographicalArea")
		private String geographicalArea;
		
		@Column(name="inputJson")
		private String inputJson;
		
		@Column(name="isActive")
		private int isActive;
		
		@Column(name="isProcessed")
		private int isProcessed;
		
		@Column(name="resolvedOutSideICAP")
		private int resolvedOutSideICAP;
		
		@Column(name="escalationCount")
		private int escalationCount;
		
		@Column(name="responseSLA")
		private String responseSLA;
		
		@Column(name="resolutionSLA")
		private String resolutionSLA;
		
		@Column(name="taskType")
		private String taskType;
		
		@Column(name="track")
		private String track;
		
		@Column(name="pendingState")
		private String pendingState;
		
		@Column(name="ticketAge")
		private int ticketAge;
		
		@Column(name="modifiedAge")
		private int modifiedAge;
		
		@Column(name="job")
		private String job;
		
		@Column(name="application")
		private String application;
		
		@Column(name="lastUpdated")
		private Date lastUpdated;
		
		@Column(name="application_id")
		private int applicationId;
		
		@Column(name="category_id")
		private int categoryId;
		
		@Column(name="last_updated_by")
		private int lastUpdatedBy;
		
		@Column(name="icap_status")
		private String icapStatus;
		
		@Column(name="id")
		private int id;
		
		@Column(name="incidentpriority")
		private String incidentPriority;
		
		@Column(name="shortdescriptionClusterId")
		private String shortdescriptionClusterId;
		
		@Column(name="shortdescriptionClusterName")
		private String shortdescriptionClusterName;
		
		@Column(name="shortdescriptionClusterType")
		private String shortdescriptionClusterType;
		
		@Column(name="shortdescriptionClusterManual")
		private String shortdescriptionClusterManual;
		
		@Column(name="resolutionStepsClusterId")
		private String resolutionStepsClusterId;
		
		@Column(name="resolutionStepsClusterName")
		private String resolutionStepsClusterName;
		
		@Column(name="resolutionStepsClusterType")
		private String resolutionStepsClusterType;
		
		@Column(name="resolutionStepsClusterManual")
		private String resolutionStepsClusterManual;
		
		@Column(name="type")
		private String type;
		
		@Column(name="source")
		private String source;
		
		@Column(name="responsesladate")
		private Date responseSlaDate;
		
		@Column(name="resolutionsladate")
		private Date resolutionSlaDate;
		
		@Column(name="responseslamet")
		private int responseSlaMet;
		
		@Column(name="resolutionslamet")
		private int resolutionSlaMet;
		
		@Column(name="location")
		private String location;
		
		@Column(name="sop")
		private String sop;
		
		@Column(name="problem_type")
		private String problemType;
}
