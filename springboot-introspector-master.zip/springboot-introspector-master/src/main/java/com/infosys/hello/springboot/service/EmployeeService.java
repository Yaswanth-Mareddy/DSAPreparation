package com.infosys.hello.springboot.service;

import java.util.List;
import java.util.Map;

import com.infosys.hello.springboot.model.Employee;

public interface EmployeeService {
	Employee getEmployee(int id);

	Map<Integer, Employee> getEmployees();

	void saveEmployee(Employee employee);

	void deleteEmployee(int id);
}
