package com.infosys.reach.service;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.WebServiceOutput;

public interface WebService {

	public WebServiceOutput consumeRestService(String strURL, String apiType, boolean isAuthorized, String authorizationString, String input) throws CustomException;
	public boolean filevalidationService(String url, String tempfileFullPath) throws CustomException;
}
