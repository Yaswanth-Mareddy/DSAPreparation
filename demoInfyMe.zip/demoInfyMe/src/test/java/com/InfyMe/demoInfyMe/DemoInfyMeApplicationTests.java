package com.InfyMe.demoInfyMe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoInfyMeApplicationTests {

	@Test
	void contextLoads() {
	}

}
