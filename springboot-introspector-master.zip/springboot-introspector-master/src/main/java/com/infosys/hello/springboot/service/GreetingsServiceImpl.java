package com.infosys.hello.springboot.service;

import com.infosys.hello.springboot.config.IntrospectorConfig;
import com.infosys.hello.springboot.model.Greeting;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicLong;

@Service
@Slf4j
public class GreetingsServiceImpl implements GreetingsService{

    private final IntrospectorConfig config;

    private static final String template = "Greetings, %s!";
    private final AtomicLong counter = new AtomicLong();

    @Autowired
    public GreetingsServiceImpl(IntrospectorConfig config){
        this.config = config;
    }

    /**
     * Returns the Greetings for a given name
     * @param content Greetings content
     * @return Greeting Bean for the content
     */
    public Greeting getGreetings(String content){

        //log.debug("method = getGreetings, type = service, content = {}", content);
        String contentValue;
        if(content != null )
            contentValue = String.format(template, content);
        else
            contentValue
                    = String.format(
                        template,
                        config.getDefaultGreetings().getDefaultContent());
        return new Greeting(counter.incrementAndGet(),contentValue);
    }

}
