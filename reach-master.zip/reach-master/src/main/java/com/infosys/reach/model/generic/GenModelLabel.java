package com.infosys.reach.model.generic;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GenModelLabel {

	private String apiType;
	private String name;
	private String value;
	private int type;
	private String input;
	
	public GenModelLabel(String name) {
		super();
		this.apiType = "";
		this.name = name;
		this.value = "";
		this.type = 14;
		this.input = "";
	}
	
	
}
