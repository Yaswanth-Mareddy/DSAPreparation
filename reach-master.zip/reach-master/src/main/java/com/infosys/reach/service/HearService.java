package com.infosys.reach.service;


import java.util.List;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.hear.CaseDetailsValidationResponse;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.model.hear.HearAccess;
import com.infosys.reach.model.hear.HearCaseDetails;
import com.infosys.reach.model.hear.HearCaseResponse;
import com.infosys.reach.model.hear.Policy;

public interface HearService {
	
	
	HearCaseResponse initiateHearCase(String reporteeEmpNo, String reporteeMailId, String reporteeEmpName, HearCaseDetails caseDetails,List<String> taggedEmpMailIdList) throws CustomException;
	
	CaseDetailsValidationResponse validateCaseDetails(String reporteeEmpNo, String reporteeMailID, HearCaseDetails caseDetails);
	
	List<Categories> getConcernModuleDetails(int moduleId,String company,String countryCode);
	
	List<Countries> getCountriesByModuleId(int moduleId);
	
	List<Cities> getCitiesByCountryCode(String countryCode);
	
	HearAccess checkHearAccess(String empNo);
	
	
	Policy getHearPolicy();
	
}
