package com.infosys.hello.springboot.telemetry;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.sunbird.common.models.util.JsonKey;
import org.sunbird.common.request.ExecutionContext;
import org.sunbird.telemetry.util.TelemetryUtil;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.BaseEncoding;
import com.infosys.hello.springboot.config.TelemetryConfig;


public abstract class Event {

	
	
	@Autowired
	TelemetryConfig telemetryConfig;
	
	@Value("${telemetry_env}")
	public String env;
	@Value("${telemetry_actor_type}")
	public String actorType;
	@Value("${telemetry_actor_id}")
	public String actorId;
	@Value("${telemetry_log_type}")
	public String logType;
	
	public static Map<String, Map<String, Object>> requestInfo = new HashMap<>();
	private static final String version = "v1";
	protected static String messageId;

	
	public void initializeRequestInfo( ) {

       

		ExecutionContext context = ExecutionContext.getCurrent();

		messageId = context.getRequestId();

		if (StringUtils.isBlank(messageId)) {
			UUID uuid = UUID.randomUUID();
			messageId = uuid.toString();

		}

		context.setRequestId(messageId);

		Map<String, Object> reqContext = new HashMap<>();

		String channel = telemetryConfig.getContext().getChannel();

		reqContext.put(JsonKey.CHANNEL, channel);

		reqContext.put(JsonKey.ENV, "Collaboration-API");// change this based on applications
		reqContext.put(JsonKey.ACTOR_ID, actorId);
		reqContext.put(JsonKey.ACTOR_TYPE, actorType);

		context.setRequestContext(reqContext);

		context.getGlobalContext().put(JsonKey.PDATA_ID, telemetryConfig.getContext().getpData().getId());

		context.getGlobalContext().put(JsonKey.PDATA_PID, telemetryConfig.getContext().getpData().getPid());

		context.getGlobalContext().put(JsonKey.PDATA_VERSION, telemetryConfig.getContext().getpData().getVersion());

		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.CONTEXT, TelemetryUtil.getTelemetryContext());


		if (requestInfo == null) {
			requestInfo = new HashMap<>();
		}

		if (StringUtils.isBlank(messageId)) {
			messageId = JsonKey.DEFAULT_CONSUMER_ID;
		}
		requestInfo.put(messageId, map);

	}
	
	
	
}
