package com.infosys.reach.controller;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.handler.MappedInterceptor;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.CaseDetailsAuthorization;
import com.infosys.reach.util.Message;




@Component
@EnableAutoConfiguration
public class Session {
	
	private static String tokenMAILID;
	private static String tokenEMPNO;
	private static String tokenEMPNAME;
	private static String jwtTOKEN;
	private static CaseDetailsAuthorization caseDetails;
	private static boolean isAuthorized;
	private static String authorizedMessage;
	

	@Component
    public static class AccessToken {
		private AccessToken() {
			
		}
        public static boolean judgeToken(HttpServletRequest request) throws CustomException{
            String token = request.getHeader("Authorization");
            if(token!=null) {
            	
    			try {
    				jwtTOKEN=token;
    				String jwt = token.substring(7, token.length());
                	String[] splitString = jwt.split("\\.");
        			String base64EncodedBody = splitString[1];
        			Base64 base64Url = new Base64(true);
        			String body = new String(base64Url.decode(base64EncodedBody));
        			JSONObject json = new JSONObject(body);
        			tokenEMPNO=json.get("EmpNo").toString();
        			tokenEMPNAME=json.get("name").toString();
        			tokenMAILID=json.getString("upn");
        			long exp=json.getLong("exp");
        			if((System.currentTimeMillis()-(exp*1000))>0)
        					return false;
    			}
    			catch(Exception e) {
    				throw new CustomException(Message.INVALIDTOKEN);
    			}

            	 return true;
            }else {
            	throw new CustomException(Message.UNAUTHORIZED);
            }           
        }
    }
	
	
	  @Bean	  
	  @Autowired 
	  public MappedInterceptor getMappedInterceptor(TokenInterceptor tokenInterceptor) { 
		  return new MappedInterceptor(new String[] { "/v2/api/**" }, new String[] { "/v2/api/**/mailbasedaction" }, tokenInterceptor);
	  }
	 
	
	@Component
    public static class TokenInterceptor implements HandlerInterceptor {

        @Override
        public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws CustomException{
            boolean result=AccessToken.judgeToken(request);
        	if(result)
        		return true;
        	else
            	throw new CustomException(Message.JWTEXPIRED);
        }
    }


	public static String getTokenMAILID() {
		return tokenMAILID;
	}


	public static String getTokenEMPNO() {
		return tokenEMPNO;
	}


	public static String getTokenEMPNAME() {
		return tokenEMPNAME;
	}


	public static String getJwtTOKEN() {
		return jwtTOKEN;
	}
	
	public static void setCaseDetails(CaseDetailsAuthorization caseDetails) {
		Session.caseDetails = caseDetails;
	}
	
	public static CaseDetailsAuthorization getCaseDetails() {
		return caseDetails;
	}
	
	public static void setIsAuthorized(boolean isAuthorized) {
		Session.isAuthorized = isAuthorized;
	}
	
	public static boolean isAuthorized() {
		return isAuthorized;
	}
	
	public static void setAuthorizedMessage(String authorizedMessage) {
		Session.authorizedMessage = authorizedMessage;
	}


	public static String getAuthorizedMessage() {
		return authorizedMessage;
	}






	
	

}
