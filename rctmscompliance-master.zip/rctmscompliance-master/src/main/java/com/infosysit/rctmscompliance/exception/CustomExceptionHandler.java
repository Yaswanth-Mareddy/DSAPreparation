package com.infosysit.rctmscompliance.exception;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.infosysit.rctmscompliance.telemetry.ErrorEvent;
import com.infosysit.rctmscompliance.util.Message;

@ControllerAdvice

//This is a CustomException Handler where all any exception is handled here
//Also sending Error Event data to telemetry service in case of any exception.
//Custom Exception here uses class ErrorDetails class .

public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

	@Autowired
	ErrorEvent errorTelemetry;

	
	@Override
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		ErrorDetails errorDetails = new ErrorDetails("Validation Failed", ex.getMessage());
		errorTelemetry.setTelemetryData( "Validation Failed", HttpStatus.BAD_REQUEST.toString(),Object.class.getClass().getEnclosingMethod().getName());

		return new ResponseEntity<>(errorDetails, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorDetails> handleAllExceptions(Exception ex, WebRequest request) {
		final HttpStatus httpStatus;
		if(ex.getMessage().equalsIgnoreCase(Message.UNAUTHORIZED) || ex.getMessage().equalsIgnoreCase(Message.JWTEXPIRED))
			httpStatus= HttpStatus.UNAUTHORIZED;
		
		else if(ex.getMessage().equalsIgnoreCase(Message.INVALIDTOKEN))
			httpStatus= HttpStatus.FORBIDDEN;
		
		else
			httpStatus= HttpStatus.INTERNAL_SERVER_ERROR;

		ErrorDetails errorDetails = new ErrorDetails(ex.getMessage(), request.getDescription(false));
		
		errorTelemetry.setTelemetryData( ex.getMessage(), httpStatus.toString(),ex.getStackTrace()[0].toString());
		return new ResponseEntity<>(errorDetails, httpStatus);
	}

}
