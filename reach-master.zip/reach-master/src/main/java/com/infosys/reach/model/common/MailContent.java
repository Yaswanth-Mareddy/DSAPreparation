package com.infosys.reach.model.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MailContent {

	private String body;
	private String subject;
	private String recipientMailId;
	private String ccMailId;
	
	public MailContent(String body, String subject) {
		super();
		this.body = body;
		this.subject = subject;
	}
	
	public MailContent(String body, String subject, String recipientMailId) {
		super();
		this.body = body;
		this.subject = subject;
		this.recipientMailId = recipientMailId;
		this.ccMailId = "";
	}
	
	
}
