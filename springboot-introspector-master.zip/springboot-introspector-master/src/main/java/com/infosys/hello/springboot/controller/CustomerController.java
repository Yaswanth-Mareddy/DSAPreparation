package com.infosys.hello.springboot.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.BaseEncoding;
import com.infosys.hello.springboot.entity.Customer;
import com.infosys.hello.springboot.service.CustomerService;

import io.swagger.v3.oas.annotations.*;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.responses.*;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.media.*;
import io.swagger.v3.oas.annotations.Operation;

@RequestMapping("/springboot/v1")
@RestController
public class CustomerController {

	@Autowired
	CustomerService customerService;

	/**
	 * This method is used to create a customer
	 * 
	 * @param customer - RequestBody - customer data
	 * @return ResponseEntity
	 */
	@Operation(summary = "Add a customer.", tags = "customer")
	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public ResponseEntity<HttpStatus> create(@Valid @NotEmpty @RequestBody Customer customer) {
		customerService.saveCustomer(customer);
		return ResponseEntity.ok(HttpStatus.OK);
	}

	/**
	 * This method is used to fetch all the customer data
	 * 
	 * @return - List<Customer>
	 */
	@Operation(summary = "Find all the customers.", tags = "customer")
	@GetMapping(value = "/customers", produces = MediaType.APPLICATION_JSON)
	public List<Customer> customers() {
		return customerService.getCustomers();
	}

	/**
	 * This method is used to fetch customer by name
	 * 
	 * @param name
	 * @return Customer details
	 */
	@Operation(summary = "Find customer by name. ", tags = "customer")
	@GetMapping(value = "/customer")
	@Produces(MediaType.APPLICATION_JSON)
	
	@ApiResponses(value = {
           	@ApiResponse(responseCode="200",description="Success",content = @Content),
           	@ApiResponse(responseCode="401",description="Unauthorized",content = @Content),
           	@ApiResponse(responseCode="403",description="Forbidden",content = @Content),
           	@ApiResponse(responseCode = "404", description = "Not Found",content = @Content),
           	@ApiResponse(responseCode = "500", description = "Failure", content = @Content)})
	public List<Customer> getCustomerByName(@Valid @NotEmpty @RequestParam("name") String name) {
		return customerService.getCustomerByName(name);
	}

	/**
	 * This method is used to return customer details group by location
	 * 
	 * @return
	 */
	@Operation(summary = "Get total number of customers. ", tags = "customer")
	@GetMapping(value = "/customer/count")
	public int getCustomerCount() {
		return customerService.getCustomerCount();
	}
	
	
	/**
	 * get User Principal Name 
	 * @param accessToken: User JWT Token
	 * @return user UPN value
	 */
	@SuppressWarnings({ "unchecked" })
	private String getUserUPN(String token) {
		
		String json = "";
		try {
			json = new String(BaseEncoding.base64().decode(token.split("\\.")[1]), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			StringWriter stackTrace = new StringWriter();
			e.printStackTrace(new PrintWriter(stackTrace));
			return null;
		}
		
		ObjectMapper objectMapper = new ObjectMapper();		
		Map<String, Object> jsonMap = null;
		
		try {
			jsonMap = objectMapper.readValue(json, Map.class);
		} catch (IOException e) {
			StringWriter stackTrace = new StringWriter();
			e.printStackTrace(new PrintWriter(stackTrace));
		}
			
		return jsonMap!=null ? (String) jsonMap.get("upn") : null;
	}

}
