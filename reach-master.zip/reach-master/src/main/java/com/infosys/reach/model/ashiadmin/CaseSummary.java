package com.infosys.reach.model.ashiadmin;


import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CaseSummary {
	private String respondentType;
	private String assignedTo;
	private String reportedOn;
	private String slaExpiry;
	private String raisedBy;
	private List<String> documents;
	private String description;
	
	public CaseSummary(String respondentType, String assignedTo, Date reportedOn, String raisedBy,
			 String description) {
		super();
		this.respondentType = respondentType.trim();
		this.assignedTo = assignedTo.trim();
		this.slaExpiry = "30 Days";
		this.reportedOn = new DateTime(reportedOn.getTime()).toString("dd-MMM-yyyy");
		this.raisedBy = raisedBy;
		this.description = description.trim();
	}
	
}
