package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECMstASHICocomplainantsDetails;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstASHICocomplainantsDetailsRepository extends JpaRepository<ELCMECMstASHICocomplainantsDetails, Integer> {

	@TrackExecutionTime
	@Override
	<S extends ELCMECMstASHICocomplainantsDetails> S save(S entity);
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECMstASHICocomplainantsDetails> List<S> saveAll(Iterable<S> entities);
	
	@TrackExecutionTime
	Optional<ELCMECMstASHICocomplainantsDetails> findByTranIdAndFlgActive(int tranId,int flgActive);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCOCOMPLAINANTSDETAILSBYCASEID)
	List<EmployeeDetails> findCocomplainanatsDetailsByCaseId(@Param("caseId") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCOCOMPLAINANTSBYCASEID)
	List<GenModelOption> findCocomplainanats(@Param("caseId") int caseId);

}
