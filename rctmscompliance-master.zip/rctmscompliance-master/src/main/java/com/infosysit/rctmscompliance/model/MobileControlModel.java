package com.infosysit.rctmscompliance.model;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class MobileControlModel {

	private String txtParamName ;
	private int intType ;
	private String txtControlDesc ;
	private String txtDisplayMessage ;
	private String txtIsDependent ;
	private String txtDependentTo;
	private String txtUrl;
	private int flgActive ;
	private String txtIsPastDateRestricted ;
	private String txtIsRequired ;
	private int intLength ;
	private String txtErrorMsg ;
	private String txtIsVisible ;
	private int intOrder ;
	private int options;
}
