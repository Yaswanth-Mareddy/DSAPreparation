package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class InbayDeleteDTO {

	private String strApplicationCode;
	private int intAppCatID;
	private String strAppTransactionID;
	private String strRequestorEmpNo;
	private String strApproverEmpNo;
	private String strTransactionTitle;

}
