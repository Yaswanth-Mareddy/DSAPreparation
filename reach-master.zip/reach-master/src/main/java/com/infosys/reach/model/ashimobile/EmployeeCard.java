package com.infosys.reach.model.ashimobile;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EmployeeCard {
	private String heading;
	private String status;
	private boolean isSelected;
	private List<EmployeeField> fields;

	public EmployeeCard(String heading,List<EmployeeField> fields) {
		super();
		this.heading = heading;
		this.status = "";
		this.isSelected = false;
		this.fields = fields;
	}
}
