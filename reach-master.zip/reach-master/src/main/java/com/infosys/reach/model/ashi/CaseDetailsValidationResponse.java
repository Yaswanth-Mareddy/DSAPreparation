package com.infosys.reach.model.ashi;


import java.util.List;

import com.infosys.reach.entity.ViewCurrEmpAllDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CaseDetailsValidationResponse {

	private boolean status;
	private String message;
	private ValidatedCaseDetails caseDetails;
	private List<ViewCurrEmpAllDetails> ids;
	
	public CaseDetailsValidationResponse(boolean status) {
		super();
		this.status = status;
	}
	
	public CaseDetailsValidationResponse(boolean status, String message) {
		super();
		this.status = status;
		this.message = message;
	}


	public CaseDetailsValidationResponse(boolean status, List<ViewCurrEmpAllDetails> ids) {
		super();
		this.status = status;
		this.ids = ids;
	}


	public CaseDetailsValidationResponse(boolean status, String message, ValidatedCaseDetails caseDetails) {
		super();
		this.status = status;
		this.message = message;
		this.caseDetails = caseDetails;
	}
	
	
	
}
