package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstHearTaggedEmpDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstHearTaggedEmpDetailsRepository extends JpaRepository<ELCMECMstHearTaggedEmpDetails, Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECMstHearTaggedEmpDetails> S save(S entity);
}
