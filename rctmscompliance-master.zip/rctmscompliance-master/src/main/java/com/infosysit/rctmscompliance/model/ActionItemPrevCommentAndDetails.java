package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class ActionItemPrevCommentAndDetails {

	private String txtAssigneeComments;
	private String txtRejectComments;
	private String txtCloseComments;
	private String txtOwner;
	private String txtAssignee;
	private int noOfCycles;
}
