package com.infosys.hello.springboot.exception;

import java.util.Date;

import lombok.Data;

@Data
public class ErrorDetails {
	private Date createdDate;
	private String message;
	private String details;
	
	public ErrorDetails(String message,String details) {
		this.createdDate = new Date();
		this.message = message;
		this.details = details;
	}
}
