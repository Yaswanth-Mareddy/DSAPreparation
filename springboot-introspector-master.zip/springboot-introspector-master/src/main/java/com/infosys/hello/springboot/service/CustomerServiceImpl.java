package com.infosys.hello.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.hello.springboot.entity.Customer;
import com.infosys.hello.springboot.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepository customerRepository;

	public void saveCustomer(Customer customer) {
		customerRepository.save(customer);
	}

	public List<Customer> getCustomers() {
		return customerRepository.findAll();
	}

	public List<Customer> getCustomerByName(String name) {
		return customerRepository.findAllByName(name);
	}

	public int getCustomerCount() {
		return customerRepository.noOfCustomers();
	}
	
}
