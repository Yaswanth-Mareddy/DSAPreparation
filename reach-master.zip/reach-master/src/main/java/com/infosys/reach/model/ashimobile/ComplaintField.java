package com.infosys.reach.model.ashimobile;

import com.infosys.reach.model.ashi.ComplaintDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplaintField {

	private int caseId;
	private String respondentType;
	private String managedBy;
	private String reportedOn;
	private String location;
	private String description;
	private String status;
	
	public ComplaintField(int caseId, String respondentType, ComplaintDetails details)
 {
		super();
		this.caseId = caseId;
		this.respondentType = respondentType;
		this.managedBy = details.getManagedBy();
		this.reportedOn = details.getReportedOn();
		this.location = details.getLocation();
		this.description = details.getDescription();
		this.status = details.getStatus();
	}
	
	
	
}
