package com.infosysit.rctmscompliance.model;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComplianceDetailsForUserDateNull {

	private int intComplianceID;
	private String txtComplianceName;
	private int heirarchyIntNodeID;
	private String txtDescription;
	private int intLocationID;
	private int intCompGroupID;
	private String dtDueDate;
	private String dtEndDate;
	private int intFrequencyID;
	private int intDaysBeforeStart;
	private int intReminderInterval;
	private String txtAName;
	private String txtVName;
	private String txtOName;
	private String txtNodeName;
	private int deptIntNodeID;
	private String txtXPathToNode;
	private String txtType;
	
}
