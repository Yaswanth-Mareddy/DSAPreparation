package com.infosys.reach.model.common;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class CAMSOutput {

	private String empNo;
	private String empName;
	private String empMailId;
	private String roleName;
	private String roleDesc;
	private String appRoleName;
	private String contextName;
	private String contextValue;
	private String contextText;
	
	
	
}
