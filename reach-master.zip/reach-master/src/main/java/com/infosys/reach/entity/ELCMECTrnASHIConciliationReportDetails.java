package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;

import com.infosys.reach.controller.Session;
import com.infosys.reach.model.ashi.GMFields;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmectrnashiconciliationreportdetails")
public class ELCMECTrnASHIConciliationReportDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;

	@Column(name="intcaseid")
	private int caseId ;

	@Column(name="txtreason")
	private String conciliationReason;

	@Column(name="txtkeyfindings")
	private String keyFindings;

	@Column(name="txtrecommendations")
	private String recommendations;

	@Column(name="txtdmsagreementfiles")
	private String agreementDocs;

	@Column(name="txtdmsotherfiles")
	private String otherDocs;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="dtcreateddate")
	private Timestamp createdDate = new Timestamp(new DateTime(DateTimeZone.forOffsetHoursMinutes(5, 30)).getMillis());

	public ELCMECTrnASHIConciliationReportDetails(GMFields fields, String agreementDocs, String otherDocs) {
		super();
		this.caseId = fields.getCaseid();
		this.conciliationReason = fields.getConciliationReason();
		this.keyFindings = fields.getConciliationFindings();
		this.recommendations = fields.getConciliationRecommendations();
		this.agreementDocs = agreementDocs;
		this.otherDocs = otherDocs;
		this.createdBy = Session.getTokenEMPNO();
	}
	
	
}
