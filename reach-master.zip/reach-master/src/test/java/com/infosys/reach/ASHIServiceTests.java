package com.infosys.reach;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.sql.Timestamp;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang.WordUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.entity.ELCMECMstASHICocomplainantsDetails;
import com.infosys.reach.entity.ELCMECMstASHICommunicationDetails;
import com.infosys.reach.entity.ELCMECMstASHIConciliationConsentDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.entity.HRISTrnEmpLocation;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ASHIAccess;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.ComplaintDetails;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.common.CAMSOutput;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.common.MailApprovalRequest;
import com.infosys.reach.model.common.MailApprovalResponse;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.CommunicationModel;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelForm;
import com.infosys.reach.model.generic.GenModelFormData;
import com.infosys.reach.model.generic.GenModelFormObj;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.Header;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICocomplainantsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICommunicationDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIConciliationConsentDetailsRepository;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECtrnASHIConcernSLADetailsRepository;
import com.infosys.reach.repository.GENMstCityRepository;
import com.infosys.reach.repository.GenMstInfosysEstablishmentsRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.repository.HRISTrnEmpLocationRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@ExtendWith(MockitoExtension.class)
class ASHIServiceTests{

	private Timestamp dateTime = new Timestamp(System.currentTimeMillis());

	@InjectMocks
	ASHIServiceImpl service;

	@Mock
	GENMstCityRepository cityRepository;

	@Mock
	private Property property;

	@Mock
	CommonServiceImpl commonService;

	@Mock
	GenMstInfosysEstablishmentsRepository genMstInfosysEstablishmentsRepository;

	@Mock
	HRISTrnEmpLocationRepository empLocationRepository;

	@Mock
	ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;

	@Mock
	ELCMECMstASHICocomplainantsDetailsRepository ashiCocomplainantsDetailsRepository;

	@Mock
	HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Mock
	ELCMECMstASHICaseEmployeeDetailsRepository ashiCaseEmployeeDetailsRepository;

	@Mock
	ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;

	@Mock
	ViewCurrEmpAllDetailsRepository empDetailsRepository;

	@Mock
	ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Mock
	ELCMECMstConcernModulesDetailsRepository concernModulesDetailsRepository;

	@Mock
	ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;

	@Mock
	GenMstMailConfigHeaderRepository mailConfigHeaderRepository;
	
	@Mock
	ELCMECMstASHIConciliationConsentDetailsRepository conciliationConsentDetailsRepository;
	
	@Mock
	ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Mock
	ELCMECtrnASHIConcernSLADetailsRepository slaDetailsRepository;
	
	@Mock
	ELCMECMstASHICommunicationDetailsRepository communicationRepository;

	@Test
	void getCitiesByCountryCodeTest() throws CustomException {
		List<GenModelOption> expected = Arrays.asList(new GenModelOption(Constants.SELECT, "Select", true), new GenModelOption("3", "BANGALORE", false), new GenModelOption(0,"MYSORE-GEC"));

		Mockito.when(cityRepository.getCitiesByCountryCodeNew("INDIA")).thenReturn(Arrays.asList(new GenModelOption("3", "BANGALORE", false)));

		List<GenModelOption> actual = service.getCitiesByCountryCode("INDIA");

		assertEquals(expected.size(), actual.size());
	}
	@Test
	void getCitiesByCountryCodeTest1() throws CustomException {
		List<GenModelOption> expected = Arrays.asList(new GenModelOption(Constants.SELECT, "Select", true),new GenModelOption("3", "BANGALORE", false));

		Mockito.when(cityRepository.getCitiesByCountryCodeNew("CHINA")).thenReturn(Arrays.asList(new GenModelOption("3", "BANGALORE", false)));

		List<GenModelOption> actual = service.getCitiesByCountryCode("CHINA");

		assertEquals(expected.size(), actual.size());
	}
	@Test
	void getCitiesByCountryCodeTest2() throws CustomException {
		List<GenModelOption> expected = Arrays.asList(new GenModelOption(Constants.SELECT, "Select", true));
		List<GenModelOption> s1 = new ArrayList<>();
		Mockito.when(cityRepository.getCitiesByCountryCodeNew("INDIA")).thenReturn(s1);

		List<GenModelOption> actual = service.getCitiesByCountryCode("INDIA");

		assertEquals(expected.size(), actual.size());
	}

	@Test
	void isLoggedInUserAdminTestCase() throws Exception{
		Mockito.when(property.getCamsAppCode()).thenReturn("");

		boolean expected = false;
		boolean actual = service.isLoggedInUserAdmin();
		assertEquals(expected, actual);	
	}
	@Test
	void isLoggedInUserAdminTestCase1() throws Exception{
		String str= "abc";
		Mockito.when(property.getCamsAppCode()).thenReturn(str);

		List<CAMSOutput> adminList = new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);

		boolean expected = true;
		boolean actual = service.isLoggedInUserAdmin();
		assertEquals(expected, actual);	
	}

	@Test
	void checkHearAccessTestCase()  throws Exception{
		String baseLocation = "INDIA";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation("abc@gmail.com","BLR","101","IN"));
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(true);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());			
	}

	@Test
	void checkHearAccessTestCase1()  throws Exception{
		String baseLocation = "";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation("abc@gmail.com","BLR","101","IN"));
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(false);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());			
	}

	@Test
	void checkHearAccessTestCase2()  throws Exception{
		String baseLocation = "INDIA";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation("abc@gmail.com","BLR","101",""));
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(false);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());			
	}

	@Test
	void checkHearAccessTestCase3()  throws Exception{
		String baseLocation = "UK";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation("abc@gmail.com","BLR","101","IN"));
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(false);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());	
	}

	@Test
	void checkHearAccessTestCase4()  throws Exception{
		String baseLocation = "INDIA";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.of(new HRISTrnEmpLocation("abc@gmail.com","BLR","101","pak"));
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(false);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());		
	}

	@Test
	void checkHearAccessTestCase5()  throws Exception{
		String baseLocation = "INDIA";
		Optional<HRISTrnEmpLocation> empLocationObj = Optional.empty();
		Mockito.when(genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(Mockito.anyString())).thenReturn(baseLocation);
		Mockito.when(empLocationRepository.findByEmpNo(Mockito.anyString())).thenReturn(empLocationObj);

		ASHIAccess expected = new ASHIAccess(false);
		ASHIAccess actual = service.checkHearAccess("101");
		assertEquals(expected.isHasAccess(), actual.isHasAccess());	
	}

	@Test
	void getHearPolicyTestCase() throws Exception{
		String policy="Infosys has a global policy to address issues of sexual harassment at the workplace. The Grievance Redressal Body (GRB) established in 1999 helps to define, interpret and implement the Infosys Anti-Sexual Harassment Initiative (ASHI). We assure discretion and guarantee non-retaliation to all the complainants. We follow a gender neutral approach in redressing matters of sexual harassment.<br><br>The Policy on Prevention & Redressal of Sexual Harassment talks about prohibition of unlawful harassment from/to any employee of the Company towards other employees including supervisors, vendors and clients.";	
		List<GenModelField> fieldList=new ArrayList<>();
		fieldList.add(new GenModelField(13, "ASHI_POLICY", "", policy, false, true ));
		GenModel expected = new GenModel("Policy Page", "", fieldList);
		GenModel actual = service.getHearPolicy();
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getFields().size(), actual.getFields().size());
	}

	@Test
	void getInboxTabsTestCase() throws Exception{
		List<TabView> tabs=new ArrayList<>();
		tabs.add(new TabView("All", ""));
		tabs.add(new TabView("Initiated by Me", ""));
		tabs.add(new TabView("As a Co-Complainant", ""));
		tabs.add(new TabView("Initiated by GRB", ""));

		Mockito.when(property.getAllURL()).thenReturn("");
		Mockito.when(property.getInitiatedByMeURL()).thenReturn("");
		Mockito.when(property.getCoComplainantURL()).thenReturn("");
		Mockito.when(property.getInitiatedByGRBURL()).thenReturn("");

		List<TabView> expected = tabs;
		List<TabView> actual = service.getInboxTabs();
		assertEquals(expected.size(), actual.size());

	}

	@Test
	void getTaggedCasesTestCase() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("NOT ACCEPTED");
		caseDetails.add(a);
		a.setTransId(1);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<CardViewAction> actions=new ArrayList<>();

		actions.add(new CardViewAction(Constants.ACCEPT, "serviceurl", ""+1, "POST", "Are you sure you want to be tagged as a co-complainant?"));
		actions.add(new CardViewAction("Reject", "serviceurl", ""+1, "POST", "Are you sure you do not want to be tagged as a co-complainant?"));
		List<Row> rowList=new ArrayList<>();
		rowList.add(new Row(a, 1,actions));

		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetails);
		Mockito.when(property.getCocomplainantAcceptURL()).thenReturn("");
		Mockito.when(property.getCocomplainantRejectURL()).thenReturn("");

		InboxView expected = new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getTaggedCases("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getTaggedCasesTestCase1() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("ACCEPTED");
		caseDetails.add(a);
		a.setTransId(1);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<CardViewAction> actions=new ArrayList<>();

		actions.add(new CardViewAction(1, Constants.CASE_ID, "GET", "abc", Constants.REDIRECTID));
		List<Row> rowList=new ArrayList<>();
		rowList.add(new Row(a, 1,actions));

		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetails);
		Mockito.when(commonService.getUIModuleId("CD")).thenReturn("abc");

		InboxView expected = new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getTaggedCases("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());

	}

	@Test
	void getTaggedCasesTestCase2() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("Abc");
		caseDetails.add(a);
		a.setTransId(1);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<CardViewAction> actions=new ArrayList<>();
		List<Row> rowList=new ArrayList<>();
		rowList.add(new Row(a, 1,actions));

		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getTaggedCases("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());

	}

	@Test
	void getTaggedCasesTestCase3() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();

		Mockito.when(caseDetailsRepository.findTaggedCases(Mockito.anyString())).thenReturn(caseDetails);


		InboxView expected = new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getTaggedCases("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());

	}

	@Test
	void getCasesInitiatedByMeTestCase() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("");
		caseDetails.add(a);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(1, Constants.CASE_ID, "GET", "", Constants.REDIRECTID));
		rowList.add(new Row(a, 1,actions));
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);

		Mockito.when(commonService.getUIModuleId("CD")).thenReturn("");

		InboxView expected = new InboxView("Tab - Initiated by me", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesInitiatedByMe("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getCasesInitiatedByMeTestCase1() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - Initiated by me", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesInitiatedByMe("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getCasesInitiatedByGRBTestCase() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("");
		caseDetails.add(a);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(1, Constants.CASE_ID, "GET", "", Constants.REDIRECTID));
		rowList.add(new Row(a, 1,actions));

		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);
		Mockito.when(commonService.getUIModuleId("CD")).thenReturn("");
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndActorAndMailIdAndFlgAcceptAndFlgReject(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.empty());

		InboxView expected = new InboxView("Tab - Initiated by GRB", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesInitiatedByGRB("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getCasesInitiatedByGRBTestCase1() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - Initiated by GRB", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesInitiatedByGRB("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getAllCasesTestCase() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		InboxCaseDetails a = new InboxCaseDetails(123,"12-11-2020","shashank","with GRB");
		a.setMessage("");
		caseDetails.add(a);
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		List<CardViewAction> actions=Arrays.asList(new CardViewAction(1, Constants.CASE_ID, "GET", "", Constants.REDIRECTID));
		rowList.add(new Row(a, 1,actions));

		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);
		Mockito.when(commonService.getUIModuleId("CD")).thenReturn("");
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndActorAndMailIdAndFlgAcceptAndFlgReject(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString(), Mockito.anyInt(), Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime)));

		InboxView expected = new InboxView("Tab - All", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getAllCases("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void getAllCasesTestCase1() throws Exception{
		List<InboxCaseDetails> caseDetails = new ArrayList<>();
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		Mockito.when(caseDetailsRepository.findMyCases(Mockito.anyString(),Mockito.anyList())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - All", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getAllCases("123", "abc");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
	}

	@Test
	void consentGenModelTestCase() throws Exception{
		DPServiceOutput output = new DPServiceOutput();
		output.setContent("abc");
		List<GenModelField> fieldList=new ArrayList<>();

		fieldList.add(new GenModelField(54, "ASHI_DPCONSENT", "", "abc", false, true));

		List<GenModelOption> isCheckedOptions=new ArrayList<>();
		isCheckedOptions.add(new GenModelOption(1, Constants.ACCEPT));
		isCheckedOptions.add(new GenModelOption(2, "Do not accept (If you check this box you will not be able to raise a case.)"));
		GenModelField isChecked=new GenModelField( 18, "isChecked", "", "", "",isCheckedOptions, true);
		isChecked.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select Accept / Do not accept before proceeding.")));
		fieldList.add(isChecked);

		Mockito.when(commonService.dpService("ASHI","CONTENT")).thenReturn(output);
		GenModel expected = new GenModel("DP Consent", "", fieldList);
		GenModel actual = service.consentGenModel();
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getFields().size(), actual.getFields().size());

	}

	@Test
	void getAdminsTestCase() throws Exception{

		List<CAMSOutput> adminCamsList = Arrays.asList(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));

		Mockito.when(property.getCamsAppCode()).thenReturn("");
		
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		List<String> expected = Arrays.asList("125");
		List<String> actual = service.getAdmins();

		assertEquals(expected, actual);
	}

	@Test
	void getAdminsTestCase1() throws Exception{

		List<CAMSOutput> adminCamsList = Arrays.asList(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"),new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));

		Mockito.when(property.getCamsAppCode()).thenReturn("");
		

		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		List<String> expected =Arrays.asList("125");;
		List<String> actual = service.getAdmins();

		assertEquals(expected, actual);
	}

	@Test
	void addEvidenceGenModelTestCase() throws Exception{
		List<GenModelField> evidenceFieldList=new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, "caseid", "", 123, true, false);
		caseidField.setEditable(false);
		evidenceFieldList.add(caseidField);

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", "", "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1"));
		validations.add(new GenModelValidation("15", "75", "Filename is too long. Please rename."));
		validations.add(new GenModelValidation("10", "5000|KB", "Exceeding file size limit"));
		validations.add(new GenModelValidation("11", "", Message.FILETYPES));

		GenModelField evidences=new GenModelField( 57, Constants.EVIDENCES, Constants.ADD_EVIDENCE, new ArrayList<DocumentData>(), "", Message.FILESIZE, validations);
		evidenceFieldList.add(evidences);

		Mockito.when(property.getFileValidationRegex()).thenReturn("");
		Mockito.when(property.getFileValidationTypes()).thenReturn("");
		Mockito.when(property.getUploadEvidenceURL()).thenReturn("");

		GenModel expected = new GenModel(Constants.ADD_EVIDENCE, "", evidenceFieldList);
		GenModel actual = service.addEvidenceGenModel(123);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getFields().size(), actual.getFields().size());
	}

	@Test
	void saveUserConsentApprovalTestCase() throws Exception{
		GenModel genmodel = new GenModel();
		GMFields details = new GMFields();
		details.setDPAccepted(true);

		DPServiceOutput output = new DPServiceOutput();
		output.setContent("true");
		Mockito.when(commonService.dpService("ASHI","SAVE")).thenReturn(output);

		Mockito.when(commonService.convertGenModelToObject(genmodel, 0)).thenReturn(details);
		Mockito.when(commonService.getUIModuleId("IF")).thenReturn("");

		Response expected = new Response(Message.SUCCESSPROCEED, "", "", "");
		Response actual = service.saveUserConsentApproval(genmodel);
		assertEquals(expected.getType(), actual.getType());
	}

	@Test
	void saveUserConsentApprovalTestCase1() throws Exception{
		GenModel genmodel = new GenModel();
		GMFields details = new GMFields();
		details.setDPAccepted(true);

		DPServiceOutput output = new DPServiceOutput();
		output.setContent("abc");
		Mockito.when(commonService.dpService("ASHI","SAVE")).thenReturn(output);

		Mockito.when(commonService.convertGenModelToObject(genmodel, 0)).thenReturn(details);
		Mockito.when(commonService.getUIModuleId(Mockito.anyString())).thenReturn("");

		Response expected = new Response(Message.SUCCESSPROCEED, "Improper return from cams service : "+"abc", "", "");
		Response actual = service.saveUserConsentApproval(genmodel);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}

	@Test
	void saveUserConsentApprovalTestCase2() throws Exception{
		GenModel genmodel = new GenModel();
		GMFields details = new GMFields();
		details.setDPAccepted(true);

		Mockito.when(commonService.dpService("ASHI","SAVE")).thenThrow(new CustomException());

		Mockito.when(commonService.convertGenModelToObject(genmodel, 0)).thenReturn(details);
		Mockito.when(commonService.getUIModuleId(Mockito.anyString())).thenReturn("");

		Response expected = new Response(Message.SUCCESSPROCEED,null, "", "");
		Response actual = service.saveUserConsentApproval(genmodel);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}

	@Test
	void saveUserConsentApprovalTestCase3() throws Exception{
		GenModel genmodel = new GenModel();
		GMFields details = new GMFields();
		details.setDPAccepted(false);

		Mockito.when(commonService.convertGenModelToObject(genmodel, 0)).thenReturn(details);
		Mockito.when(commonService.getUIModuleId(Mockito.anyString())).thenReturn("");

		Response expected = new Response(Message.SUCCESSPROCEED, "", "", "");
		Response actual = service.saveUserConsentApproval(genmodel);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}

	@Test
	void getASHIPolicyPDFTestCase() throws Exception{
		DMSModel outputModel = new DMSModel("applicationName","applicationId","storageURL","ab","Policy on Prevention and Redressal of Harassmen-India.pdf");

		Mockito.when(commonService.dmsService(Mockito.any(DMSModel.class), Mockito.anyString())).thenReturn(outputModel);
		Mockito.when(property.getDmsApplicationName()).thenReturn("applicatioName");
		Mockito.when(property.getDmsApplicationID()).thenReturn("applicatioId");
		Mockito.when(property.getDmsStorageURL()).thenReturn("storageURL");
		Mockito.when(property.getDmsDocumentPath()).thenReturn("a");
		Mockito.when(property.getDmsOfficialDocumentPath()).thenReturn("b");

		DocumentData expected = new DocumentData("Policy on Prevention and Redressal of Harassment-India.pdf", "");
		DocumentData actual = service.getASHIPolicyPDF();
		assertEquals(expected.getFilename(),actual.getFilename());
	}

	@Test
	void updateCocomplainantResponseTestCase() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.empty();

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);

		Response expected = new Response(Message.ERROR, "Cocomplainant details not found");
		Response actual = service.updateCocomplainantResponse(123, 124);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	}

	@Test
	void updateCocomplainantResponseTestCase1() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);

		long date = 0;
		List<CaseEmployeeDetails> employeeDetails = new ArrayList<>();
		employeeDetails.add(new CaseEmployeeDetails("empNo","mailId","empName","unit","sbuCode","empBandCode",new java.sql.Date(date),"duCode","roleDesc","projectCode","company","currentCity","baseCity","confirmationStatus","reportingManager"));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(employeeDetails);
		Mockito.when(ashiCocomplainantsDetailsRepository.save(cocomplainantsDetails.get())).thenReturn(null);
		Mockito.when(ashiCaseEmployeeDetailsRepository.save(Mockito.any())).thenReturn(null);

		Response expected = new Response(Message.SUCCESS,"Accepted successfully");
		Response actual = service.updateCocomplainantResponse(123, 1);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	
	}

	@Test
	void updateCocomplainantResponseTestCase2() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);

		long date = 0;
		List<CaseEmployeeDetails> employeeDetails = new ArrayList<>();
		employeeDetails.add(new CaseEmployeeDetails("empNo","mailId","empName","unit","sbuCode","empBandCode",new java.sql.Date(date),"duCode","roleDesc","projectCode","company","currentCity","baseCity","confirmationStatus","reportingManager"));
		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(employeeDetails);
		Mockito.when(ashiCocomplainantsDetailsRepository.save(cocomplainantsDetails.get())).thenReturn(null);
		Mockito.when(ashiCaseEmployeeDetailsRepository.save(Mockito.any())).thenReturn(null);

		Response expected = new Response(Message.SUCCESS,"Rejected successfully");
		Response actual = service.updateCocomplainantResponse(123, 0);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	
	}

	@Test
	void updateCocomplainantResponseTestCase3() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);

		Response expected = new Response(Message.ERROR, "Invalid response entered. Enter 1 or 0.");
		Response actual = service.updateCocomplainantResponse(123, 2);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	}

	@Test
	void updateCocomplainantResponseTestCase4() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);
		cocomplainantsDetails.get().setFlgAccept(1);
		cocomplainantsDetails.get().setFlgReject(0);

		Response expected = new Response(Message.ERROR, "Already accepted");
		Response actual = service.updateCocomplainantResponse(123, 2);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	
	}
	@Test
	void updateCocomplainantResponseTestCase5() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);
		cocomplainantsDetails.get().setFlgAccept(1);
		cocomplainantsDetails.get().setFlgReject(1);

		Response expected = new Response(Message.ERROR, "Already rejected");
		Response actual = service.updateCocomplainantResponse(123, 2);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}
	@Test
	void updateCocomplainantResponseTestCase6() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);
		cocomplainantsDetails.get().setFlgAccept(0);
		cocomplainantsDetails.get().setFlgReject(1);

		Response expected = new Response(Message.ERROR, "Already rejected");
		Response actual = service.updateCocomplainantResponse(123, 2);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	
	}

	@Test
	void updateCocomplainantResponseTestCase7() throws Exception{
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails = Optional.of(new ELCMECMstASHICocomplainantsDetails(1,"email"));

		Mockito.when(ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(123,1)).thenReturn(cocomplainantsDetails);

		List<CaseEmployeeDetails> employeeDetails = new ArrayList<>();

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(employeeDetails);

		Response expected = new Response(Message.ERROR, "Something went wrong. Please try again.");
		Response actual = service.updateCocomplainantResponse(123, 1);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());	
	}

	@Test
	void getComplaintDetailsTestCase() throws Exception{
		List<CardViewField> fieldList=new ArrayList<>();
		List<ComplaintDetails> complaintDetailsWithRespondents= new ArrayList<>();
		complaintDetailsWithRespondents.add(new ComplaintDetails(1,"respondentType","managedBy","status","12-01-2021","location","descp"));
		Mockito.when(caseDetailsRepository.findComplaintDetailsByCaseId(Mockito.anyInt())).thenReturn(complaintDetailsWithRespondents);		

		fieldList.add(new CardViewField("Respondent Type", "respondentType", 14));
		fieldList.add(new CardViewField(Constants.MANAGEDBYLABEL, "managedBy", 14));
		fieldList.add(new CardViewField(Constants.REPORTEDONLABEL, "12-01-2021", 14));
		fieldList.add(new CardViewField("Location", "location", 14));
		fieldList.add(new CardViewField(Constants.DESCRIPTION, "descp", 54));

		LabelView expected = new LabelView(Constants.CASE_DETAILS,fieldList);
		LabelView actual = service.getComplaintDetails(1);
		assertEquals(expected.getView().getFields().size(), actual.getView().getFields().size());	
	}

	@Test
	void getComplaintDetailsTestCase1() throws Exception{
		List<CardViewField> fieldList=new ArrayList<>();
		List<ComplaintDetails> complaintDetailsWithRespondents= new ArrayList<>();
		Mockito.when(caseDetailsRepository.findComplaintDetailsByCaseId(Mockito.anyInt())).thenReturn(complaintDetailsWithRespondents);		

		LabelView expected = new LabelView(Constants.CASE_DETAILS,fieldList);
		LabelView actual = service.getComplaintDetails(1);
		assertEquals(expected.getView().getFields().size(), actual.getView().getFields().size());	
	}

	@Test
	void getEvidencesTestCase() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,"filename1,filename2"));
		evidenceString.get().setCaseActionId(1);
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);

		Mockito.when(property.getDownloadURL()).thenReturn("abc1");
		Mockito.when(property.getEvidenceGenModelURL()).thenReturn("abc");

		List<CardViewField> fields=new ArrayList<>();
		List<CardViewField> highlightFields=new ArrayList<>();
		highlightFields.add(new CardViewField("Evidences", Message.FILESIZE	, 14));
		fields.add(new CardViewField("filename1", MessageFormat.format("abc1", "A", 1,"filename1"), 35));
		fields.add(new CardViewField("filename2", MessageFormat.format("abc1", "A", 1,"filename2"), 35));
		fields.add(new CardViewField(Constants.ADD_EVIDENCE, "abc".replace("{0}", "1"), 57));
		cards.add(new Card(highlightFields, fields));

		CardView expected = new CardView("Case evidences", cards);
		CardView actual = service.getEvidences(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}

	@Test
	void getEvidencesTestCase1() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.empty();
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);

		//Mockito.when(property.getDownloadURL()).thenReturn("abc1");
		Mockito.when(property.getEvidenceGenModelURL()).thenReturn("abc");

		cards.add(new Card(Arrays.asList(new CardViewField("Evidences", Message.FILESIZE, 14)), Arrays.asList(new CardViewField(Message.NOFILE, "", 12),new CardViewField(Constants.ADD_EVIDENCE, "abc".replace("{0}", "1"), 57))));

		CardView expected = new CardView("Case evidences", cards);
		CardView actual = service.getEvidences(1);
		assertEquals(expected.getCards().size(), actual.getCards().size());	
	}

	@Test
	void getEvidencesTestCase2() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);


		Optional<ELCMECTrnASHIActionDetails> evidenceString= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,""));
		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(Mockito.anyInt())).thenReturn(evidenceString);
		Mockito.when(property.getEvidenceGenModelURL()).thenReturn("abc");

		cards.add(new Card(Arrays.asList(new CardViewField("Evidences", Message.FILESIZE, 14)), Arrays.asList(new CardViewField(Message.NOFILE, "", 12),new CardViewField(Constants.ADD_EVIDENCE, "abc".replace("{0}", "1"), 57))));

		CardView expected = new CardView("Case evidences", cards);
		CardView actual = service.getEvidences(1);
		assertEquals(expected.getCards().size(), actual.getCards().size());	

	}	

	@Test
	void getEvidencesTestCase3() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		CardView expected = new CardView("Case evidences", cards);
		CardView actual = service.getEvidences(1);
		assertEquals(expected.getCards().size(), actual.getCards().size());	

	}

	@Test
	void uploadEvidenceTestCase() throws Exception{
		GenModel evidenceGenModel = new GenModel();
		String folder = new String();
		List<String> validatedEvidences=new ArrayList<String>();

		GMFields input = new GMFields();

		Mockito.when(commonService.convertGenModelToObject(evidenceGenModel, 0)).thenReturn(input);

		DocumentData data = new DocumentData(null);
		data.setBase64file("base64File");
		List<DocumentData> evidences = Arrays.asList(data);
		input.setEvidences(evidences);

		Mockito.when(commonService.validateFile(data, folder, validatedEvidences)).thenReturn(false);

		Response expected = new Response(Message.ERROR, "Invalid File. Unable to upload attached file " + null);
		Response actual = service.uploadEvidence(evidenceGenModel,folder,validatedEvidences);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}

	@Test
	void uploadEvidenceTestCase1() throws Exception{
		GenModel evidenceGenModel = new GenModel();
		String folder = new String();
		List<String> validatedEvidences=new ArrayList<String>();

		GMFields input = new GMFields();
		input.setCaseid(1);

		Mockito.when(commonService.convertGenModelToObject(evidenceGenModel, 0)).thenReturn(input);

		DocumentData data = new DocumentData(null);
		data.setBase64file("base64File");
		List<DocumentData> evidences = Arrays.asList(data);
		input.setEvidences(evidences);

		Mockito.when(commonService.validateFile(data, folder, validatedEvidences)).thenReturn(true);


		Optional<ELCMECTrnASHIActionDetails> actionObj= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,"filename1,filename2"));

		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(1)).thenReturn(actionObj);

		StringBuilder filenameString=new StringBuilder();
		String dmsFileNames = "";

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("abcde");
		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(), Mockito.anyString(), Mockito.anyList(), Mockito.anyString())).thenReturn(dmsFileNames);

		filenameString.append("filename1,filename2").append(",").append(dmsFileNames);

		actionObj.get().setDmsFileName(filenameString.toString());

		Mockito.when(ashiActionDetailsRepository.save(actionObj.get())).thenReturn(null);

		Response expected = new Response(Message.SUCCESS,"Successfully uploaded file.");
		Response actual = service.uploadEvidence(evidenceGenModel,folder,validatedEvidences);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());

	}

	@Test
	void uploadEvidenceTestCase2() throws Exception{
		GenModel evidenceGenModel = new GenModel();
		String folder = new String();
		List<String> validatedEvidences=new ArrayList<String>();

		GMFields input = new GMFields();
		input.setCaseid(1);

		Mockito.when(commonService.convertGenModelToObject(evidenceGenModel, 0)).thenReturn(input);

		DocumentData data = new DocumentData(null);
		data.setBase64file("base64File");
		List<DocumentData> evidences = Arrays.asList(data);
		input.setEvidences(evidences);

		Mockito.when(commonService.validateFile(data, folder, validatedEvidences)).thenReturn(true);


		Optional<ELCMECTrnASHIActionDetails> actionObj= Optional.of(new ELCMECTrnASHIActionDetails(1,"role","status","comments","createdBy",dateTime,""));

		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(1)).thenReturn(actionObj);

		StringBuilder filenameString=new StringBuilder();
		String dmsFileNames = "";

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("abcde");
		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(), Mockito.anyString(), Mockito.anyList(), Mockito.anyString())).thenReturn(dmsFileNames);
		filenameString.append(dmsFileNames);

		actionObj.get().setDmsFileName(filenameString.toString());

		Mockito.when(ashiActionDetailsRepository.save(actionObj.get())).thenReturn(null);

		Response expected = new Response(Message.SUCCESS,"Successfully uploaded file.");
		Response actual = service.uploadEvidence(evidenceGenModel,folder,validatedEvidences);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());

	}

	@Test
	void uploadEvidenceTestCase3() throws Exception{
		GenModel evidenceGenModel = new GenModel();
		String folder = new String();
		List<String> validatedEvidences=new ArrayList<String>();

		GMFields input = new GMFields();
		input.setCaseid(1);

		Mockito.when(commonService.convertGenModelToObject(evidenceGenModel, 0)).thenReturn(input);

		DocumentData data = new DocumentData(null);
		data.setBase64file("base64File");
		List<DocumentData> evidences = Arrays.asList(data);
		input.setEvidences(evidences);

		Mockito.when(commonService.validateFile(data, folder, validatedEvidences)).thenReturn(true);

		Optional<ELCMECTrnASHIActionDetails> actionObj= Optional.empty();

		Mockito.when(ashiActionDetailsRepository.findevidencesByCaseId(1)).thenReturn(actionObj);

		Response expected = new Response(Message.ERROR,"Unable to find case.");
		Response actual = service.uploadEvidence(evidenceGenModel,folder,validatedEvidences);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());

	}

	@Test
	void getCaseEmployeeDetailsTestCase() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(false);

		CardView expected = new CardView("Employee details", cards);
		CardView actual = service.getCaseEmployeeDetails(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}

	@Test
	void getCaseEmployeeDetailsTestCase1() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(true);

		List<EmployeeDetails> employeeDetails=Arrays.asList(new EmployeeDetails("mailId","empNo","name"));
		List<CardViewField> fields=new ArrayList<>();
		List<CardViewField> highlightFields=new ArrayList<>();
		highlightFields.add(new CardViewField(Constants.RESPONDENTS, ""	, 14));
		fields.add(new CardViewField("name", "empNo", 14));

		List<CardViewField> highlightFields1=new ArrayList<>();
		highlightFields1.add(new CardViewField(Constants.WITNESSES, ""	, 14));

		List<CardViewField> highlightFields2=new ArrayList<>();
		highlightFields2.add(new CardViewField("Co-Complainants", ""	, 14));

		cards.add(new Card(highlightFields, fields));
		cards.add(new Card(highlightFields1, fields));
		cards.add(new Card(highlightFields2, fields));

		Mockito.when(ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(employeeDetails);
		CardView expected = new CardView("Employee details", cards);
		CardView actual = service.getCaseEmployeeDetails(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}

	@Test
	void getCaseEmployeeDetailsTestCase2() throws Exception{
		List<Card> cards=new ArrayList<>();

		Mockito.when(caseDetailsRepository.existsById(1)).thenReturn(true);
		Mockito.when(ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(Mockito.anyInt(), Mockito.anyList())).thenReturn(new ArrayList<>());

		cards.add(new Card(Arrays.asList(new CardViewField(Constants.RESPONDENTS, "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));
		cards.add(new Card(Arrays.asList(new CardViewField(Constants.WITNESSES, "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));
		cards.add(new Card(Arrays.asList(new CardViewField("Co-Complainants", "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));

		CardView expected = new CardView("Employee details", cards);
		CardView actual = service.getCaseEmployeeDetails(1);
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getCards().size(), actual.getCards().size());
	}

	@Test
	void initiateCaseFormTestCase() throws CustomException {
		
		List<CAMSOutput> adminList = new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));

		Mockito.when(property.getCamsAppCode()).thenReturn("abc");
		
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);

		List<GenModelFormObj> genModelFormObjList=new ArrayList<>();
		List<GenModelForm> genModelFormList=new ArrayList<>();
		List<GenModelForm> accordionFormList=new ArrayList<>();
		List<GenModelForm> genModelFormListEvidence=new ArrayList<>();

		List<GenModelField> complainantFieldList=new ArrayList<>();

		List<GenModelOption> raisingForOptions=Arrays.asList(new GenModelOption("1", "Myself",true),new GenModelOption(0, Constants.OTHERS));
		GenModelField raisingFor=new GenModelField( 47, "raisingFor", "Raising case for", "1", "", raisingForOptions, true);
		complainantFieldList.add(raisingFor);

		List<GenModelOption> complainantTypeOptions=Arrays.asList(new GenModelOption("1", "Infosys Employee",true),new GenModelOption(0, Constants.OTHERS));
		GenModelField complaintBy=new GenModelField( 47, "complainantType", "", "1", "raisingFor|0", complainantTypeOptions, false);
		complainantFieldList.add(complaintBy);

		GenModelField isComplainantKnown=new GenModelField( 45, "isComplainantKnown", "I know the identity of the complainant", 0, "complainantType|1", "",false);
		complainantFieldList.add(isComplainantKnown);

		GenModelField complainantInfy=new GenModelField( 46, "complainantsInfy", "Complainant (Complaint By)", "isComplainantKnown|1", "employeeUrl", Message.EMPID_OR_EMPNO, false);
		complainantFieldList.add(complainantInfy);

		GenModelField complainantOther=new GenModelField( 0, "complainantsOther", "Complainant (Complaint By)","complainantType|0","","Enter names or identity of complainants separated by comma.", false);
		complainantFieldList.add(complainantOther);

		genModelFormList.add(new GenModelForm(Constants.COMPLAINANT, complainantFieldList));

		//Respondent section
		List<GenModelField> respondentFieldList=new ArrayList<>();
		List<GenModelOption> respondentTypeOptions=new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee",true));
		respondentTypeOptions.add(new GenModelOption("0", Constants.OTHERS));
		GenModelField complaintAgainst=new GenModelField( 47, "respondentType", "Complaint against is", "1", "",respondentTypeOptions, true);
		respondentFieldList.add(complaintAgainst);

		GenModelField isIdentityKnown=new GenModelField( 45, "isRespondentKnown", "I know the identity of the respondent", 0,"respondentType|1","", true);
		respondentFieldList.add(isIdentityKnown);		

		GenModelField respondentInfy=new GenModelField( 46, "respondentsInfy", "Respondent (Complaint Against)", "isRespondentKnown|1", "employeeUrl", Message.EMPID_OR_EMPNO, false);
		respondentFieldList.add(respondentInfy);

		GenModelField respondentOther=new GenModelField( 0, "respondentsOther", "Respondent (Complaint Against)", "respondentType|0", "", "Enter names or identity of respondents separated by comma.", false);
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new GenModelForm(Constants.RESPONDENT, respondentFieldList));


		//Location section
		List<GenModelField> locationFieldList=new ArrayList<>();

		List<GenModelOption> countryOptions=new ArrayList<>();
		countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

		GenModelField country=new GenModelField( 11, "country", "Country", WordUtils.capitalize(Constants.SELECT), "", countryOptions, true);
		locationFieldList.add(country);


		GenModelField city=new GenModelField( 11, "baseLocation", "Base Location", WordUtils.capitalize(Constants.SELECT), "country", new ArrayList<>(), true);
		city.setDependantAction("baseLocationUrl");
		locationFieldList.add(city);

		genModelFormList.add(new GenModelForm("Your Current Location Details", locationFieldList, "", true));


		//Complaint Details section
		List<GenModelField> descriptionFieldList=new ArrayList<>();

		GenModelField description=new GenModelField( 1, "description", Constants.DESCRIPTION,"", "","Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new GenModelForm("Complaint Details", descriptionFieldList));


		//Category and place of incident sections
		List<GenModelField> categoryFieldList=new ArrayList<>();
		List<GenModelOption> categoryOptions= new ArrayList<>();
		categoryOptions.add(new GenModelOption("key","value",true));
		GenModelField complaintCategory=new GenModelField( 18, Constants.COMPLAINT_CATEGORY, "", categoryOptions.get(0).getValue(), "",categoryOptions, true);
		categoryFieldList.add(complaintCategory);

		genModelFormList.add(new GenModelForm("Complaint Category", categoryFieldList,"",true));

		List<GenModelField> placeOfIncidentFieldList=new ArrayList<>();
		List<GenModelOption> placeOfIncidentOptions=new ArrayList<GenModelOption>();
		placeOfIncidentOptions.add(new GenModelOption("key","value",true));
		GenModelField placeOfIncident=new GenModelField( 18, "placeOfIncident", "", placeOfIncidentOptions.get(0).getValue(), "",placeOfIncidentOptions, true);
		placeOfIncidentFieldList.add(placeOfIncident);

		genModelFormList.add(new GenModelForm("Place of Incident", placeOfIncidentFieldList,"",true));


		//Cocomplainant section
		List<GenModelField> cocomplainantFieldList=new ArrayList<>();
		GenModelField cocomplainant=new GenModelField( 46, "cocomplainants", "Tag Other Complainants", "", "employeeUrl", "Email ID's / Emp. Nos of co-complainants or other impacted employees",true);
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new GenModelForm("Other Complainants", cocomplainantFieldList));


		//Witnesses section
		List<GenModelField> witnessesFieldList=new ArrayList<>();

		GenModelField witnesses=new GenModelField( 46, "witnesses", "Tag Witnesses", "", "employeeUrl",Message.EMPID_OR_EMPNO, true);
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new GenModelForm(Constants.WITNESSES, witnessesFieldList));


		//Evidence section
		List<GenModelField> evidenceFieldList=new ArrayList<>();
		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1"));
		validations.add(new GenModelValidation("15", "75", "Filename is too long. Please rename."));
		validations.add(new GenModelValidation("10", "5000|KB", "Exceeding file size limit"));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField evidences=new GenModelField( 60, Constants.EVIDENCES, "Add Evidences",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);
		evidenceFieldList.add(evidences);

		genModelFormListEvidence.add(new GenModelForm("Upload Evidences", evidenceFieldList));

		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormList), new GenModelFormData()));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(),new GenModelFormData("More Details On The Complaint (Optional)",accordionFormList)));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormListEvidence), new GenModelFormData()));

		Mockito.when(property.getEmployeeSearchURL()).thenReturn("employeeUrl");
		Mockito.when(property.getBaselocationbycountrycodeURL()).thenReturn("baseLocationUrl");
		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1)).thenReturn(countryOptions);
		Mockito.when(concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN")).thenReturn(categoryOptions);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "POI")).thenReturn(placeOfIncidentOptions);

		GenModel expected = new GenModel("Initiate Case Form", "", genModelFormObjList, new ArrayList<>());
		GenModel actual = service.initiateCaseForm();
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getForms().size(), actual.getForms().size());

	}

	@Test
	void initiateCaseFormTestCase1() throws CustomException {
		
		List<CAMSOutput> adminList = new ArrayList<>();

		Mockito.when(property.getCamsAppCode()).thenReturn("abc");
		
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);

		List<GenModelFormObj> genModelFormObjList=new ArrayList<>();
		List<GenModelForm> genModelFormList=new ArrayList<>();
		List<GenModelForm> accordionFormList=new ArrayList<>();
		List<GenModelForm> genModelFormListEvidence=new ArrayList<>();

		//Respondent section
		List<GenModelField> respondentFieldList=new ArrayList<>();
		List<GenModelOption> respondentTypeOptions=new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee",true));
		respondentTypeOptions.add(new GenModelOption("0", Constants.OTHERS));
		GenModelField complaintAgainst=new GenModelField( 47, "respondentType", "Complaint against is", "1", "",respondentTypeOptions, true);
		respondentFieldList.add(complaintAgainst);

		GenModelField isIdentityKnown=new GenModelField( 45, "isRespondentKnown", "I know the identity of the respondent", 0,"respondentType|1","", true);
		respondentFieldList.add(isIdentityKnown);		

		GenModelField respondentInfy=new GenModelField( 46, "respondentsInfy", "Respondent (Complaint Against)", "isRespondentKnown|1", "employeeUrl", Message.EMPID_OR_EMPNO, false);
		respondentFieldList.add(respondentInfy);

		GenModelField respondentOther=new GenModelField( 0, "respondentsOther", "Respondent (Complaint Against)", "respondentType|0", "", "Enter names or identity of respondents separated by comma.", false);
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new GenModelForm(Constants.RESPONDENT, respondentFieldList));


		//Location section
		List<GenModelField> locationFieldList=new ArrayList<>();

		List<GenModelOption> countryOptions=new ArrayList<>();
		countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

		GenModelField country=new GenModelField( 11, "country", "Country", WordUtils.capitalize(Constants.SELECT), "", countryOptions, true);
		locationFieldList.add(country);


		GenModelField city=new GenModelField( 11, "baseLocation", "Base Location", WordUtils.capitalize(Constants.SELECT), "country", new ArrayList<>(), true);
		city.setDependantAction("baseLocationUrl");
		locationFieldList.add(city);

		genModelFormList.add(new GenModelForm("Your Current Location Details", locationFieldList, "", true));


		//Complaint Details section
		List<GenModelField> descriptionFieldList=new ArrayList<>();

		GenModelField description=new GenModelField( 1, "description", Constants.DESCRIPTION,"", "","Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new GenModelForm("Complaint Details", descriptionFieldList));	

		//Cocomplainant section
		List<GenModelField> cocomplainantFieldList=new ArrayList<>();
		GenModelField cocomplainant=new GenModelField( 46, "cocomplainants", "Tag Other Complainants", "", "employeeUrl", "Email ID's / Emp. Nos of co-complainants or other impacted employees",true);
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new GenModelForm("Other Complainants", cocomplainantFieldList));


		//Witnesses section
		List<GenModelField> witnessesFieldList=new ArrayList<>();

		GenModelField witnesses=new GenModelField( 46, "witnesses", "Tag Witnesses", "", "employeeUrl",Message.EMPID_OR_EMPNO, true);
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new GenModelForm(Constants.WITNESSES, witnessesFieldList));

		//Stakeholder section
		List<GenModelField> stakeholderFieldList=new ArrayList<>();

		GenModelField isStakeHolder=new GenModelField( 45, "isStakeHolder", "Reported to any other stakeholder before raising the case", 0,"","", true);
		stakeholderFieldList.add(isStakeHolder);

		List<GenModelOption> stakeholderOptions=new ArrayList<>();
		stakeholderOptions.add(new GenModelOption("key","value",true));
		GenModelField stakeholderRole=new GenModelField( 11, "stakeholderRole", "Stakeholder Role", stakeholderOptions.get(0).getValue(), "isStakeHolder|1", stakeholderOptions, false);
		stakeholderFieldList.add(stakeholderRole);

		GenModelField stakeholder=new GenModelField( 76, "stakeholder", Constants.STAKEHOLDER, "isStakeHolder|1", "employeeUrl",Message.EMPID_OR_EMPNO, false);
		stakeholder.setDependantField("stakeholderRole");
		stakeholderFieldList.add(stakeholder);

		accordionFormList.add(new GenModelForm("Stakeholders", stakeholderFieldList));			

		//Evidence section
		List<GenModelField> evidenceFieldList=new ArrayList<>();
		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1"));
		validations.add(new GenModelValidation("15", "75", "Filename is too long. Please rename."));
		validations.add(new GenModelValidation("10", "5000|KB", "Exceeding file size limit"));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField evidences=new GenModelField( 60, Constants.EVIDENCES, "Add Evidences",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);
		evidenceFieldList.add(evidences);

		genModelFormListEvidence.add(new GenModelForm("Upload Evidences", evidenceFieldList));

		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormList), new GenModelFormData()));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(),new GenModelFormData("More Details On The Complaint (Optional)",accordionFormList)));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormListEvidence), new GenModelFormData()));

		Mockito.when(property.getEmployeeSearchURL()).thenReturn("employeeUrl");
		Mockito.when(property.getBaselocationbycountrycodeURL()).thenReturn("baseLocationUrl");
		Mockito.when(reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1)).thenReturn(countryOptions);
		Mockito.when(genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "SHR")).thenReturn(stakeholderOptions);

		GenModel expected = new GenModel("Initiate Case Form", "", genModelFormObjList, new ArrayList<>());
		GenModel actual = service.initiateCaseForm();
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getForms().size(), actual.getForms().size());
	}

	@Test
	void initiateASHICaseTestCase() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(ashiActionDetailsRepository.save(Mockito.any())).thenReturn(null);

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.empty();
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Details for grb empNo is unavailable"
				);

		assertTrue(thrown.getMessage().contains("Details for grb empNo is unavailable"));

	}

	@Test
	void initiateASHICaseTestCaseExceptionInsetEmpDetail() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();

		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Details for id mailId is unavailable"
				);

		assertTrue(thrown.getMessage().contains("Details for id mailId is unavailable"));	

	}


	@Test
	void initiateASHICaseTestCase3() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("domain").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");


		//		 for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";


		//		for getComplainantType==1
		String complainantType = "Infoscion";
		String complainantTitle = "Complainant Name & Emp. No.";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI")).thenReturn(caseInitiatorMailInfo);

		complainantDetails1 = complainantDetails1.delete(0, 4);
		complainantDetails1.append("NA");

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);


		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);

		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(1);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj);
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Case Initiator "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Case Initiator "+Message.MAIL_NOT_TRIGGERED));

	}

	@Test
	void initiateASHICaseTestCase4() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;



		//		ELCMECTrnASHICaseDetails ashiCaseDetails=new ELCMECTrnASHICaseDetails(caseDetails, dateTime);

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details


		//		Response expected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
		//		Response actual = service.initiateASHICase(caseDetails);
		//		assertEquals(expected, actual);

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("domain").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");


		//  for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";

		String complainantType = "";
		String complainantTitle = "";

		//		for getComplainantType==0
		complainantType = "Other";
		complainantTitle = "Complainant Details";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI")).thenReturn(caseInitiatorMailInfo);

		complainantDetails1.append(caseDetails.getComplainantsOther());

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);


		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);

		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo);

		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(1);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj);
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Case Initiator "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Case Initiator "+Message.MAIL_NOT_TRIGGERED));

	}
	@Test
	void initiateASHICaseTestCase5() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, false, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;



		//		ELCMECTrnASHICaseDetails ashiCaseDetails=new ELCMECTrnASHICaseDetails(caseDetails, dateTime);

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details


		//		Response expected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
		//		Response actual = service.initiateASHICase(caseDetails);
		//		assertEquals(expected, actual);

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("domain").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");

		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmployeeName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#") ;		

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICI")).thenReturn(caseInitiatorMailInfo);

		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(1);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj);

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Case Initiator "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Case Initiator "+Message.MAIL_NOT_TRIGGERED));

	}
	@Test
	void initiateASHICaseTestCase6() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(1);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details
		Mockito.when(ashiActionDetailsRepository.save(Mockito.any())).thenReturn(null);


		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("domain").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");

		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmployeeName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#") ;		
		//		String caseInitiatorMailBody = "";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICI")).thenReturn(caseInitiatorMailInfo);

		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(1);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj);

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"Case Initiator "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("Case Initiator "+Message.MAIL_NOT_TRIGGERED));

	}

	@Test
	void initiateASHICaseTestCase2() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details


		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("abc").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");

		//		 for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";


		//		for getComplainantType==1
		String complainantType = "Infoscion";
		String complainantTitle = "Complainant Name & Emp. No.";

		
		List<ViewCurrEmpAllDetails> complainantsInfy = new ArrayList<>();
		complainantsInfy.add(new ViewCurrEmpAllDetails("mailId4","empNo4","empName4"));
		caseDetails.setComplainantsInfy(complainantsInfy);
		complainantDetails1.append("<br>").append("empName4").append(" (").append("empNo4").append(")");

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);

		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);

		MailerAssistResponse caseInitiatorMailResponse = new MailerAssistResponse();
		caseInitiatorMailResponse.setCode(0);

		MailerAssistResponse grbMailResponse = new MailerAssistResponse();
		grbMailResponse.setCode(1);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(caseInitiatorMailResponse, grbMailResponse);

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"GRB Mail has not triggered"
				);

		assertTrue(thrown.getMessage().contains("GRB Mail has not triggered"));

	}
	@Test
	void initiateASHICaseTestCase7() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;



		//		ELCMECTrnASHICaseDetails ashiCaseDetails=new ELCMECTrnASHICaseDetails(caseDetails, dateTime);

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details
		Mockito.when(ashiActionDetailsRepository.save(Mockito.any())).thenReturn(null);

		//		Response expected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
		//		Response actual = service.initiateASHICase(caseDetails);
		//		assertEquals(expected, actual);

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("abc").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		List<ViewCurrEmpAllDetails> resp = new ArrayList<>();
		resp.add(new ViewCurrEmpAllDetails("mailId3","empNo3","empName3"));
		caseDetails.setRespondentsInfy(resp);

		respondentDetails.append("<br>").append("empName3").append(" (").append("empNo3").append(")");
		respondentDetails = respondentDetails.delete(0, 4);
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");

		//		 for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";


		//		for getComplainantType==1
		String complainantType = "Infoscion";
		String complainantTitle = "Complainant Name & Emp. No.";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI")).thenReturn(caseInitiatorMailInfo);
		List<ViewCurrEmpAllDetails> complainantsInfy = new ArrayList<>();
		complainantsInfy.add(new ViewCurrEmpAllDetails("mailId4","empNo4","empName4"));
		caseDetails.setComplainantsInfy(complainantsInfy);
		complainantDetails1.append("<br>").append("empName4").append(" (").append("empNo4").append(")");

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);


		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);


		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(0);
		MailerAssistResponse MARObj1 = new MailerAssistResponse();
		MARObj1.setCode(0);

		//		the first two if condition are false and now for private (this.getComplainantMailObj(caseId, caseDetails))
		MailContent complainantMailInfoNew=new MailContent("mailBody,#ComplainantsName#","mailSubject #CaseId#");

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICO")).thenReturn(complainantMailInfoNew);
		String complainantMailSubject=complainantMailInfoNew.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		StringBuilder complainantNames = new StringBuilder();
		StringBuilder complainantIds = new StringBuilder();

		complainantNames.append(", ").append(WordUtils.capitalize("empname4"));
		complainantIds.append("mailId4").append("abc").append(";");

		String complainantMailBody=complainantMailInfoNew.getBody().replace("#ComplainantsName#", complainantNames.deleteCharAt(0).toString().trim());
		complainantMailInfoNew.setSubject(complainantMailSubject);
		complainantMailInfoNew.setBody(complainantMailBody);

		MailerAssistResponse MARObj2 = new MailerAssistResponse();
		MARObj2.setCode(1);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo, complainantMailInfoNew);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj, MARObj1, MARObj2);
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.initiateASHICase(caseDetails),
				"On behalf of GRB complainant "+Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains("On behalf of GRB complainant "+Message.MAIL_NOT_TRIGGERED));
	}

	@Test
	void initiateASHICaseTestCase8() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details


		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("abc").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(0);
		respondentDetails = respondentDetails.delete(0, 4);
		respondentDetails.append("NA");
		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");

		//		 for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";


		//		for getComplainantType==1
		String complainantType = "Infoscion";
		String complainantTitle = "Complainant Name & Emp. No.";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI")).thenReturn(caseInitiatorMailInfo);
		List<ViewCurrEmpAllDetails> complainantsInfy = new ArrayList<>();
		//		complainantsInfy.add(new ViewAllEmpDetails("mailId4","empNo4","empName4"));
		caseDetails.setComplainantsInfy(complainantsInfy);
		complainantDetails1.append("<br>").append("empName4").append(" (").append("empNo4").append(")");

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);

		//		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);


		//		System.out.println(grbMailObj.toString());
		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(0);
		//Mockito.when(commonService.triggerMail(newMailerObj)).thenReturn(MARObj);
		MailerAssistResponse MARObj1 = new MailerAssistResponse();
		MARObj1.setCode(0);
		//Mockito.when(commonService.triggerMail(grbMailObj)).thenReturn(MARObj1);

		//		the first two if condition are false and now for private (this.getComplainantMailObj(caseId, caseDetails))
		MailContent complainantMailInfoNew=new MailContent("mailBody,#ComplainantsName#","mailSubject #CaseId#");

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICO")).thenReturn(complainantMailInfoNew);
		String complainantMailSubject=complainantMailInfoNew.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		StringBuilder complainantNames = new StringBuilder();
		StringBuilder complainantIds = new StringBuilder();

		complainantNames.append(", ").append(WordUtils.capitalize("empname4"));
		complainantIds.append("mailId4").append("abc").append(";");

		String complainantMailBody=complainantMailInfoNew.getBody().replace("#ComplainantsName#", complainantNames.deleteCharAt(0).toString().trim());
		complainantMailInfoNew.setSubject(complainantMailSubject);
		complainantMailInfoNew.setBody(complainantMailBody);

		MailerAssistResponse MARObj2 = new MailerAssistResponse();
		MARObj2.setCode(0);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo, complainantMailInfoNew);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj, MARObj1, MARObj2);

		Response expected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
		Response actual = service.initiateASHICase(caseDetails);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}

	@Test
	void initiateASHICaseTestCase9() throws CustomException {
		GMFields fields = new GMFields(); 
		ValidatedCaseDetails caseDetails = new ValidatedCaseDetails(fields, true, "Mobile");
		caseDetails.setRaisingFor(0);
		ViewCurrEmpAllDetails caseInitiator = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		caseInitiator.setRole("emp");

		List<ViewCurrEmpAllDetails> empIds = new ArrayList<>();
		empIds.add(caseInitiator);
		caseDetails.setCaseInitiator(caseInitiator);

		CaseEmployeeDetails employeeDetail = new CaseEmployeeDetails();
		List<CaseEmployeeDetails> complainantDetails= new ArrayList<>();
		complainantDetails.add(employeeDetail);


		int caseId=1;

		ELCMECTrnASHICaseDetails newObj = new ELCMECTrnASHICaseDetails();
		newObj.setCaseId(caseId);
		Mockito.when(caseDetailsRepository.save(Mockito.any())).thenReturn(newObj);

		Mockito.when(hrisMstEmployeeRepository.findCaseEmployeeDetails(Mockito.anyString())).thenReturn(complainantDetails);

		Mockito.when(ashiCaseEmployeeDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);

		Mockito.when(commonService.uploadFilesToDMS(Mockito.anyString(),Mockito.anyString(),Mockito.anyList(),Mockito.anyString())).thenReturn("dmsFileNames");

		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("");


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(1, complainantDetails.get(0), "I", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);


		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsOther("123");
		caseDetails.setWitnesses(empIds);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setDescription("description");

		ViewCurrEmpAllDetails details = new ViewCurrEmpAllDetails("mailId","empNo","empName");
		List<ViewCurrEmpAllDetails> cocomplainants =new ArrayList<>();
		cocomplainants.add(details);
		caseDetails.setCocomplainants(cocomplainants);
		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "A"));
		List<ELCMECMstASHICaseEmployeeDetails> complainantList = ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(complainantList);


		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, "123", "R"));
		List<ELCMECMstASHICaseEmployeeDetails> respondentList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), "W", "emp"));
		List<ELCMECMstASHICaseEmployeeDetails> witnessList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList =  ashiCaseEmployeeDetailsList;
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, "emailId"));

		Mockito.when(ashiCocomplainantsDetailsRepository.saveAll(Mockito.anyIterable())).thenReturn(null);


		//Action Details
		Mockito.when(ashiActionDetailsRepository.save(Mockito.any())).thenReturn(null);
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstSysParams("", "", "28", "")));

		Mockito.when(property.getCamsAppCode()).thenReturn("appCode");
		
		
		List<CAMSOutput> adminCamsList = new ArrayList<CAMSOutput>();
		adminCamsList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminCamsList);

		StringBuilder grbIds=new StringBuilder();

		Optional<ViewCurrEmpAllDetails> empDetails= Optional.of(new ViewCurrEmpAllDetails("shashank.jain18@infosys.com","empNo","empName"));
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(empDetails);

		Mockito.when(property.getInfyDomain()).thenReturn("abc");
		grbIds.append("shashank.jain18@infosys.com").append("abc").append(";");
		Mockito.when(property.getGrbId()).thenReturn("grbId");
		grbIds.insert(0, "grbId");

		//		#for else if conditions
		StringBuilder respondentDetails = new StringBuilder();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsOther("abc");
		respondentDetails.append("abc");

		//		till here

		MailContent grbMailInfo = new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description#","mailSubject #CaseId#");
		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB")).thenReturn(grbMailInfo);
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		caseDetails.setBaseLocation("bangalore");
		caseDetails.setDescription("description");
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", "empNo").replace("#Location#", WordUtils.capitalize("bangalore")).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", "description");
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		Mockito.when(property.getAppCode()).thenReturn("appCode");
		Mockito.when(property.getEventIdFYI()).thenReturn("eventId");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(123);
		Mockito.when(property.getFromId()).thenReturn("fromId");


		//		 for  getCaseInitiatorMailObj private object

		StringBuilder complainantDetails1 = new StringBuilder();
		//		for first condition to be true
		MailContent caseInitiatorMailInfo=new MailContent("mailBody,#EmpName#,#Location#,#RespondentDetails#,#Description# ,#ComplainantType#, #ComplainantTitle#, #ComplainantDetails# ","mailSubject #CaseId#");

		String caseInitiatorMailBody = "";
		String ccId = "";


		//		for getComplainantType==1
		String complainantType = "Infoscion";
		String complainantTitle = "Complainant Name & Emp. No.";

		//Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI")).thenReturn(caseInitiatorMailInfo);
		List<ViewCurrEmpAllDetails> complainantsInfy = new ArrayList<>();
		caseDetails.setComplainantsInfy(complainantsInfy);
		complainantDetails1.append("<br>").append("empName4").append(" (").append("empNo4").append(")");

		ccId = "grbId";
		Mockito.when(property.getGrbId()).thenReturn(ccId);
		caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails1);


		String caseInitiatorMailSubject = caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);


		MailerAssistResponse MARObj = new MailerAssistResponse();
		MARObj.setCode(0);
		MailerAssistResponse MARObj1 = new MailerAssistResponse();
		MARObj1.setCode(0);

		//		the first two if condition are false and now for private (this.getComplainantMailObj(caseId, caseDetails))
		MailContent complainantMailInfoNew=new MailContent("mailBody,#ComplainantsName#","mailSubject #CaseId#");

		String complainantMailSubject=complainantMailInfoNew.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		StringBuilder complainantNames = new StringBuilder();
		StringBuilder complainantIds = new StringBuilder();

		complainantNames.append(", ").append(WordUtils.capitalize("empname4"));
		complainantIds.append("mailId4").append("abc").append(";");

		String complainantMailBody=complainantMailInfoNew.getBody().replace("#ComplainantsName#", complainantNames.deleteCharAt(0).toString().trim());
		complainantMailInfoNew.setSubject(complainantMailSubject);
		complainantMailInfoNew.setBody(complainantMailBody);

		MailerAssistResponse MARObj2 = new MailerAssistResponse();
		MARObj2.setCode(0);
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(caseInitiatorMailInfo, grbMailInfo, complainantMailInfoNew);
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(MARObj, MARObj1, MARObj2);

		Response expected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
		Response actual = service.initiateASHICase(caseDetails);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
	}
	
	
	@Test
	void validateCaseDetailsTest() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.empty(); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Case-initiator id "+caseInitiator+Constants.INVALID);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest1() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide "+Constants.RESPONDENT+" details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest2() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(false);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide "+Constants.RESPONDENT+" details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest3() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide "+Constants.RESPONDENT+" details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest4() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide "+Constants.RESPONDENT+" details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest5() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
			
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide other respondents details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest6() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(0);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false, "Please enter complaint description.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest7() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(0);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false, Message.DESCRIPTIONLENGTH);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest8() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(0);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false, "Please select base location.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
		
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	
	@Test
	void validateCaseDetailsTest9() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(0);
		caseDetails.setIsRespondentKnown(0);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(false);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(cocomplainantResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest10() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails()); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest11() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse);		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest12() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(false);
				
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest13() throws CustomException {
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		employees.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees2);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest14() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide "+Constants.COMPLAINANT+" details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest15() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

//		CaseDetailsValidationResponse respondentResponseGRB = new CaseDetailsValidationResponse(false);
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getComplainantsInfy(), Constants.COMPLAINANT)).thenReturn(respondentResponseGRB);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest16() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

//		CaseDetailsValidationResponse respondentResponseGRB = new CaseDetailsValidationResponse(true,employeesGRB);
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getComplainantsInfy(), Constants.COMPLAINANT)).thenReturn(respondentResponseGRB);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest17() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

//		CaseDetailsValidationResponse respondentResponseGRB = new CaseDetailsValidationResponse(true,employeesGRB);
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getComplainantsInfy(), Constants.COMPLAINANT)).thenReturn(respondentResponseGRB);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest18() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

//		CaseDetailsValidationResponse respondentResponseGRB = new CaseDetailsValidationResponse(true,employeesGRB);
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getComplainantsInfy(), Constants.COMPLAINANT)).thenReturn(respondentResponseGRB);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please select complaint category.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest19() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide other complainants details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest20() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please select place of incident.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest21() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file"));
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		
		Mockito.when(commonService.validateFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(false);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest22() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		
		Mockito.when(commonService.validateFile(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(true);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(true);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest23() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		caseDetails.setIsStakeHolder(1);
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,"Please provide stake holder details");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest24() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		caseDetails.setIsStakeHolder(1);
		caseDetails.setStakeholder("Stakeholder");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		CaseDetailsValidationResponse stakeholderResponse = new CaseDetailsValidationResponse(false);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, stakeholderResponse);

		
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getStakeholder(), Constants.STAKEHOLDER)).thenReturn(stakeholderResponse);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest25() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		caseDetails.setIsStakeHolder(1);
		caseDetails.setStakeholder("Stakeholder");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		List<ViewCurrEmpAllDetails> employees3=new ArrayList<>();
		employees3.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		CaseDetailsValidationResponse stakeholderResponse = new CaseDetailsValidationResponse(true,employees3);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, stakeholderResponse);

		
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getStakeholder(), Constants.STAKEHOLDER)).thenReturn(stakeholderResponse);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest26() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		caseDetails.setIsStakeHolder(1);
		caseDetails.setStakeholder("Stakeholder");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		List<ViewCurrEmpAllDetails> employees3=new ArrayList<>();
		employees3.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		CaseDetailsValidationResponse stakeholderResponse = new CaseDetailsValidationResponse(true,employees3);
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, stakeholderResponse);

		
//		Mockito.when(commonService.validateEmployeeDetails(caseDetails.getStakeholder(), Constants.STAKEHOLDER)).thenReturn(stakeholderResponse);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(true);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest27() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		List<DocumentData> evidences = new ArrayList<>();
		evidences.add(new DocumentData("file1", "base64file1"));
		evidences.add(new DocumentData("file2", "base64file2"));
		
		String caseInitiator = "722284";
		String appType = "MOBILE";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(0);
		caseDetails.setIsComplainantKnown(0);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		caseDetails.setComplainantsOther("ComplainantsOther");
		caseDetails.setComplaintCategory(2);
		caseDetails.setPlaceOfIncident("BLR");
		caseDetails.setEvidences(evidences);
		caseDetails.setIsStakeHolder(0);
		caseDetails.setStakeholder("");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		List<ViewCurrEmpAllDetails> employeesGRB=new ArrayList<>();
		employeesGRB.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		List<ViewCurrEmpAllDetails> employees3=new ArrayList<>();
		employees3.add(new ViewCurrEmpAllDetails("dilisha.n","722285","dilishaH"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse);
		
		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(true);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		//assertEquals(objExpected.getMessage(), objActual.getMessage());
		
	}
	
	@Test
	void validateCaseDetailsTest28() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("ComplainantsInfy");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		CaseDetailsValidationResponse complainantsResponse = new CaseDetailsValidationResponse(false, Constants.COMPLAINANT + " ComplainantsInfy"+Constants.INVALID);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, complainantsResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,Constants.COMPLAINANT + " ComplainantsInfy"+Constants.INVALID);
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest29() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("722284");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		CaseDetailsValidationResponse complainantsResponse = new CaseDetailsValidationResponse(true,Arrays.asList(caseInitiatorDetails.get()));
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, complainantsResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,Constants.CASE_INITIATOR + " and " + Constants.COMPLAINANT + " id cannot be same.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	void validateCaseDetailsTest30() throws CustomException {
		
		Mockito.when(property.getCamsAppCode()).thenReturn("cams.appcode");
		
		List<CAMSOutput> adminList =new ArrayList<>();
		adminList.add(new CAMSOutput("empno", "empname", "mailid","rolename","roledesc","approlename","contextname","contextvalue", "contexttext"));
		Mockito.when(commonService.camsService(Mockito.anyString(), Mockito.any())).thenReturn(adminList);
		
		String caseInitiator = "722284";
		String appType = "MOBIL";
		GMFields caseDetails = new GMFields();
		caseDetails.setRespondentType(1);
		caseDetails.setIsRespondentKnown(1);
		caseDetails.setRespondentsInfy("RespondentsInfy");
		caseDetails.setRespondentsOther("RespondentsOther");
		caseDetails.setCountry("IN");
		caseDetails.setDescription("Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbfDescription asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf Description asdfadsgasdgfasgsahkfbahdvfdbf");
		caseDetails.setBaseLocation("BLR");
		caseDetails.setCocomplainants("cocomplainants");
		caseDetails.setWitnesses("witnesses");
		caseDetails.setRaisingFor(0);
		caseDetails.setComplainantType(1);
		caseDetails.setIsComplainantKnown(1);
		caseDetails.setComplainantsInfy("722284");
		
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails = Optional.of(new ViewCurrEmpAllDetails("dilisha@gmail","722280","dilishN")); 
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(caseInitiator)).thenReturn(caseInitiatorDetails);
		
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		employees.add(new ViewCurrEmpAllDetails("dilisha","722283","dilish"));
		employees.add(new ViewCurrEmpAllDetails("dilisha.m","722284","dilisha"));
		List<ViewCurrEmpAllDetails> employees1=new ArrayList<>();
		employees1.add(new ViewCurrEmpAllDetails("dilisha@","722281","dilishM"));
		List<ViewCurrEmpAllDetails> employees2=new ArrayList<>();
		employees2.add(new ViewCurrEmpAllDetails("dilisha!","722280","dilishP"));
		
		CaseDetailsValidationResponse respondentResponse = new CaseDetailsValidationResponse(true,employees);
		
		
		CaseDetailsValidationResponse cocomplainantResponse = new CaseDetailsValidationResponse(true,employees1);
		
		
		CaseDetailsValidationResponse witnessResponse = new CaseDetailsValidationResponse(true,employees1);
		
		CaseDetailsValidationResponse complainantsResponse = new CaseDetailsValidationResponse(true,employees);
		
		Mockito.when(commonService.validateEmployeeDetails(Mockito.anyString(), Mockito.anyString())).thenReturn(respondentResponse, cocomplainantResponse, witnessResponse, complainantsResponse);

		CaseDetailsValidationResponse objExpected = new CaseDetailsValidationResponse(false,Constants.RESPONDENT + " and " + Constants.COMPLAINANT + " id cannot be same.");
		CaseDetailsValidationResponse objActual = service.validateCaseDetails(caseInitiator, caseDetails, appType);
			
		assertEquals(objExpected.isStatus(), objActual.isStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	@DisplayName("When consent detail is not found")
	void updateConsentResponseTest1() throws CustomException {
		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.empty());

		Response expected = new Response(Message.ERROR, "Consent details not found");
		Response actual = service.updateConsentResponse(1, 1);
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent is accepted")
	void updateConsentResponseTest2() throws CustomException {
		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime)));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		Mockito.when(property.getAppCode()).thenReturn("ECSASHI");
		Mockito.when(property.getEventIdFYI()).thenReturn("FYI01");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(10);
		Mockito.when(property.getFromId()).thenReturn("EmailProTST@infosys.com");
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));

		Response expected = new Response(Message.SUCCESS, "Accepted successfully");
		Response actual = service.updateConsentResponse(1, 1);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent is rejected")
	void updateConsentResponseTest3() throws CustomException {
		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime)));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		Mockito.when(property.getAppCode()).thenReturn("ECSASHI");
		Mockito.when(property.getEventIdFYI()).thenReturn("FYI01");
		Mockito.when(property.getTemplateIdFYI()).thenReturn(10);
		Mockito.when(property.getFromId()).thenReturn("EmailProTST@infosys.com");
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
		
		Response expected = new Response(Message.SUCCESS, "Rejected successfully");
		Response actual = service.updateConsentResponse(1, 0);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent action is invalid")
	void updateConsentResponseTest4() throws CustomException {
		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime)));

		Response expected = new Response(Message.ERROR, "Invalid action.");
		Response actual = service.updateConsentResponse(1, 2);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent is Already accepted")
	void updateConsentResponseTest5() throws CustomException {
		ELCMECMstASHIConciliationConsentDetails consent = new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime);
		consent.setFlgAccept(1);

		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(consent));

		Response expected = new Response(Message.ERROR, "Already accepted");
		Response actual = service.updateConsentResponse(1, 2);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent is Already rejected")
	void updateConsentResponseTest6() throws CustomException {
		ELCMECMstASHIConciliationConsentDetails consent = new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime);
		consent.setFlgReject(1);

		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(consent));
		
		Response expected = new Response(Message.ERROR, "Already rejected");
		Response actual = service.updateConsentResponse(1, 2);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	@DisplayName("When consent is Already rejected")
	void updateConsentResponseTest7() throws CustomException {
		ELCMECMstASHIConciliationConsentDetails consent = new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime);
		consent.setFlgReject(1);
		consent.setFlgAccept(1);

		Mockito.when(conciliationConsentDetailsRepository.findBySerialNo(Mockito.anyInt())).thenReturn(Optional.of(consent));
		
		Response expected = new Response(Message.ERROR, "Already rejected");
		Response actual = service.updateConsentResponse(1, 2);
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void getCasesAsRespondentTest1() throws CustomException {
		
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList=new ArrayList<>();
		Mockito.when(caseDetailsRepository.findCasesAsRespondent(Mockito.anyString())).thenReturn(new ArrayList<>());

		InboxView expected = new InboxView("Tab - As a Respondent", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesAsRespondent("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		
	}
	
	@Test
	void getCasesAsRespondentTest2() throws CustomException {
		List<InboxCaseDetails> caseDetails = Arrays.asList(new InboxCaseDetails(1, "07-Nov-2020", "GRB", "WG", "NOT ACCEPTED", 1));
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList = Arrays.asList(new Row(caseDetails.get(0), 1,new ArrayList<>()));
		Mockito.when(caseDetailsRepository.findCasesAsRespondent(Mockito.anyString())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - As a Respondent", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesAsRespondent("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		
	}
	
	@Test
	void getCasesAsRespondentTest3() throws CustomException {
		List<InboxCaseDetails> caseDetails = Arrays.asList(new InboxCaseDetails(1, "07-Nov-2020", "GRB", "WG", "ACCEPTED", 1));
		List<Header> headerList=new ArrayList<>();
		headerList.add(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""));
		headerList.add(new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""));
		headerList.add(new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));

		List<Row> rowList = Arrays.asList(new Row(caseDetails.get(0), 1,new ArrayList<>()));
		Mockito.when(caseDetailsRepository.findCasesAsRespondent(Mockito.anyString())).thenReturn(caseDetails);

		InboxView expected = new InboxView("Tab - As a Respondent", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		InboxView actual = service.getCasesAsRespondent("123");
		assertEquals(expected.getName(), actual.getName());
		assertEquals(expected.getHeader().size(), actual.getHeader().size());
		assertEquals(expected.getRow().size(), actual.getRow().size());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "R", "surajkumar.dewangan", "1030816", dateTime)));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
	
		MailApprovalResponse expected = new MailApprovalResponse(Message.SUCCESS.toUpperCase(), "Request is accepted successfully.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "approve", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest1() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "R", "surajkumar.dewangan", "1030816", dateTime)));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
	
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "approve", "", "", "1")),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest2() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "R", "surajkumar.dewangan", "1030816", dateTime)));
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "reject", "", "", "1")),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest3() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(new ELCMECMstASHIConciliationConsentDetails(1, "R", "surajkumar.dewangan", "1030816", dateTime)));

		MailApprovalResponse expected = new MailApprovalResponse(Message.ERROR.toUpperCase(), "Invalid action.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "action", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest4() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent = new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime);
		consent.setFlgReject(1);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(consent));

		MailApprovalResponse expected = new MailApprovalResponse("ACTED", "Request is already rejected.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "reject", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest5() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		ELCMECMstASHIConciliationConsentDetails consent = new ELCMECMstASHIConciliationConsentDetails(1, "A", "surajkumar.dewangan", "1030816", dateTime);
		consent.setFlgAccept(1);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(consent));

		MailApprovalResponse expected = new MailApprovalResponse("ACTED", "Request is already accepted.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "reject", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest6() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(true);
		
		Mockito.when(conciliationConsentDetailsRepository.findByCaseIdAndMailId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());

		MailApprovalResponse expected = new MailApprovalResponse(Message.ERROR.toUpperCase(), "Request details not found.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "reject", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void mailBasedApprovalConciliationConsentTest7() throws CustomException {
		
		Mockito.when(caseDetailsRepository.existsById(Mockito.anyInt())).thenReturn(false);

		MailApprovalResponse expected = new MailApprovalResponse(Message.ERROR.toUpperCase(), "Invalid request number.");
		MailApprovalResponse actual = service.mailBasedApprovalConciliationConsent(new MailApprovalRequest("", "reject", "", "", "1"));
		
		assertEquals(expected.getStatus(), actual.getStatus());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void postCommunicationResponseTest1() throws CustomException {
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(0);
		comm.setRespondedBy("suraj");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(Optional.of(new ViewCurrEmpAllDetails("mailId", "empNo", "empName")));
		
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(0, ""));
	
		Response expected = new Response(Message.SUCCESS, "Successfully posted your response.");
		Response actual = service.postCommunicationResponse("suraj", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void postCommunicationResponseTest2() throws CustomException {
		
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(0);
		comm.setRespondedBy("suraj");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(Optional.of(new ViewCurrEmpAllDetails("mailId", "empNo", "empName")));
		Mockito.when(commonService.triggerMail(Mockito.any())).thenReturn(new MailerAssistResponse(1, ""));
	
		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.postCommunicationResponse("suraj", new GenModel()),
				Message.MAIL_NOT_TRIGGERED
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_NOT_TRIGGERED));
		
	}
	
	@Test
	void postCommunicationResponseTest3() throws CustomException {
		
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(0);
		comm.setRespondedBy("suraj");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));
		
		ELCMECTrnASHIActionDetails assigneeDetails = new ELCMECTrnASHIActionDetails();
		assigneeDetails.setAssigneeLocation("HYDERABAD");
		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.of(assigneeDetails));
		
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(Optional.empty());

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.postCommunicationResponse("suraj", new GenModel()),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));
		
	}
	
	@Test
	void postCommunicationResponseTest4() throws CustomException {
		
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(0);
		comm.setRespondedBy("suraj");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
		
		Mockito.when(mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(Mockito.anyString())).thenReturn(new MailContent("body", "subject"));

		Mockito.when(ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(Mockito.anyInt(), Mockito.anyString())).thenReturn(Optional.empty());

		CustomException thrown = assertThrows(
				CustomException.class,
				() -> service.postCommunicationResponse("suraj", new GenModel()),
				Message.MAIL_DETAILS_NOTFOUND
				);

		assertTrue(thrown.getMessage().contains(Message.MAIL_DETAILS_NOTFOUND));
		
	}
	
	@Test
	void postCommunicationResponseTest5() throws CustomException {
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(0);
		comm.setRespondedBy("dinesh");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
	
		Response expected = new Response("You can't reply for this comment.");
		Response actual = service.postCommunicationResponse("suraj", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void postCommunicationResponseTest6() throws CustomException {
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails();
		comm.setFlgResponded(1);
		comm.setRespondedBy("dinesh");
		comm.setResponse("response");
		comm.setComments("comments");
		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(comm));
	
		Response expected = new Response("Already responded for this comment.");
		Response actual = service.postCommunicationResponse("suraj", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void postCommunicationResponseTest7() throws CustomException {
		GMFields fields = new GMFields();
		fields.setTransactionid("1");
		fields.setResponse("response");

		Mockito.when(commonService.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(fields);

		Mockito.when(communicationRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
	
		Response expected = new Response(Message.INVALID_INPUT);
		Response actual = service.postCommunicationResponse("suraj", new GenModel());
		
		assertEquals(expected.getType(), actual.getType());
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void getCommunicationHistoryTest1() throws CustomException {
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails(1, 1, "seekedBy", "seekedByRole", "comments", "respondedBy", "respondedByRole", "response", dateTime, dateTime, 0);
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(Arrays.asList(comm));
	
		CommunicationModel actual = service.getCommunicationHistory(1, "respondedBy");

		assertEquals(1, actual.getCommentssummary().size());
		
	}
	
	@Test
	void getCommunicationHistoryTest2() throws CustomException {
		
		ELCMECMstASHICommunicationDetails comm = new ELCMECMstASHICommunicationDetails(1, 1, "seekedBy", "seekedByRole", "comments", "respondedBy", "respondedByRole", "response", dateTime, dateTime, 1);
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(Arrays.asList(comm));
	
		CommunicationModel actual = service.getCommunicationHistory(1, "respondedBy");

		assertEquals(1, actual.getCommentssummary().size());
		
	}
	
	@Test
	void getCommunicationHistoryTest3() throws CustomException {
	
		Mockito.when(communicationRepository.findByCaseIdOrderBySerialNoDesc(Mockito.anyInt())).thenReturn(Arrays.asList());
	
		CommunicationModel actual = service.getCommunicationHistory(1, "suraj");

		assertTrue(actual.getCommentssummary().isEmpty());
		
	}


}























