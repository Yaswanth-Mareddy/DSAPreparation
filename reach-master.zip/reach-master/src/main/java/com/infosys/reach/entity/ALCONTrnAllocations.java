package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="alcontrnallocations")
public class ALCONTrnAllocations {

	@Id
	@Column(name="txtprojectcode")
	private String projectCode;
	

	@Column(name="txtempnoreportto")
	private String reportingManager;
	
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="dtfromdate")
	private String fromDate;
	
	@Column(name="dttodate")
	private String toDate;
	
}
