package com.infosysit.itsm.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
public class EDSTrnDepPassportDetailsModel {
	private String txtEmpNo;
	private Integer intSerialNo;
	private String txtRelationDesc;
	private String txtPassPortNo;

	public EDSTrnDepPassportDetailsModel(String txtEmpNo,Integer intSerialNo,String txtRelationDesc,String txtPassPortNo) {
		super();
		this.txtEmpNo=txtEmpNo == null ? "" : String.valueOf(txtEmpNo);
		this.intSerialNo=intSerialNo;
		this.txtRelationDesc = txtRelationDesc == null ? "" : String.valueOf(txtRelationDesc);
		this.txtPassPortNo = txtPassPortNo == null ? "" : String.valueOf(txtPassPortNo);
		
	}
}
