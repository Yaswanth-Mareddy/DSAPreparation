package com.infosysit.rctmscompliance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstbisfilterdetails")
public class CMSmstBISfilterdetails {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intid")
	private int intID;
	
	@Column(name="txtfinding")
	private String txtFinding;
	
	@Column(name="txtreason")
	private String txtReason;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedby;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
}
