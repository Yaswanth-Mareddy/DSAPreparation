package com.infosys.reach.model.generic;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class Link {

	private String label;
	private String description;
	private String header;
	private String value;
	private String type;
	private String apiType;
	private String isBenefit;
	private String benefitId;
	private String delegationEnabled;
	private String isIcon;
	private String imagePath;
	
	public Link(String label, String description, String header, String value, String type, String apiType) {
		super();
		this.label = label;
		this.description = description;
		this.header = header;
		this.value = value;
		this.type = type;
		this.apiType = apiType;
		this.isBenefit = "";
		this.benefitId = "";
		this.delegationEnabled = "";
		this.isIcon = "";
		this.imagePath = "";
	}
	
	
	
}
