package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import com.infosys.reach.entity.ELCMECTrnASHIInterimReliefDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnASHIInterimReliefDetailsRepository extends JpaRepository<ELCMECTrnASHIInterimReliefDetails, Integer> {

	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnASHIInterimReliefDetails> S save(S entity);
	
	Optional<ELCMECTrnASHIInterimReliefDetails> findByCaseId(int caseid);
	
	boolean existsByCaseId(int caseId);
	
	Optional<ELCMECTrnASHIInterimReliefDetails> findByCaseIdAndFlgReliefAndFlgActionTaken(int caseId, int flgRelief, int flgActionTaken);
}
