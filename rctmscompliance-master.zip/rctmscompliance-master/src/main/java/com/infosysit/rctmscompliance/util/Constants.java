package com.infosysit.rctmscompliance.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.infosysit.rctmscompliance.exception.CustomException;

public class Constants {
	
	private Constants() {
		
	}

	public static final String DATETIMEFORMAT="yyyy-MM-dd HH:mm:ss";
	
	protected static final String[] COMPLIANCESTATUS= {"Pending Input","NonComplianceA","Pending Verification","NonComplianceV","Verified","NonComplianceO","Closed","NonComplianceC"};
	
	public static final String[] getComplianceStatus() {
		return COMPLIANCESTATUS;
	}
	
	public static String formatDate(String date) throws CustomException {
		try {
			DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			DateTimeFormatter format2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			if(!(date.isEmpty() || date==null))
			{
				LocalDateTime parsedDate=LocalDateTime.parse(date,format1);
				return parsedDate.format(format2);
			}
			return "NA";
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in normalDate method-InbayServices");
		}
	}
	public static final String FAILURE = "FAILURE ";
	public static final String TXTNEWDATACONCAT="Uploaded Documents=";
	public static final String COMMENTEXCEEDED="Please limit your reason within 1500 characters";
	public static final String EMPTYCOMMENT="Reason can not be empty";
	public static final String COMPRECALLED="Compliance is Recalled";
	public static final String AUDITNODATA="No New Data";
	public static final String AUDITNOREM="No Remarks";
	public static final String RECALLED="Recalled";
	public static final String SUBMIT="Submit";
	public static final String NOACTION="Action is not Applicable for Actor";
	public static final String REJECTSUCCESS="Reject Remark Updated";
	public static final String REMARKSUCCESS="Compliance submitted to ";
	public static final String COMPCLOSESUCCESS="Compliance closed successfully";
	public static final String TXTSTATUSERROR="Compliance is with ";
	public static final String AUDITSTATUSUNKOWN="Unknown";
	public static final String AUDITSTATUSPASS="Pass";
	public static final String AUDITCATEGORYCOMPLIANCE="Compliance";
	public static final String APPLICATIONCODE="COMPLMGMT";
	public static final int APPASSIGNEECATID=7501;
	public static final int APPVERIFIERCATID=7502;
	public static final int APPOWNERCATID=7503;
	public static final String ASSIGNEETRANSACTIONTITLE="Pending Compliance";
	public static final String ASSIGNEETRANSACTIONDESCRIPTION="Following compliances assigned to you need your action";
	public static final String VERIFIERTRANSACTIONTITLE="Pending Compliance";
	public static final String VERIFIERTRANSACTIONDESCRIPTION="Following compliances submitted to you need your action";
	public static final String OWNERTRANSACTIONTITLE="Pending Compliance";
	public static final String OWNERTRANSACTIONDESCRIPTION="Following compliances submitted to you need your action";
	public static final String INBOXEMPTY="There are no pending compliances for you";
	public static final String COMPCLOSE=" Compliance is closed";
	public static final String ERRORMESSAGE="Something went wrong.Try again later";
	public static final String SUCCESS="Success";
	public static final String ERROR="Error";
	public static final String VERIFIER="verifier";
	public static final String ASSIGNEE="assignee";
	public static final String OWNER="owner";
	public static final boolean TRUE=true;
	public static final boolean FALSE=false;
	public static final String ASSIGNEESUBMIT="rctmscomp/api/submitActionItemToOwner";
	public static final String OWNERCLOSE="rctmscomp/api/closeActionItem";
	public static final String OWNERRJECT="rctmscomp/api/rejectActionItem";
	public static final String SELECT="--Select--";
	public static final String STRINGFALSE="false";
	public static final String STRINGTRUE="true";
	public static final String ACTIONITEMACTIONSUBMIT="Submit To Owner";
	public static final String ACTIONITEMACTIONREJECT="Reject";
	public static final String ACTIONITEMACTIONCLOSE="Close";
	public static final int APPSURVEYACTIONCATID=7550;
	public static final String ACTIONITEMTRANSACTIONTITLE="RCTMS Action items";
	public static final String ACTIONITEMTRANSACTIONDESC="Following action item is pending with you";
	public static final String ACTIONITEMASSIGNEESTATUS="With Assignee";
	public static final String ACTIONITEMOWNERSTATUS="With Owner";
	
}

