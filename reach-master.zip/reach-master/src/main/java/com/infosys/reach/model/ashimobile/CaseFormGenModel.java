package com.infosys.reach.model.ashimobile;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.infosys.reach.model.generic.CardViewAction;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(value = Include.NON_DEFAULT)
public class CaseFormGenModel {
	private String name;
	private String id;
	private CaseGenModelFormData genModel;
	private CaseGenModelFormData accordion;
	private List<CaseGenModelField> fields;
	private List<CardViewAction> actions;

	public CaseFormGenModel(String name, String id, CaseGenModelFormData genModel,CaseGenModelFormData accordion, List<CardViewAction> actions) {
		super();
		this.name = name;
		this.id = id;
		this.genModel = genModel;
		this.accordion = accordion;
		this.actions = actions;
	}
}
