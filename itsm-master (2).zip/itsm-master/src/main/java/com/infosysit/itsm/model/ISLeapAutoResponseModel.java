package com.infosysit.itsm.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
public class ISLeapAutoResponseModel {
	private String status;
	private String suggestion;
	private String transfer;
	private String newCategoryName;
	private String deptName;
	public ISLeapAutoResponseModel(String status, String suggestion, String transfer, String newCategoryName,
			String deptName) {
		super();
		this.status=status == null ? "" : String.valueOf(status);
		this.suggestion=suggestion == null ? "" : String.valueOf(suggestion);
		this.transfer = transfer == null ? "" : String.valueOf(transfer);
		this.newCategoryName = newCategoryName == null ? "" : String.valueOf(newCategoryName);
		this.deptName = deptName == null ? "" : String.valueOf(deptName);
	}
}
