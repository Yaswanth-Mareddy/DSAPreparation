package com.infosys.reach.model.generic;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class GenModelValidation {

	private String validationtype;
	private String value;
	private String errorMessage;
}
