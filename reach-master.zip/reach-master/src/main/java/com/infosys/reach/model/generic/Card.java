package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Card {

	private String heading = "";
	private String status = "";
	private String cardID = "";
	private boolean isSelected = false;
	private List<CardViewAction> actions = new ArrayList<>();
	private List<CardViewField> highlightFields = new ArrayList<>();
	private List<CardViewField> fields = new ArrayList<>();
	private String transactionID;
	
	public Card(List<CardViewField> highlightFields, List<CardViewField> fields) {
		super();
		this.highlightFields = highlightFields;
		this.fields = fields;
	}
	
	public Card(List<CardViewField> highlightFields, List<CardViewField> fields, List<CardViewAction> actions) {
		super();
		this.highlightFields = highlightFields;
		this.fields = fields;
		this.actions = actions;
	}
	
	public Card(String heading, List<CardViewField> fields) {
		super();
		this.heading = heading;
		this.highlightFields = new ArrayList<>();
		this.fields = fields;
	}
	
	public Card(String transactionID, List<CardViewField> fields, List<CardViewAction> actions) {
		super();
		this.transactionID = transactionID;
		this.highlightFields = new ArrayList<>();
		this.fields = fields;
		this.actions = actions;
	}
	
	public Card(int caseid, String status, String category) {
		this.cardID = String.valueOf(caseid);
		this.transactionID = String.valueOf(caseid);
		this.fields.add(new CardViewField("Case No", String.valueOf(caseid), 14));
		this.fields.add(new CardViewField("Status", status, 14));
		this.fields.add(new CardViewField("Concern Type", "ASHI", 14));
		this.fields.add(new CardViewField("Category", category, 14));
		this.fields.add(new CardViewField("Outcome", "NA", 14));

	}
	
	
}
