package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnnoticetracking")
public class CMSTrnNoticeTracking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intnoticeid")
	private int intNoticeId;
	
	@Column(name="txtreferencenumber")
    private String txtReferenceNumber;
    
    @Column(name="intcomplianceid")
    private int intComplianceID;
    
    @Column(name="dtassigneddate")
    private String dtAssignedDate;
    
    @Column(name="txtdepartment")
    private String txtDepartment;
    
    @Column(name="dtnoticedate")
    private String dtNoticeDate;
    
    @Column(name="txtdescription")
    private String txtDescription;
    
    @Column(name="dtperiodinconsiderationto")
    private String dtPeriodInConsiderationTo;
    
    @Column(name="dtperiodinconsiderationfrom")
    private String dtPeriodInConsiderationFrom;
    
    @Column(name="txtattachmentlist")
    private String txtAttachmentList;
    
    @Column(name="txtlastmodifiedby")
    private String txtLastModifiedBy;
    
    @Column(name="dtlastmodified")
    private String dtLastModified;
    
    @Column(name="txtnoticepriority")
    private String txtNoticePriority;
    
    @Column(name="txtnoticetype")
    private String txtNoticeType;
    
    @Column(name="intcompgroupid")
    private int intCompGroupID;
    
    @Column(name="dtnoticeduedate")
    private String dtNoticeDueDate;
    
    @Column(name="txtnoticestage")
    private String txtNoticeStage;
    
    @Column(name="intreminterval")
    private int intRemInterval;
    
    @Column(name="txtnoticestatus")
    private String txtNoticeStatus;
    
    @Column(name="txtnoticeownerid")
    private String txtNoticeOwnerID;
    
    @Column(name="intnodeid")
    private int intNodeID;
    
    @Column(name="txtnoticemapto")
    private String txtNoticeMapTo;
    
    @Column(name="flgisownerdelegated")
    private String flgIsOwnerDelegated;
    
    @Column(name="txttype")
    private String txtType;
    
    @Column(name="txtruletypedesc")
    private String txtRuleTypeDesc;
    
    @Column(name="flgisreopenreq")
    private String flgIsReopenReq;
    
    @Column(name="flgisadditionalfieldsreq")
    private String flgIsAdditionalFieldsReq;

}
