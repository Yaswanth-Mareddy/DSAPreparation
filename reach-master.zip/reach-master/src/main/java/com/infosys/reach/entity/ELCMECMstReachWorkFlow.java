package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmecmstreachworkflow")
public class ELCMECMstReachWorkFlow {

	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Column(name="intworkflowid")
	private int workFlowId;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="txtfromrole")
	private String fromRole;

	@Column(name="txtcurrentstatus")
	private String currentStatus;
	
	@Column(name="txttorole")
	private String toRole;

	@Column(name="txtnextstatus")
	private String nextStatus;

	@Column(name="txtcurrentstatusdescription")
	private String statusDescription;
	
	@Column(name="txtmaileventcode")
	private String mailEventCode;
	
	@Column(name="txtmessage")
	private String message;

	@Column(name="txtactionlabel")
	private String actionLabel;
	
	@Column(name="txttype")
	private String type;

	@Column(name="intuimoduleid")
	private int uiModuleId;
	
	@Column(name="intsladays")
	private int slaDays;

	@Column(name="flgactive")
	private int flgActive;
	
	@Column(name="txtdirection")
	private String direction;

}
