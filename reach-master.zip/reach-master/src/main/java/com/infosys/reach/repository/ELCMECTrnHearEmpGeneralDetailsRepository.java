package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnHearEmpGeneralDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnHearEmpGeneralDetailsRepository extends JpaRepository<ELCMECTrnHearEmpGeneralDetails, Integer>{
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnHearEmpGeneralDetails> S save(S entity);
}
