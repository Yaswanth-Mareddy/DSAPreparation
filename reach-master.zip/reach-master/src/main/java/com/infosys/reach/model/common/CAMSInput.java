package com.infosys.reach.model.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = Include.NON_NULL)
public class CAMSInput {

	private String appCode;
	private String contextName;
	private String contextValue;
	private String roleCode;
	private String isLoginUser;
	private String empId;
	private String contetxtNameFilter1;
	private String contetxtValueFilter1;
	private String contetxtNameFilter2;
	private String contetxtValueFilter2;
	private String contetxtNameFilter3;
	private String contetxtValueFilter3;
	private String contetxtNameFilter4;
	private String contetxtValueFilter4;
	
	public CAMSInput(String appCode, String contextName, String contextValue, String roleCode, String isLoginUser) {
		this(appCode, contextName, contextValue, roleCode, isLoginUser, null, null, null, null, null, null, null, null, null);
	}
	
	public CAMSInput(String appCode, String roleCode, String isLoginUser) {
		this(appCode, null, null, roleCode, isLoginUser, null, null, null, null, null, null, null, null, null);
	}
	
	public CAMSInput(String appCode, String roleCode, String moduleid, String isLoginUser) {
		this(appCode, null, null, roleCode, isLoginUser, null, Constants.MODULES, moduleid, null, null, null, null, null, null);
	}
	
	
}
