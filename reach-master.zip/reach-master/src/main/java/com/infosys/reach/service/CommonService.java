package com.infosys.reach.service;

import java.util.List;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.common.CAMSInput;
import com.infosys.reach.model.common.CAMSOutput;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;

public interface CommonService {

	public MailerAssistResponse triggerMail(MailerAssistRequest inputModel) throws CustomException;
	public DPServiceOutput dpService(String module,String task) throws CustomException;
	public List<CAMSOutput> camsService(String type, CAMSInput inputModel) throws CustomException;
	public DMSModel dmsService(DMSModel inputModel, String task) throws CustomException;
	public GMFields convertGenModelToObject(Object object, int type);
	public boolean validateFile(DocumentData file, String folder, List<String> validatedEvidences) throws CustomException;
	public String deleteFolder(String folder, List<String> validatedEvidences) throws CustomException;
	public String deleteFiles(List<String> files) throws CustomException;
	public String uploadFilesToDMS(String mailId, String folder, List<String> validatedEvidences, String dmsFolder) throws CustomException;
	public String getUIModuleId(String paramId);
	public CaseDetailsValidationResponse validateEmployeeDetails(String idString,String type);
	public List<DocumentData> downloadDocuments(String type, int transactionid, String filename) throws CustomException;
	public String validateAndUploadDocumentsToDMS(List<DocumentData> documents, String dmsFolder) throws CustomException;
	public List<GenModelOption> getCAMSRoles(String module, String isLoginUser, List<String> filter) throws CustomException ;
	public String getIdStringByRoleAndModule(String appCode, String roleCode, String moduleId, String filterContextName, String filterContextValue) throws CustomException;
	public void checkCaseAuthorization(int caseid, boolean isAdmin) throws CustomException;
	public boolean checkIsActionEnabled(String moduleid, String paramId, String status);
	public List<GenModelOption> getGenModelOptionsByModuleIdAndGroupId(int moduleid, String groupId) throws CustomException;
	
}
