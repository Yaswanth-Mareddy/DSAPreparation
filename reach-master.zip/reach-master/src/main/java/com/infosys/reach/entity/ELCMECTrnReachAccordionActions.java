package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;

@Getter
@Entity
@Table(name="elcmectrnreachaccordionactions")
public class ELCMECTrnReachAccordionActions {

	@Id
	@Column(name="intactionid")
	private int actionId;

	@Column(name="intmoduleid")
	private int moduleId;

	@Column(name="txtname")
	private String name;
	
	@Column(name="txtapitype")
	private String apiType;
	
	@Column(name="txtvalue")
	private String value;

	@Column(name="txttype")
	private String type;

	@Column(name="flgactive")
	private int flgActive;
}
