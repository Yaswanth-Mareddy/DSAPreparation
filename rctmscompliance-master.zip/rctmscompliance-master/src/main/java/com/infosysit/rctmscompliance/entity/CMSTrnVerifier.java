package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnverifier")
public class CMSTrnVerifier {

	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
	
	@Column(name="txtverifierid")
	private String txtVerifierID;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
}
