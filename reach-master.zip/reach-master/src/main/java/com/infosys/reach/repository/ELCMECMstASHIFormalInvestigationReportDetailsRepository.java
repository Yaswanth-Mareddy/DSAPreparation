package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstASHIFormalInvestigationReportDetails;

public interface ELCMECMstASHIFormalInvestigationReportDetailsRepository
		extends JpaRepository<ELCMECMstASHIFormalInvestigationReportDetails, Integer> {
	
	Optional<ELCMECMstASHIFormalInvestigationReportDetails> findByCaseId(int caseid);
	
	boolean existsByCaseId(int caseid);

}
