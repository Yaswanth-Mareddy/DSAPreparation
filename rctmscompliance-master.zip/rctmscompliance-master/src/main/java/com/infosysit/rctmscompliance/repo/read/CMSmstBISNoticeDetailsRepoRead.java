package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSmstBISNoticeDetails;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSmstBISNoticeDetailsRepoRead extends JpaRepository<CMSmstBISNoticeDetails, Integer> {

	@Query(value = CustomQueries.GETNOTICEDETAILFORBIS)
	public int getNoticedetailsBISActionitems(@Param("txtNoticeReferenceNo") String txtNoticeReferenceNo);
}
