package com.infosys.reach;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.reach.entity.ELCMECMstASHIFormalInvestigationReportDetails;
import com.infosys.reach.entity.ELCMECMstASHIPreliminaryDiscussionDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHIConciliationReportDetails;
import com.infosys.reach.entity.ELCMECTrnASHIInterimReliefDetails;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.CaseGenModelField;
import com.infosys.reach.model.ashimobile.CaseGenModelForm;
import com.infosys.reach.model.ashimobile.CaseGenModelFormData;
import com.infosys.reach.model.common.CAMSInput;
import com.infosys.reach.model.common.CAMSOutput;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailInfo;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.PlaceHolder;
import com.infosys.reach.model.common.WebServiceOutput;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelForm;
import com.infosys.reach.model.generic.GenModelFormData;
import com.infosys.reach.model.generic.GenModelFormObj;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.repository.ELCMECMstASHIFormalInvestigationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIPreliminaryDiscussionDetailsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIConciliationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIInterimReliefDetailsRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.service.WebServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Property;

@ExtendWith(MockitoExtension.class)
class CommonServiceTests {

	@InjectMocks
	CommonServiceImpl commonservice;
	
	@Mock
	WebServiceImpl webservice;
	
	@Mock
	Property property;
	
	@Mock
	ViewCurrEmpAllDetailsRepository empDetailsRepository;
	
	@Mock
	ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Mock
	ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;
	
	@Mock
	ELCMECMstASHIPreliminaryDiscussionDetailsRepository preliminaryDiscussionDetailsRepository;
	
	@Mock
	ELCMECTrnASHIInterimReliefDetailsRepository interimReliefRepository;
	
	@Mock
	ELCMECTrnASHIConciliationReportDetailsRepository conciliationReportDetailsRepository;
	
	@Mock
	ELCMECMstASHIFormalInvestigationReportDetailsRepository formalInvestigationReportDetailsRepository;
	
	@Test
	void triggerMailTest1() throws Exception {
		MailerAssistResponse expected =  new MailerAssistResponse(0, "mail triggered successfully");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.isFlgTriggerMail()).thenReturn(true);
		
		PlaceHolder[] placeholder = {new PlaceHolder()};
		MailerAssistResponse actual = commonservice.triggerMail(new MailerAssistRequest(new MailInfo("", "", 10, "", "", ""), placeholder));
		
		assertEquals(expected.getCode(), actual.getCode());
		assertEquals(expected.getMessage(), actual.getMessage());
		
	}
	
	@Test
	void triggerMailTest2() throws Exception {
		String expected = "Status : 400, Output : bad request";
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(new WebServiceOutput(400, "bad request"));
		
		Mockito.when(property.isFlgTriggerMail()).thenReturn(false);
		
		PlaceHolder[] placeholder = {new PlaceHolder()};
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.triggerMail(new MailerAssistRequest(new MailInfo("", "", 10, "", "", ""), placeholder)),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void triggerMailTest3() throws Exception {
		String expected =  "exception";

		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenThrow(new CustomException(expected));
		
		Mockito.when(property.isFlgTriggerMail()).thenReturn(false);
		
		PlaceHolder[] placeholder = {new PlaceHolder()};
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.triggerMail(new MailerAssistRequest(new MailInfo("", "", 10, "", "", ""), placeholder)),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void dpServiceTest1() throws Exception {
		DPServiceOutput expected =  new DPServiceOutput("true");

		WebServiceOutput output = new WebServiceOutput(200, "true");
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getAshiParentId()).thenReturn("abc");
		Mockito.when(property.getAshiChildId()).thenReturn("abc");
		Mockito.when(property.getDpUpdateStatusURL()).thenReturn("abc");
		
		DPServiceOutput actual = commonservice.dpService("ASHI", "SAVE");
		
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void dpServiceTest2() throws Exception {
		DPServiceOutput expected =  new DPServiceOutput("true");

		WebServiceOutput output = new WebServiceOutput(200, "[{strParentConsentStatus:true}]");
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getHearParentId()).thenReturn("abc");
		Mockito.when(property.getHearChildId()).thenReturn("abc");
		Mockito.when(property.getDpStatusURL()).thenReturn("abc");
		
		DPServiceOutput actual = commonservice.dpService("HEAR", "STATUS");
		
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void dpServiceTest3() throws Exception {
		DPServiceOutput expected =  new DPServiceOutput("dp consent");

		WebServiceOutput output = new WebServiceOutput(200, "[{strTemplateContent:dp consent}]");
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getHearParentId()).thenReturn("abc");
		Mockito.when(property.getHearChildId()).thenReturn("abc");
		Mockito.when(property.getDpConsentURL()).thenReturn("abc");
		
		DPServiceOutput actual = commonservice.dpService("HEAR", "CONTENT");
		
		assertEquals(expected.getContent(), actual.getContent());
		
	}
	
	@Test
	void dpServiceTest4() throws Exception {
		String expected = "Status : 400, Output : bad request";
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(new WebServiceOutput(400, "bad request"));
		
		Mockito.when(property.getHearParentId()).thenReturn("abc");
		Mockito.when(property.getHearChildId()).thenReturn("abc");
		Mockito.when(property.getDpConsentURL()).thenReturn("abc");

		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.dpService("HEAR", "CONTENT"),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void dpServiceTest5() throws Exception {
		String expected =  "exception";

		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenThrow(new CustomException(expected));
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.dpService("HEAR", "CONSENT"),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void dmsServiceTest1() throws Exception {
		DMSModel expected = new DMSModel();
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsUploadURL()).thenReturn("abc");
		
		DMSModel actual = commonservice.dmsService(new DMSModel(), Constants.UPLOAD);
		
		assertThat(actual).hasSameClassAs(expected);
		
	}
	
	@Test
	void dmsServiceTest2() throws Exception {
		String expected = "Status : 400, Output : bad request";
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(new WebServiceOutput(400, "bad request"));
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");

		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.dmsService(new DMSModel(), Constants.DOWNLOAD),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void dmsServiceTest3() throws Exception {
		String expected =  "exception";

		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenThrow(new CustomException(expected));
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.dmsService(new DMSModel(), "dba"),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void camsServiceTest1() throws Exception {
		List<CAMSOutput> expected = new ArrayList<>();
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "IC", "Internal committee", "IC", "Location", "Pune",""));
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getCamsContextURL()).thenReturn("abc");
		
		//List<CAMSOutput> actual = commonservice.camsService(Constants.CONTEXT, new CAMSInput());
		List<GenModelOption> actual = commonservice.getCamsContextDropdown("ECS", "IC", "Modules", "2", "Location", "yes");
		
		assertEquals(expected.size(), actual.size());
		
	}
	
	@Test
	void camsServiceTest2() throws Exception {
		String expected = "Status : 400, Output : bad request";
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(new WebServiceOutput(400, "bad request"));
		
		Mockito.when(property.getCamsRolesURL()).thenReturn("abc");

		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.camsService("ROLES", new CAMSInput()),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void camsServiceTest3() throws Exception {
		String expected =  "exception";

		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenThrow(new CustomException(expected));
		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.camsService("abc", new CAMSInput()),
		expected
		);

		assertTrue(thrown.getMessage().contains(expected));
		
	}
	
	@Test
	void getIdsByRoleAndModuleAndContextTest1() throws Exception {
		List<CAMSOutput> expected = new ArrayList<>();
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "IC", "Internal committee", "IC", "Location", "Pune",""));
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getCamsContextURL()).thenReturn("abc");
		Mockito.when(property.getInfyDomain()).thenReturn("@infosys.com");
		
		String actual = commonservice.getIdStringByRoleAndModule("IC", "2", "IN", "INFSYS", "Pune");
		
		assertEquals("suraj.kumar@infosys.com;", actual);
		
	}
	
	@Test
	void getIdsForCamsContextDropdownTest1() throws Exception {
		List<CAMSOutput> expected = new ArrayList<>();
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "IC", "Internal Committee", "IC", "Location", "Pune", ""));

		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getCamsContextURL()).thenReturn("abc");
		
		List<GenModelOption> actual = commonservice.getIdsByModuleAndRole("IC", "2", "IN", "INFSYS", "Pune", "No");
		
		assertEquals(1, actual.size());
		
	}
	
	@Test
	void getCAMSRolesTest1() throws Exception {
		List<CAMSOutput> expected = new ArrayList<>();
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "IC", "Internal committee", "IC", "Location", "Pune",""));
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "GRB", "GRB", "ECS", "Location", "Pune",""));
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getCamsRolesURL()).thenReturn("abc");
		
		List<GenModelOption> actual = commonservice.getCAMSRoles("2", "Yes", Arrays.asList("GRB"));
		
		assertEquals(1, actual.size());
		
	}
	
	@Test
	void getCAMSRolesTest2() throws Exception {
		List<CAMSOutput> expected = new ArrayList<>();
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "IC", "Internal committee", "IC", "Location", "Pune",""));
		expected.add(new CAMSOutput("1030816", "suraj", "suraj.kumar", "GRB", "GRB", "ECS", "Location", "Pune",""));
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getCamsRolesURL()).thenReturn("abc");
		
		List<GenModelOption> actual = commonservice.getCAMSRoles("2", "Yes", new ArrayList<>());
		
		assertEquals(2, actual.size());
		
	}
	
	@Test
	void convertGenModelToObjectTest1() {
		List<String> keys = Arrays.asList("raisingFor", "respondentType", "isRespondentKnown", "respondentsOther", "respondentsInfy", "complainantType", "isComplainantKnown", "complainantsOther", "complainantsInfy");
		List<String> values = Arrays.asList("1", "1", "1", "person", "1030816", "1", "1", "person", "1030816");
		List<CaseGenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			fields.add(new CaseGenModelField(keys.get(i), values.get(i)));
		}
		GMFields actual = commonservice.convertGenModelToObject(new CaseFormGenModel("", "", new CaseGenModelFormData(Arrays.asList(new CaseGenModelForm(fields))),  new CaseGenModelFormData(), new ArrayList<>()), 2);

		assertEquals(1, actual.getRaisingFor());
		assertEquals(1, actual.getRespondentType());
		assertEquals(1, actual.getIsRespondentKnown());
		assertEquals("person", actual.getRespondentsOther());
		assertEquals("1030816", actual.getRespondentsInfy());
		assertEquals(1, actual.getComplainantType());
		assertEquals(1, actual.getIsComplainantKnown());
		assertEquals("person", actual.getComplainantsOther());
		assertEquals("1030816", actual.getComplainantsInfy());
	}
	
	@Test
	void convertGenModelToObjectTest2() {
		List<String> keys = Arrays.asList("country", "baseLocation", "description", "placeOfIncident", "complaintCategory", "cocomplainants", "witnesses", "isStakeHolder", "stakeholderRole", "stakeholder");
		List<Object> values = Arrays.asList("INDIA", "Pune", "testing testing", "workplace", "Quid pro", "1030816", "1030816", "1", "Manager", "1030816");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			if(keys.get(i).equals(Constants.COMPLAINT_CATEGORY)){
				fields.add(new GenModelField(1, keys.get(i), values.get(i), Arrays.asList(new GenModelOption("1", "Quid pro"))));
			}
			else
				fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", Arrays.asList(new GenModelFormObj(new GenModelFormData(Arrays.asList(new GenModelForm("", fields))), new GenModelFormData())), new ArrayList<>()), 1);
		
		assertEquals("INDIA", actual.getCountry());
		assertEquals("Pune", actual.getBaseLocation());
		assertEquals("testing testing", actual.getDescription());
		assertEquals("workplace", actual.getPlaceOfIncident());
		assertEquals(1, actual.getComplaintCategory());
		assertEquals("1030816", actual.getCocomplainants());
		assertEquals("1030816", actual.getWitnesses());
		assertEquals(1, actual.getIsStakeHolder());
		assertEquals("Manager", actual.getStakeholderRole());
		assertEquals("1030816", actual.getStakeholder());
	}
	
	@Test
	void convertGenModelToObjectTest3() {
		List<String> keys = Arrays.asList("evidences", "caseid", "isChecked", "isChecked", "role", "company", "location", "status", "location", "status");
		List<Object> values = Arrays.asList(Arrays.asList(new DocumentData("file.pdf", "base64file")), "1", "1", Constants.ACCEPT, "GRB", "INFSYS", "", "", "Pune,Hyderabad", "WE,WG");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals(1, actual.getEvidences().size());
		assertEquals(1, actual.getCaseid());
		assertEquals(true, actual.isDPAccepted());
		assertEquals(true, actual.isDPAccepted());
		assertEquals("GRB", actual.getRole());
		assertEquals("INFSYS", actual.getCompany());
		assertEquals(2, actual.getLocation().size());
		assertEquals(2, actual.getStatus().size());
	}
	
	@Test
	void convertGenModelToObjectTest4() {
		List<String> keys = Arrays.asList("discussedOn", "discussedWith", "summaryOfDiscussion", "documents", "comments", "assignedRole", "assignedLocation", "assignedTo", Constants.COMPLAINANT);
		List<Object> values = Arrays.asList("07-Nov-1992", "suraj", "testing testing", Arrays.asList(new DocumentData("file.pdf", "base64file")), "comment", "IC", "Pune", "1030816", "suraj");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals(1, actual.getDocuments().size());
		assertEquals("07-Nov-1992", actual.getDiscussedOn());
		assertEquals("suraj", actual.getDiscussedWith());
		assertEquals("testing testing", actual.getDiscussionSummary());
		assertEquals("comment", actual.getComments());
		assertEquals("IC", actual.getAssignedRole());
		assertEquals("Pune", actual.getAssignedLocation());
		assertEquals("1030816", actual.getAssignedTo());
		assertEquals("suraj", actual.getComplainant());
	}
	
	@Test
	void convertGenModelToObjectTest5() {
		List<String> keys = Arrays.asList("flgRelief", "flgRelief", "flgRelief", "reliefs", "otherRelief", "reliefs", "otherRelief", "conciliationAggrementDocs", "remarks", "mailTo", "investigationType", "conciliationReason", "conciliationFindings", "conciliationRecommendations");
		List<Object> values = Arrays.asList("1", "yes", "no", new ArrayList<>(), "coupon", Arrays.asList("1"), "bonus", Arrays.asList(new DocumentData("file.pdf", "base64file")), "remark", "suraj", Constants.CONCILIATION, "reason", "finding", "recommendations");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			if(keys.get(i).equals("mailTo")){
				fields.add(new GenModelField(1, keys.get(i), values.get(i), Arrays.asList(new GenModelOption("1030816", "suraj"))));
			}
			else if(keys.get(i).equals("reliefs")){
				fields.add(new GenModelField(77, keys.get(i), values.get(i), Arrays.asList(new GenModelOption("1", "WFH"))));
			}
			else
				fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals(1, actual.getConciliationAggrementDocs().size());
		assertEquals(2, actual.getFlgRelief());
		assertEquals("WFH,bonus", actual.getReliefs());
		assertEquals("remark", actual.getRemarks());
		assertEquals("1030816", actual.getMailTo());
		assertEquals(Constants.CONCILIATION, actual.getInvestigationType());
		assertEquals("reason", actual.getConciliationReason());
		assertEquals("finding", actual.getConciliationFindings());
		assertEquals("recommendations", actual.getConciliationRecommendations());
	}
	
	@Test
	void convertGenModelToObjectTest6() {
		List<String> keys = Arrays.asList("action", "transactionid", Constants.RESPONDENT, Constants.WITNESS, "actionAgainst", "severityLevel", "recommendedActions", "recommendedActions", "summonsTo", "summonsWith", "formalCaseSummary");
		List<Object> values = Arrays.asList("action", "123", "1030816", "1030816", "actionAgainst", "severityLevel", new ArrayList<>(), Arrays.asList("1"), "summonsTo", "summonsWith", "formalCaseSummary");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			if(keys.get(i).equals("recommendedActions")){
				fields.add(new GenModelField(149, keys.get(i), values.get(i), Arrays.asList(new GenModelOption("1", "Suspend"))));
			}
			else
				fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals("action", actual.getAction());
		assertEquals("123", actual.getTransactionid());
		assertEquals("1030816", actual.getRespondent());
		assertEquals("1030816", actual.getWitness());
		assertEquals("actionAgainst", actual.getActionAgainst());
		assertEquals("severityLevel", actual.getSeverityLevel());
		assertEquals("Suspend", actual.getRecommendedActions());
		assertEquals("summonsTo", actual.getSummonsTo());
		assertEquals("summonsWith", actual.getSummonsWith());
		assertEquals("formalCaseSummary", actual.getFormalCaseSummary());
	}
	
	@Test
	void convertGenModelToObjectTest7() {
		List<String> keys = Arrays.asList("formalOtherRecommendation", "formalInvestigationDocs", "investigationPanelApprovals", "flgInvestigationPanelApproval", "investigationPanelReason", "presidingOfficersApprovals", "flgPresidingOfficersApproval", "presidingOfficersReason", "extICMembersapprovals", "flgExtICMembersApproval", "extICMembersReason");
		List<Object> values = Arrays.asList("formalOtherRecommendation", Arrays.asList(new DocumentData("file.pdf", "base64file")), Arrays.asList(new DocumentData("file.pdf", "base64file")), "1", "investigationPanelReason", Arrays.asList(new DocumentData("file.pdf", "base64file")), "1", "presidingOfficersReason", Arrays.asList(new DocumentData("file.pdf", "base64file")), "1", "extICMembersReason");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals("formalOtherRecommendation", actual.getFormalOtherRecommendation());
		assertEquals(1, actual.getFormalInvestigationDocs().size());
		assertEquals(1, actual.getInvestigationPanelApprovals().size());
		assertEquals(1, actual.getPresidingOfficersApprovals().size());
		assertEquals(1, actual.getExtICMembersapprovals().size());
		assertEquals(1, actual.getFlgInvestigationPanelApproval());
		assertEquals(1, actual.getFlgPresidingOfficersApproval());
		assertEquals(1, actual.getFlgExtICMembersApproval());
		assertEquals("investigationPanelReason", actual.getInvestigationPanelReason());
		assertEquals("presidingOfficersReason", actual.getPresidingOfficersReason());
		assertEquals("extICMembersReason", actual.getExtICMembersReason());
	}
	
	@Test
	void convertGenModelToObjectTest8() {
		List<String> keys = Arrays.asList("slaExtendDate", "extensionReason", "recipientType", "recipient", "recipient", "allegationDesc", "findings", "outcome", "incidentDate", "implementationDocs", "checklistRespondent", "flgBothPartiesClosure", "response", "template");
		List<Object> values = Arrays.asList("07-Nov-1992", "extensionReason", "recipientType", new ArrayList<>(), Arrays.asList("1030816"), "allegationDesc", "findings", "outcome", "07-Nov-1992", Arrays.asList(new DocumentData("file.pdf", "base64file")), "", "1", "response", "template");
		List<GenModelField> fields = new ArrayList<>();
		
		for(int i=0; i<keys.size(); i++) {
			if(keys.get(i).equals("checklistRespondent")){
				fields.add(new GenModelField(149, keys.get(i), values.get(i), Arrays.asList(new GenModelOption("1", "suraj", true), new GenModelOption("2", "dinesh", false))));
			}
			else
				fields.add(new GenModelField(1, keys.get(i), values.get(i), new ArrayList<>()));
		}
		GMFields actual = commonservice.convertGenModelToObject(new GenModel("", "", fields), 0);
		
		assertEquals(1, actual.getImplementationDocs().size());
		assertEquals("07-Nov-1992", actual.getSlaExtendDate());
		assertEquals("extensionReason", actual.getExtensionReason());
		assertEquals("recipientType", actual.getRecipientType());
		assertEquals("1030816", actual.getRecipient());
		assertEquals("allegationDesc", actual.getAllegationDesc());
		assertEquals("findings", actual.getFindings());
		assertEquals("outcome", actual.getOutcome());
		assertEquals("07-Nov-1992", actual.getIncidentDate());
		assertEquals("response", actual.getResponse());
		assertEquals("template", actual.getTemplate());
		assertEquals(1, actual.getFlgBothPartiesClosure());
		assertEquals(1, actual.getCheckedRecommendations().get(0));
		assertEquals(2, actual.getUncheckedRecommendations().get(0));
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest1() throws Exception {
		DMSModel expected = new DMSModel();
		expected.setDocumentID("akjdbakfba");
		expected.setDocumentName("file.txt");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsUploadURL()).thenReturn("abc");
	
		
		Mockito.when(property.getTempStoragePath()).thenReturn("D:\\");
		Mockito.when(webservice.filevalidationService(Mockito.any(), Mockito.anyString())).thenReturn(true);
		
		List<DocumentData> docs = Arrays.asList(new DocumentData("file.txt", "QUxURVIgVEFCTEUgW3Rlc3Rvd25lcl0uW0VMQ01FQ01zdEFTSElXb3JrRmxvd10gQUREIFtpbnRTTEFEYXlzXSBJTlQgREVGQVVMVCgwKTsNCkFMVEVSIFRBQkxFIFt0ZXN0b3duZXJdLltFTENNRUN0cm5BU0hJQ29uY2VyblNMQURldGFpbHNdIEFERCBbdHh0U3RhdHVzXSBWQVJDSEFSKDEwKSBOVUxMOw=="));
		String actual = commonservice.validateAndUploadDocumentsToDMS(docs, "folder");
		
		assertEquals("file.txt", actual);
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest2() throws Exception {
		String expected = "Invalid File. Unable to upload file.txt";

		Mockito.when(property.getTempStoragePath()).thenReturn("D:\\");
		Mockito.when(webservice.filevalidationService(Mockito.any(), Mockito.anyString())).thenReturn(false);
		
		List<DocumentData> docs = Arrays.asList(new DocumentData("file.txt", "QUxURVIgVEFCTEUgW3Rlc3Rvd25lcl0uW0VMQ01FQ01zdEFTSElXb3JrRmxvd10gQUREIFtpbnRTTEFEYXlzXSBJTlQgREVGQVVMVCgwKTsNCkFMVEVSIFRBQkxFIFt0ZXN0b3duZXJdLltFTENNRUN0cm5BU0hJQ29uY2VyblNMQURldGFpbHNdIEFERCBbdHh0U3RhdHVzXSBWQVJDSEFSKDEwKSBOVUxMOw=="));
		String actual = commonservice.validateAndUploadDocumentsToDMS(docs, "folder");
		
		assertEquals(expected, actual);
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest3() throws Exception {
				
		Mockito.when(property.getTempStoragePath()).thenReturn("D:\\temp\\");		
		List<DocumentData> docs = Arrays.asList(new DocumentData("file.msg", ""));

		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.validateAndUploadDocumentsToDMS(docs, "folder"),
		""
		);

		assertTrue(thrown.getMessage().contains(""));
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest4() throws Exception {
		DMSModel expected = new DMSModel();
		expected.setDocumentID("");
		expected.setDocumentName("file.txt");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsUploadURL()).thenReturn("abc");
	
		
		Mockito.when(property.getTempStoragePath()).thenReturn("D:\\");
		Mockito.when(webservice.filevalidationService(Mockito.any(), Mockito.anyString())).thenReturn(true);
		
		List<DocumentData> docs = Arrays.asList(new DocumentData("file.txt", "QUxURVIgVEFCTEUgW3Rlc3Rvd25lcl0uW0VMQ01FQ01zdEFTSElXb3JrRmxvd10gQUREIFtpbnRTTEFEYXlzXSBJTlQgREVGQVVMVCgwKTsNCkFMVEVSIFRBQkxFIFt0ZXN0b3duZXJdLltFTENNRUN0cm5BU0hJQ29uY2VyblNMQURldGFpbHNdIEFERCBbdHh0U3RhdHVzXSBWQVJDSEFSKDEwKSBOVUxMOw=="));

		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.validateAndUploadDocumentsToDMS(docs, "folder"),
		"Unable to upload file file.txt"
		);

		assertTrue(thrown.getMessage().startsWith("Unable to upload file"));
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest5() throws Exception {
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenThrow(new CustomException("exception"));
		
		Mockito.when(property.getDmsUploadURL()).thenReturn("abc");
	
		
		Mockito.when(property.getTempStoragePath()).thenReturn("D:\\");
		Mockito.when(webservice.filevalidationService(Mockito.any(), Mockito.anyString())).thenReturn(true);
		
		List<DocumentData> docs = Arrays.asList(new DocumentData("file.txt", "QUxURVIgVEFCTEUgW3Rlc3Rvd25lcl0uW0VMQ01FQ01zdEFTSElXb3JrRmxvd10gQUREIFtpbnRTTEFEYXlzXSBJTlQgREVGQVVMVCgwKTsNCkFMVEVSIFRBQkxFIFt0ZXN0b3duZXJdLltFTENNRUN0cm5BU0hJQ29uY2VyblNMQURldGFpbHNdIEFERCBbdHh0U3RhdHVzXSBWQVJDSEFSKDEwKSBOVUxMOw=="));

		
		CustomException thrown = assertThrows(
		CustomException.class,
		() -> commonservice.validateAndUploadDocumentsToDMS(docs, "folder"),
		"exception"
		);

		assertTrue(thrown.getMessage().contains("exception"));
	}
	
	@Test
	void validateAndUploadDocumentsToDMSTest6() throws Exception {
		assertThrows(
		CustomException.class,
		() -> commonservice.deleteFolder("folder", new ArrayList<>()),
		""
		);
	}

	@Test
	void getUIModuleIdTest1() {
		ELCMECMstSysParams expected = new ELCMECMstSysParams();
		expected.setParamDesc("1234");
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.of(expected));
		
		String actual = commonservice.getUIModuleId("ADIN");
		
		assertEquals(expected.getParamDesc(), actual);
	}
	
	@Test
	void getUIModuleIdTest2() {
		Mockito.when(elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(Mockito.anyString(), Mockito.anyString())).thenReturn(Optional.empty());
		
		String actual = commonservice.getUIModuleId("ADIN");
		
		assertTrue(actual.isEmpty());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void validateEmployeeDetailsTest() {
		
		Mockito.when(empDetailsRepository.findByEmpNoOrMailId(Mockito.anyString())).thenReturn(Optional.of(new ViewCurrEmpAllDetails("suraj.kumar", "1030816", "suraj")), Optional.of(new ViewCurrEmpAllDetails("suraj.kumar", "1030816", "suraj")), Optional.empty());
		
		CaseDetailsValidationResponse actual1 = commonservice.validateEmployeeDetails("1030186", Constants.COMPLAINANT);
		CaseDetailsValidationResponse actual2 = commonservice.validateEmployeeDetails("HR|1030186", Constants.STAKEHOLDER);
		CaseDetailsValidationResponse actual3 = commonservice.validateEmployeeDetails("1030186", Constants.RESPONDENT);
		
		assertTrue(actual1.isStatus());
		assertTrue(actual2.isStatus());
		assertTrue(!actual3.isStatus());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void downloadDocumentsTest1() throws Exception {
		
		ELCMECTrnASHIActionDetails obj = new ELCMECTrnASHIActionDetails();
		obj.setDmsFileName("file.pdf");
		Mockito.when(ashiActionDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(obj), Optional.empty(), Optional.of(obj), Optional.empty());
		
		DMSModel expected = new DMSModel();
		expected.setDocumentName("file.pdf");
		expected.setDocumentBytes("base64");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("A", 123, "file.pdf");
		List<DocumentData> actual2 = commonservice.downloadDocuments("A", 123, "file.pdf");
		List<DocumentData> actual3 = commonservice.downloadDocuments("ID", 123, "file.pdf");
		List<DocumentData> actual4 = commonservice.downloadDocuments("ID", 123, "file.pdf");
		
		assertEquals(1, actual1.size());
		assertEquals(0, actual2.size());
		assertEquals(1, actual3.size());
		assertEquals(0, actual4.size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void downloadDocumentsTest2() throws Exception {
		
		ELCMECMstASHIPreliminaryDiscussionDetails obj = new ELCMECMstASHIPreliminaryDiscussionDetails();
		obj.setDmsFileName("file.pdf");
		Mockito.when(preliminaryDiscussionDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(obj), Optional.empty());
		
		DMSModel expected = new DMSModel();
		expected.setDocumentName("file.pdf");
		expected.setDocumentBytes("base64");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("P", 123, "file.pdf");
		List<DocumentData> actual2 = commonservice.downloadDocuments("P", 123, "file.pdf");
		
		assertEquals(1, actual1.size());
		assertEquals(0, actual2.size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void downloadDocumentsTest3() throws Exception {
		
		ELCMECTrnASHIInterimReliefDetails obj = new ELCMECTrnASHIInterimReliefDetails();
		obj.setDmsFiles("file.pdf");
		Mockito.when(interimReliefRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(obj), Optional.empty());
		
		DMSModel expected = new DMSModel();
		expected.setDocumentName("file.pdf");
		expected.setDocumentBytes("base64");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("IR", 123, Constants.ALL);
		List<DocumentData> actual2 = commonservice.downloadDocuments("IR", 123, "file.pdf");
		
		assertEquals(1, actual1.size());
		assertEquals(0, actual2.size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void downloadDocumentsTest4() throws Exception {
		
		ELCMECTrnASHIConciliationReportDetails obj = new ELCMECTrnASHIConciliationReportDetails();
		obj.setAgreementDocs("file.pdf");
		obj.setOtherDocs("file.pdf");
		Mockito.when(conciliationReportDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(obj), Optional.empty(), Optional.of(obj), Optional.empty());
		
		DMSModel expected = new DMSModel();
		expected.setDocumentName("file.pdf");
		expected.setDocumentBytes("base64");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("CRA", 123, "file.pdf");
		List<DocumentData> actual2 = commonservice.downloadDocuments("CRA", 123, "file.pdf");
		List<DocumentData> actual3 = commonservice.downloadDocuments("CRO", 123, "file.pdf");
		List<DocumentData> actual4 = commonservice.downloadDocuments("CRO", 123, "file.pdf");
		
		assertEquals(1, actual1.size());
		assertEquals(0, actual2.size());
		assertEquals(1, actual3.size());
		assertEquals(0, actual4.size());
	}
	
	@SuppressWarnings("unchecked")
	@Test
	void downloadDocumentsTest5() throws Exception {
		
		ELCMECMstASHIFormalInvestigationReportDetails obj = new ELCMECMstASHIFormalInvestigationReportDetails();
		obj.setDmsInvestigationPanelApprovals("file.pdf");
		obj.setDmsPresidingOfficersApprovals("file.pdf");
		obj.setDmsExtICMembersApprovals("file.pdf");
		Mockito.when(formalInvestigationReportDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(obj), Optional.empty(), Optional.of(obj), Optional.empty(), Optional.of(obj), Optional.empty());
		
		DMSModel expected = new DMSModel();
		expected.setDocumentName("file.pdf");
		expected.setDocumentBytes("base64");
		
		String jsonOutputString = new ObjectMapper().writeValueAsString(expected);
		WebServiceOutput output = new WebServiceOutput(200, jsonOutputString);
		Mockito.when(webservice.consumeRestService(Mockito.any(), Mockito.anyString(), Mockito.anyBoolean(), Mockito.any(), Mockito.anyString())).thenReturn(output);
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("ADI", 123, "file.pdf");
		List<DocumentData> actual2 = commonservice.downloadDocuments("ADI", 123, "file.pdf");
		List<DocumentData> actual3 = commonservice.downloadDocuments("ADP", 123, "file.pdf");
		List<DocumentData> actual4 = commonservice.downloadDocuments("ADP", 123, "file.pdf");
		List<DocumentData> actual5 = commonservice.downloadDocuments("ADE", 123, "file.pdf");
		List<DocumentData> actual6 = commonservice.downloadDocuments("ADE", 123, "file.pdf");
		
		assertEquals(1, actual1.size());
		assertEquals(0, actual2.size());
		assertEquals(1, actual3.size());
		assertEquals(0, actual4.size());
		assertEquals(1, actual5.size());
		assertEquals(0, actual6.size());
	}
	
	@Test
	void downloadDocumentsTest6() throws Exception {
		
		List<DocumentData> actual1 = commonservice.downloadDocuments("X", 123, "file.pdf");
		
		assertEquals(0, actual1.size());
	}
	
}
