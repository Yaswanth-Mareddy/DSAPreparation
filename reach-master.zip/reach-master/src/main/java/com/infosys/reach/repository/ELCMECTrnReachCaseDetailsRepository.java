package com.infosys.reach.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnReachCaseDetails;



public interface ELCMECTrnReachCaseDetailsRepository extends JpaRepository<ELCMECTrnReachCaseDetails, String>{ 
	
}
