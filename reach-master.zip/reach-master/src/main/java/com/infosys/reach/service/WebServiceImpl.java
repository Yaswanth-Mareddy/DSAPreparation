package com.infosys.reach.service;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.springframework.stereotype.Service;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.WebServiceOutput;
import com.infosys.reach.util.Constants;

@Service
public class WebServiceImpl implements WebService {

	/* 
	Authorization Types:
	0 - No Authorization
	1 - Bearer
	2 - Basic
	 */
	@Override
	public WebServiceOutput consumeRestService(String strURL, String apiType, boolean isAuthorized, String authorizationString, String input) throws CustomException {
		try {
			URL url=new URL(strURL);
			HttpURLConnection conn=(HttpURLConnection) url.openConnection();
			conn.setDoOutput(true);
			conn.setInstanceFollowRedirects(false);
			conn.setRequestMethod(apiType);
			conn.setRequestProperty(Constants.CONTENTTYPE, Constants.JSON);
			if(isAuthorized)
				conn.addRequestProperty(Constants.AUTHORIZATION, authorizationString);
			conn.connect();

			if(apiType.equals(Constants.POST)) {
				OutputStream os = conn.getOutputStream();
				os.write(input.getBytes(StandardCharsets.UTF_8));
				os.close();
			}

			// read the response
			InputStream in;
			if(conn.getResponseCode()==200)
				in = new BufferedInputStream(conn.getInputStream());
			else
				in = new BufferedInputStream(conn.getErrorStream());
			String result = org.apache.commons.io.IOUtils.toString(in, StandardCharsets.UTF_8);
			in.close();
			conn.disconnect();
			return new WebServiceOutput(conn.getResponseCode(), result);
		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}
	
	@Override
	public boolean filevalidationService(String url, String tempfileFullPath) throws CustomException {
		File f = new File(tempfileFullPath);
		try(
				CloseableHttpClient httpClient = HttpClients.createDefault();
				FileInputStream is = new FileInputStream(f);
				) {

			HttpPost uploadFile = new HttpPost(url);
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.addTextBody("field1", "yes", ContentType.TEXT_PLAIN);

			builder.addBinaryBody(
					"file",
					is,
					ContentType.APPLICATION_OCTET_STREAM,
					f.getName()
					);

			HttpEntity multipart = builder.build();
			uploadFile.setEntity(multipart);
			CloseableHttpResponse response = httpClient.execute(uploadFile);
			HttpEntity responseEntity = response.getEntity();

			InputStream in = new BufferedInputStream(responseEntity.getContent());
			String result = org.apache.commons.io.IOUtils.toString(in, StandardCharsets.UTF_8);
			return result.equals("File is Valid");

		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}
}
