package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnConfigurableInstanceDetails;
import com.infosysit.rctmscompliance.model.ComplianceConfigurableDetails;

@Repository
public interface CMSTrnConfigurableInstanceDetailsRepoRead extends JpaRepository<CMSTrnConfigurableInstanceDetails, Integer> {

	List<ComplianceConfigurableDetails> findAllByIntComplianceID(int intComplianceID);
	
	@Query(value="SELECT distinct CID.intComplianceID FROM CMSTrnConfigurableInstanceDetails AS CID WHERE CID.intComplianceID = :intComplianceID AND CID.dtAssignedDate = :dtAssignedDate")
	public int getComplianceIdFromConifgurationInstance(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
}
