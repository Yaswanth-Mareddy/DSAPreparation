package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardViewField {

	private String label;
	private String value;
	private int type;
	private List<GenModelOption> options;
	
	public CardViewField(String label, String value, int type) {
		super();
		this.label = label;
		this.value = value;
		this.type = type;
		this.options = new ArrayList<>();
		
		if(type==120) {
			this.value = "";
			for(String option : value.split(",")) {
				this.options.add(new GenModelOption(option, option));
			}
		}

	}
	
	
}
