package com.infosysit.itsm.controller;



import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



import com.infosysit.itsm.util.Message;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import com.infosysit.itsm.service.ITSMServiceImpl;


@RestController
@RequestMapping("/api/v1/ITSM")
public class ITSMController {
	@Autowired
	private ITSMServiceImpl service;
	
	@Autowired
	private ITSMInterceptor itsmInterceptor;
	

	
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "100000") })
 	@PostMapping(path = "/DecisionAnalysis", produces = "application/json")
	 public ResponseEntity<Object> decisionAnalysis() {
 		
		try {
			boolean statusDecision=service.decisionAnalysis();
			itsmInterceptor.setLogEventData("Successfully executed DecisionAnalysis");
			return  ResponseEntity.ok(statusDecision);	
			
		} catch (Exception e) {
		
			itsmInterceptor.setExeceptionEventData("Message "+e.getMessage(),"StackTrace "+ Arrays.toString(e.getStackTrace()), "DecisionAnalysis");
			return ResponseEntity.ok(Message.SOMEERROROCCURED);
		}
 		
 	}
	
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "100000") })
 	@PostMapping(path = "/AutoResponse", produces = "application/json")
	 public ResponseEntity<Object> autoResponse(){
 		
		try {
			boolean statusAuto=service.autoResponse();
			itsmInterceptor.setLogEventData("Successfully executed AutoResponse");
			return  ResponseEntity.ok(statusAuto);	
			
		} catch (Exception e) {
			
			itsmInterceptor.setExeceptionEventData("Message "+e.getMessage(), "StackTrace "+Arrays.toString(e.getStackTrace()), "AutoResponse");
			return ResponseEntity.ok( Message.SOMEERROROCCURED);
		}
 		
 	}
	
	public ResponseEntity<Object> defaultFallback() {
        return ResponseEntity.ok( "Timeout! FallBack of Method");
    }
		
}
