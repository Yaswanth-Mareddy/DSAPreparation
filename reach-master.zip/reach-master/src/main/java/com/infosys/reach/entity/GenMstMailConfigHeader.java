package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="genmstmailconfigheader")
public class GenMstMailConfigHeader {

	@Id
	@Column(name="txteventcode")
	private String eventCode;	
	
	@Column(name="txtapplicationcode")
	private String applicationCode;
	
	@Column(name="txtsubject")
	private String subject;
	
	@Column(name="txtbody")
	private String body;

	public GenMstMailConfigHeader(String subject, String body) {
		super();
		this.subject = subject;
		this.body = body;
	}
	
	
}
