package com.infosysit.rctmscompliance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Immutable
@Table(name="viewcmstrnescalationdetails")
public class ViewCMSTrnEscalationDetails {
	
	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="intescalationlevel")
	private int intEscalationLevel;
	
	@Column(name="intescalationinterval")
	private int intEscalationInterval;
	
	@Column(name="txtmailid")
	private String txtMailId;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
	
	@Column(name="dtduedate")
	private String dtDueDate;
	
	@Column(name="dtescalateddate")
	private String dtEscalatedDate;

}
