package com.infosys.reach.model.hear;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Policy {

	private String hearModulePolicy;

	public Policy() {
		this.hearModulePolicy = "Infosys is committed to respecting and supporting the fundamental principles contained in the Universal Declaration of Human Rights. As a signatory of the United Nations Global Compact, the company has adopted the \"Infosys Human Rights Statement \"which provides for a framework to ensure that all employees are treated with respect and dignity, and a common set of principles that apply to our business practices to ensure that we do not condone human rights violations or abuses. The grievance resolution mechanism of the Company recognizes the rights of our employees to be able to highlight their queries / concerns. Accordingly, the Company has constituted support groups, forums and resolution hubs that are designated to hear, address employee concerns & resolve issues or conflicts in a fair and transparent manner. The grievance resolution framework of the Company is also made accessible to all employees through multiple avenues. The HEAR Forum provides a single unified platform committed to addressing workplace grievances & ensuring a positive work environment. Employees can report concerns to the HEAR forum after having made reasonable efforts to address them with support of their Manager / Unit HR / Region HR.";
	}
}
