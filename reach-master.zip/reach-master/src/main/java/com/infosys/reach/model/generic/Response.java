package com.infosys.reach.model.generic;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(value = Include.NON_DEFAULT)
public class Response {

	private String type;
	private String content;
	private String htmlContent;
	private String value;
	
	public Response(String type, String content) {
		super();
		this.type = type;
		this.content = content;
		this.htmlContent = "";
	}
	
	public Response(String msg) {
		super();
		this.type = Constants.FAILURE;
		this.content = msg;
	}

}
