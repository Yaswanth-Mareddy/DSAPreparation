package com.infosys.hello.springboot.entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="project_details")
public class Project {
	/**
	 * Auto generated primary key of the project entity
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private ObjectId id;
	
	/**
	 * Project code 
	 */
	@NotNull
	@NotEmpty(message="Project code cannot be empty")
	@Size(min = 6, message = "Project code should have atleast 6 characters")
	private String code;
	
	/**
	 * Details/description about the project
	 */
	@NotNull
	@NotEmpty(message="Project details cannot be empty")
	@Size(max = 100, message = "Project details cannot exceed 100 characters")
	private String details;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
}
