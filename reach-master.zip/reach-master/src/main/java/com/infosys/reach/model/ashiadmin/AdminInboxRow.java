package com.infosys.reach.model.ashiadmin;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang.WordUtils;

import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class AdminInboxRow {

	private int caseId;
	private String reportedOn;
	private String reportedBy;
	private String location;
	private String category;
	private String slaExpiry;
	private String status;
	private String statusDesc;
	private boolean flgSLA;
	private boolean flgInterim;
	
	
	public AdminInboxRow(int caseId, Date reportedOn, String reportedBy, String location, String category, String status, Date sla) {
		this(caseId, new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn), reportedBy.trim(), WordUtils.capitalize(location), category, sla!=null ? MessageFormat.format(Constants.DAYS, String.valueOf(TimeUnit.MILLISECONDS.toDays(sla.getTime() - new Date(System.currentTimeMillis()).getTime())), new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(sla)) : "", status.split(",")[0].trim(), status.split(",")[1], false, false);
	}
	
	public AdminInboxRow(Date reportedOn, int caseId, String reportedBy, String location, String category, String status, Date sla) {
		this(caseId, new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn), reportedBy.trim(), WordUtils.capitalize(location), category, sla!=null ? MessageFormat.format(Constants.DAYS, String.valueOf(TimeUnit.MILLISECONDS.toDays(sla.getTime() - new Date(System.currentTimeMillis()).getTime())), new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(sla)) : "", status.split(",")[0].trim(), status.split(",")[1], true, false);
	}
	
	public AdminInboxRow(Date reportedOn, String reportedBy, int caseId, String location, String category, String status, Date sla) {
		this(caseId, new SimpleDateFormat(Constants.DATE_FORMAT).format(reportedOn), reportedBy.trim(), WordUtils.capitalize(location), category, sla!=null ? MessageFormat.format(Constants.DAYS, String.valueOf(TimeUnit.MILLISECONDS.toDays(sla.getTime() - new Date(System.currentTimeMillis()).getTime())), new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(sla)) : "", status.split(",")[0].trim(), status.split(",")[1], false, true);
	}
	
	public boolean filterByStatusAndLocation(List<String> status, List<String> locations) {
		Set<String> statusSet = status.stream().collect(Collectors.toSet());
		Set<String> locationSet = locations.stream().collect(Collectors.toSet());
		if(!statusSet.isEmpty() && !locationSet.isEmpty()) {
			return (statusSet.contains(this.statusDesc) && locationSet.contains(this.location));
		}
		
		else if(!statusSet.isEmpty()) {
			return statusSet.contains(this.statusDesc);
		}
		
		else if(!locationSet.isEmpty()) {
			return locationSet.contains(this.location);
		}
		
		else
			return false;
		
	}

}
