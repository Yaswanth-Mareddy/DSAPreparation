package com.infosysit.rctmscompliance.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnactionitemresponse")
public class CMSTrnActionItemResponse {

	@Id
	@Column(name="intactionitemid")
	private int intActionItemId;
	
	@Column(name="intnoofcycles")
	private int intNoOfCycles;
	
	@Column(name="txtactionitemassigneecomments")
    private String txtActionItemAssigneeComments;
	
	@Column(name="dtactionitemassigneecomments")
	private String dtActionItemAssigneeComments;
	
	@Column(name="txtassigneeattachmentlist")
	private String txtAssigneeAttachmentList;
	
	@Column(name="txtactionitemrejectcomments")
	private String txtActionItemRejectComments;
	
	@Column(name="dtactionitemrejectcomments")
	private String dtActionItemRejectComments;
	
	@Column(name="txtrejectattachmentlist")
	private String txtRejectAttachmentList;
	
	@Column(name="txtactionitemclosecomments")
	private String txtActionItemCloseComments;
	
	@Column(name="dtactionitemclosecomments")
	private String dtActionItemCloseComments;
	
	@Column(name="txtcloseattachmentlist")
	private String txtCloseAttachmentList;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtactionitemownercomments")
	private String txtActionItemOwnerComments;
	
	@Column(name="dtactionitemownercomments")
	private String dtActionItemOwnerComments;
	
	@Column(name="txtownerattachmentlist")
	private String txtOwnerAttachmentList;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy;
	
	@Column(name="dtmodifiedon")
	private Date dtModifiedOn;
	
	@Column(name="txtfindings")
	private String txtFindings;
	
	@Column(name="txtreason")
	private String txtReason;
	
	@Column(name="txtcorrectiveaction")
	private String txtCorrectiveAction;
	
	@Column(name="txtremediation")
	private String txtRemediation;
}
