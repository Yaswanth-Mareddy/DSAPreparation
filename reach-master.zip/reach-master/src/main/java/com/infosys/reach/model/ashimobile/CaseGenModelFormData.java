package com.infosys.reach.model.ashimobile;

import java.util.ArrayList;
import java.util.List;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class CaseGenModelFormData {
	private String heading;
	private List<CaseGenModelForm> formdata;
	
	public CaseGenModelFormData() {
		super();
		this.heading = "";
		this.formdata = new ArrayList<>();
	}

	public CaseGenModelFormData(List<CaseGenModelForm> formdata) {
		super();
		this.heading = "";
		this.formdata = formdata;
	}
}
