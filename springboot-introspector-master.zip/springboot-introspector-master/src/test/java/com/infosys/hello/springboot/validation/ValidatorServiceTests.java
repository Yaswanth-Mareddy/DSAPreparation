package com.infosys.hello.springboot.validation;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.infosys.hello.springboot.dto.ValidatorDTO;
import com.infosys.hello.springboot.repository.ValidatorRepository;
import com.infosys.hello.springboot.service.ValidatorService;

@RunWith(SpringJUnit4ClassRunner.class)
public class ValidatorServiceTests {
	
	@Mock
	ValidatorRepository validateRepository;
	
	@InjectMocks
	ValidatorService validateService;
	
	
	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void saveTest() throws Exception{
		
		ValidatorDTO customer = new ValidatorDTO();
		customer.setName("John");
		customer.setAge(23);
		
		String responseExpected = "customer saved successfully";
		
		Mockito.when(validateRepository.save(customer)).thenReturn(responseExpected);
		
		String responseActual = validateService.save(customer);
		
		assertEquals(responseExpected, responseActual);
	}
	
	@Test
	public void getObjTest() throws Exception{
		ValidatorDTO customerExpected = new ValidatorDTO();
		customerExpected.setName("John");
		customerExpected.setAge(23);
		
		Mockito.when(validateRepository.getValidateDTO("John")).thenReturn(customerExpected);
		
		ValidatorDTO customerActual = validateService.getObj("John");
		
		assertEquals(customerExpected.getAge(),customerActual.getAge());
	}
	
	@Test
	public void customValidationPositiveTest() throws Exception{
		ValidatorDTO req = new ValidatorDTO();
		req.setPhoneNumber("123456");
		String region = "usa";
		
		String responseExpected = "validation successful";
		
		String responseActual = validateService.customValidation(region, req);
		
		assertEquals(responseExpected, responseActual);
	}
	
	@Test
	public void customValidationNegativeTest() throws Exception{
		ValidatorDTO req = new ValidatorDTO();
		req.setPhoneNumber("1234567890");
		String region = "usa";
		
		String responseExpected = "phoneNumber must be of length 6";
		
		String responseActual = validateService.customValidation(region, req);
		
		assertEquals(responseExpected, responseActual);
	}
}
