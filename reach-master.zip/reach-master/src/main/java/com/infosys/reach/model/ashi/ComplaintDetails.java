package com.infosys.reach.model.ashi;

import java.util.Date;

import org.joda.time.DateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class ComplaintDetails {

	private int caseId;
	private String respondentType;
	private String managedBy;
	private String status;
	private String reportedOn;
	private String location;
	private String description;
	
	public ComplaintDetails(int caseId, String respondentType, String managedBy, String status, Date reportedOn, String location,
			String description) {
		super();
		this.caseId = caseId;
		this.respondentType = respondentType.trim();
		this.managedBy = managedBy.trim();
		this.status = status.trim();
		this.reportedOn = new DateTime(reportedOn.getTime()).toString("dd-MMM-yyyy");
		this.location = location;
		this.description = description.trim();
	}
	
	
}
