package com.infosys.reach.service;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.reach.entity.ELCMECMstEmployeeCaseDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnConcernActionDetails;
import com.infosys.reach.entity.ELCMECTrnConcernSLADetails;
import com.infosys.reach.entity.ELCMECTrnReachCaseDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.InitiateCaseResponse;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailInfo;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.PlaceHolder;
import com.infosys.reach.model.disciplinary.CaseDetails;
import com.infosys.reach.repository.ELCMECMstEmployeeCaseDetailsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnConcernActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnConcernSLADetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCaseDetailsRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.repository.HRISTrnEmpInfosysLocationRepository;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

@Service
@Transactional(rollbackFor = {CustomException.class, Exception.class})
public class DisciplinaryServiceImpl implements DisciplinaryService {

	private Timestamp currentDateTime=new Timestamp(ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli() + 19800000);
	
	@Autowired
	private Property property;
	
	@Autowired
	private CommonServiceImpl commonService;
	
	@Autowired
	private ELCMECTrnReachCaseDetailsRepository reachCaseDetailsRepository;
	
	@Autowired
	private HRISMstEmployeeRepository hrisMstEmployeeRepository;
	
	@Autowired
	private HRISTrnEmpInfosysLocationRepository empInfosysLocationRepository;
	
	@Autowired
	private ELCMECMstEmployeeCaseDetailsRepository employeeCaseDetailsRepository;
	
	@Autowired
	private ELCMECTrnConcernActionDetailsRepository actionDetailsRepository;
	
	@Autowired
	private ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Autowired
	private ELCMECTrnConcernSLADetailsRepository slaDetailsRepository;
	
	@Autowired
	private GenMstMailConfigHeaderRepository mailConfigHeaderRepository;

	@Override
	public InitiateCaseResponse initiateCase(String createdBy, String createdByMailId, CaseDetails caseDetails) throws CustomException {
		CaseDetailsValidationResponse employeeResponse = commonService.validateEmployeeDetails(caseDetails.getEmpNo(), "Employee");
		if(!employeeResponse.isStatus())
			return new InitiateCaseResponse(0, employeeResponse.getMessage());
		
		if(StringUtils.isBlank(caseDetails.getCountry())) {
			Optional<String> countryCode = empInfosysLocationRepository.findEmpCountryCodeForDiscAndBG(currentDateTime, employeeResponse.getIds().get(0).getEmpNo());
			if(!countryCode.isPresent())
				return new InitiateCaseResponse(0, "Employee country detail not found.");
			
			caseDetails.setCountry(countryCode.get());
		}

		Timestamp incidentDate = new Timestamp(DateTimeFormat.forPattern(Constants.DATE_FORMAT).parseMillis(caseDetails.getIncidentDate()));
		ELCMECTrnReachCaseDetails discCaseDetails = new ELCMECTrnReachCaseDetails(caseDetails, employeeResponse.getIds().get(0).getEmpNo(), incidentDate, createdBy, currentDateTime);
		
		ELCMECTrnReachCaseDetails updatedDiscCaseDetails = reachCaseDetailsRepository.save(discCaseDetails);
		
		int caseid = updatedDiscCaseDetails.getCaseId();
		
		List<CaseEmployeeDetails> respondentCaseDetailsObj=hrisMstEmployeeRepository.findCaseEmployeeDetails(caseDetails.getEmpNo());
		if(respondentCaseDetailsObj.isEmpty())
			throw new CustomException(Message.SOMETHING_WENT_WRONG);
		
		ELCMECMstEmployeeCaseDetails employeeDetails = new ELCMECMstEmployeeCaseDetails(caseid, respondentCaseDetailsObj.get(0), caseDetails.getCountry(), caseDetails.getCurrentLocation());
		
		ELCMECMstEmployeeCaseDetails updatedEmployeeDetails = employeeCaseDetailsRepository.save(employeeDetails);
		
		ELCMECTrnConcernActionDetails actionDetails = new ELCMECTrnConcernActionDetails(caseid, caseDetails, createdBy, currentDateTime);
		
		actionDetailsRepository.save(actionDetails);
		
		int slaDays=0;
		Optional<ELCMECMstSysParams> sysParam = elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("IM", "SLA");
		
		if(sysParam.isPresent()) {
			slaDays=Integer.parseInt(sysParam.get().getParamValue());
		}
		
		Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
		
		ELCMECTrnConcernSLADetails slaDetails = new ELCMECTrnConcernSLADetails(caseid, slaDays, "IMG", currentDateTime, slaEndDateTime, createdBy);
		
		slaDetailsRepository.save(slaDetails);
		
		MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("DISINIT");
		String toIds =  commonService.getIdStringByRoleAndModule("IMG", "4", caseDetails.getCountry(), updatedEmployeeDetails.getCompany(), "");
		
		if(mailInfo!=null && !toIds.isEmpty()) {
			String ccIds = createdByMailId + property.getInfyDomain();
			String subject = mailInfo.getSubject().replace(Constants.REQNO_PH, String.valueOf(caseid));
			String body = mailInfo.getBody().replace(Constants.EMPRAISED_PH, createdByMailId.toLowerCase()).replace(Constants.EMP_PH, updatedEmployeeDetails.getMailId().toLowerCase()).replace(Constants.SLAENDDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT).format(slaEndDateTime)).replace(Constants.LINK_PH, property.getDiscURL());
			MailInfo imgMailInfoObj=new MailInfo(property.getDiscMailerAppCode(), property.getDiscMailerEventId(), property.getTemplateIdFYI(), property.getDiscFromId(), toIds, ccIds);
			PlaceHolder[] imgPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

			MailerAssistRequest mailObj=new MailerAssistRequest(imgMailInfoObj, imgPlaceHolders);

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());

			return new InitiateCaseResponse(caseid, "Case has been registered successfully with Request Number " + caseid);
		}
		
		else
			return new InitiateCaseResponse(0, Message.MAIL_DETAILS_NOTFOUND);
	}
}
