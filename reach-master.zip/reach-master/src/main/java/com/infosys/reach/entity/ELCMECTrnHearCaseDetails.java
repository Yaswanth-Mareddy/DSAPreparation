package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.hear.HearCaseDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmectrnhearcasedetails")
public class ELCMECTrnHearCaseDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="intcategoryid")
	private int categoryId;
	
	@Column(name="txtrespondentempno")
	private String respondentEmpNo;
	
	@Column(name="txtstatus")
	private String status;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="txtmodifiedby")
	private String modifiedBy;
	
	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtincidentdate")
	private Timestamp incidentDate;
	
	@Column(name="txttaggedempmailid")
	private String taggedEmpMailId;
	
	@Column(name="flgseniormanagement")
	private int flgSeniorManagement;

	public ELCMECTrnHearCaseDetails(HearCaseDetails caseDetails,String createdBy,Timestamp createdOn) {
		super();
		this.moduleId = caseDetails.getModuleId();
		this.categoryId = caseDetails.getCategoryId();
		this.respondentEmpNo = caseDetails.getRespondentEmpNo();
		this.status = "CH";
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
		this.incidentDate = createdOn;
		this.taggedEmpMailId = caseDetails.getTaggedEmpMailId();
		this.flgSeniorManagement = caseDetails.getFlgSeniorManagement();
	}
	
	
}
