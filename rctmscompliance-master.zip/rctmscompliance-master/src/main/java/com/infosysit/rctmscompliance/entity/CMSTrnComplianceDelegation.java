package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrncompliancedelegation")
public class CMSTrnComplianceDelegation {

	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
	
	@Column(name="txtstatus")
	private String txtStatus;
	
	@Column(name="txtassigneefrom")
	private String txtAssigneeFrom;
	
	@Column(name="txtassigneeto")
	private String txtAssigneeto;
	
	@Column(name="txtverifierfrom")
	private String txtVerifierFrom;
	
	@Column(name="txtverifierto")
	private String txtVerifierto;
	
	@Column(name="txtownerfrom")
	private String txtOwnerFrom;
	
	@Column(name="txtownerto")
	private String txtOwnerto;
	
	@Column(name="flgactive")
	private String flgActive;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy;
	
	@Column(name="dtmodifiedon")
	private String dtModifiedOn;
}
