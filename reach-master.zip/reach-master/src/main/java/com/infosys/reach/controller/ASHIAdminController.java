package com.infosys.reach.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.reach.model.ashiadmin.FindingFilter;
import com.infosys.reach.model.ashiadmin.InboxFilter;
import com.infosys.reach.model.generic.AccordionView;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.WorkFlow;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author surajkumar.dewangan
 *
 */
@CrossOrigin
@RestController
@Api(tags="ASHI Admin Module : Employee Hub")
@RequestMapping("/v2/api/admin")
@DefaultProperties(defaultFallback = "defaultFallback")
public class ASHIAdminController extends Logging{
	
	@ApiOperation(value="Fetch inbox genmodel", tags="ASHI Admin Module : Employee Hub")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "60000") })
	@PostMapping(path="/inbox/genmodel", produces="application/json")
	public ResponseEntity<Object> getFilterGenModel() {
		try {

			GenModel outputObj=ashiAdminService.getInboxFilterGenmodel();
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched inbox filter GenModel.", Message.NOACCESS));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch inbox filter genmodel dropdown", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/context/options", produces="application/json")
	public ResponseEntity<Object> getOptionsByContextAndRole(@RequestParam(name = "moduleid",required = true) String moduleid, @RequestParam(name="role", required=true) String role, @RequestParam(name="country", required=false) String country, @RequestParam(name="company", required=false) String company, @RequestParam(name="location", required=false) String location, @RequestParam(name = "isloginuser",required = true) String isloginuser){
		try{
			List<GenModelOption> employeeOptions= commonService.getCamsContextDropdown(role, moduleid, country, company, location, isloginuser);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched cam options by context.");
			return ResponseEntity.ok(employeeOptions);
		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}
	
	@ApiOperation(value="Fetch empid based on cams role", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/context/members", produces="application/json")
	public ResponseEntity<Object> getIdsForCamsContextDropdown(@RequestParam(name = "moduleid",required = true) String moduleid, @RequestParam(name="role", required=true) String role, @RequestParam(name="country", required=true) String country, @RequestParam(name="company", required=true) String company, @RequestParam(name="location", required=true) String location){
		try{
			List<GenModelOption> employeeOptions= commonService.getIdsByModuleAndRole(role, moduleid, country, company, location, "No");
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched cams ids by context.");
			return ResponseEntity.ok(employeeOptions);
		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}
	
	@ApiOperation(value="Fetch inbox genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/inbox/inlinefilter/genmodel", produces="application/json")
	public ResponseEntity<Object> getInLineFilterGenModel(@RequestParam(name = "role",required = true) String role, @RequestParam(name="country", required=true) String country, @RequestParam(name="company", required=true) String company, @RequestParam(name="type", required=false) String type) {
		try {
			GenModel outputObj=ashiAdminService.getInboxInLineFilterGenmodel(role, country, company, type);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched inbox in-line filter GenModel.", Message.INVALID_INPUT));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	
	@ApiOperation(value="Fetch inbox filtered using genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/inbox/genmodelfiltered", produces="application/json")
	public ResponseEntity<Object> getInboxGenmodelFiltered(@RequestBody InboxFilter filter) {
		try {
			String message = "";
			if(StringUtils.isBlank(filter.getRole()))
				message = "Please select role";
			else if(StringUtils.isBlank(filter.getCountry()))
				message = "Please select country";
			else if(StringUtils.isBlank(filter.getCompany()))
				message = "Please select company";
			else if(Arrays.asList("ERH","GRB","IC").contains(filter.getRole().trim()) && StringUtils.isBlank(filter.getCaseType()))
				message = "Please select case type";
			
			if(!message.isEmpty()) {
				telemetry.setLogEventData(Message.ERROR+ " " + message);
				return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, message)));
			}
			else {
				InboxView details=ashiAdminService.getAdminInboxGenModelFiltered(filter);
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched admin inbox cases.");
				return ResponseEntity.ok(details);
			}
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}
	}
	
	@ApiOperation(value="Fetch inbox filtered using in-line genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/inbox/inlinefiltered", produces="application/json")
	public ResponseEntity<Object> getInboxInLineGenmodelFiltered(@RequestParam(name = "role",required = true) String role, @RequestParam(name="country", required=true) String country, @RequestParam(name="company", required=true) String company, @RequestParam(name="type", required=false) String type, @RequestBody GenModel filter) {
		try {
			InboxView details=ashiAdminService.getAdminInboxInLineFiltered(role, country, company, type, filter);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched admin inbox cases.");
			return ResponseEntity.ok(details);

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}
	}
	
	@ApiOperation(value="Inbox - action genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/inbox/actiongenmodel", produces="application/json")
	public ResponseEntity<Object> getInboxActionGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "type",required = true) String type) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getInboxActionForms(caseid, type);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched inbox action GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch case summary - complaint details", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/complaintdetails", produces="application/json")
	public ResponseEntity<Object> getCaseDetailsByCaseId(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			LabelView outputObj=ashiAdminService.getCaseSummaryByCaseId(caseid);			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched case summary - complaint details.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Fetch case summary - employee details", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/employeedetails", produces="application/json")
	public ResponseEntity<Object> getCaseEmployeeDetails(@RequestParam(name = Constants.ACTOR,required = true) String actor, @RequestParam(name=Constants.TRANSACTIONID, required=true) int transactionid) {
		try{
			if(transactionid==0)
				return ResponseEntity.ok(new LabelView(Constants.CASEEMPLOYEE_DETAILS, "LabelViewType1", new ArrayList<>()));

			LabelView outputObj=ashiAdminService.getCaseSummaryEmployeeDetails(actor, transactionid);
			
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched case summary - employee details.", "No employee details found."));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Trigger notification mail to case employees", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/notify",produces = "application/json")
	public ResponseEntity<Object> notifyCaseEmployee(@RequestParam(name=Constants.CASEID, required=true) int caseid, @RequestParam(name = Constants.ACTOR,required = true) String actor, @RequestParam(name=Constants.TRANSACTIONID, required=true) int transactionid) {
		try {
			
			Response output=ashiAdminService.triggerEmployeeNotificationMail(caseid, actor, transactionid);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY sent notification mail.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch employees for Case Summary dropdown", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/employees", produces="application/json")
	public ResponseEntity<Object> getCaseSummaryEmployeeDropdown(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = Constants.ACTOR,required = true) String actor){
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel employeeOptions= ashiAdminService.getCaseSummaryEmployeeDropDown(caseid, actor);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched employee options for case summary.");
			return ResponseEntity.ok(this.registerLogs(!employeeOptions.getFields().isEmpty(), employeeOptions, "SUCCESSFULLY fetched employee options for case summary.", Message.INVALID_INPUT));

		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}
	
	@ApiOperation(value="Fetch case summary - previous complaints", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/previouscomplaints", produces="application/json")
	public ResponseEntity<Object> getpreviousComplaints(@RequestParam(name=Constants.ACTOR, required=true) String actor, @RequestParam(name="empno", required=true) String empno) {
		try{
			//Authorization if there is no role access
			
			CardView outputObj=ashiAdminService.viewPreviousComplaints(actor, empno);			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case summary - previous complaints.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	
	@ApiOperation(value="Fetch case summary - add employee genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/addemployeegenmodel", produces="application/json")
	public ResponseEntity<Object> addEmployeeGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name=Constants.ACTOR, required=true) String actor) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.addEmployeeGenModel(caseid, actor);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched add employee GenModel.", "Invalid input."));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch case summary - add employee", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/addemployee",produces = "application/json")
	public ResponseEntity<Object> addEmployee(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.addEmployee(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added employees.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch case summary - remove employee", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/removeemployee",produces = "application/json")
	public ResponseEntity<Object> removeEmployee(@RequestParam(name=Constants.TRANSACTIONID, required=true) int transactionid) {
		try {
			Response output=ashiAdminService.removeEmployee(transactionid);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added employees.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	
	@ApiOperation(value="Fetch case summary - location and category details", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/locationdetails", produces="application/json")
	public ResponseEntity<Object> getLocationAndCategoryDetails(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			LabelView outputObj=ashiAdminService.getLocationAndCategoryDetails(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched case summary location details.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch case summary - update location and category genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/locationgenmodel", produces="application/json")
	public ResponseEntity<Object> getLocationAndCategoryGenmodel(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getLocationAndCategoryGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched update location GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case summary - update location and category", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/updatelocation",produces = "application/json")
	public ResponseEntity<Object> updateLocationAndCategoryDetails(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.updateLocationAndCategoryDetails(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated location.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	
	@ApiOperation(value="Fetch case summary - add preliminary discussion genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/preliminarydiscussiongenmodel", produces="application/json")
	public ResponseEntity<Object> preliminaryDiscussionGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.addPreliminaryDiscussionDetails(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched preliminary discussion GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case summary - add preliminary discussion", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/addpreliminarydiscussion",produces = "application/json")
	public ResponseEntity<Object> addPreliminaryDiscussion(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.addPreliminaryDiscusionDetails(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added preliminary discussion.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch case summary - previous complaints", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/casesummary/preliminarydiscussions", produces="application/json")
	public ResponseEntity<Object> getPreliminaryDiscussions(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "showtop2",required = true) int showtop2) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			CardView outputObj=ashiAdminService.getPreliminaryDiscussions(caseid, showtop2);
			telemetry.setLogEventData(Message.SUCCESSFULLY + "SUCCESSFULLY fetched preliminary discussions.");
			return ResponseEntity.ok(outputObj);

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Fetch assign case genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/actions", produces="application/json")
	public ResponseEntity<Object> getActions(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getActions(caseid);
			return ResponseEntity.ok(this.registerLogs(true, outputObj, "SUCCESSFULLY fetched dynamic actions.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch assign case genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/accordions", produces="application/json")
	public ResponseEntity<Object> getAccordions(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			AccordionView outputObj=ashiAdminService.getAccordions(caseid);
			return ResponseEntity.ok(this.registerLogs(true, outputObj, "SUCCESSFULLY fetched dynamic actions.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch update case status case genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/updatecasestatusgenmodel", produces="application/json")
	public ResponseEntity<Object> getUpdateCaseStatusGenModel(@RequestParam(name = Constants.ACTION,required = true) String action, @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.updateCaseStatusGenmodel(caseid, action);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched update case status GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 

	@ApiOperation(value="Update case status", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/updatecasestatus",produces = "application/json")
	public ResponseEntity<Object> updateCaseStatus(@RequestParam(name = Constants.ACTION,required = true) String action, @RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestBody GenModel genmodel) {
		try {
			String empNo = Session.getTokenEMPNO();
			Response output=ashiAdminService.updateCaseStatus(caseid, action, empNo, genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated case status.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch assign case genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/assigncasegenmodel", produces="application/json")
	public ResponseEntity<Object> getAssignCaseGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getAssignCaseGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched assigncase GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 

	@ApiOperation(value="Assign Case", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/assigncase",produces = "application/json")
	public ResponseEntity<Object> assignCase(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.assignCase(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY assigned case.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - Fetch seek inputs from complainant genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/communications/seekinputgenmodel", produces="application/json")
	public ResponseEntity<Object> getSeekInputGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.seekInputGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched seek inputs from complainant GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 

	@ApiOperation(value="Case investigation - Seek inputs from complainant", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/communications/seekinput",produces = "application/json")
	public ResponseEntity<Object> seekinput(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.seekInput(genmodel, AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()));
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY seeked inputs from complainant.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - communication history", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/communications/history", produces="application/json")
	public ResponseEntity<Object> communicationHistory(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "showtop2",required = true) int showtop2) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			CardView outputObj=ashiAdminService.communicationHistory(caseid, showtop2);			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case summary - previous complaints.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Case investigation - Interim Relief genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/interimreliefgenmodel", produces="application/json")
	public ResponseEntity<Object> getInterimReliefGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getInterimReliefGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched interim relief GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Add Interim Relief", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/addinterimrelief",produces = "application/json")
	public ResponseEntity<Object> addInterimRelief(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.addInterimRelief(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added interim relief details.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - Interim Relief Details", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/interimrelief", produces="application/json")
	public ResponseEntity<Object> getInterimRelief(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			LabelView outputObj=ashiAdminService.getInterimRelief(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched case investigation - interim relief details.", "Interim reliefs not submitted yet."));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Case investigation - Add Interim Relief", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/interimreliefaction",produces = "application/json")
	public ResponseEntity<Object> takeActionOnInterimRelief(@RequestParam(name = Constants.ACTION,required = true) String action, @RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.takeActionOnInterimRelief(action, genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added interim relief details.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - First Contact Mail genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/firstcontactmailgenmodel", produces="application/json")
	public ResponseEntity<Object> getFirstContactMailGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getFirstContactGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched first contact mails GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	

	
	@ApiOperation(value="Case investigation - Send first contact mails", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/sendfirstcontactmails",produces = "application/json")
	public ResponseEntity<Object> sendFirstContactMails(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.sendFirstContactMails(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY sent first contact mails.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - First contact mails", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/firstcontactmails", produces="application/json")
	public ResponseEntity<Object> getFirstContactMails(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "showtop2",required = true) int showtop2) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			CardView outputObj=ashiAdminService.getFirstContactMailsDetails(caseid, showtop2);		
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case investigation - first contact mails.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Case investigation - Investigation Type genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/typegenmodel", produces="application/json")
	public ResponseEntity<Object> getInvestigationTypeGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getInvestigationTypeGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched Investigation type GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Choose investigation type", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/choosetype",produces = "application/json")
	public ResponseEntity<Object> chooseInvestigationType(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.chooseInvestigationType(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated investigation type.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - Initiate Conciliation genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/initiateconciliation/genmodel", produces="application/json")
	public ResponseEntity<Object> getInitiateConciliationGenmodel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getInitiateConciliationGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched Initiate Conciliation genmodel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Initiate Conciliation action", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/initiateconciliation/action", produces="application/json")
	public ResponseEntity<Object> initiateConciliationAction(@RequestParam(name = Constants.ACTION,required = true) String action, @RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.initiateConciliation(Session.getTokenEMPNO(), action, genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY taken initiate conciliation action");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Conciliation consents", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/conciliation/consents", produces="application/json")
	public ResponseEntity<Object> getConciliationConsents(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			CardView outputObj=ashiAdminService.getConciliationConsents(caseid);		
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case investigation - first contact mails.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Case investigation - Conciliation report genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/conciliation/preparereportgenmodel", produces="application/json")
	public ResponseEntity<Object> getConciliationReportGenmodel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getPrepareConciliationReport(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched Conciliation report genmodel.", outputObj.getId()));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Initiate Conciliation action", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/conciliation/preparereport", produces="application/json")
	public ResponseEntity<Object> submitConciliationReport(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.submitConciliationReport(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY submitted conciliation report");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - Conciliation report", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/conciliation/report", produces="application/json")
	public ResponseEntity<Object> getConciliationReport(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			LabelView outputObj=ashiAdminService.getConciliationReport(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched case investigation - interim relief details.", "Conciliation report not prepared yet."));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Fetch move case genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/movecasegenmodel", produces="application/json")
	public ResponseEntity<Object> getMoveCaseGenModel(@RequestParam(name = Constants.ACTION,required = true) String action, @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.moveCaseGenModel(action, caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched assigncase GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 

	@ApiOperation(value="Move Case", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/movecase",produces = "application/json")
	public ResponseEntity<Object> moveCase(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.moveCase(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY moved case.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch add allegation and finding genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/finding/genmodel", produces="application/json")
	public ResponseEntity<Object> getFindingGenmodel(@RequestParam(name = Constants.TRANSACTIONID,required = false) String transactionid, @RequestParam(name = Constants.CASEID,required = false,defaultValue = "0") int caseid, @RequestParam(name = "type",required = true) int type) {
		try {
			if((!Arrays.asList(1,2,3,4).contains(type)) || (Arrays.asList(1,2,4).contains(type) && caseid==0) || (type==3 && StringUtils.isEmpty(transactionid)))
				return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, Message.INVALID_INPUT)));
			
			GenModel outputObj=ashiAdminService.addFindingsGenmodel(caseid, transactionid, type);
			
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched add allegation and finding genmodel", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Add or update allegation and finding", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/finding/addorupdate",produces = "application/json")
	public ResponseEntity<Object> addOrUpdateFinding(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.addFindings(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added or updated finding");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Add or update allegation and finding", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/finding/delete",produces = "application/json")
	public ResponseEntity<Object> deleteFinding(@RequestParam(name = Constants.TRANSACTIONID,required = true) int transactionid) {
		try {
			Response output=ashiAdminService.deleteFindings(transactionid);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added or updated finding");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch findings", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/findings", produces="application/json")
	public ResponseEntity<Object> getFindings(@RequestParam(name = "filter",required = false) boolean filter, @RequestBody FindingFilter findingFilter) {
		try {
			commonService.checkCaseAuthorization(findingFilter.getCaseid(), true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			InboxView details=ashiAdminService.getFindings(filter, findingFilter);
			
			if(details.getHeader().isEmpty())
				return ResponseEntity.ok(Arrays.asList(new Response("nodata", details.getName())));
			
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched findings", Message.NOCASEFOUND));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}
	}
	
	@ApiOperation(value="Fetch recommended action genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/recommendedaction/genmodel", produces="application/json")
	public ResponseEntity<Object> getRecommendedActionsGenmodel(@RequestParam(name = Constants.TRANSACTIONID,required = false) String transactionid, @RequestParam(name = Constants.CASEID,required = false,defaultValue = "0") int caseid, @RequestParam(name = "type",required = true) int type) {
		try {
			if((!Arrays.asList(1,2).contains(type)) || (type==1 && caseid==0) || (type==2 && StringUtils.isEmpty(transactionid)))
				return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, Message.INVALID_INPUT)));
			
			GenModel outputObj=ashiAdminService.getRecommendedActionsGenmodel(type, caseid, transactionid);
			
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched recommended action GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Fetch genmodel options by groupid", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/optionsbygroupid", produces="application/json")
	public ResponseEntity<Object> getGenModelOptionsByGroupId(@RequestParam(name = "moduleid",required = true) int moduleid, @RequestParam(name = "groupid",required = true) String groupid){
		try{
			List<GenModelOption> employeeOptions= commonService.getGenModelOptionsByModuleIdAndGroupId(moduleid, groupid);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY genmodel options by groupid.");
			return ResponseEntity.ok(employeeOptions);
		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}
	
	@ApiOperation(value="Add or update recommended action", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/recommendedaction/addorupdate",produces = "application/json")
	public ResponseEntity<Object> addOrUpdateRecommendedActions(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.addOrUpdateRecommendedActions(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added or updated recommended action");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Add or update recommended action", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/recommendedaction/delete",produces = "application/json")
	public ResponseEntity<Object> deleteRecommendedActions(@RequestParam(name = Constants.TRANSACTIONID,required = true) int transactionid, @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			Response output=ashiAdminService.deleteRecommendedActions(caseid, transactionid);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY deleted recommended action");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - Recommended actions", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/recommendedaction/cards", produces="application/json")
	public ResponseEntity<Object> getRecommendedActions(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "filter",required = true) boolean filter) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}

			CardView outputObj=ashiAdminService.getRecommendedActions(caseid, filter);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched recommended actions cards", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Fetch employeed by actor", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/employees", produces="application/json")
	public ResponseEntity<Object> getEmployeesByActor(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = Constants.ACTOR,required = true) String actor){
		try{
			List<GenModelOption> employeeOptions= ashiAdminService.getEmployeesByActor(caseid, actor);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched employees by actor");
			return ResponseEntity.ok(employeeOptions);
		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}
	
	@ApiOperation(value="Case investigation - Issue summons genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/issuesummonsgenmodel", produces="application/json")
	public ResponseEntity<Object> getIssueSummonsGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getIssueSummonGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched issue summons GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	

	
	@ApiOperation(value="Case investigation - Send first contact mails", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/issuesummons",produces = "application/json")
	public ResponseEntity<Object> issueSummons(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.issueSummon(genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY issued summon.");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - Issued summons", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/summons", produces="application/json")
	public ResponseEntity<Object> getSummons(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = "showtop2",required = true) int showtop2) {
		try{
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			CardView outputObj=ashiAdminService.getIssuedSummons(caseid,showtop2);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched issued summons", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Case investigation - send findings genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/sendfindinggenmodel", produces="application/json")
	public ResponseEntity<Object> sendFindingGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = Constants.ACTOR,required = true) String actor, @RequestParam(name = "mailid",required = true) String mailid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.sendFindingsGenmodel(caseid, actor, mailid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched send findings genmodel", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Send findings", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/sendfinding",produces = "application/json")
	public ResponseEntity<Object> sendFinding(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestParam(name = Constants.ACTOR,required = true) String actor, @RequestParam(name = "mailid",required = true) String mailid) {
		try {
			Response output=ashiAdminService.sendFindings(AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), caseid, actor, mailid);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY added or updated recommended action");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - consolidated finding", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/consolidatedfinding", produces="application/json")
	public ResponseEntity<Object> consolidatedFinding( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.consolidatedFindingsGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched consolidated finding", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Case investigation - approvals genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formalreport/genmodel", produces="application/json")
	public ResponseEntity<Object> formalReportGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			GenModel outputObj=ashiAdminService.getFormalReportGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched formal report genmodel", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Save formal report", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formalreport/save",produces = "application/json")
	public ResponseEntity<Object> submitFormalReport(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.submitFormalReport(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY save formal report");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch formal report details", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formalreport/details", produces="application/json")
	public ResponseEntity<Object> getFormalReportDetails(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			LabelView outputObj=ashiAdminService.getFormalReportDetails(caseid);		
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched formal report details.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Investigation - comment label", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/commentslabel", produces="application/json")
	public ResponseEntity<Object> commentLabel(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			LabelView outputObj=ashiAdminService.getCommentsLabel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched investigation - comment label", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Formal investigation - checklist genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formal/checklist/genmodel", produces="application/json")
	public ResponseEntity<Object> formalReportChecklistGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getFormalReportCheckListGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched formal report genmodel", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="Save formal report checklist", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formal/checklist/save",produces = "application/json")
	public ResponseEntity<Object> updateFormalReportCheckList(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.updateFormalReportCheckList(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY save formal report checklist");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Case investigation - approvals genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/uploadapprovalsgenmodel", produces="application/json")
	public ResponseEntity<Object> uploadApprovalGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			GenModel outputObj=ashiAdminService.getUploadApprovalsGenmodel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched upload approvals genmodel", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 
	
	@ApiOperation(value="upload approvals", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/uploadapprovals",produces = "application/json")
	public ResponseEntity<Object> uploadApprovals(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.submitApprovals(Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY uploaded approvals");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="SLA workflow", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/workflow/sla",produces = "application/json")
	public ResponseEntity<Object> slaWorkflow(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			WorkFlow output=ashiAdminService.getWorkFlow(caseid);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"Successfully fetched sla workflow.");
			return ResponseEntity.ok(output);

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Template genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/templategenmodel",produces = "application/json")
	public ResponseEntity<Object> getTemplateGenmodel() {
		try {
			GenModel output=ashiAdminService.getDownloadTemplateGenmodel();
			return ResponseEntity.ok(this.registerLogs(!output.getFields().isEmpty(), output, "SUCCESSFULLY fetched download template genmodel", Message.SOMETHING_WENT_WRONG));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Download template", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/downloadtemplate", produces="application/json")
	public ResponseEntity<Object> downloadTemplate(@RequestBody GenModel genmodel) {
		try {
			DocumentData output = ashiAdminService.downloadTemplate(genmodel);
			
			if(output.getFilename().equals(Message.ERROR)) {
				telemetry.setLogEventData(output.getFilename() + " " +output.getBase64file());
				return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, output.getBase64file())));
			}
			else {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"Successfully downloaded template");
				return ResponseEntity.ok(output);
			}
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="SLA Extension Action", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/slaextension/action",produces = "application/json")
	public ResponseEntity<Object> actionSLAExtension(@RequestParam(name = "flgaction",required = true) boolean flgAction, @RequestParam(name = "flgapprove",required = false) boolean flgApprove, @RequestParam(name = Constants.TRANSACTIONID,required = false) String transactionid, @RequestBody GenModel genmodel) {
		try {
			Response output=ashiAdminService.actionSLAExtension(flgAction, flgApprove, transactionid, genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY uploaded approvals");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	

	@ApiOperation(value="Download formal report", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/formalreport/download",produces = "application/json")
	public ResponseEntity<Object> downloadFormalReport(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			DocumentData output=ashiAdminService.downloadFormalReport(caseid);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"Successfully downloaded formal report document");
			return ResponseEntity.ok(output);

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	} 
	
	@ApiOperation(value="Case investigation - Charge Sheet genmodel", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/chargesheetgenmodel", produces="application/json")
	public ResponseEntity<Object> getChargeSheetGenModel( @RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			GenModel outputObj=ashiAdminService.getChargeSheetGenModel(caseid);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched Charge sheet GenModel.", Message.CASENOTREGISTERED));

		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	} 

	@ApiOperation(value="Save Charge sheet", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/chargesheetgenmodel/save",produces = "application/json")
	public ResponseEntity<Object> submitChargeSheet(@RequestParam(name = Constants.CASEID,required = true) int caseid, @RequestBody GenModel genmodel) {
		try {
			commonService.checkCaseAuthorization(caseid, true);
			if(!Session.isAuthorized()) {
				return this.registerAuthorizationLogs();
			}
			
			Response output=ashiAdminService.saveChargeSheet(caseid, Session.getTokenEMPNO(), genmodel);
			if(output.getType().equals(Message.SUCCESS)) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY save Charge sheet");
					
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
			}
			return ResponseEntity.ok(Arrays.asList(output));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Fetch Charge sheets", tags="ASHI Admin Module : Employee Hub")
	@PostMapping(path="/investigation/chargesheetgenmodel/details", produces="application/json")
	public ResponseEntity<Object> getChargeSheet(@RequestParam(name=Constants.CASEID, required=true) int caseid) {
		try{
			LabelView outputObj=ashiAdminService.getChargeSheet(caseid);		
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched Charge sheets.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	public ResponseEntity<Object> defaultFallback() {
		return ResponseEntity.ok(Message.ERROR + "Service is down. Please try again after sometime.");
	}
}
