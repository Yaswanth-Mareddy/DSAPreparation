package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.hear.HearCaseDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmectrnhearempgeneraldetails")
public class ELCMECTrnHearEmpGeneralDetails {

	@Id
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="flgmanager")
	private int flgManager;
	
	@Column(name="flgreviewer")
	private int flgReviewer;
	
	@Column(name="flgunithr")
	private int flgUnitHR; 
	
	@Column(name="txtmanagerreason")
	private String managerReason;
	
	@Column(name="txtreviewerreason")
	private String reviewerReason;
	
	@Column(name="txtunithrreason")
	private String unitHRReason;
	
	@Column(name="txtempmanager")
	private String empManager;              
 	
	@Column(name="txtempreviewer")
	private String empReviewer;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="txtmodifiedby")
	private String modifiedBy;
	
	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;

	public ELCMECTrnHearEmpGeneralDetails(int caseId, String empNo, HearCaseDetails caseDetails,Timestamp currentDate) {
		super();
		this.caseId = caseId;
		this.empNo = empNo;
		this.flgManager = caseDetails.getFlgManager();
		this.flgReviewer = caseDetails.getFlgReviewer();
		this.flgUnitHR = caseDetails.getFlgUnitHR();
		this.managerReason = caseDetails.getManagerReason();
		this.reviewerReason = caseDetails.getReviewerReason();
		this.unitHRReason = caseDetails.getUnitHRReason();
		this.empManager = caseDetails.getEmpManager();
		this.empReviewer = caseDetails.getEmpReviewer();
		this.createdBy = empNo;
		this.modifiedBy = empNo;
		this.createdOn = currentDate;
		this.modifiedOn = currentDate;
	}
	
	
}
