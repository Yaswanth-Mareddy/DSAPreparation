package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardView {

	private String name;
	private String guid;
	private String type;
	private List<Card> cards;
	private String heading;
	private String transactionID;
	private List<CardViewAction> actions;
	public CardView(String name, List<Card> cards) {
		this(name, "", Constants.CARDVIEW, cards, "", "", new ArrayList<>());
	}
	
	public CardView(String name, String heading, List<Card> cards) {
		this(name, "", Constants.CARDVIEW, cards, heading, "", new ArrayList<>());
	}
	
	public CardView(String name, List<Card> cards, String heading, int transactionID, List<CardViewAction> actions) {
		this(name, "", Constants.CARDVIEW, cards, heading, String.valueOf(transactionID), actions);
	}
	
}
