package com.infosys.reach.model.ashiadmin;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class InboxFilter {

	private String role;
	private String country;
	private String company;
	private String caseType;
}
