package com.infosys.reach.entity;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.common.CaseEmployeeDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="elcmecmsthearemployeecasedetails")
public class ELCMECMstHearEmployeeCaseDetails {

	@Id
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="txtempname")
	private String empName;
	
	@Column(name="txtsbucode")
	private String sbuCode;
	
	@Column(name="dtjoineddate")
	private Date joinedDate;
	
	@Column(name="txtempbandcode")
	private String empBandCode;
	
	@Column(name="txtducode")
	private String duCode;
	
	@Column(name="txtprojectcode")
	private String projectCode;
	
	@Column(name="txtroledesc")
	private String roleDesc;
	
	@Column(name="txtcompany")
	private String company;
	
	@Column(name="txtcurrentcity")
	private String currentCity;
	
	@Column(name="txtcountrycode")
	private String countryCode;
	
	@Column(name="txtbasecity")
	private String baseCity;
	
	@Column(name="txtreportingmanager")
	private String reportingManager;
	
	@Column(name="txtconfirmationstatus")
	private String confirmationStatus;
	
	@Column(name="txtactor")
	private String actor;
	
	@Column(name="txtselectedcity")
	private String selectedCity;
	
	@Column(name="txtselectedcountry")
	private String selectedCountry;
	
	public ELCMECMstHearEmployeeCaseDetails(int caseId,CaseEmployeeDetails caseDetails,String countryCode,String actor,String selectedCountry,String selectedCity) {
		super();
		this.caseId=caseId;
		this.empNo = caseDetails.getEmpNo();
		this.mailId = caseDetails.getMailId();
		this.empName = caseDetails.getEmpName();
		this.sbuCode = caseDetails.getSbuCode();
		this.empBandCode = caseDetails.getEmpBandCode();
		this.joinedDate = (Date) caseDetails.getJoinedDate();
		this.duCode = caseDetails.getDuCode();
		this.roleDesc = caseDetails.getRoleDesc();
		this.projectCode = caseDetails.getProjectCode();
		this.company = caseDetails.getCompany();
		this.currentCity = caseDetails.getCurrentCity();
		this.baseCity = caseDetails.getBaseCity();
		this.confirmationStatus = caseDetails.getConfirmationStatus();
		this.reportingManager = caseDetails.getReportingManager();
		this.countryCode=countryCode;
		this.actor=actor;
		this.selectedCity=selectedCity;
		this.selectedCountry=selectedCountry;
	}
	
	
	
	
	
}
