package com.infosys.hello.springboot.service;

import java.util.List;

import com.infosys.hello.springboot.entity.Project;
import com.infosys.hello.springboot.model.Employee;

public interface ProjectService {
	void saveProject(Project project);

	List<Project> getProjects();
	
	Employee getEmployee(int employeeId);
}
