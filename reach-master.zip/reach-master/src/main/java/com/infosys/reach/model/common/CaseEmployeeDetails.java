package com.infosys.reach.model.common;

import java.util.Date;

import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class CaseEmployeeDetails {

	private String empNo;
	private String mailId;
	private String empName;
	private String unit;
	private String sbuCode;
	private String empBandCode;
	private Date joinedDate;
	private String duCode;
	private String roleDesc;
	private String projectCode;
	private String company;
	private String currentCity;
	private String baseCity;
	private String confirmationStatus;
	private String reportingManager;
	
	public CaseEmployeeDetails(ELCMECMstASHICaseEmployeeDetails details) {
		super();
		this.empNo = details.getEmpNo();
		this.mailId = details.getMailId();
		this.empName = details.getEmpName();
		this.unit = details.getUnit();
		this.sbuCode = details.getSbuCode();
		this.empBandCode = details.getEmpBandCode();
		this.joinedDate = details.getJoinedDate();
		this.duCode = details.getDuCode();
		this.roleDesc = details.getRoleDesc();
		this.projectCode = details.getProjectCode();
		this.company = details.getCompany();
		this.currentCity = details.getCurrentCity();
		this.baseCity = details.getBaseCity();
		this.confirmationStatus = details.getConfirmationStatus();
		this.reportingManager = details.getReportingManager();
	}
	
	
}
