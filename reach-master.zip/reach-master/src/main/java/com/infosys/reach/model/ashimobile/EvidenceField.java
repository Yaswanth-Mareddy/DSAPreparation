package com.infosys.reach.model.ashimobile;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EvidenceField {
	private String fileName;
	private String fileURL;
}
