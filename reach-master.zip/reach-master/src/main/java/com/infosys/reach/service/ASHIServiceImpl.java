package com.infosys.reach.service;







import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.reach.controller.Session;
import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.entity.ELCMECMstASHICocomplainantsDetails;
import com.infosys.reach.entity.ELCMECMstASHICommunicationDetails;
import com.infosys.reach.entity.ELCMECMstASHIConciliationConsentDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.entity.ELCMECtrnASHIConcernSLADetails;
import com.infosys.reach.entity.HRISTrnEmpLocation;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ASHIAccess;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.ComplaintDetails;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.ashiadmin.UpdateCaseStatusReturn;
import com.infosys.reach.model.common.CAMSInput;
import com.infosys.reach.model.common.CAMSOutput;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.common.MailApprovalRequest;
import com.infosys.reach.model.common.MailApprovalResponse;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailInfo;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.PlaceHolder;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.CommentSummary;
import com.infosys.reach.model.generic.CommentSummaryAction;
import com.infosys.reach.model.generic.CommunicationModel;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelForm;
import com.infosys.reach.model.generic.GenModelFormData;
import com.infosys.reach.model.generic.GenModelFormObj;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.Header;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICocomplainantsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICommunicationDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIConciliationConsentDetailsRepository;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECtrnASHIConcernSLADetailsRepository;
import com.infosys.reach.repository.GENMstCityRepository;
import com.infosys.reach.repository.GenMstInfosysEstablishmentsRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.repository.HRISTrnEmpLocationRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;



@Service
@Transactional(rollbackFor = CustomException.class)
public class ASHIServiceImpl implements ASHIService {

	@Autowired
	private Property property;
	
	@Autowired
	private ASHIAdminServiceImpl adminService;
	
	private Timestamp currentDateTime=new Timestamp(ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli() + 19800000);

	@Autowired
	private CommonServiceImpl commonService;

	@Autowired
	private ViewCurrEmpAllDetailsRepository empDetailsRepository;

	@Autowired
	private ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;

	@Autowired
	private GenMstInfosysEstablishmentsRepository genMstInfosysEstablishmentsRepository;

	@Autowired
	private HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Autowired
	private ELCMECMstASHICaseEmployeeDetailsRepository ashiCaseEmployeeDetailsRepository;

	@Autowired
	private ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;

	@Autowired
	private ELCMECMstASHICocomplainantsDetailsRepository ashiCocomplainantsDetailsRepository;

	@Autowired
	private ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Autowired
	private GENMstCityRepository cityRepository;

	@Autowired
	private ELCMECMstConcernModulesDetailsRepository concernModulesDetailsRepository;

	@Autowired
	private ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;

	@Autowired
	private HRISTrnEmpLocationRepository empLocationRepository;

	@Autowired
	private GenMstMailConfigHeaderRepository mailConfigHeaderRepository;
	
	@Autowired
	private ELCMECtrnASHIConcernSLADetailsRepository slaDetailsRepository;

	@Autowired
	private ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Autowired
	private ELCMECMstASHIConciliationConsentDetailsRepository conciliationConsentDetailsRepository;
	
	@Autowired
	private ELCMECMstASHICommunicationDetailsRepository communicationRepository;


	/**
	 *
	 */
	@Override
	public Response initiateASHICase(ValidatedCaseDetails caseDetails) throws CustomException{

		int caseId=0;
		ELCMECTrnASHICaseDetails ashiCaseDetails=new ELCMECTrnASHICaseDetails(caseDetails, currentDateTime);
		caseId=caseDetailsRepository.save(ashiCaseDetails).getCaseId();


		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();

		List<ELCMECMstASHICaseEmployeeDetails> caseInitiatorList=this.insertemployeeDetails(1,1, "",  Arrays.asList(caseDetails.getCaseInitiator()), caseId, "I");
		ashiCaseEmployeeDetailsList.addAll(caseInitiatorList);

		if(caseDetails.isGRB() && caseDetails.getRaisingFor()==0) {
			List<ELCMECMstASHICaseEmployeeDetails> complainantList=this.insertemployeeDetails(caseDetails.getComplainantType(),caseDetails.getIsComplainantKnown(), caseDetails.getComplainantsOther(), caseDetails.getComplainantsInfy(), caseId, "A");
			ashiCaseEmployeeDetailsList.addAll(complainantList);
		}

		else {
			List<ELCMECMstASHICaseEmployeeDetails> complainantList=this.insertemployeeDetails(1, 1,"", Arrays.asList(caseDetails.getCaseInitiator()), caseId, "A");
			ashiCaseEmployeeDetailsList.addAll(complainantList);
		}

		List<ELCMECMstASHICaseEmployeeDetails> respondentList=this.insertemployeeDetails(caseDetails.getRespondentType(),caseDetails.getIsRespondentKnown(), caseDetails.getRespondentsOther(), caseDetails.getRespondentsInfy(), caseId, "R");
		ashiCaseEmployeeDetailsList.addAll(respondentList);

		List<ELCMECMstASHICaseEmployeeDetails> witnessList=this.insertemployeeDetails(1,1, "", caseDetails.getWitnesses(), caseId, "W");
		ashiCaseEmployeeDetailsList.addAll(witnessList);

		List<ELCMECMstASHICaseEmployeeDetails> stakeholderList=this.insertemployeeDetails(1,caseDetails.getIsStakeHolder(), "", caseDetails.getStakeholder(), caseId, "S");
		ashiCaseEmployeeDetailsList.addAll(stakeholderList);


		ashiCaseEmployeeDetailsRepository.saveAll(ashiCaseEmployeeDetailsList);

		//Add Cocomplainant Details
		List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

		for(ViewCurrEmpAllDetails id:caseDetails.getCocomplainants()) {
			ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(caseId, id.getMailId()));

		}		
		ashiCocomplainantsDetailsRepository.saveAll(ashiCocomplainantsDetailsList);


		String dmsFileNames = commonService.uploadFilesToDMS(caseDetails.getCaseInitiator().getMailId(), caseDetails.getFolder(), caseDetails.getValidatedEvidences(), property.getDmsASHICaseDocFolder());

		//Action Details
		ELCMECTrnASHIActionDetails actionDetails=new ELCMECTrnASHIActionDetails(caseId, "CIN", "WE", caseDetails.getDescription(), caseDetails.getCaseInitiator().getEmpNo(), currentDateTime, dmsFileNames);

		ashiActionDetailsRepository.save(actionDetails);
		
		int slaDays=0;
		Optional<ELCMECMstSysParams> sysParam = elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("ERH", "SLA");
		
		if(sysParam.isPresent()) {
			slaDays=Integer.parseInt(sysParam.get().getParamValue());
			Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(slaDays));
			ELCMECtrnASHIConcernSLADetails slaDetails=new ELCMECtrnASHIConcernSLADetails(caseId, slaDays, "ERH", currentDateTime, slaEndDateTime, caseDetails.getCaseInitiator().getEmpNo());
			slaDetailsRepository.save(slaDetails);
		}
		


		this.triggerMails(caseId, caseDetails);

		return new Response(Message.SUCCESS, "Done! Your case is submitted with Case id "+caseId+".");
	}

	private void triggerMails(int caseId, ValidatedCaseDetails caseDetails) throws CustomException{

		StringBuilder grbIds=new StringBuilder();
		List<String> grbIdList=this.getAdmins();
		for(String grb:grbIdList) {
			Optional<ViewCurrEmpAllDetails> empDetails=empDetailsRepository.findByEmpNoOrMailId(grb.trim());
			if(!empDetails.isPresent()) {
				throw new CustomException("Details for grb "+grb.trim()+Constants.UNAVAILABLE);
			}
			grbIds.append(empDetails.get().getMailId().trim()).append(property.getInfyDomain()).append(";");

		}
		grbIds.insert(0, property.getGrbId());


		//GRB mail

		StringBuilder respondentDetails = new StringBuilder();
		if(caseDetails.getRespondentType()==1) {
			if(caseDetails.getIsRespondentKnown()==1) {
				for(ViewCurrEmpAllDetails resp : caseDetails.getRespondentsInfy()) {
					respondentDetails.append("<br>").append(resp.getEmpName().trim()).append(" (").append(resp.getEmpNo().trim()).append(")");
				}
				respondentDetails = respondentDetails.delete(0, 4);
			}
			else {
				respondentDetails.append("NA");
			}
		}
		else {
			respondentDetails.append(caseDetails.getRespondentsOther());
		}

		MailContent grbMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGRB");
		String grbMailSubject=grbMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));
		String grbMailBody=grbMailInfo.getBody().replace("#EmpName#", caseDetails.getCaseInitiator().getEmpName()).replace("#EmpNo#", caseDetails.getCaseInitiator().getEmpNo()).replace("#Location#", WordUtils.capitalize(caseDetails.getBaseLocation().toLowerCase().trim())).replace("#RespondentDetails#", respondentDetails.toString()).replace("#Description#", caseDetails.getDescription().trim());
		grbMailInfo.setBody(grbMailBody);
		grbMailInfo.setSubject(grbMailSubject);

		MailInfo grbMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), grbIds.toString(), "");
		PlaceHolder[] grbPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, grbMailInfo.getSubject())),new PlaceHolder("Body", grbMailInfo.getBody())};

		MailerAssistRequest grbMailObj=new MailerAssistRequest(grbMailInfoObj, grbPlaceHolders);
		
		
		MailerAssistResponse caseInitiatorMailerResponse = commonService.triggerMail(this.getCaseInitiatorMailObj(caseId, caseDetails));
		if(caseInitiatorMailerResponse.getCode()!=0) 
			throw new CustomException("Case Initiator "+Message.MAIL_NOT_TRIGGERED + caseInitiatorMailerResponse.getMessage());

		MailerAssistResponse grbMailerResponse = commonService.triggerMail(grbMailObj);
		if(grbMailerResponse.getCode()!=0) 
			throw new CustomException("GRB "+Message.MAIL_NOT_TRIGGERED + grbMailerResponse.getMessage());

		if(caseDetails.isGRB() && caseDetails.getRaisingFor()==0 && caseDetails.getIsComplainantKnown()==1 && !caseDetails.getComplainantsInfy().isEmpty()) {
			this.triggerComplainantMailObj(caseId, caseDetails);
		}
	}

	private MailerAssistRequest getCaseInitiatorMailObj(int caseId, ValidatedCaseDetails caseDetails) {
		//Case initiator mail
		MailContent caseInitiatorMailInfo=null;
		
		String caseInitiatorMailBody = "";
		String ccId = "";
		if(caseDetails.isGRB() && caseDetails.getRaisingFor()==0) {
			caseInitiatorMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIGCI");
			StringBuilder complainantDetails = new StringBuilder();
			String complainantType = "";
			String complainantTitle = "";
			
			if(caseDetails.getComplainantType()==1) {
				complainantType = "Infoscion";
				complainantTitle = "Complainant Name & Emp. No.";
				if(caseDetails.getIsComplainantKnown()==1) {
					for(ViewCurrEmpAllDetails comp : caseDetails.getComplainantsInfy()) {
						complainantDetails.append("<br>").append(comp.getEmpName().trim()).append(" (").append(comp.getEmpNo().trim()).append(")");
					}
					complainantDetails = complainantDetails.delete(0, 4);
				}
				else {
					complainantDetails.append("NA");
				}
			}
			else {
				complainantType = "Other";
				complainantTitle = "Complainant Details";
				complainantDetails.append(caseDetails.getComplainantsOther());
			}
			
			caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#ComplainantType#", complainantType).replace("#ComplainantTitle#", complainantTitle).replace("#ComplainantDetails#", complainantDetails);
			ccId = property.getGrbId();
		}
		else {
			caseInitiatorMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICI");
			caseInitiatorMailBody=caseInitiatorMailInfo.getBody().replace("#EmployeeName#", caseDetails.getCaseInitiator().getEmpName());
			
		}
		String toId = caseDetails.getCaseInitiator().getMailId() + property.getInfyDomain();
		String caseInitiatorMailSubject=caseInitiatorMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		
		
		caseInitiatorMailInfo.setBody(caseInitiatorMailBody);
		caseInitiatorMailInfo.setSubject(caseInitiatorMailSubject);

		MailInfo caseInitiatorMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), toId, ccId);
		PlaceHolder[] caseInitiatorPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, caseInitiatorMailInfo.getSubject())),new PlaceHolder("Body", caseInitiatorMailInfo.getBody())};

		return new MailerAssistRequest(caseInitiatorMailInfoObj, caseInitiatorPlaceHolders);
	}

	private void triggerComplainantMailObj(int caseId, ValidatedCaseDetails caseDetails) throws CustomException {
		MailContent complainantMailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICO");
		String complainantMailSubject=complainantMailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseId));

		StringBuilder complainantNames = new StringBuilder();
		StringBuilder complainantIds = new StringBuilder();

		for(ViewCurrEmpAllDetails details : caseDetails.getComplainantsInfy()) {
			complainantNames.append(", ").append(WordUtils.capitalize(details.getEmpName().trim().split(" ")[0].toLowerCase()));
			complainantIds.append(details.getMailId().trim()).append(property.getInfyDomain()).append(";");
		}

		String complainantMailBody=complainantMailInfo.getBody().replace("#ComplainantsName#", complainantNames.deleteCharAt(0).toString().trim());
		complainantMailInfo.setSubject(complainantMailSubject);
		complainantMailInfo.setBody(complainantMailBody);

		MailInfo complainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), complainantIds.toString(), "");
		PlaceHolder[] complainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, complainantMailInfo.getSubject())),new PlaceHolder("Body", complainantMailInfo.getBody())};

		MailerAssistResponse mailerResponse = commonService.triggerMail(new MailerAssistRequest(complainantMailInfoObj, complainantPlaceHolders));
		if(mailerResponse.getCode()!=0)
			throw new CustomException("On behalf of GRB complainant "+Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());

	}

	private List<ELCMECMstASHICaseEmployeeDetails> insertemployeeDetails(int type, int isknown, String idString, List<ViewCurrEmpAllDetails> empIds, int caseId, String actor) throws CustomException {
		List<ELCMECMstASHICaseEmployeeDetails> ashiCaseEmployeeDetailsList=new ArrayList<>();
		if(type==0 && this.notNullOrEmpty(idString)) {
			String[] ids=idString.split(",");
			for(String id:ids)
				ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, id.trim(), actor));

		}
		if(type==1 && isknown==1) {
			for(ViewCurrEmpAllDetails id:empIds) {
				List<CaseEmployeeDetails> complainantDetails=hrisMstEmployeeRepository.findCaseEmployeeDetails(id.getEmpNo());
				if(!complainantDetails.isEmpty())
					ashiCaseEmployeeDetailsList.add(new ELCMECMstASHICaseEmployeeDetails(caseId, complainantDetails.get(0), actor, id.getRole()));
				else
					throw new CustomException("Details for id "+id.getMailId()+Constants.UNAVAILABLE);
			}
		}	
		return ashiCaseEmployeeDetailsList;

	}



	private CaseDetailsValidationResponse validateDuplicateDetails(List<ViewCurrEmpAllDetails> employees1,List<ViewCurrEmpAllDetails> employees2,String type1,String type2) {
		for(ViewCurrEmpAllDetails details:employees2) {
			if(employees1.contains(details))
				return new CaseDetailsValidationResponse(false, new StringBuilder(type1).append(" and ").append(type2).append(" id cannot be same.").toString());
		}
		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateCommonEmployeeCaseDetails(GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) {

		if(caseDetails.getIsStakeHolder()==1) {
			if(this.nullOrEmpty(caseDetails.getStakeholder()))
				return new CaseDetailsValidationResponse(false, "Please provide stake holder details");
			
			else {
				CaseDetailsValidationResponse stakeholderResponse = commonService.validateEmployeeDetails(caseDetails.getStakeholder(), Constants.STAKEHOLDER);
				if(!stakeholderResponse.isStatus())
					return stakeholderResponse;

				CaseDetailsValidationResponse stakeholderVsRespondentResponse = this.validateDuplicateDetails(validatedCaseDetails.getRespondentsInfy(), stakeholderResponse.getIds(), Constants.RESPONDENT, Constants.STAKEHOLDER);
				if(!stakeholderVsRespondentResponse.isStatus())
					return stakeholderVsRespondentResponse;

				validatedCaseDetails.setStakeholder(stakeholderResponse.getIds());
			}
		}

		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateGRBCaseDetails(GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) {
		if(caseDetails.getRaisingFor()==0 && caseDetails.getComplainantType()==1 && caseDetails.getIsComplainantKnown()==1) {

			if(this.nullOrEmpty(caseDetails.getComplainantsInfy()))
				return new CaseDetailsValidationResponse(false, "Please provide "+Constants.COMPLAINANT+" details");

			CaseDetailsValidationResponse complainantResponse = commonService.validateEmployeeDetails(caseDetails.getComplainantsInfy(), Constants.COMPLAINANT);
			if(!complainantResponse.isStatus())
				return complainantResponse;

			CaseDetailsValidationResponse complainantVsCaseInitiatorResponse = this.validateDuplicateDetails(Arrays.asList(validatedCaseDetails.getCaseInitiator()), complainantResponse.getIds(), Constants.CASE_INITIATOR, Constants.COMPLAINANT);
			if(!complainantVsCaseInitiatorResponse.isStatus())
				return complainantVsCaseInitiatorResponse;

			CaseDetailsValidationResponse complainantVsRespondentResponse = this.validateDuplicateDetails(validatedCaseDetails.getRespondentsInfy(), complainantResponse.getIds(), Constants.RESPONDENT, Constants.COMPLAINANT);
			if(!complainantVsRespondentResponse.isStatus())
				return complainantVsRespondentResponse;

			validatedCaseDetails.setComplainantsInfy(complainantResponse.getIds());
		}

		if(caseDetails.getRaisingFor()==0 && caseDetails.getComplainantType()==0 && (this.nullOrEmpty(caseDetails.getComplainantsOther())))
			return new CaseDetailsValidationResponse(false, "Please provide other complainants details"); 

		validatedCaseDetails.setComplainantsOther(caseDetails.getComplainantsOther());


		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateCategoryAndPOI(GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) {

		if(caseDetails.getComplaintCategory()<1)
			return new CaseDetailsValidationResponse(false, "Please select complaint category.");

		validatedCaseDetails.setComplaintCategory(caseDetails.getComplaintCategory());

		if(this.nullOrEmpty(caseDetails.getPlaceOfIncident()))
			return new CaseDetailsValidationResponse(false, "Please select place of incident.");

		validatedCaseDetails.setPlaceOfIncident(caseDetails.getPlaceOfIncident());

		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateEvidence(GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) throws CustomException {
		String folder = UUID.randomUUID().toString();
		List<String> validatedEvidences = new ArrayList<>();
		validatedCaseDetails.setFolder(folder);

		for(Object obj:caseDetails.getEvidences()) {
			DocumentData file=new ObjectMapper().convertValue(obj, DocumentData.class);

			if(!commonService.validateFile(file, folder, validatedEvidences)) 
				return new CaseDetailsValidationResponse(false, "Invalid File. Unable to upload attached file " + file.getFilename());	

		}
		validatedCaseDetails.setValidatedEvidences(validatedEvidences);
		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateCommonDetails(String caseInitiator,GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) {
		Optional<ViewCurrEmpAllDetails> caseInitiatorDetails=empDetailsRepository.findByEmpNoOrMailId(caseInitiator);
		if(!caseInitiatorDetails.isPresent())
			return new CaseDetailsValidationResponse(false, "Case-initiator id "+caseInitiator+Constants.INVALID);
		validatedCaseDetails.setCaseInitiator(caseInitiatorDetails.get());


		if(caseDetails.getRespondentType()==1 && caseDetails.getIsRespondentKnown()==1) {

			if(this.nullOrEmpty(caseDetails.getRespondentsInfy()))
				return new CaseDetailsValidationResponse(false, "Please provide "+Constants.RESPONDENT+" details");

			CaseDetailsValidationResponse respondentResponse = commonService.validateEmployeeDetails(caseDetails.getRespondentsInfy(), Constants.RESPONDENT);
			if(!respondentResponse.isStatus())
				return respondentResponse;

			CaseDetailsValidationResponse repondentVsCaseInitiatorResponse = this.validateDuplicateDetails(Arrays.asList(validatedCaseDetails.getCaseInitiator()), respondentResponse.getIds(), Constants.CASE_INITIATOR, Constants.RESPONDENT);
			if(!repondentVsCaseInitiatorResponse.isStatus())
				return repondentVsCaseInitiatorResponse;

			validatedCaseDetails.setRespondentsInfy(respondentResponse.getIds());
		}



		if(caseDetails.getRespondentType()==0 && (this.nullOrEmpty(caseDetails.getRespondentsOther())))
			return new CaseDetailsValidationResponse(false, "Please provide other respondents details");

		if(this.nullOrEmptyOrSelect(caseDetails.getCountry()))
			return new CaseDetailsValidationResponse(false, "Please select country.");

		if(this.nullOrEmpty(caseDetails.getDescription()))
			return new CaseDetailsValidationResponse(false, "Please enter complaint description.");

		if(caseDetails.getDescription().length()<200)
			return new CaseDetailsValidationResponse(false,Message.DESCRIPTIONLENGTH);

		if(this.nullOrEmptyOrSelect(caseDetails.getBaseLocation()))
			return new CaseDetailsValidationResponse(false, "Please select base location.");


		return new CaseDetailsValidationResponse(true);
	}

	private CaseDetailsValidationResponse validateCocomplainantAndWitness(GMFields caseDetails,ValidatedCaseDetails validatedCaseDetails) {

		CaseDetailsValidationResponse cocomplainantResponse = commonService.validateEmployeeDetails(caseDetails.getCocomplainants(), Constants.CO_COMPLAINANT);
		if(!cocomplainantResponse.isStatus())
			return cocomplainantResponse;

		CaseDetailsValidationResponse cocomplainantVsRespondentResponse = this.validateDuplicateDetails(validatedCaseDetails.getRespondentsInfy(), cocomplainantResponse.getIds(), Constants.RESPONDENT, Constants.CO_COMPLAINANT);
		if(!cocomplainantVsRespondentResponse.isStatus())
			return cocomplainantVsRespondentResponse;

		CaseDetailsValidationResponse cocomplainantVsCaseInitiatorResponse = this.validateDuplicateDetails(Arrays.asList(validatedCaseDetails.getCaseInitiator()), cocomplainantResponse.getIds(), Constants.CASE_INITIATOR, Constants.CO_COMPLAINANT);
		if(!cocomplainantVsCaseInitiatorResponse.isStatus())
			return cocomplainantVsCaseInitiatorResponse;

		validatedCaseDetails.setCocomplainants(cocomplainantResponse.getIds());

		CaseDetailsValidationResponse witnessResponse = commonService.validateEmployeeDetails(caseDetails.getWitnesses(), "Witness");
		if(!witnessResponse.isStatus())
			return witnessResponse;

		CaseDetailsValidationResponse witnessVsRespondentResponse = this.validateDuplicateDetails(validatedCaseDetails.getRespondentsInfy(), witnessResponse.getIds(), Constants.RESPONDENT, "Witness");
		if(!witnessVsRespondentResponse.isStatus())
			return witnessVsRespondentResponse;

		validatedCaseDetails.setWitnesses(witnessResponse.getIds());

		return new CaseDetailsValidationResponse(true);
	}

	@Override
	public CaseDetailsValidationResponse validateCaseDetails(String caseInitiator, GMFields caseDetails, String appType) throws CustomException{
		//check for logged in user GRB or normal
		boolean isGRB=this.isLoggedInUserAdmin();
		if(appType.equals("MOBILE"))
			isGRB=false;

		ValidatedCaseDetails validatedCaseDetails=new ValidatedCaseDetails(caseDetails,isGRB,appType);

		CaseDetailsValidationResponse commonCaseDetailsResponse=this.validateCommonDetails(caseInitiator, caseDetails, validatedCaseDetails);
		if(!commonCaseDetailsResponse.isStatus())
			return commonCaseDetailsResponse;

		CaseDetailsValidationResponse cocomplainantAndWitnessDetailsResponse=this.validateCocomplainantAndWitness(caseDetails, validatedCaseDetails);
		if(!cocomplainantAndWitnessDetailsResponse.isStatus())
			return cocomplainantAndWitnessDetailsResponse;

		if(isGRB) {
			CaseDetailsValidationResponse grbCaseDetailsResponse=this.validateGRBCaseDetails(caseDetails, validatedCaseDetails);
			if(!grbCaseDetailsResponse.isStatus())
				return grbCaseDetailsResponse;

			CaseDetailsValidationResponse categoryAndPOIResponse=this.validateCategoryAndPOI(caseDetails, validatedCaseDetails);
			if(!categoryAndPOIResponse.isStatus())
				return categoryAndPOIResponse;

		}
		else {
			CaseDetailsValidationResponse normalEmployeeCaseDetailsResponse=this.validateCommonEmployeeCaseDetails(caseDetails, validatedCaseDetails);
			if(!normalEmployeeCaseDetailsResponse.isStatus())
				return normalEmployeeCaseDetailsResponse;
		}

		if(appType.equals("MOBILE")) {
			validatedCaseDetails.setEvidences(new ArrayList<>());
		}
		else {
			CaseDetailsValidationResponse evidenceValidationResponse=this.validateEvidence(caseDetails, validatedCaseDetails);
			if(!evidenceValidationResponse.isStatus())
				return evidenceValidationResponse;
		}

		return new CaseDetailsValidationResponse(true, "Validated",validatedCaseDetails);
	}



	@Override
	public Response updateCocomplainantResponse(int transactionId, int response) {
		Optional<ELCMECMstASHICocomplainantsDetails> cocomplainantsDetails=ashiCocomplainantsDetailsRepository.findByTranIdAndFlgActive(transactionId,1);
		if(!cocomplainantsDetails.isPresent())
			return new Response(Message.ERROR, "Cocomplainant details not found");

		if(cocomplainantsDetails.get().getFlgAccept()==0 && cocomplainantsDetails.get().getFlgReject()==0) {
			if(response==1) 
				cocomplainantsDetails.get().setFlgAccept(1);
			else if(response==0)
				cocomplainantsDetails.get().setFlgReject(1);
			else
				return new Response(Message.ERROR, "Invalid response entered. Enter 1 or 0.");
		}
		else {
			if(cocomplainantsDetails.get().getFlgAccept()==1 && cocomplainantsDetails.get().getFlgReject()==0)
				return new Response(Message.ERROR, "Already accepted");
			else
				return new Response(Message.ERROR, "Already rejected");
		}

		List<CaseEmployeeDetails> employeeDetails=hrisMstEmployeeRepository.findCaseEmployeeDetails(cocomplainantsDetails.get().getMailId().trim());
		if(!employeeDetails.isEmpty()) {
			ashiCocomplainantsDetailsRepository.save(cocomplainantsDetails.get());
			ashiCaseEmployeeDetailsRepository.save(new ELCMECMstASHICaseEmployeeDetails(cocomplainantsDetails.get().getCaseId(), employeeDetails.get(0), "T"));
			return new Response(Message.SUCCESS, response==1?"Accepted successfully":"Rejected successfully");
		}

		return new Response(Message.ERROR, "Something went wrong. Please try again.");

	}


	@Override
	public GenModel initiateCaseForm() throws CustomException{

		boolean isGRB=this.isLoggedInUserAdmin();
		List<GenModelFormObj> genModelFormObjList=new ArrayList<>();
		List<GenModelForm> genModelFormList=new ArrayList<>();
		List<GenModelForm> accordionFormList=new ArrayList<>();
		List<GenModelForm> genModelFormListEvidence=new ArrayList<>();

		if(isGRB) {
			//complainant section
			List<GenModelField> complainantFieldList=new ArrayList<>();

			List<GenModelOption> raisingForOptions=Arrays.asList(new GenModelOption("1", "Myself",true),new GenModelOption(0, Constants.OTHERS));
			GenModelField raisingFor=new GenModelField( 47, "raisingFor", "Raising case for", "1", "", raisingForOptions, true);
			complainantFieldList.add(raisingFor);

			List<GenModelOption> complainantTypeOptions=Arrays.asList(new GenModelOption("1", "Infosys Employee",true),new GenModelOption(0, Constants.OTHERS));
			GenModelField complaintBy=new GenModelField( 47, "complainantType", "", "1", "raisingFor|0", complainantTypeOptions, false);
			complainantFieldList.add(complaintBy);

			GenModelField isComplainantKnown=new GenModelField( 45, "isComplainantKnown", "I know the identity of the complainant", 0, "complainantType|1", "",false);
			complainantFieldList.add(isComplainantKnown);

			GenModelField complainantInfy=new GenModelField( 46, "complainantsInfy", "Complainant (Complaint By)", "isComplainantKnown|1", property.getEmployeeSearchURL(), Message.EMPID_OR_EMPNO, false);
			complainantFieldList.add(complainantInfy);

			GenModelField complainantOther=new GenModelField( 0, "complainantsOther", "Complainant (Complaint By)","complainantType|0","","Enter names or identity of complainants separated by comma.", false);
			complainantFieldList.add(complainantOther);

			genModelFormList.add(new GenModelForm(Constants.COMPLAINANT, complainantFieldList));
		}

		//Respondent section
		List<GenModelField> respondentFieldList=new ArrayList<>();
		List<GenModelOption> respondentTypeOptions=new ArrayList<>();
		respondentTypeOptions.add(new GenModelOption("1", "Infosys Employee",true));
		respondentTypeOptions.add(new GenModelOption("0", Constants.OTHERS));
		GenModelField complaintAgainst=new GenModelField( 47, "respondentType", "Complaint against is", "1", "",respondentTypeOptions, true);
		respondentFieldList.add(complaintAgainst);

		GenModelField isIdentityKnown=new GenModelField( 45, "isRespondentKnown", "I know the identity of the respondent", 0,"respondentType|1","", true);
		respondentFieldList.add(isIdentityKnown);		

		GenModelField respondentInfy=new GenModelField( 46, "respondentsInfy", "Respondent (Complaint Against)", "isRespondentKnown|1", property.getEmployeeSearchURL(), Message.EMPID_OR_EMPNO, false);
		respondentFieldList.add(respondentInfy);

		GenModelField respondentOther=new GenModelField( 0, "respondentsOther", "Respondent (Complaint Against)", "respondentType|0", "", "Enter names or identity of respondents separated by comma.", false);
		respondentFieldList.add(respondentOther);

		genModelFormList.add(new GenModelForm(Constants.RESPONDENT, respondentFieldList));

		//Location section

		List<GenModelField> locationFieldList=new ArrayList<>();

		List<GenModelOption> countryOptions=reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1);
		countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

		GenModelField country=new GenModelField( 11, "country", "Country", WordUtils.capitalize(Constants.SELECT), "", countryOptions, true);
		locationFieldList.add(country);


		GenModelField city=new GenModelField( 11, "baseLocation", "Base Location", WordUtils.capitalize(Constants.SELECT), "country", new ArrayList<>(), true);
		city.setDependantAction(property.getBaselocationbycountrycodeURL());
		locationFieldList.add(city);

		genModelFormList.add(new GenModelForm("Your Current Location Details", locationFieldList, "", true));


		//Complaint Details section
		List<GenModelField> descriptionFieldList=new ArrayList<>();

		GenModelField description=new GenModelField( 1, "description", Constants.DESCRIPTION,"", "","Provide brief description of the incident in at least 200 characters", true);
		description.setValidations(Arrays.asList(new GenModelValidation("6", "200", Message.DESCRIPTIONLENGTH)));
		descriptionFieldList.add(description);

		genModelFormList.add(new GenModelForm("Complaint Details", descriptionFieldList));

		//Category and place of incident sections
		if(isGRB) {
			List<GenModelField> categoryFieldList=new ArrayList<>();
			List<GenModelOption> categoryOptions=concernModulesDetailsRepository.findASHICategories(2, "INFSYS", "IN");
			GenModelField complaintCategory=new GenModelField( 18, Constants.COMPLAINT_CATEGORY, "", categoryOptions.get(0).getValue(), "",categoryOptions, true);
			categoryFieldList.add(complaintCategory);

			genModelFormList.add(new GenModelForm("Complaint Category", categoryFieldList,"",true));

			List<GenModelField> placeOfIncidentFieldList=new ArrayList<>();
			List<GenModelOption> placeOfIncidentOptions=genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "POI");
			GenModelField placeOfIncident=new GenModelField( 18, "placeOfIncident", "", placeOfIncidentOptions.get(0).getValue(), "",placeOfIncidentOptions, true);
			placeOfIncidentFieldList.add(placeOfIncident);

			genModelFormList.add(new GenModelForm("Place of Incident", placeOfIncidentFieldList,"",true));
		}

		//Cocomplainant section
		List<GenModelField> cocomplainantFieldList=new ArrayList<>();
		GenModelField cocomplainant=new GenModelField( 46, "cocomplainants", "Tag Other Complainants", "", property.getEmployeeSearchURL(), "Email ID's / Emp. Nos of co-complainants or other impacted employees",true);
		cocomplainantFieldList.add(cocomplainant);

		accordionFormList.add(new GenModelForm("Other Complainants", cocomplainantFieldList));


		//Witnesses section
		List<GenModelField> witnessesFieldList=new ArrayList<>();

		GenModelField witnesses=new GenModelField( 46, "witnesses", "Tag Witnesses", "", property.getEmployeeSearchURL(),Message.EMPID_OR_EMPNO, true);
		witnessesFieldList.add(witnesses);

		accordionFormList.add(new GenModelForm(Constants.WITNESSES, witnessesFieldList));

		//Stakeholder section
		if(!isGRB) {
			List<GenModelField> stakeholderFieldList=new ArrayList<>();

			GenModelField isStakeHolder=new GenModelField( 45, "isStakeHolder", "Reported to any other stakeholder before raising the case", 0,"","", true);
			stakeholderFieldList.add(isStakeHolder);

			List<GenModelOption> stakeholderOptions=genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "SHR");

			GenModelField stakeholderRole=new GenModelField( 11, "stakeholderRole", "Stakeholder Role", stakeholderOptions.get(0).getValue(), "isStakeHolder|1", stakeholderOptions, false);
			stakeholderFieldList.add(stakeholderRole);

			GenModelField stakeholder=new GenModelField( 76, "stakeholder", Constants.STAKEHOLDER, "isStakeHolder|1", property.getEmployeeSearchURL(),Message.EMPID_OR_EMPNO, false);
			stakeholder.setDependantField("stakeholderRole");
			stakeholderFieldList.add(stakeholder);

			accordionFormList.add(new GenModelForm("Stakeholders", stakeholderFieldList));
		}

		//Evidence section
		List<GenModelField> evidenceFieldList=new ArrayList<>();
		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1"));
		validations.add(new GenModelValidation("15", "75", "Filename is too long. Please rename."));
		validations.add(new GenModelValidation("10", "5000|KB", "Exceeding file size limit"));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField evidences=new GenModelField( 60, Constants.EVIDENCES, "Add Evidences",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);
		evidenceFieldList.add(evidences);

		genModelFormListEvidence.add(new GenModelForm("Upload Evidences", evidenceFieldList));

		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormList), new GenModelFormData()));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(),new GenModelFormData("More Details On The Complaint (Optional)",accordionFormList)));
		genModelFormObjList.add(new GenModelFormObj(new GenModelFormData(genModelFormListEvidence), new GenModelFormData()));

		return new GenModel("Initiate Case Form", "", genModelFormObjList, new ArrayList<>());
	}

	@Override
	public LabelView getComplaintDetails(int caseId)  throws CustomException{


		List<ComplaintDetails> complaintDetailsWithRespondents=caseDetailsRepository.findComplaintDetailsByCaseId(caseId);

		List<CardViewField> fieldList=new ArrayList<>();
		if(!complaintDetailsWithRespondents.isEmpty()) {
			fieldList.add(new CardViewField("Respondent Type", complaintDetailsWithRespondents.get(0).getRespondentType(), 14));
			fieldList.add(new CardViewField(Constants.MANAGEDBYLABEL, complaintDetailsWithRespondents.get(0).getManagedBy(), 14));
			fieldList.add(new CardViewField(Constants.REPORTEDONLABEL, complaintDetailsWithRespondents.get(0).getReportedOn(), 14));
			fieldList.add(new CardViewField("Location", complaintDetailsWithRespondents.get(0).getLocation(), 14));
			fieldList.add(new CardViewField(Constants.DESCRIPTION, complaintDetailsWithRespondents.get(0).getDescription(), 54));
		}

		return new LabelView(Constants.CASE_DETAILS,fieldList);
	}


	@Override
	public CardView getCaseEmployeeDetails(int caseId)  throws CustomException{
		List<Card> cards=new ArrayList<>();

		if(!caseDetailsRepository.existsById(caseId))
			return new CardView("Employee details", cards);

		List<EmployeeDetails> respondentsDetails=ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId, Arrays.asList("R"));
		if(!respondentsDetails.isEmpty()) {
			List<CardViewField> fields=new ArrayList<>();
			List<CardViewField> highlightFields=new ArrayList<>();
			highlightFields.add(new CardViewField(Constants.RESPONDENTS, ""	, 14));
			for(EmployeeDetails details:respondentsDetails) {
				fields.add(new CardViewField(details.getName().trim(), details.getEmpNo().trim(), 14));
			}
			cards.add(new Card(highlightFields, fields));
		}
		else
			cards.add(new Card(Arrays.asList(new CardViewField(Constants.RESPONDENTS, "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));

		List<EmployeeDetails> witnessesDetails=ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId, Arrays.asList("W"));
		if(!witnessesDetails.isEmpty()) {
			List<CardViewField> fields=new ArrayList<>();
			List<CardViewField> highlightFields=new ArrayList<>();
			highlightFields.add(new CardViewField(Constants.WITNESSES, ""	, 14));
			for(EmployeeDetails details:witnessesDetails) {
				fields.add(new CardViewField(details.getName().trim(), details.getEmpNo().trim(), 14));
			}
			cards.add(new Card(highlightFields, fields));
		}
		else
			cards.add(new Card(Arrays.asList(new CardViewField(Constants.WITNESSES, "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));


		List<EmployeeDetails> cocomplainantsDetails=ashiCaseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseId, Arrays.asList("A","T"));
		cocomplainantsDetails.removeIf(c -> c.getEmpNo().trim().equals(Session.getTokenEMPNO()));
		if(!cocomplainantsDetails.isEmpty()) {
			List<CardViewField> fields=new ArrayList<>();
			List<CardViewField> highlightFields=new ArrayList<>();
			highlightFields.add(new CardViewField("Co-Complainants", ""	, 14));
			
			for(EmployeeDetails details:cocomplainantsDetails) {
				fields.add(new CardViewField(details.getName().trim(), details.getEmpNo().trim(), 14));
			}
			cards.add(new Card(highlightFields, fields));
		}
		else
			cards.add(new Card(Arrays.asList(new CardViewField("Co-Complainants", "", 14)), Arrays.asList(new CardViewField(Message.NOTAVAILABLE, "", 12))));

		return new CardView("Employee details", cards);
	}

	@Override
	public CardView getEvidences(int caseId) throws CustomException{
		List<Card> cards=new ArrayList<>();
		if(caseDetailsRepository.existsById(caseId)) {
			Optional<ELCMECTrnASHIActionDetails> evidenceString=ashiActionDetailsRepository.findevidencesByCaseId(caseId);
			if(evidenceString.isPresent() && this.notNullOrEmpty(evidenceString.get().getDmsFileName())) {
				String[] evidencesList=evidenceString.get().getDmsFileName().split(",");
				List<CardViewField> fields=new ArrayList<>();
				List<CardViewField> highlightFields=new ArrayList<>();
				highlightFields.add(new CardViewField("Evidences", Message.FILESIZE	, 14));
				for(String evidence:evidencesList) {
					fields.add(new CardViewField(evidence.trim(), MessageFormat.format(property.getDownloadURL(), "A", evidenceString.get().getCaseActionId(),evidence.trim()), 35));
				}
				if(commonService.checkIsActionEnabled("2", "ADCEV", Session.getCaseDetails().getStatus())) {
					fields.add(new CardViewField(Constants.ADD_EVIDENCE, property.getEvidenceGenModelURL().replace("{0}", String.valueOf(caseId)), 57));
				}
				cards.add(new Card(highlightFields, fields));
			}
			else {
				cards.add(new Card(Arrays.asList(new CardViewField("Evidences", Message.FILESIZE, 14)), Arrays.asList(new CardViewField(Message.NOFILE, "", 12),new CardViewField(Constants.ADD_EVIDENCE, property.getEvidenceGenModelURL().replace("{0}", String.valueOf(caseId)), 57))));
			}

		}
		return new CardView("Case evidences", cards);
	}



	@Override
	public Response uploadEvidence(GenModel evidenceGenModel, String folder, List<String> validatedEvidences) throws CustomException{
		GMFields input=commonService.convertGenModelToObject(evidenceGenModel, 0);
		int caseId=input.getCaseid();

		for(DocumentData file:input.getEvidences()) {

			if(!commonService.validateFile(file, folder, validatedEvidences)) 
				return  new Response(Message.ERROR, "Invalid File. Unable to upload attached file " + file.getFilename());	

		}

		Optional<ELCMECTrnASHIActionDetails> actionObj=ashiActionDetailsRepository.findevidencesByCaseId(caseId);
		if(actionObj.isPresent()) {
			StringBuilder filenameString=new StringBuilder();
			String dmsFileNames = commonService.uploadFilesToDMS(AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), folder, validatedEvidences, property.getDmsASHICaseDocFolder());
			if(this.notNullOrEmpty(actionObj.get().getDmsFileName()))
				filenameString.append(actionObj.get().getDmsFileName().trim()).append(",").append(dmsFileNames);
			else
				filenameString.append(dmsFileNames);

			actionObj.get().setDmsFileName(filenameString.toString());
			ashiActionDetailsRepository.save(actionObj.get());
			return new Response(Message.SUCCESS,"Successfully uploaded file.");
		}
		else
			return new Response(Message.ERROR,"Unable to find case.");
	}

	@Override
	public List<GenModelOption> getCitiesByCountryCode(String country)  throws CustomException{
		List<GenModelOption> cities = new ArrayList<>();
		cities.add(new GenModelOption(Constants.SELECT, "Select", true));
		
		List<GenModelOption> citiesList=cityRepository.getCitiesByCountryCodeNew(country);
		
		if(!citiesList.isEmpty()) {
			cities.addAll(citiesList);
			if(country.trim().equalsIgnoreCase("INDIA"))
				cities.add(new GenModelOption(0,"MYSORE-GEC"));	
		}
		
		return cities;
	}

	@Override
	public ASHIAccess checkHearAccess(String empNo)  throws CustomException{
		String baseLocation=genMstInfosysEstablishmentsRepository.findBaseLocationByEmpNo(empNo);
		Optional<HRISTrnEmpLocation> empLocationObj=empLocationRepository.findByEmpNo(empNo);

		if(empLocationObj.isPresent()) {

			String currentLocation=empLocationObj.get().getCurrentCountryCode();

			if(this.notNullOrEmpty(baseLocation) && this.notNullOrEmpty(currentLocation)
					&& baseLocation.trim().equalsIgnoreCase("INDIA") && currentLocation.trim().equalsIgnoreCase("IN")) {
				return new ASHIAccess(true);
			}
		}
		return new ASHIAccess(false);
	}




	@Override
	public GenModel getHearPolicy()  throws CustomException{
		String policy="Infosys has a global policy to address issues of sexual harassment at the workplace. The Grievance Redressal Body (GRB) established in 1999 helps to define, interpret and implement the Infosys Anti-Sexual Harassment Initiative (ASHI). We assure discretion and guarantee non-retaliation to all the complainants. We follow a gender neutral approach in redressing matters of sexual harassment.<br><br>The Policy on Prevention & Redressal of Sexual Harassment talks about prohibition of unlawful harassment from/to any employee of the Company towards other employees including supervisors, vendors and clients.";
		List<GenModelField> fieldList=new ArrayList<>();
		fieldList.add(new GenModelField(13, "ASHI_POLICY", "", policy, false, true ));
		return new GenModel("Policy Page", "", fieldList);

	}

	@Override
	public List<TabView> getInboxTabs()  throws CustomException{
		List<TabView> tabs=new ArrayList<>();

		tabs.add(new TabView("All", property.getAllURL()));
		tabs.add(new TabView("Initiated by Me", property.getInitiatedByMeURL()));
		tabs.add(new TabView("As a Co-Complainant", property.getCoComplainantURL()));
		tabs.add(new TabView("Initiated by GRB", property.getInitiatedByGRBURL()));
		return tabs;
	}


	@Override
	public InboxView getTaggedCases(String id)  throws CustomException{
		List<InboxCaseDetails> caseDetails=caseDetailsRepository.findTaggedCases(id);
		List<Header> headerList=this.getInboxHeaders();
		List<Row> rowList=new ArrayList<>();
		if(!caseDetails.isEmpty()) {
			int i=0;
			for(InboxCaseDetails details:caseDetails) {
				List<CardViewAction> actions=new ArrayList<>();
				if(details.getMessage().equals("NOT ACCEPTED")) {
					actions.add(new CardViewAction(Constants.ACCEPT, Constants.SERVICEURL, property.getCocomplainantAcceptURL()+details.getTransId(), Constants.POST, "Are you sure you want to be tagged as a co-complainant?"));
					actions.add(new CardViewAction(Constants.REJECT, Constants.SERVICEURL, property.getCocomplainantRejectURL()+details.getTransId(), Constants.POST, "Are you sure you do not want to be tagged as a co-complainant?"));
				}
				else if(details.getMessage().equals("ACCEPTED"))
					actions.add(new CardViewAction(1, Constants.CASE_ID, Constants.GET, commonService.getUIModuleId("CD"), Constants.REDIRECTID));
				
				rowList.add(new Row(details, ++i,actions));
			}

			return new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		}
		else
			return new InboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
	}

	private InboxView getInboxModelForRows(List<InboxCaseDetails> caseDetails, String mailId, String inboxName) {
		List<Header> headerList=this.getInboxHeaders();
		List<Row> rowList=new ArrayList<>();
		String moduleid = commonService.getUIModuleId("CD");
		if(!caseDetails.isEmpty()) {
			int i=0;
			for(InboxCaseDetails details:caseDetails) {
				List<CardViewAction> actions = new ArrayList<>();
				actions.add(new CardViewAction(1, Constants.CASE_ID, Constants.GET, moduleid, Constants.REDIRECTID));
				Optional<ELCMECMstASHIConciliationConsentDetails> consent = conciliationConsentDetailsRepository.findByCaseIdAndActorAndMailIdAndFlgAcceptAndFlgReject(details.getCaseId(), "A", mailId, 0, 0);
				if(consent.isPresent()) {
					actions.add(new CardViewAction(Constants.ACCEPT, Constants.SERVICEURL, property.getConsentAcceptURL()+consent.get().getSerialNo(), Constants.POST, "Are you sure you want to accept conciliation consent?"));
					actions.add(new CardViewAction(Constants.REJECT, Constants.SERVICEURL, property.getConsentRejectURL()+consent.get().getSerialNo(), Constants.POST, "Are you sure you do not want to reject conciliation consent?"));
				}

				rowList.add(new Row(details, ++i,actions));
			}

			return new InboxView(inboxName, "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		}
		else
			return new InboxView(inboxName, "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
	}

	@Override
	public InboxView getCasesInitiatedByMe(String empNo, String mailId)  throws CustomException{
		List<InboxCaseDetails> caseDetails=caseDetailsRepository.findMyCases(empNo, Arrays.asList("Self"));
		return this.getInboxModelForRows(caseDetails, mailId, "Tab - Initiated by me");
	}

	@Override
	public InboxView getCasesInitiatedByGRB(String empNo, String mailId) throws CustomException{

		List<InboxCaseDetails> caseDetails=caseDetailsRepository.findMyCases(empNo, Arrays.asList("GRB"));
		return this.getInboxModelForRows(caseDetails, mailId, "Tab - Initiated by GRB");

	}

	@Override
	public InboxView getAllCases(String empNo, String mailId)  throws CustomException{
		List<InboxCaseDetails> caseDetails=caseDetailsRepository.findMyCases(empNo, Arrays.asList("Self","GRB"));
		return this.getInboxModelForRows(caseDetails, mailId, "Tab - All");
	}


	private List<Header> getInboxHeaders(){
		return Arrays.asList(new Header(Constants.CASENUMBERLABEL, Constants.CASE_ID, "", true, 58, 0, "", "", false, ""),
				new Header(Constants.REPORTEDONLABEL, "reportedOn", "", false, 14, 0, "", "", false, ""),
				new Header(Constants.MANAGEDBYLABEL, "managedBy", "", false, 14, 0, "", "", false, ""),
				new Header(Constants.STATUSLABEL, "status", "", false, 14, 0, "", "", false, ""));
	}

	@Override
	public GenModel consentGenModel() throws CustomException{
		List<GenModelField> fieldList=new ArrayList<>();

		DPServiceOutput output=commonService.dpService("ASHI","CONTENT");

		fieldList.add(new GenModelField(54, "ASHI_DPCONSENT", "", output.getContent(), false, true));

		List<GenModelOption> isCheckedOptions=new ArrayList<>();
		isCheckedOptions.add(new GenModelOption(1, Constants.ACCEPT));
		isCheckedOptions.add(new GenModelOption(2, "Do not accept (If you check this box you will not be able to raise a case.)"));
		GenModelField isChecked=new GenModelField( 18, "isChecked", "", "", "",isCheckedOptions, true);
		isChecked.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select Accept / Do not accept before proceeding.")));
		fieldList.add(isChecked);

		return new GenModel("DP Consent", "", fieldList);
	}

	@Override
	public boolean isLoggedInUserAdmin() throws CustomException{
		CAMSInput input = new CAMSInput(property.getCamsAppCode(), Constants.MODULES, "2", "GRB", "Yes");
		List<CAMSOutput> adminList = commonService.camsService("CONTEXT", input);
		return !adminList.isEmpty();
	}

	@Override
	public List<String> getAdmins() throws CustomException {
		CAMSInput input = new CAMSInput(property.getCamsAppCode(), Constants.MODULES, "2", "GRB", "No");
		List<CAMSOutput> adminCamsList = commonService.camsService("CONTEXT", input);
		List<String> adminList=new ArrayList<>();
		for(CAMSOutput empNo:adminCamsList) {
			if(!adminList.contains(empNo.getEmpNo().trim()))
				adminList.add(empNo.getEmpNo().trim());
		}
		return adminList;
	}

	@Override
	public GenModel addEvidenceGenModel(int caseId)  throws CustomException{
		//Evidence section
		List<GenModelField> evidenceFieldList=new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, "caseid", "", caseId, true, false);
		caseidField.setEditable(false);
		evidenceFieldList.add(caseidField);

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), "Invalid filename. Filename can be alphanumeric and allowable special characters are underscore(_), hyphen(-) and space. Example :- ASHI_case proof-1"));
		validations.add(new GenModelValidation("15", "75", "Filename is too long. Please rename."));
		validations.add(new GenModelValidation("10", "5000|KB", "Exceeding file size limit"));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField evidences=new GenModelField( 57, Constants.EVIDENCES, Constants.ADD_EVIDENCE, new ArrayList<DocumentData>(), property.getUploadEvidenceURL(), Message.FILESIZE, validations);
		evidenceFieldList.add(evidences);

		return new GenModel(Constants.ADD_EVIDENCE, "", evidenceFieldList);
	}


	@Override
	public Response saveUserConsentApproval(GenModel genmodel)  throws CustomException{
		GMFields details = commonService.convertGenModelToObject(genmodel, 0);
		String initiateModuleId = commonService.getUIModuleId("IF");
		String policyModuleId = commonService.getUIModuleId("IN");
		if(details.isDPAccepted()) {
			try {
				DPServiceOutput output=commonService.dpService("ASHI","SAVE");
				if(output.getContent().equalsIgnoreCase("true"))
					return new Response(Message.SUCCESSPROCEED, "", "", initiateModuleId);
				else
					return new Response(Message.SUCCESSPROCEED, "Improper return from cams service : "+output.getContent(), "", policyModuleId);
			} catch (CustomException e) {
				return new Response(Message.SUCCESSPROCEED, e.getMessage(), "", policyModuleId);
			}
		}
		else
			return new Response(Message.SUCCESSPROCEED, "", "", policyModuleId);
	}

	@Override
	public DocumentData getASHIPolicyPDF() throws CustomException {
		DMSModel outputModel = commonService.dmsService(new DMSModel(property.getDmsApplicationName(), property.getDmsApplicationID(), property.getDmsStorageURL(), property.getDmsDocumentPath() + property.getDmsOfficialDocumentPath(), "Policy on Prevention and Redressal of Harassmen-India.pdf"), Constants.DOWNLOAD);
		return new DocumentData("Policy on Prevention and Redressal of Harassment-India.pdf", outputModel.getDocumentBytes());
	}

	private boolean notNullOrEmpty(String str) {

		return str!=null && !str.isEmpty();
	}

	private boolean nullOrEmpty(String str) {

		return str==null || str.isEmpty();
	}

	private boolean nullOrEmptyOrSelect(String str) {

		return str==null || str.isEmpty() || str.equalsIgnoreCase(Constants.SELECT);
	}



	@Override
	public InboxView getCasesAsRespondent(String id) throws CustomException {
		List<InboxCaseDetails> caseDetails=caseDetailsRepository.findCasesAsRespondent(id);
		List<Header> headerList=this.getInboxHeaders();
		List<Row> rowList=new ArrayList<>();
		if(!caseDetails.isEmpty()) {
			int i=0;
			for(InboxCaseDetails details:caseDetails) {
				List<CardViewAction> actions=new ArrayList<>();
				if(details.getMessage().equals("NOT ACCEPTED")) {
					actions.add(new CardViewAction(Constants.ACCEPT, Constants.SERVICEURL, property.getConsentAcceptURL()+details.getTransId(), Constants.POST, "Are you sure you want to accept conciliation consent?"));
					actions.add(new CardViewAction(Constants.REJECT, Constants.SERVICEURL, property.getConsentRejectURL()+details.getTransId(), Constants.POST, "Are you sure you do not want to reject conciliation consent?"));
				}
				
				rowList.add(new Row(details, ++i,actions));
			}

			return new InboxView("Tab - As a Respondent", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
		}
		else
			return new InboxView("Tab - As a Respondent", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");
	}
	
	@Override
	public CommunicationModel getCommunicationHistory(int caseid, String mailId) {
		List<ELCMECMstASHICommunicationDetails> communications = communicationRepository.findByCaseIdOrderBySerialNoDesc(caseid);

		List<CommentSummary> commentSummary = new ArrayList<>();
		
		for(ELCMECMstASHICommunicationDetails comm : communications) {
			if(mailId.equalsIgnoreCase(comm.getRespondedBy().trim())) {
				CommentSummary comment = new CommentSummary("", "Update Sought by " + comm.getSeekedByRole().trim(), new SimpleDateFormat(Constants.DATE_FORMAT).format(comm.getCreatedDate()), comm.getComments().trim(), comm.getRespondedBy(), "", new ArrayList<>(), new ArrayList<>());
				if(comm.getFlgResponded()==1) {
					comment.setReplies(Arrays.asList(new CommentSummary("", comm.getRespondedBy().trim(), new SimpleDateFormat(Constants.DATE_FORMAT).format(comm.getUpdatedDate()), comm.getResponse().trim(), comm.getRespondedBy().trim(), "", new ArrayList<>(), new ArrayList<>())));
				}
				
				else {
					GenModelField transactionidField=new GenModelField( 14, Constants.TRANSACTIONID, "", comm.getSerialNo(), true, false);
					transactionidField.setEditable(false);
					GenModelField replyField=new GenModelField( 1, "response", "","", "","", true);
					CardViewAction postAction = new CardViewAction(1, "Post", Constants.POST, property.getCommunicationReplyURL(), Constants.SERVICEURL);
					CardViewAction cancelAction = new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCEL);
					comment.setActions(Arrays.asList(new CommentSummaryAction("Add Your Reply", "replygenmodel", new GenModel("" , Arrays.asList(transactionidField, replyField), Arrays.asList(postAction, cancelAction)))));
				}
				
				commentSummary.add(comment);
			}
		}
		
		return new CommunicationModel("", "", "", new ArrayList<>(), commentSummary);
		
	}

	@Override
	public Response postCommunicationResponse(String mailid, GenModel genmodel) throws CustomException {
		GMFields details = commonService.convertGenModelToObject(genmodel, 0);
		
		Optional<ELCMECMstASHICommunicationDetails> comm = communicationRepository.findById(Integer.parseInt(details.getTransactionid()));
		
		if(comm.isPresent()){
			if(comm.get().getFlgResponded()==0) {
				if(comm.get().getRespondedBy().trim().equalsIgnoreCase(mailid)) {
					comm.get().setFlgResponded(1);
					comm.get().setResponse(details.getResponse());
					comm.get().setUpdatedDate(currentDateTime);
					
					communicationRepository.save(comm.get());
					this.triggerPostCommunicationResponseMail(comm.get());
					
					return new Response(Message.SUCCESS, "Successfully posted your response.");
				}
				
				else
					return new Response("You can't reply for this comment.");
			}
			else
				return new Response("Already responded for this comment.");
		}
		else
			return new Response(Message.INVALID_INPUT);
	}
	
	private void triggerPostCommunicationResponseMail(ELCMECMstASHICommunicationDetails details) throws CustomException {
		MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIPC");
		
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(details.getCaseId(), "IC");
		Optional<ViewCurrEmpAllDetails> employeeDetails=empDetailsRepository.findByEmpNoOrMailId(details.getRespondedBy());
		if(!(assigneeDetails.isPresent() && employeeDetails.isPresent())) 
			throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);

		String subject = mailInfo.getSubject();
		String body = mailInfo.getBody();
		String ids =  commonService.getIdStringByRoleAndModule("IC", "2", "IN", "INFSYS", assigneeDetails.get().getAssigneeLocation().trim());
		
		subject = subject.replace(Constants.CASEID_PH, String.valueOf(details.getCaseId()));
		body = body.replace(Constants.CASEID_PH, String.valueOf(details.getCaseId())).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(assigneeDetails.get().getAssigneeLocation().trim())).replace(Constants.EMPNAME_PH, WordUtils.capitalize(employeeDetails.get().getEmpName())).replace(Constants.EMPNO_PH, employeeDetails.get().getEmpNo()).replace(Constants.QUERY_PH, details.getComments()).replace(Constants.RESPONSE_PH, details.getResponse());

		MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), ids, "");
		PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

		MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

		MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
		if(mailerResponse.getCode()!=0)
			throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
	}
	
	@Override
	public Response updateConsentResponse(int transactionId, int response) throws CustomException {
		String action = "";
		String actor = "";
		Optional<ELCMECMstASHIConciliationConsentDetails> consentDetails=conciliationConsentDetailsRepository.findBySerialNo(transactionId);
		if(!consentDetails.isPresent())
			return new Response(Message.ERROR, "Consent details not found");

		if(consentDetails.get().getFlgAccept()==0 && consentDetails.get().getFlgReject()==0) {
			actor = consentDetails.get().getActor();
			if(response==1) {
				consentDetails.get().setFlgAccept(1);
				action = Constants.APPROVED;
			}
			else if(response==0) {
				consentDetails.get().setFlgReject(1);
				action = Constants.REJECTED;
			}
			else
				return new Response(Message.ERROR, "Invalid action.");
		}
		else {
			if(consentDetails.get().getFlgAccept()==1 && consentDetails.get().getFlgReject()==0)
				return new Response(Message.ERROR, "Already accepted");
			else
				return new Response(Message.ERROR, "Already rejected");
		}
		consentDetails.get().setUpdatedBy(Session.getTokenEMPNO());
		consentDetails.get().setUpdatedDate(currentDateTime);
		conciliationConsentDetailsRepository.save(consentDetails.get());
		return this.checkConsentStatus(consentDetails.get().getCaseId(), Session.getTokenEMPNO(), actor, action, response==1?"Accepted successfully":"Rejected successfully");
	}

	@Override
	public MailApprovalResponse mailBasedApprovalConciliationConsent(MailApprovalRequest request)
			throws CustomException {
		String message = "";
		String action = "";
		String actor = "";

		Optional<ELCMECMstASHIConciliationConsentDetails> consentDetails=conciliationConsentDetailsRepository.findBySerialNo(Integer.parseInt(request.getRequestID()));
		if(!consentDetails.isPresent())
			return new MailApprovalResponse(Message.ERROR.toUpperCase(), "Request details not found.");

		if(consentDetails.get().getFlgAccept()==0 && consentDetails.get().getFlgReject()==0) {
			actor = consentDetails.get().getActor();
			
			if(request.getActionName().equalsIgnoreCase("approve")) {
				consentDetails.get().setFlgAccept(1);
				message = "Request is accepted successfully.";
				action = Constants.APPROVED;
			}
			else if(request.getActionName().equalsIgnoreCase("reject")) {
				consentDetails.get().setFlgReject(1);
				message = "Request is rejected successfully.";
				action = Constants.REJECTED;
			}
			else
				return new MailApprovalResponse(Message.ERROR.toUpperCase(), "Invalid action.");
		}
		else {
			if(consentDetails.get().getFlgAccept()==1 && consentDetails.get().getFlgReject()==0)
				return new MailApprovalResponse("ACTED", "Request is already accepted.");
			else
				return new MailApprovalResponse("ACTED", "Request is already rejected.");
		}
		String actorUsername = AuthenticationClass.getUserMailFromLoginId(request.getActor()); 
		ViewCurrEmpAllDetails actorDetails = empDetailsRepository.findByEmpNoOrMailId(actorUsername).orElse(new ViewCurrEmpAllDetails("", actorUsername, ""));
		consentDetails.get().setUpdatedBy(actorDetails.getEmpNo());
		consentDetails.get().setUpdatedDate(currentDateTime);
		conciliationConsentDetailsRepository.save(consentDetails.get());
		Response response = this.checkConsentStatus(consentDetails.get().getCaseId(), actorDetails.getEmpNo(), actor, action, message);
		return new MailApprovalResponse(response.getType().toUpperCase(), response.getContent());
			
	}
	
	private Response checkConsentStatus(int caseid, String actorEmpNo, String actor, String action, String message) throws CustomException {
		List<ELCMECMstASHIConciliationConsentDetails> consents = conciliationConsentDetailsRepository.findByCaseId(caseid);
		
		String result = adminService.checkConciliationStatus(consents);
		
		if(result.equals("NI")) {
			Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(caseid);
			if(!caseDetails.isPresent())
				return new Response(Message.ERROR, Message.CASENOTREGISTERED);
			
			UpdateCaseStatusReturn response = adminService.updateCaseAndActionDetails(caseDetails.get(), actorEmpNo, "", "", "CRR", "", "");
			if(response.isSuccess()) {
				this.triggerConciliationConsentActionMail(caseid, actor, action, response.getAssigneeLocation());
				return new Response(Message.SUCCESS, message);
			}
			else
				return new Response(Message.ERROR, Message.UNABLE_TO_PROCEED);
		}
		
		else {
			Optional<ELCMECTrnASHIActionDetails> assigneeDetails = ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(caseid, "IC");
			if(!assigneeDetails.isPresent()) 
				throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);
			this.triggerConciliationConsentActionMail(caseid, actor, action, assigneeDetails.get().getAssigneeLocation());
			return new Response(Message.SUCCESS, message);
		}
	}
	
	private void triggerConciliationConsentActionMail(int caseid, String actor, String action, String assigneeLocation) throws CustomException {

		MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICCA");

		String subject = mailInfo.getSubject();
		String body = mailInfo.getBody();
		String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
		
		if(actor.equals("A"))
			actor = Constants.COMPLAINANT;
		else if(actor.equals("R"))
			actor = Constants.RESPONDENT;
		
		subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ACTOR_PH, actor).replace(Constants.ACTION_PH, action);
		body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, assigneeLocation).replace(Constants.ACTOR_PH, actor).replace(Constants.ACTION_PH, action);

		MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), ids, "");
		PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

		MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

		MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
		if(mailerResponse.getCode()!=0)
			throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());

	}
}
