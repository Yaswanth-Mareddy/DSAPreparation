package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnnoticedelegation")
public class CMSTrnNoticeDelegation {

	@Id
	@Column(name="intnoticeid")
	private int intNoticeID;
	
	@Column(name="txtnoticestatus")
    private String txtNoticeStatus;
	
	@Column(name="txtownerfrom")
	private String txtOwnerFrom;
	
	@Column(name="txtownerto")
	private String txtOwnerto;
	
	@Column(name="flgactive")
	private String flgActive;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;

}
