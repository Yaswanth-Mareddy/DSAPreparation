package com.example.demoInfyApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoInfyAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
