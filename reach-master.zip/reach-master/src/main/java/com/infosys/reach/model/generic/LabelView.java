package com.infosys.reach.model.generic;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class LabelView {

	private String name;
	private String guid;
	private String type;
	@JsonProperty("labelView")
	private Label view;
	private String transactionid;
	
	public LabelView(String name, List<CardViewField> fieldList) {
		this(name, "", "labelview", new Label(fieldList),"");
	}
	
	public LabelView(String name, String type, List<CardViewField> fieldList) {
		this(name, "", type, new Label(fieldList),"");
	}
	
	public LabelView(String name, String type, List<CardViewField> fieldList, List<CardViewAction> actions, String transactionid) {
		this(name, "", type, new Label(fieldList, actions), transactionid!=null ? transactionid.trim() : "");
	}
	
}
