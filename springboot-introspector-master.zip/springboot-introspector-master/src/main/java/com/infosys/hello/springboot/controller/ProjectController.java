package com.infosys.hello.springboot.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.hello.springboot.entity.Project;
import com.infosys.hello.springboot.model.Employee;
import com.infosys.hello.springboot.service.ProjectService;

import io.swagger.v3.oas.annotations.Operation;

@RequestMapping("/springboot/v1")
@RestController
public class ProjectController {
		
	@Autowired
	ProjectService projectService;

	/**
	 * This method is used to create a project. DB:MongoDB
	 * @param project
	 * @return
	 */
	@Operation(summary = "Add a Project.", tags="project")
	@RequestMapping(value = "/project", method = RequestMethod.POST)
	public ResponseEntity<HttpStatus> createProject(@Valid @NotEmpty @RequestBody Project project) {
		projectService.saveProject(project);
		return ResponseEntity.ok(HttpStatus.OK);
	}

	/**
	 * This method is used to fetch all the Projects data
	 * 
	 * @return - List<Projects>
	 */
	@Operation(summary = "Fetch all the projects.", tags="project")
	@GetMapping(value = "/projects", produces = MediaType.APPLICATION_JSON)
	public List<Project> projects() {
		return projectService.getProjects();
	}
	
	/**
	 * This is a sample method implementing feign client to communicate with other service.
	 * @param employeeId
	 * @return Employee Data
	 */
	@Operation(summary = "Feign client sample - This method will communicate to Employee service to fetch the employee data", tags="project")
	@GetMapping(value = "/project/{employeeId}", produces = MediaType.APPLICATION_JSON)
	public Employee getEmployee(@PathVariable(value="employeeId") int employeeId) {
		return projectService.getEmployee(employeeId);
	}
}
