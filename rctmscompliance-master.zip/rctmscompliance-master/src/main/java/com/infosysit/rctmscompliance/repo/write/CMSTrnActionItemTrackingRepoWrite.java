package com.infosysit.rctmscompliance.repo.write;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnActionItemTracking;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSTrnActionItemTrackingRepoWrite extends JpaRepository<CMSTrnActionItemTracking, Integer> {

	@Modifying
	@Query(value=CustomQueries.UPDATEACTIONITEMSTATUS)
	public void changeActionItemStatus(@Param("intActionItemId") int intActionItemId,@Param("txtActionItemStatus") String txtActionItemStatus);
}
