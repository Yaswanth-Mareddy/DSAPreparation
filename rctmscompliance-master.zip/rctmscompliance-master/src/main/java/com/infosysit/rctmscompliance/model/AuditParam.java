package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class AuditParam {

	private String txtEmpNo;
	private String txtActor;
	private String txtActivity;
	private String txtStatus;
	private String txtCategory;
	private String txtOlddata;
	private String txtNewData;
	private String txtOldRemark;
	private String txtNewRemark;
	private int intNodeID;
	private String dtAssignedDate;
}
