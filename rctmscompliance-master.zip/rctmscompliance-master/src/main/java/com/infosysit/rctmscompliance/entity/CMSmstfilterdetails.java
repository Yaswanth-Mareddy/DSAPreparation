package com.infosysit.rctmscompliance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstfilterdetails")
public class CMSmstfilterdetails {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intid")
	private int intID;
	
	@Column(name="txtcorrectiveaction")
	private String txtCorrectiveAction;
	
	@Column(name="txtremediation")
	private String txtRemediation;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedby;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
}
