package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="hristrnempinfosyslocation")
public class HRISTrnEmpInfosysLocation {
	
	@Id
	@Column(name = "intserialno")
	private int serialNo;
	
	@Column(name = "txtempno")
	private String empNo;
	
	@Column(name = "txtdevcentrecode")
	private String devCentreCode;
	
	@Column(name = "dteffectivedate")
	private Timestamp dtEffectiveDate;

}
