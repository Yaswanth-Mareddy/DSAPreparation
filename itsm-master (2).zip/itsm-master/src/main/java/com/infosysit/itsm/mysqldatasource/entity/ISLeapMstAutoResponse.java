package com.infosysit.itsm.mysqldatasource.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Entity
@Table(name="ISLeapMstAutoResponse")
public class ISLeapMstAutoResponse {
	


	
	@Column(name="txtCategoryName")
	private String txtCategoryName;
	
	@Column(name="txtKeyword")
	private String txtKeyword;
	
	@Column(name="txtSuggestion")
	private String txtSuggestion;
	
	@Column(name="txtStatusCode")
	private String txtStatusCode;
	
	@Column(name="txtTransfer")
	private String txtTransfer;
	

	
	@Column(name="txtNewDeptName")
	private String txtNewDeptName;
	
	@Column(name="intIsActive")
	private int intIsActive;
	
	@Column(name="txtNewCategoryName")
	private String txtNewCategoryName;
	
	@Id
	@Column(name="txtRuleNo")
	private String txtRuleNo;
	
	public ISLeapMstAutoResponse(String txtStatusCode, String txtSuggestion, String txtTransfer, String txtNewCategoryName,
			String txtNewDeptName) {
		super();
		this.txtStatusCode=txtStatusCode;
		this.txtSuggestion=txtSuggestion;
		this.txtTransfer = txtTransfer;
		this.txtNewCategoryName = txtNewCategoryName;
		this.txtNewDeptName = txtNewDeptName;
		
	}
}