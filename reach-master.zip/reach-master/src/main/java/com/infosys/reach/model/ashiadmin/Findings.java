package com.infosys.reach.model.ashiadmin;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Findings {

	private int serialNo;
	private String allegation;
	private String finding;
	private String outcome;
	private int flgFindingSent;
	private String empName;
	private String assigneeLocation;
	
	public Findings(int serialNo, String allegation, String finding, String outcome, int flgFindingSent) {
		super();
		this.serialNo = serialNo;
		this.allegation = allegation;
		this.finding = finding;
		this.outcome = outcome;
		this.flgFindingSent = flgFindingSent;
	}
	
	
}
