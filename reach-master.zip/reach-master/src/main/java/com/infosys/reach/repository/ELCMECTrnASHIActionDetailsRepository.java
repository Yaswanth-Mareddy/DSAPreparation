package com.infosys.reach.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnASHIActionDetailsRepository extends JpaRepository<ELCMECTrnASHIActionDetails, Integer> {

	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnASHIActionDetails> S save(S entity);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETEVIDENCESBASEDONCASEID)
	Optional<ELCMECTrnASHIActionDetails> findevidencesByCaseId(@Param("caseId") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETLATESTACTIONBYCASEID)
	Optional<ELCMECTrnASHIActionDetails> findByCaseIdAndMaxCaseActionId(@Param("caseId") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETALLACTIONBYCASEID)
	List<ELCMECTrnASHIActionDetails> findByCaseIdAndGreaterThanCaseActionId(@Param("caseId") int caseId, @Param("status") String status);
	
	@TrackExecutionTime
	List<ELCMECTrnASHIActionDetails> findByCaseIdAndStatusOrderByCaseActionIdDesc(int caseId, String status);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETASSIGNEELOCATIONBYROLEANDCASEID)
	Optional<ELCMECTrnASHIActionDetails> findAssigneeDetailsByRoleAndCaseId(@Param("caseId") int caseId, @Param("role") String role);
	
	@TrackExecutionTime
	List<ELCMECTrnASHIActionDetails> findByCaseIdOrderByCaseActionIdAsc(int caseId);
	
}
