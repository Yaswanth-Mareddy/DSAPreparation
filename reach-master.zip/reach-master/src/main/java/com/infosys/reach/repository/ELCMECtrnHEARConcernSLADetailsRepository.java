package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECtrnHEARConcernSLADetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECtrnHEARConcernSLADetailsRepository extends JpaRepository<ELCMECtrnHEARConcernSLADetails, Integer> {
	
	@TrackExecutionTime
	@Override
	<S extends ELCMECtrnHEARConcernSLADetails> S save(S entity);
}
