package com.infosysit.rctmscompliance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstmobilecontrols")
public class CMSMstMobileControls {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intid")
	private String intId ;
	
	@Column(name="txtparamname")
	private String txtParamName ;
	
	@Column(name="inttype")
	private int intType ;
	
	@Column(name="txtcontroldesc")
	private String txtControlDesc ;
	
	@Column(name="txtdisplaymessage")
	private String txtDisplayMessage ;
	
	@Column(name="txtisdependent")
	private String txtIsDependent ;
	
	@Column(name="txtdependentto")
	private String txtDependentTo;
	
	@Column(name="txturl")
	private String txtUrl;
	
	@Column(name="txtpagename")
	private String txtPageName;
	
	@Column(name="flgactive")
	private int flgActive ;
	
	@Column(name="txtispastdaterestricted")
	private String txtIsPastDateRestricted ;
	
	@Column(name="txtisrequired")
	private String txtIsRequired ;
	
	@Column(name="intlength")
	private int intLength ;
	
	@Column(name="txterrorMsg")
	private String txtErrorMsg ;
	
	@Column(name="txtisvisible")
	private String txtIsVisible ;
	
	@Column(name="intorder")
	private int intOrder ;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy ;
	
	@Column(name="dtlastmodified")
	private String dtLastModified ;
	
	@Column(name="options")
	private int options;
}
