package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class InboxView {

	private String name;
	private String guid;
	private String type;
	private List<Header> header;
	private List<Row> row;
	private int pagination;
	private List<CardViewAction> actions;
	private String filterservice;
	
	public InboxView(String name) {
		super();
		this.name = name;
		this.header = new ArrayList<>();
	}
	
	
}
