package com.infosys.reach;

import static org.junit.Assert.assertEquals;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ASHIAccess;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailApprovalRequest;
import com.infosys.reach.model.common.MailApprovalResponse;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.CommentSummary;
import com.infosys.reach.model.generic.CommunicationModel;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

public class ASHIControllerTests extends AbstractTest{

	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@MockBean
	ASHIServiceImpl service;
	
	@MockBean
	CommonServiceImpl webservice;


	@Override
	@Before
	public void setUp() {
		super.setUp();
		

	}

	@Test
	public void initiateCaseFormPositiveTest() throws Exception{
		GenModel objExpected=new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>());
		Mockito.when(service.initiateCaseForm()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/initiatecaseform").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getForms().size(), objActual.getForms().size());
	}

	@Test
	public void initiateCaseFormNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(service.initiateCaseForm()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/initiatecaseform").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void initiateCasePositiveTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.SUCCESS));

		GMFields caseDetails = new GMFields(); 
		ValidatedCaseDetails validatedCaseDetails = new ValidatedCaseDetails();
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(true, "", validatedCaseDetails);

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);
		Mockito.when(service.initiateASHICase( Mockito.any())).thenReturn(objExpected.get(0));

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/submitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void initiateCaseNegativeTest1() throws Exception{
		String message="You don't have access to use this application.";
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR, message));

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(false));

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/submitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void initiateCaseNegativeTest2() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		GMFields caseDetails = new GMFields(); 
		ValidatedCaseDetails validatedCaseDetails = new ValidatedCaseDetails();
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(true, "", validatedCaseDetails);

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);
		Mockito.when(service.initiateASHICase( Mockito.any())).thenThrow(new CustomException());

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/submitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void initiateCaseNegativeTest3() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR, "validation failed"));

		GMFields caseDetails = new GMFields(); 
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(false, "validation failed");

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/submitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}


	@Test
	public void updateCocomplainantResponsePositiveTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.SUCCESS));

		Mockito.when(service.updateCocomplainantResponse(Mockito.anyInt(),Mockito.anyInt())).thenReturn(objExpected.get(0));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/cocomplainant/response").header("Authorization", "Bearer "+token).param("response", "1").param("transactionid", "12345");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void updateCocomplainantResponseNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR, Message.SOMEERROROCCURED));

		Mockito.when(service.updateCocomplainantResponse(Mockito.anyInt(),Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/cocomplainant/response").header("Authorization", "Bearer "+token).param("response", "1").param("transactionid", "12345");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void getCaseDetailsByCaseIdPositiveTest() throws Exception{
		LabelView objExpected=new LabelView("Complaint details",  Arrays.asList(new CardViewField()));

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/complaintdetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		LabelView objActual=super.mapFromJson(content, LabelView.class);

		
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getView().getFields().size(), objActual.getView().getFields().size());
	}

	@Test
	public void getCaseEmployeeDetailsPositiveTest() throws Exception{
		CardView objExpected=new CardView("Employee details", Arrays.asList(new Card()));

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/caseemployeedetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		CardView objActual=super.mapFromJson(content, CardView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getCards().size(), objActual.getCards().size());
	}

	@Test
	public void getEvidencesPositiveTest() throws Exception{
		CardView objExpected=new CardView("Evidences", Arrays.asList(new Card()));

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/evidences").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		CardView objActual=super.mapFromJson(content, CardView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getCards().size(), objActual.getCards().size());
	}
	
	@Test
	public void getCaseDetailsByCaseIdPositiveTest2() throws Exception{
		
		Response objExpected=new Response(Message.ERROR, Message.CASENOTREGISTERED);

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenReturn(new LabelView("Complaint details",  Arrays.asList()));

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/complaintdetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}

	@Test
	public void getCaseEmployeeDetailsPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.CASENOTREGISTERED);

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenReturn(new CardView("Employee details", Arrays.asList()));

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/caseemployeedetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}

	@Test
	public void getEvidencesPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.CASENOTREGISTERED);

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenReturn(new CardView("Evidences", Arrays.asList()));

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/evidences").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}

	@Test
	public void addEvidencesGenModelPositiveTest() throws Exception{
		GenModel objExpected=new GenModel("Add Evidences", "", new ArrayList<>());

		Mockito.when(service.addEvidenceGenModel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/addevidences").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getFields().size(), objActual.getFields().size());
	}

	@Test
	public void getCitiesByCountryCodePositiveTest() throws Exception{
		List<GenModelOption> objExpected=Arrays.asList(new GenModelOption(1, "Manali"));

		Mockito.when(service.getCitiesByCountryCode(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/locations").header("Authorization", "Bearer "+token).param("country", "India");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);

		assertEquals(objExpected.size(), objActual.size());
	}

	@Test
	public void uploadEvidencePositiveTest() throws Exception{
		Response objExpected=new Response(Message.SUCCESS);

		Mockito.when(service.uploadEvidence(Mockito.any(), Mockito.anyString(), Mockito.anyList())).thenReturn(objExpected);

		String json=super.mapToJson(new GenModel("Upload evidence", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/uploadevidence").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getAllCasesPositiveTest1() throws Exception{
		InboxView objExpected=new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(new Row()), 10, new ArrayList<>(),"");

		Mockito.when(service.getAllCases(Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/all").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		InboxView objActual=super.mapFromJson(content, InboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	public void getAllCasesPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.NOCASEFOUND);

		Mockito.when(service.getAllCases(Mockito.anyString(), Mockito.anyString())).thenReturn(new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(), 10, new ArrayList<>(),""));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/all").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByMePositiveTest1() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.NOCASEFOUND);

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString(), Mockito.anyString())).thenReturn(new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(), 10, new ArrayList<>(),""));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbyme").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByMePositiveTest2() throws Exception{
		InboxView objExpected=new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(new Row()), 10, new ArrayList<>(),"");

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbyme").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		InboxView objActual=super.mapFromJson(content, InboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	public void getInboxInitiatedByGRBPositiveTest1() throws Exception{
		InboxView objExpected=new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(new Row()), 10, new ArrayList<>(),"");

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbygrb").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		InboxView objActual=super.mapFromJson(content, InboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	public void getInboxInitiatedByGRBPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.NOCASEFOUND);

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString(), Mockito.anyString())).thenReturn(new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(), 10, new ArrayList<>(),""));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbygrb").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByComcomplainantPositiveTest1() throws Exception{
		InboxView objExpected=new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(new Row()), 10, new ArrayList<>(),"");
		
		Mockito.when(service.getTaggedCases(Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/cocomplainant").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		InboxView objActual=super.mapFromJson(content, InboxView.class);
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	public void getInboxInitiatedByComcomplainantPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.NOCASEFOUND);
		
		Mockito.when(service.getTaggedCases(Mockito.anyString())).thenReturn(new InboxView("Tabs-All", "", "inboxview", new ArrayList<>(), Arrays.asList(), 10, new ArrayList<>(),""));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/cocomplainant").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getHearPolicyPositiveTest() throws Exception{
		GenModel objExpected=new GenModel("ASHI Policy", "", new ArrayList<>(), new ArrayList<>());

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(service.getHearPolicy()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/ashipolicy").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getFields().size(), objActual.getFields().size());
	}
	
	@Test
	public void getDPStatusPositiveTest1() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, "", "", "4164");
		DPServiceOutput objReturned=new DPServiceOutput("true");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		Mockito.when(webservice.getUIModuleId(Mockito.anyString())).thenReturn("4164");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getDPStatusPositiveTest2() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, "", "", "4163");
		DPServiceOutput objReturned=new DPServiceOutput("false");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		Mockito.when(webservice.getUIModuleId(Mockito.anyString())).thenReturn("4163");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getDPStatusPositiveTest3() throws Exception{
		Response objExpected = new Response(Message.ERROR, Message.NOACCESS);
		DPServiceOutput objReturned=new DPServiceOutput("NA");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void saveDPStatusPositiveTest1() throws Exception{
		Response objExpected=new Response(Message.SUCCESSPROCEED,"","","4164");

		Mockito.when(webservice.getUIModuleId(Mockito.anyString())).thenReturn("4164");
		Mockito.when(service.saveUserConsentApproval(Mockito.any())).thenReturn(objExpected);
		
		

		String json=super.mapToJson(new GenModel("DP Status", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/saveconsentapproval").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void saveDPStatusPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.SUCCESSPROCEED,"","","4164");
		Response consentReturn=new Response(Message.SUCCESSPROCEED,"","","4163");

		Mockito.when(webservice.getUIModuleId(Mockito.anyString())).thenReturn("4164", "4163");
		Mockito.when(service.saveUserConsentApproval(Mockito.any())).thenReturn(consentReturn);
		
		

		String json=super.mapToJson(new GenModel("DP Status", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/saveconsentapproval").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getdpcontentPositiveTest() throws Exception{
		GenModel objExpected=new GenModel("DP Consent", "", new ArrayList<>(), new ArrayList<>());

		Mockito.when(service.consentGenModel()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpcontent").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getFields().size(), objActual.getFields().size());
	}
	
	@Test
	public void downloadEvidencePositiveTest1() throws Exception{
		DocumentData objExpected=new DocumentData("file.jpeg", "abcdefghijklmnopqrstuvwxyz");

		Mockito.when(webservice.downloadDocuments(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList(objExpected));

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", "abc.pdf");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		DocumentData objActual=super.mapFromJson(content, DocumentData.class);

		assertEquals(objExpected.getFilename(), objActual.getFilename());
		assertEquals(objExpected.getBase64file(), objActual.getBase64file());
	}
	
	@Test
	public void downloadEvidencePositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR,"NOT FOUND");

		Mockito.when(webservice.downloadDocuments(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", "abc.pdf");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void downloadEvidencePositiveTest3() throws Exception{
		List<DocumentData> objExpected=Arrays.asList(new DocumentData("file1.jpeg", "abcdefghijklmnopqrstuvwxyz"), new DocumentData("file2.jpeg", "abcdefghijklmnopqrstuvwxyz"));

		Mockito.when(webservice.downloadDocuments(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", Constants.ALL);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<DocumentData> objActual=super.mapFromJsonList(content, DocumentData.class);

		assertEquals(objExpected.size(), objActual.size());
	}
	
	@Test
	public void downloadEvidencePositiveTest4() throws Exception{
		Response objExpected=new Response(Message.ERROR,"NOT FOUND");
		
		Mockito.when(webservice.downloadDocuments(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", Constants.ALL);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	

	
	@Test
	public void getCaseDetailsByCaseIdNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/complaintdetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void getCaseEmployeeDetailsNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/caseemployeedetails").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	

	@Test
	public void getEvidencesNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/evidences").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void addEvidencesGenModelNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.addEvidenceGenModel(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/addevidences").header("Authorization", "Bearer "+token).param("caseid", "123");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void getCitiesByCountryCodeNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getCitiesByCountryCode(Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/locations").header("Authorization", "Bearer "+token).param("country", "India");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void uploadEvidenceNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.uploadEvidence(Mockito.any(), Mockito.anyString(), Mockito.anyList())).thenThrow(new CustomException());

		String json=super.mapToJson(new GenModel("Upload evidence", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/uploadevidence").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	
	@Test
	public void getAllCasesNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getAllCases(Mockito.anyString(), Mockito.anyString())).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/all").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByMeNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString(), Mockito.anyString())).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbyme").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByGRBNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString(), Mockito.anyString())).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/initiatedbygrb").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxInitiatedByComcomplainantNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		Mockito.when(service.getTaggedCases(Mockito.anyString())).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/cocomplainant").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getHearPolicyNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(service.getHearPolicy()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/ashipolicy").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getDPStatusNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void saveDPStatusNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.SUCCESSPROCEED,Message.SOMEERROROCCURED));

		Mockito.when(webservice.getUIModuleId(Mockito.anyString())).thenReturn("4164");
		Mockito.when(service.saveUserConsentApproval(Mockito.any())).thenThrow(new CustomException());

		String json=super.mapToJson(new GenModel("DP Status", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/saveconsentapproval").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getdpcontentNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.consentGenModel()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/dpcontent").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void downloadEvidenceNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(webservice.downloadDocuments(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", "abc.pdf");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getASHIPolicyDocPositiveTest() throws Exception{
		DocumentData objExpected=new DocumentData("policy.pdf", "dyuagidygaildgaywidgaiwydgawyid");

		Mockito.when(service.getASHIPolicyPDF()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/ashipolicydoc").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		DocumentData objActual=super.mapFromJson(content, DocumentData.class);

		assertEquals(objExpected.getFilename(), objActual.getFilename());
		assertEquals(objExpected.getBase64file(), objActual.getBase64file());
	}
	
	@Test
	public void getASHIPolicyDocNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.getASHIPolicyPDF()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/ashipolicydoc").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void updateConsentResponsePositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS,"successfully updated consent status");

		Mockito.when(service.updateConsentResponse(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/consent/response").header("Authorization", "Bearer "+token).param("response", "1").param(Constants.TRANSACTIONID, "1");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void updateConsentResponseNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(service.updateConsentResponse(Mockito.anyInt(), Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/consent/response").header("Authorization", "Bearer "+token).param("response", "1").param(Constants.TRANSACTIONID, "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxAsRespondentPositiveTest1() throws Exception{
		InboxView objExpected=new InboxView("Tab - As a Respondent", "", "inboxview", new ArrayList<>(), Arrays.asList(new Row()), 10, new ArrayList<>(),"");
		
		Mockito.when(service.getCasesAsRespondent(Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/respondent").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		InboxView objActual=super.mapFromJson(content, InboxView.class);
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	public void getInboxAsRespondentPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR,Message.NOCASEFOUND);
		
		Mockito.when(service.getCasesAsRespondent(Mockito.anyString())).thenReturn(new InboxView("Tab - As a Respondent", "", "inboxview", new ArrayList<>(), Arrays.asList(), 10, new ArrayList<>(),""));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/respondent").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxAsRespondentNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		Mockito.when(service.getCasesAsRespondent(Mockito.anyString())).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/myinbox/respondent").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void communicationHistoryPositiveTest1() throws Exception{
		CommunicationModel objExpected = new CommunicationModel("", "", "", new ArrayList<>(), Arrays.asList(new CommentSummary()));
		
		Mockito.when(service.getCommunicationHistory(Mockito.anyInt(), Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/communicationhistory").header("Authorization", "Bearer "+token).param(Constants.CASEID, "1");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		CommunicationModel objActual=super.mapFromJson(content, CommunicationModel.class);
		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getCommentssummary().size(), objActual.getCommentssummary().size());
	}
	
	@Test
	public void communicationHistoryPositiveTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, "No communication happenend yet.");
		
		Mockito.when(service.getCommunicationHistory(Mockito.anyInt(), Mockito.anyString())).thenReturn(new CommunicationModel("", "", "", new ArrayList<>(), Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/communicationhistory").header("Authorization", "Bearer "+token).param(Constants.CASEID, "1");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void communicationHistoryNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		Mockito.when(service.getCommunicationHistory(Mockito.anyInt(), Mockito.anyString())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/communicationhistory").header("Authorization", "Bearer "+token).param(Constants.CASEID, "1");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void postCommunicationResponsePositiveTest() throws Exception{
		Response objExpected=new Response(Message.SUCCESS,"successfully replied");
		
		Mockito.when(service.postCommunicationResponse(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);
		
		String json=super.mapToJson(new GenModel("", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/communication/reply").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getType(), objActual.get(0).getType());assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void postCommunicationResponseNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		Mockito.when(service.postCommunicationResponse(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		
		String json=super.mapToJson(new GenModel("", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/communication/reply").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getType(), objActual.get(0).getType());
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void mailBasedApprovalConciliationConsentPositiveTest1() throws Exception{
		MailApprovalResponse objExpected=new MailApprovalResponse(Message.SUCCESS,"successfully processed");
		
		Mockito.when(service.mailBasedApprovalConciliationConsent(Mockito.any())).thenReturn(objExpected);
		
		String json=super.mapToJson(new MailApprovalRequest());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/conciliationconsent/mailbasedaction").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MailApprovalResponse objActual=super.mapFromJson(content, MailApprovalResponse.class);
		assertEquals(objExpected.getStatus(), objActual.getStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	public void mailBasedApprovalConciliationConsentPositiveTest2() throws Exception{
		MailApprovalResponse objExpected=new MailApprovalResponse(Message.ERROR, Message.SOMEERROROCCUREDMAIL);
		
		Mockito.when(service.mailBasedApprovalConciliationConsent(Mockito.any())).thenReturn(objExpected);
		
		String json=super.mapToJson(new MailApprovalRequest());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/conciliationconsent/mailbasedaction").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MailApprovalResponse objActual=super.mapFromJson(content, MailApprovalResponse.class);
		assertEquals(objExpected.getStatus(), objActual.getStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}
	
	@Test
	public void mailBasedApprovalConciliationConsentNegativeTest() throws Exception{
		MailApprovalResponse objExpected=new MailApprovalResponse(Constants.FAILURE, Message.SOMEERROROCCUREDMAIL);
		
		Mockito.when(service.mailBasedApprovalConciliationConsent(Mockito.any())).thenThrow(new RuntimeException());
		
		String json=super.mapToJson(new MailApprovalRequest());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/conciliationconsent/mailbasedaction").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);
		
		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MailApprovalResponse objActual=super.mapFromJson(content, MailApprovalResponse.class);
		assertEquals(objExpected.getStatus(), objActual.getStatus());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
	}

	
	
}
