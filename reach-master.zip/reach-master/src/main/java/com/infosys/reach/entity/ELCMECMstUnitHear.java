package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name="elcmecmstunithear")
public class ELCMECMstUnitHear {

	@Id
	@Column(name="txtunit")
	private String unit;
	
	@Column(name="txtemailid")
	private String emailId;
}
