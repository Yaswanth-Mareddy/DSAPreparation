package com.infosysit.rctmscompliance.repo.write;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSMstEscalationDetails;
import com.infosysit.rctmscompliance.entity.EscalationDetailsCompPKey;

@Repository
public interface CMSMstEscalationDetailsRepoWrite extends JpaRepository<CMSMstEscalationDetails, EscalationDetailsCompPKey> {

}
