package com.infosys.hello.springboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.hello.springboot.api.EmployeeServiceClient;
import com.infosys.hello.springboot.entity.Project;
import com.infosys.hello.springboot.model.Employee;
import com.infosys.hello.springboot.repository.ProjectRepository;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	ProjectRepository projectRepository;
	
	@Autowired
	EmployeeServiceClient employeeProxy;

	@Override
	public void saveProject(Project project) {
		projectRepository.save(project);
	}

	@Override
	public List<Project> getProjects() {
		return projectRepository.findAll();
	}
	
	@Override
	public Employee getEmployee(int employeeId) {
		return employeeProxy.findById(employeeId);
	}

}
