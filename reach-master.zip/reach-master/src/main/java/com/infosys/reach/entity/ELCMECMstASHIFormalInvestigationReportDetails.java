package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.ashi.GMFields;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmecmstashiformalinvestigationreportdetails")
public class ELCMECMstASHIFormalInvestigationReportDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtsummary")
	private String summary;

	@Column(name="txtadditionalfindings")
	private String additionalFindings;

	@Column(name="txtotherrecommendations")
	private String otherRecommendations;

	@Column(name="txtdmsinvestigationdocs")
	private String dmsInvestigationDocs;

	@Column(name="txtdmsfindings")
	private String dmsFindings;

	@Column(name="txtdmsreport")
	private String dmsReport;

	@Column(name="flginvestigationpanelapproval")
	private int flgInvestigationPanelApproval;

	@Column(name="txtdmsinvestigationpanelapprovals")
	private String dmsInvestigationPanelApprovals;

	@Column(name="txtinvestigationpanelreason")
	private String investigationPanelReason;

	@Column(name="flgpresidingofficersapproval")
	private int flgPresidingOfficersApproval;

	@Column(name="txtdmspresidingofficersapprovals")
	private String dmsPresidingOfficersApprovals;

	@Column(name="txtpresidingofficersreason")
	private String presidingOfficersReason;

	@Column(name="flgexticmembersapproval")
	private int flgExtICMembersApproval;

	@Column(name="txtdmsexticmembersapprovals")
	private String dmsExtICMembersApprovals;

	@Column(name="txtexticmembersreason")
	private String extICMembersReason;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="dtcreateddate")
	private Timestamp createdDate;

	@Column(name="txtupdatedby")
	private String updatedBy;

	@Column(name="dtupdateddate")
	private Timestamp updatedDate;
	
	@Column(name="flgclosedwithbothparties")
	private int flgClosedWithBothParties;
	
	@Column(name="txtdmsactionimplementaiondocs")
	private String dmsActionImplementaionDocs;

	public ELCMECMstASHIFormalInvestigationReportDetails(GMFields fields, String dmsInvestigationDocs, String createdBy, Timestamp createdDate) {
		super();
		this.caseId = fields.getCaseid();
		this.summary = fields.getFormalCaseSummary();
		this.otherRecommendations = fields.getFormalOtherRecommendation();
		this.dmsInvestigationDocs = dmsInvestigationDocs;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public ELCMECMstASHIFormalInvestigationReportDetails(ELCMECMstASHIFormalInvestigationReportDetails details, GMFields fields, String modifiedBy,
			Timestamp modifiedOn, String dmsInvestigationPanelApprovals, String dmsPresidingOfficersApprovals, String dmsExtICMembersApprovals) {
		super();
		this.serialNo = details.getSerialNo();
		this.caseId = details.getCaseId();
		this.summary = details.getSummary();
		this.additionalFindings = details.getAdditionalFindings();
		this.otherRecommendations = details.getOtherRecommendations();
		this.dmsInvestigationDocs = details.getDmsInvestigationDocs();
		this.dmsFindings = details.getDmsFindings();
		this.dmsReport = details.getDmsReport();
		this.flgInvestigationPanelApproval = fields.getFlgInvestigationPanelApproval();
		this.dmsInvestigationPanelApprovals = dmsInvestigationPanelApprovals;
		this.investigationPanelReason = fields.getInvestigationPanelReason();
		this.flgPresidingOfficersApproval = fields.getFlgPresidingOfficersApproval();
		this.dmsPresidingOfficersApprovals = dmsPresidingOfficersApprovals;
		this.presidingOfficersReason = fields.getPresidingOfficersReason();
		this.flgExtICMembersApproval = fields.getFlgExtICMembersApproval();
		this.dmsExtICMembersApprovals = dmsExtICMembersApprovals;
		this.extICMembersReason = fields.getExtICMembersReason();
		this.createdBy = details.getCreatedBy();
		this.createdDate = details.getCreatedDate();
		this.updatedBy = modifiedBy;
		this.updatedDate = modifiedOn;
	}
}
