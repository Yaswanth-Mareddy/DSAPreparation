package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="genmstinfosysestablishments")
public class GenMstInfosysEstablishments {

	@Id
	@Column(name="txtcountry")
	private String country;	
	
	@Column(name="txtsapcountrycode")
	private String sapCountryCode;
	
	@Column(name="txtcity")
	private String city;
	
	@Column(name="txtestablishmentcode")
	private String establishmentCode;
	
	@Column(name="intcitycode")
	private int cityCode;
	
	@Column(name="flgactive")
	private String isActive;

}
