package com.infosys.reach.model.hear;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HearCaseDetails {

	private int moduleId;
	private int categoryId;
	private String respondentEmpNo;                             
	private String taggedEmpMailId;                     
	private String comments;                 
	private String empManager;              
	private String empReviewer;               
	private int flgManager;              
	private int flgReviewer;              
	private int flgUnitHR;              
	private String managerReason;              
	private String reviewerReason;              
	private String unitHRReason;  
	private String selectedCountry;   
	private String selectedCity; 
	private int flgSeniorManagement;
	
}
