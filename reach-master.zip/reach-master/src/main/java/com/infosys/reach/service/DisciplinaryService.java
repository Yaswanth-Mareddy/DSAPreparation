package com.infosys.reach.service;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.common.InitiateCaseResponse;
import com.infosys.reach.model.disciplinary.CaseDetails;

public interface DisciplinaryService {
	
	InitiateCaseResponse initiateCase(String createdBy, String createdByMailId, CaseDetails caseDetails) throws CustomException;
}
