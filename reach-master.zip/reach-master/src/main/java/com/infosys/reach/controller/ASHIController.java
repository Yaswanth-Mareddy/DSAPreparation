package com.infosys.reach.controller;




import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CommunicationModel;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.MailApprovalRequest;
import com.infosys.reach.model.common.MailApprovalResponse;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * @author surajkumar.dewangan
 *
 */
@RestController
@CrossOrigin(origins = "*")
@Api(tags="ASHI Module : Employee Hub")
@RequestMapping("/v2/api")
public class ASHIController extends Logging{

	@ApiOperation(value="Fetch initiate case GenModel", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/initiatecaseform", produces="application/json")
	public ResponseEntity<Object> initiateASHICaseForm(){
		try {
			GenModel caseForm = ashiWebService.initiateCaseForm();
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched initiate case GenModel");
			return ResponseEntity.ok(caseForm);
		}

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	}


	@ApiOperation(value="Submit ASHI case", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/submitcase", produces="application/json", consumes="application/json")
	public ResponseEntity<Object> submitASHICase(@RequestBody GenModel caseGenModel) {
		String folder = "";
		List<String> validatedEvidences = new ArrayList<>();
		try {
			String initiatorId=Session.getTokenEMPNO();

			if(!ashiWebService.checkHearAccess(initiatorId).isHasAccess()) {
				String message="You don't have access to use this application.";
				Response response=new Response(Message.ERROR, message);
				telemetry.setLogEventData(Message.ERROR+" "+message);
				return ResponseEntity.ok(Arrays.asList(response));
			}
			GMFields caseDetails=commonService.convertGenModelToObject(caseGenModel, 1);

			CaseDetailsValidationResponse validateResponse=ashiWebService.validateCaseDetails(initiatorId,caseDetails,"WEB");

			if(validateResponse.isStatus()) {
				folder = validateResponse.getCaseDetails().getFolder();
				validatedEvidences = validateResponse.getCaseDetails().getValidatedEvidences();
				Response outputObj=ashiWebService.initiateASHICase(validateResponse.getCaseDetails());
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY submitted ASHI case.");
				return ResponseEntity.ok(Arrays.asList(outputObj));
			} 

			else {
				Response response=new Response(Message.ERROR, validateResponse.getMessage());
				telemetry.setLogEventData(Message.ERROR+" "+validateResponse.getMessage());
				return ResponseEntity.ok(Arrays.asList(response));
			}
		}
		catch (Exception e) {

			return this.registerExceptionLogs(e);
		}
		finally {
			this.deleteFilesFromTempPath(folder, validatedEvidences);

		}
	}


	@ApiOperation(value="Update cocomplainant's action on tagged case", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/cocomplainant/response", produces="application/json")
	public ResponseEntity<Object> updateCocomplainantResponse(@RequestParam(name="response", required=true) int response, @RequestParam(name=Constants.TRANSACTIONID, required=true) int transactionId) {
		try {
			Response output=ashiWebService.updateCocomplainantResponse(transactionId, response);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated co-complainants response.");
			return ResponseEntity.ok(Arrays.asList(output));
		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}


	@ApiOperation(value="Fetch complainant details", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/complaintdetails", produces="application/json")
	public ResponseEntity<Object> getCaseDetailsByCaseId(@RequestParam(name=Constants.CASEID, required=true) int caseId) {
		try{
			LabelView outputObj=ashiWebService.getComplaintDetails(caseId);			
			return ResponseEntity.ok(this.registerLogs(!outputObj.getView().getFields().isEmpty(), outputObj, "SUCCESSFULLY fetched complaint details.", Message.CASENOTREGISTERED));

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}


	@ApiOperation(value="Fetch case concerned employees details", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/caseemployeedetails", produces="application/json")
	public ResponseEntity<Object> getCaseEmployeeDetails(@RequestParam(name = Constants.CASEID,required = true) int caseId) {
		try{
			CardView outputObj=ashiWebService.getCaseEmployeeDetails(caseId);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case employee details.", Message.CASENOTREGISTERED)); 

		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Fetch case evidences", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/evidences", produces="application/json")
	public ResponseEntity<Object> getEvidences(@RequestParam(name = Constants.CASEID,required = true) int caseId) {
		try {
			CardView outputObj=ashiWebService.getEvidences(caseId);
			return ResponseEntity.ok(this.registerLogs(!outputObj.getCards().isEmpty(), outputObj, "SUCCESSFULLY fetched case evidences.", Message.CASENOTREGISTERED));

		} catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	}


	@ApiOperation(value="Fetch add evidences genmodel", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/addevidences", produces="application/json")
	public ResponseEntity<Object> addEvidencesGenModel(@RequestParam(name = Constants.CASEID,required = true) int caseId) {
		try {
			GenModel outputObj=ashiWebService.addEvidenceGenModel(caseId);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched add evidence GenModel.");
			return ResponseEntity.ok(outputObj);


		} 
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}
	}  


	@ApiOperation(value="Fetch locations for ASHI enabled country", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/locations", produces="application/json")
	public ResponseEntity<Object> getCitiesByCountryCode(@RequestParam(name = "country",required = true) String countryCode){
		try{
			List<GenModelOption> countryDetails= ashiWebService.getCitiesByCountryCode(countryCode);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched location options.");
			return ResponseEntity.ok(countryDetails);
		} 

		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}  

	}


	@ApiOperation(value="Upload more evidence", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/uploadevidence", produces="application/json")
	public ResponseEntity<Object> uploadEvidence(@RequestBody GenModel genmodel) {
		String folder = UUID.randomUUID().toString();
		List<String> validatedEvidences = new ArrayList<>();
		try{
			Response response= ashiWebService.uploadEvidence(genmodel, folder, validatedEvidences);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY uploaded new evidence.");
			return ResponseEntity.ok(Arrays.asList(response));
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);

		}


		finally {

			this.deleteFilesFromTempPath(folder, validatedEvidences);
		}
	}

	@ApiOperation(value="Fetch all cases", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/myinbox/all", produces="application/json")
	public ResponseEntity<Object> getInboxAll() {
		try {
			String empNo=Session.getTokenEMPNO();
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			InboxView details=ashiWebService.getAllCases(empNo, mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox all cases.", Message.NOCASEFOUND));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}
	}



	@ApiOperation(value="Fetch cases initiated by me", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/myinbox/initiatedbyme", produces="application/json")
	public ResponseEntity<Object> getInboxInitiatedByMe() {
		try {
			String empNo=Session.getTokenEMPNO();
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			InboxView details=ashiWebService.getCasesInitiatedByMe(empNo, mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases initiated by employee.", Message.NOCASEFOUND));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}
	}


	@ApiOperation(value="Fetch cases initiated by GRB", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/myinbox/initiatedbygrb", produces="application/json")
	public ResponseEntity<Object> getInboxInitiatedByGRB() {
		try {
			String empNo=Session.getTokenEMPNO();
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			InboxView details=ashiWebService.getCasesInitiatedByGRB(empNo, mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases initiated by GRB.", Message.NOCASEFOUND));
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Fetch tagged cases", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/myinbox/cocomplainant", produces="application/json")
	public ResponseEntity<Object> getInboxAsComcomplainant() {
		try {
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			InboxView details=ashiWebService.getTaggedCases(mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases tagged as co-complainant.", Message.NOCASEFOUND));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Fetch ASHI Policy page", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/ashipolicy", produces="application/json")
	public ResponseEntity<Object> getASHIPolicy() {

		try {
			String empNo=Session.getTokenEMPNO();
			GenModel policyPage=ashiWebService.getHearPolicy();
			return ResponseEntity.ok(this.registerLogs(ashiWebService.checkHearAccess(empNo).isHasAccess(), policyPage, "SUCCESSFULLY fetched ASHI Policy.", Message.NOACCESS));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Check DP consent status", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/dpstatus", produces="application/json")
	public ResponseEntity<Object> getDPStatus() {
		try {
			DPServiceOutput output=commonService.dpService("ASHI","STATUS");
			Response response=null;
			String message="SUCCESSFULLY fetched DP status eligibility model";
			if(output.getContent().equalsIgnoreCase("true")) {
				response=new Response(Message.SUCCESS, "", "", commonService.getUIModuleId("IF"));
				telemetry.setLogEventData(Message.SUCCESSFULLY+message);
			}
			else if(output.getContent().equalsIgnoreCase("false")) {
				response=new Response(Message.SUCCESS, "", "", commonService.getUIModuleId("DP"));
				telemetry.setLogEventData(Message.SUCCESSFULLY+message);
			}
			else {
				response=new Response(Message.ERROR, Message.NOACCESS);
				telemetry.setLogEventData(Message.ERROR+" "+Message.NOACCESS);
			}

			return ResponseEntity.ok(Arrays.asList(response));
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Save user consent approval", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/saveconsentapproval",produces = "application/json")
	public ResponseEntity<Object> saveDPStatus(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiWebService.saveUserConsentApproval(genmodel);
			if(output.getValue().equals(commonService.getUIModuleId("IF"))) {
				telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated user consent approval.");
				return ResponseEntity.ok(Arrays.asList(output));	
			}
			else {
				telemetry.setLogEventData(Message.ERROR+output.getContent());
				return ResponseEntity.ok(Arrays.asList(new Response(Message.SUCCESSPROCEED, "", "", commonService.getUIModuleId("IN"))));
			}

		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return ResponseEntity.ok(Arrays.asList(new Response(Message.SUCCESSPROCEED, Message.SOMEERROROCCURED)));
		}

	}


	@ApiOperation(value="Fetch DP content GenModel", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/dpcontent", produces="application/json")
	public ResponseEntity<Object> getDPContent() {
		try {
			GenModel output=ashiWebService.consentGenModel();
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY fetched DP form.");
			return ResponseEntity.ok(output);
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Download files", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/downloadfiles", produces="application/json")
	public ResponseEntity<Object> downloadFiles(@RequestParam(name = "type",required = true) String type, @RequestParam(name = Constants.TRANSACTIONID,required = true) int transactionid, @RequestParam(name = "filename",required = false,defaultValue = Constants.ALL) String filename) {
		try {
			List<DocumentData> docs=commonService.downloadDocuments(type, transactionid, filename);
			String message="NOT FOUND";

			if(!filename.equals(Constants.ALL)) {
				return ResponseEntity.ok(this.registerLogs(!docs.isEmpty(), !docs.isEmpty() ? docs.get(0) : new ArrayList<>(), "SUCCESSFULLY downloaded file.", message));
			}
			else
				return ResponseEntity.ok(this.registerLogs(!docs.isEmpty(), docs, "SUCCESSFULLY downloaded all files.", message));
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}


	@ApiOperation(value="Download ASHI Policy PDF", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/ashipolicydoc", produces="application/json")
	public ResponseEntity<Object> getASHIPolicyDoc() {
		try {
			telemetry.setLogEventData(Message.SUCCESSFULLY+"Successfully downloaded ASHI Policy doc.");
			return ResponseEntity.ok(ashiWebService.getASHIPolicyPDF());
		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="Update consent status", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/consent/response", produces="application/json")
	public ResponseEntity<Object> updateConsentResponse(@RequestParam(name="response", required=true) int response, @RequestParam(name=Constants.TRANSACTIONID, required=true) int transactionId) {
		try {
			Response output=ashiWebService.updateConsentResponse(transactionId, response);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY updated consent status");
			return ResponseEntity.ok(Arrays.asList(output));
		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value="Fetch cases as respondent", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/myinbox/respondent", produces="application/json")
	public ResponseEntity<Object> getInboxAsRespondent() {
		try {
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			InboxView details=ashiWebService.getCasesAsRespondent(mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getRow().isEmpty(), details, "SUCCESSFULLY fetched inbox cases as respondent.", Message.NOCASEFOUND));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}
	
	@ApiOperation(value="communication history", tags="ASHI Module : Employee Hub")
	@GetMapping(path="/communicationhistory", produces="application/json")
	public ResponseEntity<Object> communicationHistory(@RequestParam(name = Constants.CASEID,required = true) int caseid) {
		try {
			String mailId=AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID());
			CommunicationModel details=ashiWebService.getCommunicationHistory(caseid, mailId);
			return ResponseEntity.ok(this.registerLogs(!details.getCommentssummary().isEmpty(), details, "SUCCESSFULLY fetched communication history.", "No communication happenend yet."));

		}
		catch(Exception e) {
			return this.registerExceptionLogs(e);
		}

	}

	@ApiOperation(value="Post response for communication", tags="ASHI Module : Employee Hub")
	@PostMapping(path="/communication/reply", produces="application/json")
	public ResponseEntity<Object> postCommunicationResponse(@RequestBody GenModel genmodel) {
		try {
			Response output=ashiWebService.postCommunicationResponse(AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), genmodel);
			telemetry.setLogEventData(Message.SUCCESSFULLY+"SUCCESSFULLY responded for the comment.");
			return ResponseEntity.ok(Arrays.asList(output));
		}
		catch (Exception e) {
			return this.registerExceptionLogs(e);
		}	
	}
	
	@ApiOperation(value = "MailBasedApproval", tags = "ASHI Module : Employee Hub")
	@PostMapping(path = "/conciliationconsent/mailbasedaction")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "Authorization", value = "Authorization token", required = true, dataType = "string", paramType = "header") })
	public ResponseEntity<Object> mailBasedApprovalConciliationConsent(@RequestHeader HttpHeaders header,
			@RequestBody MailApprovalRequest request) {
		try {
			MailApprovalResponse response = ashiWebService.mailBasedApprovalConciliationConsent(request);
			telemetry.setLogEventData("Request body : " + request.toString() + ", Response : " +response.getStatus() + " " + response.getMessage());
			if(response.getStatus().equalsIgnoreCase(Message.ERROR)) 
				response.setMessage(Message.SOMEERROROCCUREDMAIL);
			return ResponseEntity.ok(response);
		}

		catch (Exception e) {
			telemetry.setExeceptionEventData(e);
			return ResponseEntity.ok(new MailApprovalResponse(Constants.FAILURE, Message.SOMEERROROCCUREDMAIL));
		}	
	}
}
