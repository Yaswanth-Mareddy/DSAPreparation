package com.infosysit.rctmscompliance.service;

import java.time.LocalDateTime;

import org.springframework.http.HttpHeaders;

import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.AppInfoJson;
import com.infosysit.rctmscompliance.model.CMSRemarkDTO;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserFinal;

public interface InbayService {

	public void assigneeInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException;
	public void assigneeDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException;
	public void verifierInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException;
	public void verifierDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException;
	public void ownerInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException;
	public void ownerDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException;
	public String inbayInsertRequest(String requestUrl,Object inbay) throws CustomException;
	public String inbayDeleteRequest(String requestUrl,Object inbay) throws CustomException;
	public AppInfoJson appJsonInfoOwner(ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException;
	public AppInfoJson appJsonInfoAssigneeAndVerifier(ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException;
	public String normalDate(String date) throws CustomException;
	public HttpHeaders getHeaders() throws CustomException;
	public String getZuluDateTime(LocalDateTime now) throws CustomException;
	public String mapToJson(Object obj) throws CustomException;
	public String getTransactionID(int intComplainceID,String dtAsisgnedDate) throws CustomException;
	void deleteActionItem(String strAppTransactionID, String strEmpNo) throws CustomException;
	void insertActionItem(int actionItemId, String strEmpNo) throws CustomException;
}
