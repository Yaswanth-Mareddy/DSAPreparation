package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnConcernSLADetails;

public interface ELCMECTrnConcernSLADetailsRepository extends JpaRepository<ELCMECTrnConcernSLADetails, Integer> {

}
