package com.infosys.reach.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.GenMstInfosysEstablishments;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface GenMstInfosysEstablishmentsRepository extends JpaRepository<GenMstInfosysEstablishments, String> {

	@TrackExecutionTime
	@Query(value=QueryConstants.GETCOUNTRYCODE)
	String findSapCountryCode(@Param("currentCountry")String currentCountry);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETBASELOCATION)
	String findBaseLocationByEmpNo(@Param("empNo")String empNo);
	
}
