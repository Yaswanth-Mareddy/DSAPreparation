package com.infosys.reach.model.common;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class MailInfo {

	private String appcode;
	private String eventID;
	private int templateID;
	private String fromId;
	private String toId;
	private String ccId;
	private String transactionFlowName;
	private String requestID;
	
	public MailInfo(String appcode, String eventID, int templateID, String fromId, String toId, String ccId) {
		super();
		this.appcode = appcode;
		this.eventID = eventID;
		this.templateID = templateID;
		this.fromId = fromId;
		this.toId = toId;
		this.ccId = ccId;
		this.transactionFlowName = "";
		this.requestID = "";
	}
	
	
}
