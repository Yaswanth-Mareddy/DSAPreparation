package com.infosys.reach.service;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.reach.controller.Session;
import com.infosys.reach.entity.ELCMECMstASHIFormalInvestigationReportDetails;
import com.infosys.reach.entity.ELCMECMstASHIPreliminaryDiscussionDetails;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.entity.ELCMECTrnASHIConciliationReportDetails;
import com.infosys.reach.entity.ELCMECTrnASHIInterimReliefDetails;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.CaseGenModelField;
import com.infosys.reach.model.ashimobile.CaseGenModelForm;
import com.infosys.reach.model.common.CAMSInput;
import com.infosys.reach.model.common.CAMSOutput;
import com.infosys.reach.model.common.CaseDetailsAuthorization;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.model.common.FieldData;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.WebServiceOutput;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelForm;
import com.infosys.reach.model.generic.GenModelFormObj;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.repository.ELCMECMstASHIFormalInvestigationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIPreliminaryDiscussionDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIConciliationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIInterimReliefDetailsRepository;
import com.infosys.reach.repository.ViewCurrEmpAllDetailsRepository;
import com.infosys.reach.util.AuthenticationClass;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;
import com.infosys.reach.util.TrackExecutionTime;

/**
 * @author surajkumar.dewangan
 *
 */
/**
 *
 */
@Service
public class CommonServiceImpl implements CommonService{

	@Autowired
	private Property property;
	
	@Autowired
	private WebServiceImpl webService;
	
	@Autowired
	private ViewCurrEmpAllDetailsRepository empDetailsRepository;

	@Autowired
	private ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;
	
	@Autowired
	private ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;
	
	@Autowired
	private ELCMECMstASHIPreliminaryDiscussionDetailsRepository preliminaryDiscussionDetailsRepository;
	
	@Autowired
	private ELCMECTrnASHIInterimReliefDetailsRepository interimReliefRepository;
	
	@Autowired
	private ELCMECTrnASHIConciliationReportDetailsRepository conciliationReportDetailsRepository;
	
	@Autowired
	private ELCMECMstASHIFormalInvestigationReportDetailsRepository formalInvestigationReportDetailsRepository;
	
	@Autowired
	private ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;
	
	@Autowired
	private ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;
	


	@TrackExecutionTime
	@Override
	public MailerAssistResponse triggerMail(MailerAssistRequest inputModel) throws CustomException {
		try {
			if(property.isFlgTriggerMail()) {
				inputModel.getMailInfo().setToId(property.getTestToId() + inputModel.getMailInfo().getToId());
			}
			String jsonInputString = new ObjectMapper().writeValueAsString(inputModel);

			WebServiceOutput output = webService.consumeRestService(property.getMailerAssistURL(), Constants.POST, true, Session.getJwtTOKEN(), jsonInputString);

			if(output.getStatusCode()==200)
				return new ObjectMapper().readValue(output.getResult(), MailerAssistResponse.class);
			else
				throw new CustomException(Constants.STATUS + " : " + output.getStatusCode() + ", " + Constants.OUTPUT + " : " + output.getResult());
		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}



	@TrackExecutionTime
	@Override
	public DPServiceOutput dpService(String module,String task) throws CustomException{
		try {
			String dpURL="";
			String apiType="";
			String resultString="";
			String parentId="";
			String childId="";
			if(module.equalsIgnoreCase("ASHI")) {
				parentId=property.getAshiParentId();
				childId=property.getAshiChildId();
			}
			if(module.equalsIgnoreCase("HEAR")) {
				parentId=property.getHearParentId();
				childId=property.getHearChildId();
			}
			
			if(task.equals("SAVE")) {
				apiType=Constants.POST;
				dpURL=MessageFormat.format(property.getDpUpdateStatusURL(), parentId, childId);

			}
			
			
			else if(task.equals("STATUS")) {
				apiType=Constants.GET;
				dpURL=MessageFormat.format(property.getDpStatusURL(), parentId);

			}

			else if(task.equals("CONTENT")) {
				apiType=Constants.GET;
				dpURL=MessageFormat.format(property.getDpConsentURL(), parentId);

			}

			String outputString = "";
			WebServiceOutput output = webService.consumeRestService(dpURL, apiType, true, Session.getJwtTOKEN(), "{}");
			if(output.getStatusCode()==200)
				outputString = output.getResult();
			else
				throw new CustomException(Constants.STATUS + " : " + output.getStatusCode() + ", " + Constants.OUTPUT + " : " + output.getResult());
			

			if(task.equals("SAVE"))
				resultString=outputString;
			else {
				JSONObject object=new JSONObject(outputString.substring(1,outputString.length()-1));

				if(task.equals("STATUS"))
					resultString=object.getString("strParentConsentStatus");
				if(task.equals("CONTENT"))
					resultString=object.getString("strTemplateContent");
			}

			return new DPServiceOutput(resultString);
		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}

	}

	@TrackExecutionTime
	@Override
	public DMSModel dmsService(DMSModel inputModel, String task) throws CustomException {
		try {
			int retry = 1;
			String serviceURL="";
			if(task.equals(Constants.UPLOAD)) {				
				serviceURL=property.getDmsUploadURL();
			}
			else if(task.equals(Constants.DOWNLOAD))
				serviceURL=property.getDmsDownloadURL();

			String jsonInputString = new ObjectMapper().writeValueAsString(inputModel);
			String result = "";
			int status = 0;
			while(retry<=3) {
				WebServiceOutput output = webService.consumeRestService(serviceURL, Constants.POST, true, Session.getJwtTOKEN(), jsonInputString);
				status = output.getStatusCode();
				if(status==200) {
					result = output.getResult();
					retry = 4;
				}
				else {
					result = Constants.STATUS + " : " + output.getStatusCode() + ", " + Constants.OUTPUT + " : " + output.getResult();
					retry++;
				}
			}
			
			if(status==200) {
				return new ObjectMapper().readValue(result, DMSModel.class);
			}
			else
				throw new CustomException(result);

		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}

	@TrackExecutionTime
	@Override
	public List<CAMSOutput> camsService(String type, CAMSInput inputModel) throws CustomException {
		try {
			String camsURL="";
			if(type.equals(Constants.CONTEXT))
				camsURL=property.getCamsContextURL();
			else if(type.equals("ROLES"))
				camsURL=property.getCamsRolesURL();
			else if(type.equals(Constants.USERCONTEXT))
				camsURL=property.getCamsUserContextURL();
			String jsonInputString = new ObjectMapper().writeValueAsString(inputModel);

			WebServiceOutput output = webService.consumeRestService(camsURL, Constants.POST, true, Session.getJwtTOKEN(), jsonInputString);
			
			if(output.getStatusCode()==200)
				return new ObjectMapper().readValue(output.getResult(), new TypeReference<List<CAMSOutput>>(){});
			else
				throw new CustomException(Constants.STATUS + " : " + output.getStatusCode() + ", " + Constants.OUTPUT + " : " + output.getResult());

		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}

	@TrackExecutionTime
	public List<GenModelOption> getCamsContextDropdown(String role, String moduleId, String country, String company, String location, String isLoginUser) throws CustomException{

		CAMSInput inputModel = new CAMSInput(property.getCamsAppCode(), role, moduleId, isLoginUser);
		String fetchContext = "";
		
	
		if(!StringUtils.isBlank(country)) {
			inputModel.setContetxtNameFilter2(Constants.COUNTRY);
			inputModel.setContetxtValueFilter2(country);

			if(!StringUtils.isBlank(company)) {
				inputModel.setContetxtNameFilter3(Constants.COMPANY);
				inputModel.setContetxtValueFilter3(company);

				if(!StringUtils.isBlank(location)) {
					inputModel.setContetxtNameFilter4(Constants.LOCATION);
					inputModel.setContetxtValueFilter4(location);
				}
				else {
					fetchContext = Constants.LOCATION;
				}
			}
			else {
				fetchContext = Constants.COMPANY;
			}
		}
		else {
			fetchContext = Constants.COUNTRY;
		}
	

		List<CAMSOutput> camsContexts = this.camsService(Constants.USERCONTEXT, inputModel);
		
		List<GenModelOption> contextOptions = new ArrayList<>();

		for(CAMSOutput context : camsContexts) {
			if(context.getContextName().equals(fetchContext) && contextOptions.stream().noneMatch(c -> c.getKey().equals(context.getContextValue().trim()))){
				contextOptions.add(new GenModelOption(context.getContextValue().trim(), context.getContextValue().trim()));
			}
		}

		return contextOptions;

	}

	@Override
	@TrackExecutionTime
	public String getIdStringByRoleAndModule(String role, String moduleId, String country, String company, String location) throws CustomException{
		List<GenModelOption> contextOptions = this.getIdsByModuleAndRole(role, moduleId, country, company, location, "No");
		StringBuilder ids=new StringBuilder();

		for(GenModelOption context : contextOptions) {
			if(!ids.toString().contains(context.getValue().trim())){
				ids.append(context.getValue().trim()).append(property.getInfyDomain()).append(";");
			}
		}

		return ids.toString();
	}
	

	public List<GenModelOption> getIdsByModuleAndRole(String role, String moduleId, String country, String company, String location, String isLoginUser) throws CustomException {
		CAMSInput inputModel = new CAMSInput(property.getCamsAppCode(), role, isLoginUser);
		
		if(!StringUtils.isBlank(moduleId)) {
			inputModel.setContetxtNameFilter1(Constants.MODULES);
			inputModel.setContetxtValueFilter1(moduleId);
		}
		
		if(!StringUtils.isBlank(country)) {
			inputModel.setContetxtNameFilter2(Constants.COUNTRY);
			inputModel.setContetxtValueFilter2(country);
		}
		
		if(!StringUtils.isBlank(company)) {
			inputModel.setContetxtNameFilter3(Constants.COMPANY);
			inputModel.setContetxtValueFilter3(company);
		}
		
		if(!StringUtils.isBlank(location)) {
			inputModel.setContetxtNameFilter4(Constants.LOCATION);
			inputModel.setContetxtValueFilter4(location);
		}
		
		List<CAMSOutput> camsContexts = this.camsService(Constants.USERCONTEXT, inputModel);
		
		List<GenModelOption> contextOptions = new ArrayList<>();

		for(CAMSOutput context : camsContexts) {
			if(contextOptions.stream().noneMatch(c -> c.getKey().equals(context.getEmpNo().trim()) && c.getValue().equals(context.getEmpMailId().trim()))){
				contextOptions.add(new GenModelOption(context.getEmpNo().trim(), context.getEmpMailId().trim()));
			}
		}

		return contextOptions;

	}
	
	
	@Override
	public List<GenModelOption> getCAMSRoles(String module, String isLoginUser, List<String> filter) throws CustomException {
		List<CAMSOutput> camsRoles = this.camsService("ROLES", new CAMSInput("ECS", Constants.MODULES, module, null, isLoginUser));

		List<GenModelOption> roleOptions = new ArrayList<>();

		for(CAMSOutput role : camsRoles) {
			if(!filter.isEmpty()) {
				if(filter.contains(role.getRoleName().trim()))
					roleOptions.add(new GenModelOption(role.getRoleName(), role.getRoleDesc()));
			}
			else
				roleOptions.add(new GenModelOption(role.getRoleName(), role.getRoleDesc()));

		}
		
		return roleOptions;
		
	}

	@Override
	@TrackExecutionTime
	public GMFields convertGenModelToObject(Object object, int type) {
		List<FieldData> fields=this.getAllGenModelFields(object, type);
		GMFields caseDetails=new GMFields();
		this.convertGenModelToObjectPart1(fields, caseDetails);
		this.convertGenModelToObjectPart2(fields, caseDetails);
		this.convertGenModelToObjectPart3(fields, caseDetails);
		this.convertGenModelToObjectPart4(fields, caseDetails);
		this.convertGenModelToObjectPart5(fields, caseDetails);
		this.convertGenModelToObjectPart6(fields, caseDetails);
		this.convertGenModelToObjectPart7(fields, caseDetails);
		this.convertGenModelToObjectPart8(fields, caseDetails);
		this.convertGenModelToObjectPart9(fields, caseDetails);
		this.convertGenModelToObjectPart10(fields, caseDetails);
		return caseDetails;

	}
	
	private List<FieldData> getAllGenModelFields(Object object, int type){
		List<CaseGenModelField> mobfields=new ArrayList<>();
		List<GenModelField> webfields=new ArrayList<>();
		if(type==1) {
			List<GenModelForm> formList=new ArrayList<>();
			GenModel genmodel = new ObjectMapper().convertValue(object, GenModel.class);
			for(GenModelFormObj obj:genmodel.getForms()) {
				formList.addAll(obj.getGenModel().getFormdata());
				formList.addAll(obj.getAccordion().getFormdata());
			}

			for(GenModelForm form:formList) {
				webfields.addAll(form.getFields());
			}
		}

		else if(type == 2) {
			List<CaseGenModelForm> formList=new ArrayList<>();
			CaseFormGenModel genmodel = new ObjectMapper().convertValue(object, CaseFormGenModel.class);
			formList.addAll(genmodel.getGenModel().getFormdata());
			formList.addAll(genmodel.getAccordion().getFormdata());

			for(CaseGenModelForm form:formList) {
				mobfields.addAll(form.getFields());
			}

		}
		else {
			GenModel genmodel = new ObjectMapper().convertValue(object, GenModel.class);
			webfields.addAll(genmodel.getFields());
		}
		return new FieldData().getFields(webfields, mobfields);
	}


	private void convertGenModelToObjectPart1(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				if (caseField.getName().equalsIgnoreCase("raisingFor"))
					caseDetails.setRaisingFor(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("respondentType"))
					caseDetails.setRespondentType(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("isRespondentKnown"))
					caseDetails.setIsRespondentKnown(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("respondentsOther"))
					caseDetails.setRespondentsOther(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("respondentsInfy"))
					caseDetails.setRespondentsInfy(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("complainantType"))
					caseDetails.setComplainantType(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("isComplainantKnown"))
					caseDetails.setIsComplainantKnown(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("complainantsOther"))
					caseDetails.setComplainantsOther(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("complainantsInfy"))
					caseDetails.setComplainantsInfy(caseField.getData().toString());
			}
		}
	}
	

	private void convertGenModelToObjectPart2(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				if (caseField.getName().equalsIgnoreCase("country"))
					caseDetails.setCountry(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("baseLocation"))
					caseDetails.setBaseLocation(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("description"))
					caseDetails.setDescription(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("placeOfIncident"))
					caseDetails.setPlaceOfIncident(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("complaintCategory"))
					caseDetails.setComplaintCategory(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("cocomplainants"))
					caseDetails.setCocomplainants(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("witnesses"))
					caseDetails.setWitnesses(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("isStakeHolder"))
					caseDetails.setIsStakeHolder(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("stakeholderRole"))
					caseDetails.setStakeholderRole(caseField.getData().toString());

				else if (caseField.getName().equalsIgnoreCase("stakeholder"))
					caseDetails.setStakeholder(caseField.getData().toString());

			}
		}
	}
	private void convertGenModelToObjectPart3(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				if (caseField.getName().equalsIgnoreCase("evidences")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setEvidences(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));

				}
				else if (caseField.getName().equalsIgnoreCase("caseid"))
					caseDetails.setCaseid(Integer.parseInt(caseField.getData().toString()));

				else if (caseField.getName().equalsIgnoreCase("isChecked") && (caseField.getData().toString().equals("1") || caseField.getData().toString().equals(Constants.ACCEPT))) {
					caseDetails.setDPAccepted(true);

				}
				
				else if (caseField.getName().equalsIgnoreCase("role"))
					caseDetails.setRole(caseField.getData().toString());
				
				else if (caseField.getName().equalsIgnoreCase("company"))
					caseDetails.setCompany(caseField.getData().toString());
				
			}
		}
	}

	private void convertGenModelToObjectPart4(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if (caseField.getName().equalsIgnoreCase("location")) {
					caseDetails.setLocation(caseField.getData().toString().isEmpty()?new ArrayList<>():Arrays.asList(caseField.getData().toString().split(",")));
				}
				
				else if (caseField.getName().equalsIgnoreCase("status")) {
					caseDetails.setStatus(caseField.getData().toString().isEmpty()?new ArrayList<>():Arrays.asList(caseField.getData().toString().split(",")));
				}
				
			}
		}
	}
	
	private void convertGenModelToObjectPart5(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if (caseField.getName().equalsIgnoreCase("discussedOn")) {
					caseDetails.setDiscussedOn(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("discussedWith")) {
					caseDetails.setDiscussedWith(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("summaryOfDiscussion")) {
					caseDetails.setDiscussionSummary(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("documents")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setDocuments(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));

				}
				
				else if (caseField.getName().equalsIgnoreCase("comments")) {
					caseDetails.setComments(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("assignedRole")) {
					caseDetails.setAssignedRole(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("assignedLocation")) {
					caseDetails.setAssignedLocation(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("assignedTo")) {
					caseDetails.setAssignedTo(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase(Constants.COMPLAINANT)) {
					caseDetails.setComplainant(caseField.getData().toString());
				}
			}
		}
	}
	
	private void convertGenModelToObjectPart6(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if (caseField.getName().equalsIgnoreCase("flgRelief")) {
					caseDetails.setFlgRelief(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("reliefs")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setReliefs(caseField.getOptions(), objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, String.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("otherRelief")) {
					caseDetails.setOtherRelief(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("remarks")) {
					caseDetails.setRemarks(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("mailTo")) {
					caseDetails.setMailTo(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("investigationType")) {
					caseDetails.setInvestigationType(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("conciliationReason")) {
					caseDetails.setConciliationReason(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("conciliationFindings")) {
					caseDetails.setConciliationFindings(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("conciliationRecommendations")) {
					caseDetails.setConciliationRecommendations(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("conciliationAggrementDocs")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setConciliationAggrementDocs(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));

				}
				
			}
		}
	}
	
	private void convertGenModelToObjectPart7(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if(caseField.getName().equalsIgnoreCase("action")) {
					caseDetails.setAction(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("transactionid")) {
					caseDetails.setTransactionid(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase(Constants.RESPONDENT)) {
					caseDetails.setRespondent(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase(Constants.WITNESS)) {
					caseDetails.setWitness(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("actionAgainst")) {
					caseDetails.setActionAgainst(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("severityLevel")) {
					caseDetails.setSeverityLevel(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("recommendedActions")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setRecommendedActions(caseField.getOptions(), objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, String.class)));

				}
				else if (caseField.getName().equalsIgnoreCase("summonsTo")) {
					caseDetails.setSummonsTo(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("summonsWith")) {
					caseDetails.setSummonsWith(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("formalCaseSummary")) {
					caseDetails.setFormalCaseSummary(caseField.getData().toString());
				}
				
			}
		}
	}
	
	private void convertGenModelToObjectPart8(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if(caseField.getName().equalsIgnoreCase("formalOtherRecommendation")) {
					caseDetails.setFormalOtherRecommendation(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("formalInvestigationDocs")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setFormalInvestigationDocs(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("investigationPanelApprovals")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setInvestigationPanelApprovals(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("flgInvestigationPanelApproval"))
					caseDetails.setFlgInvestigationPanelApproval(Integer.parseInt(caseField.getData().toString()));
				
				else if (caseField.getName().equalsIgnoreCase("investigationPanelReason")) {
					caseDetails.setInvestigationPanelReason(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("presidingOfficersApprovals")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setPresidingOfficersApprovals(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("flgPresidingOfficersApproval"))
					caseDetails.setFlgPresidingOfficersApproval(Integer.parseInt(caseField.getData().toString()));
				
				else if (caseField.getName().equalsIgnoreCase("presidingOfficersReason")) {
					caseDetails.setPresidingOfficersReason(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("extICMembersapprovals")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setExtICMembersapprovals(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("flgExtICMembersApproval"))
					caseDetails.setFlgExtICMembersApproval(Integer.parseInt(caseField.getData().toString()));
			}
		}
	}
	
	private void convertGenModelToObjectPart9(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if (caseField.getName().equalsIgnoreCase("extICMembersReason")) {
					caseDetails.setExtICMembersReason(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("slaExtendDate")) {
					caseDetails.setSlaExtendDate(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("extensionReason")) {
					caseDetails.setExtensionReason(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("recipientType")) {
					caseDetails.setRecipientType(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("recipient")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setRecipient(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, String.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("allegationDesc")) {
					caseDetails.setAllegationDesc(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("findings")) {
					caseDetails.setFindings(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("outcome")) {
					caseDetails.setOutcome(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("incidentDate")) {
					caseDetails.setIncidentDate(caseField.getData().toString());
				}
				

			}
		}
	}
	
	private void convertGenModelToObjectPart10(List<FieldData> fields, GMFields caseDetails) {
		for(FieldData caseField:fields) {
			if(caseField.getData()!=null) {
				
				if (Arrays.asList("checklistRespondent", "checklistComplainant", "checklistWitness").contains(caseField.getName())) {
					caseDetails.setChecklistRecommendations(caseField.getOptions());
				}
				
				else if (caseField.getName().equalsIgnoreCase("implementationDocs")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setImplementationDocs(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}
				
				else if (caseField.getName().equalsIgnoreCase("flgBothPartiesClosure")) {
					caseDetails.setFlgBothPartiesClosure(Integer.parseInt(caseField.getData().toString()));
				}
				
				else if (caseField.getName().equalsIgnoreCase("response")) {
					caseDetails.setResponse(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("template")) {
					caseDetails.setTemplate(caseField.getData().toString());
				}
				else if (caseField.getName().equalsIgnoreCase("chargesheet")) {
					caseDetails.setChargeSheetIssued(caseField.getData().toString());
				}
				
				else if (caseField.getName().equalsIgnoreCase("uploadchargesheet")) {
					ObjectMapper objectMapper = new ObjectMapper();
					caseDetails.setUploadchargesheet(objectMapper.convertValue(caseField.getData(), objectMapper.getTypeFactory().constructCollectionType(List.class, DocumentData.class)));
				}	
				
			}
		}
	}

	@Override
	@TrackExecutionTime
	public String uploadFilesToDMS(String mailId, String folder, List<String> validatedEvidences, String dmsFolder) throws CustomException {
		StringBuilder tempDirectory = new StringBuilder(property.getTempStoragePath()).append(folder).append("_").append(Session.getTokenEMPNO()).append("\\");
		try {
			StringBuilder dmsFileNames = new StringBuilder();

			for(String filename : validatedEvidences) {
				StringBuilder filepath = new StringBuilder(tempDirectory).append(filename);
				Path path = Paths.get(filepath.toString());
				byte[] pdf = Files.readAllBytes(path);
				byte[] encodedBytes = Base64.getEncoder().encode(pdf);
				String docBytes = new String(encodedBytes);

				DMSModel inputModel =  new DMSModel(property.getDmsApplicationName(), property.getDmsApplicationID(), property.getDmsStorageURL(), property.getDmsDocumentPath()+dmsFolder, filename, docBytes, mailId, "");
				DMSModel outputModel = this.dmsService(inputModel, Constants.UPLOAD);
				
				if(this.notNullOrEmpty(outputModel.getDocumentID()))
					dmsFileNames.append(",").append(outputModel.getDocumentName());
				else
					throw new CustomException("Unable to upload file "+filename);

			}

			return dmsFileNames.length()!=0 ? dmsFileNames.deleteCharAt(0).toString() : "";
		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
	}

	private String fileUploadToTempPath(DocumentData file, String tempDirectory) throws CustomException{

		StringBuilder filename = new StringBuilder(UUID.randomUUID().toString()).append(".").append(file.getFilename().split("\\.")[1].trim());


		File directory = new File(tempDirectory);
		if (! directory.exists()){
			directory.mkdir();
		}
		String tempfileFullPath = tempDirectory + filename.toString();

		File tempfile = new File(tempfileFullPath);

		try ( FileOutputStream fos = new FileOutputStream(tempfile); ) {
			byte[] decoder = Base64.getDecoder().decode(file.getBase64file());

			fos.write(decoder);

			return filename.toString();

		} 
		catch (Exception e) {
			throw new CustomException(e.getMessage());
		}


	}
	
	@Override
	@TrackExecutionTime
	public String validateAndUploadDocumentsToDMS(List<DocumentData> documents, String dmsFolder) throws CustomException {
		String tempFolder = UUID.randomUUID().toString();
		List<String> validatedDocuments = new ArrayList<>();
		try {
			for(DocumentData doc : documents) {
				if(!this.validateFile(doc, tempFolder, validatedDocuments))
					return  "Invalid File. Unable to upload "+doc.getFilename().trim() ;   
			}
			return this.uploadFilesToDMS(AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), tempFolder, validatedDocuments, dmsFolder);

		}
		catch(Exception e) {
			throw new CustomException(e.getMessage());
		}
		finally {
			this.deleteFolder(tempFolder, validatedDocuments);
		}
	}

	@Override
	@TrackExecutionTime
	public String deleteFolder(String folder, List<String> validatedEvidences) throws CustomException{
		try {
			StringBuilder tempDirectory = new StringBuilder(property.getTempStoragePath()).append(folder).append("_").append(Session.getTokenEMPNO());
			for(String filename : validatedEvidences) {
				StringBuilder filepath = new StringBuilder(tempDirectory).append("\\").append(filename);
				File f = new File(filepath.toString());
				if(f.exists()) 
					Files.delete(Paths.get(filepath.toString()));

			}
			return "Files deleted";
		}catch (Exception e) {
			throw new CustomException(e.getMessage());
		}
	}

	@Override
	@TrackExecutionTime
	public String deleteFiles(List<String> files) throws CustomException{
		try {
			for(String filename : files) {
				StringBuilder filepath = new StringBuilder(property.getTempStoragePath()).append("\\").append(filename);
				File f = new File(filepath.toString());
				if(f.exists()) 
					Files.delete(Paths.get(filepath.toString()));

			}
			return "Files deleted";
		}catch (Exception e) {
			throw new CustomException(e.getMessage());
		}
	}
	
	
	@TrackExecutionTime
	@Override
	public boolean validateFile(DocumentData file, String folder, List<String> validatedEvidences) throws CustomException {

		try {
			StringBuilder tempDirectory = new StringBuilder(property.getTempStoragePath()).append(folder).append("_").append(Session.getTokenEMPNO()).append("\\");
			String tempfile = this.fileUploadToTempPath(file, tempDirectory.toString());	
			boolean output = webService.filevalidationService(property.getFileValidationURL(), tempDirectory.append(tempfile).toString());
			if(output)
				validatedEvidences.add(tempfile);
			return output;

		} catch (CustomException e) {
			throw new CustomException(e.getMessage());
		}

	}




	@Override
	public String getUIModuleId(String paramId) {
		Optional<ELCMECMstSysParams> param = elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc(paramId, "UIMID");
		return param.isPresent() ? param.get().getParamDesc() : "";
	}
	
	/**
	 * Paramid:
	 * 
	 * ADDEMP	-	Add employee
	 * RMVEMP	-	Remove employee
	 * ADDPD	-	Add preliminary discussion
	 * UDILCP	-	Update incident date, location, category and place of incident
	 * SEEKIP	-	Seek inputs from complainants
	 * DLFRP	-	Download formal investigation report
	 * ADCEV	-	Add evidence by employee
	 * **/
	@Override
	public boolean checkIsActionEnabled(String moduleid, String paramId, String status) {
		Optional<ELCMECMstSysParams> param = elcmecMstSysParamsRepository.findByParamIdAndContextAndParamValue(paramId, "AAE", moduleid);
		
		return (param.isPresent() && Arrays.asList(param.get().getParamDesc().trim().split(",")).contains(status));

	}

	
	@Override
	public CaseDetailsValidationResponse validateEmployeeDetails(String idString,String type) {
		List<ViewCurrEmpAllDetails> employees=new ArrayList<>();
		

		if(idString!=null && !idString.isEmpty()) {
			for(String id:idString.split(",")) {

				Optional<ViewCurrEmpAllDetails> employeeDetails=empDetailsRepository.findByEmpNoOrMailId(type.equals(Constants.STAKEHOLDER)?id.split("\\|")[1].trim():id.trim());
				if(!employeeDetails.isPresent())
					return new CaseDetailsValidationResponse(false, new StringBuilder(type).append(" ").append(id).append(Constants.INVALID).toString());

				if(type.equals(Constants.STAKEHOLDER))
					employeeDetails.get().setRole(id.split("\\|")[0].trim());
				employees.add(employeeDetails.get());

			}
		}

		return new CaseDetailsValidationResponse(true, employees);
	}

	/* 
	 * 
	 *  Types:
	 *  
	 *  A - Case documents
	 *  P - Preliminary Discussion documents 
	 *  IR - Interim relief documents
	 *  CRA - Conciliation report agreement documents
	 *  CRO - Conciliation report other documents
	 *  ID - Investigation Documents from action tables
	 *  ADI - Investigation Panel approval Documents
	 *  ADP - Presiding officers approval Documents
	 *  ADE - External IC members approval Documents
	 *  AID - Action implementation documents
	 *  IID - Investigation documents from investigation table
	 *  */
	@Override
	public List<DocumentData> downloadDocuments(String type, int transactionid, String filename) throws CustomException {
		
		if(Arrays.asList("A", "P", "IR", "CRA", "CRO").contains(type)) {
			return this.downloadDocuments1(type, transactionid, filename);
		}
		else if(Arrays.asList("ID","ADI","ADP","ADE","AID").contains(type)) {
			return this.downloadDocuments2(type, transactionid, filename);
		}
		else if(Arrays.asList("CS","IID").contains(type))
			return this.downloadDocuments3(type, transactionid, filename);
		else
			return new ArrayList<>();

	}
	
	private List<DocumentData> downloadDocuments1(String type, int transactionid, String filename) throws CustomException {
		String dmsFiles = "";
		String dmsFolder = "";
		if(type.equals("A")) {
			Optional<ELCMECTrnASHIActionDetails> actionDetails = ashiActionDetailsRepository.findById(transactionid);
			dmsFiles = actionDetails.isPresent()?actionDetails.get().getDmsFileName():"";
			dmsFolder = property.getDmsASHICaseDocFolder();
		}
		else if(type.equals("P")) {
			Optional<ELCMECMstASHIPreliminaryDiscussionDetails> discussionDetails = preliminaryDiscussionDetailsRepository.findById(transactionid);
			dmsFiles = discussionDetails.isPresent()?discussionDetails.get().getDmsFileName():"";
			dmsFolder = property.getDmsASHIPreliminaryDiscussionFolder();
		}
		else if(type.equals("IR")) {
			Optional<ELCMECTrnASHIInterimReliefDetails> interimReliefDetails = interimReliefRepository.findById(transactionid);
			dmsFiles = interimReliefDetails.isPresent()?interimReliefDetails.get().getDmsFiles():"";
			dmsFolder = property.getDmsASHIInterimReliefFolder();
		}
		else if(type.equals("CRA")) {
			Optional<ELCMECTrnASHIConciliationReportDetails> conciliationReportDetails = conciliationReportDetailsRepository.findById(transactionid);
			dmsFiles = conciliationReportDetails.isPresent()?conciliationReportDetails.get().getAgreementDocs():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("CRO")) {
			Optional<ELCMECTrnASHIConciliationReportDetails> conciliationReportDetails = conciliationReportDetailsRepository.findById(transactionid);
			dmsFiles = conciliationReportDetails.isPresent()?conciliationReportDetails.get().getOtherDocs():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		return this.getAllDocuments(dmsFiles, dmsFolder, filename);

	}
	
	private List<DocumentData> downloadDocuments2(String type, int transactionid, String filename) throws CustomException {
		String dmsFiles = "";
		String dmsFolder = "";

		if(type.equals("ID")) {
			Optional<ELCMECTrnASHIActionDetails> actionDetails = ashiActionDetailsRepository.findById(transactionid);
			dmsFiles = actionDetails.isPresent()?actionDetails.get().getDmsFileName():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("ADI")) {
			Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findById(transactionid);
			dmsFiles = reportDetails.isPresent()?reportDetails.get().getDmsInvestigationPanelApprovals():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("ADP")) {
			Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findById(transactionid);
			dmsFiles = reportDetails.isPresent()?reportDetails.get().getDmsPresidingOfficersApprovals():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("ADE")) {
			Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findById(transactionid);
			dmsFiles = reportDetails.isPresent()?reportDetails.get().getDmsExtICMembersApprovals():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("AID")) {
			Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findById(transactionid);
			dmsFiles = reportDetails.isPresent()?reportDetails.get().getDmsActionImplementaionDocs():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		return this.getAllDocuments(dmsFiles, dmsFolder, filename);

	}
	
	private List<DocumentData> downloadDocuments3(String type, int transactionid, String filename) throws CustomException {
		String dmsFiles = "";
		String dmsFolder = "";

		if(type.equals("CS")) {
			Optional<ELCMECTrnASHICaseDetails> actionDetails = caseDetailsRepository.findById(transactionid);
			dmsFiles = actionDetails.isPresent()?actionDetails.get().getDmsChargeSheets():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		else if(type.equals("IID")) {
			Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findById(transactionid);
			dmsFiles = reportDetails.isPresent()?reportDetails.get().getDmsInvestigationDocs():"";
			dmsFolder = property.getDmsASHIInvestigationDocsFolder();
		}
		
		return this.getAllDocuments(dmsFiles, dmsFolder, filename);

	}

	
	/* 
	 * If parameter filename is ALL then fetch all documents else document with passed filename from DMS server
	 *  */
	private List<DocumentData> getAllDocuments(String dmsFiles, String dmsFolder, String filename) throws CustomException{
		List<DocumentData> fileDataList = new ArrayList<>();
		if(this.notNullOrEmpty(dmsFiles)) {
				String[] files = dmsFiles.split(",");
				
				for(String file : files) {
					if(filename.equals(Constants.ALL)) {
						DMSModel inputModel=new DMSModel(property.getDmsApplicationName(), property.getDmsApplicationID(), property.getDmsStorageURL(), property.getDmsDocumentPath() + dmsFolder, file, "", "","");
						DMSModel outputModel = this.dmsService(inputModel, Constants.DOWNLOAD);
						fileDataList.add(new DocumentData(outputModel.getDocumentName().trim(), outputModel.getDocumentBytes()));
					}
					else if(filename.equals(file.trim())){
						DMSModel inputModel=new DMSModel(property.getDmsApplicationName(), property.getDmsApplicationID(), property.getDmsStorageURL(), property.getDmsDocumentPath() + dmsFolder, file, "", "","");
						DMSModel outputModel = this.dmsService(inputModel, Constants.DOWNLOAD);
						fileDataList.add(new DocumentData(outputModel.getDocumentBytes()));
					}
					
				}
			
		}
		return fileDataList;
	}
	
	private boolean notNullOrEmpty(String str) {
		
		return str!=null && !str.isEmpty();
	}

	
	@Override
	public void checkCaseAuthorization(int caseid, boolean isAdmin) throws CustomException {
		Optional<CaseDetailsAuthorization> details = caseDetailsRepository.getCaseDetailsForAuthorization(caseid);
		if(details.isPresent()) {
			Session.setCaseDetails(details.get());
			
			if(isAdmin) {
				List<GenModelOption> contextOptions = this.getIdsByModuleAndRole(Session.getCaseDetails().getCurrentRole(), Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation(), "Yes");
				if(contextOptions.isEmpty()) {
					Session.setIsAuthorized(false);
					Session.setAuthorizedMessage(Message.ACCESSDENIED);
				}
				else {
					Session.setIsAuthorized(true);
					Session.setAuthorizedMessage(Message.ACCESSGRANTED);
				}
			}
			else {
				Session.setIsAuthorized(true);
			}
		}

		else {
			Session.setAuthorizedMessage(Message.CASENOTREGISTERED);
			Session.setIsAuthorized(false);
		}
	}


	@Override
	public List<GenModelOption> getGenModelOptionsByModuleIdAndGroupId(int moduleid, String groupId) {
		return genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(moduleid, groupId);
	}

}
