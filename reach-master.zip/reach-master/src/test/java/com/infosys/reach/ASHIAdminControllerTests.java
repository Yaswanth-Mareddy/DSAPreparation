package com.infosys.reach;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashiadmin.AdminInboxRow;
import com.infosys.reach.model.ashiadmin.FindingFilter;
import com.infosys.reach.model.ashiadmin.InboxFilter;
import com.infosys.reach.model.generic.AccordionView;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.Header;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.Label;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.model.generic.WorkFlow;
import com.infosys.reach.service.ASHIAdminServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;



public class ASHIAdminControllerTests extends AbstractTest{
	
	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	@MockBean
	ASHIAdminServiceImpl adminService;
	
	@MockBean
	CommonServiceImpl webservice;


	@Override
	@Before
	public void setUp() {
		super.setUp();
		}
	
	@Test
	public void positiveTest() {
		assertTrue(true);
	}
	 @Test
	  public void getFilterGenModelPositiveTest() throws Exception{
		GenModel objExpected=new GenModel("Admin Inbox", "", new ArrayList<>(), new ArrayList<>());
		
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 objExpected.setFields(fields);
		
		 Mockito.when(adminService.getInboxFilterGenmodel()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodel").header("Authorization", "Bearer "+token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getFields().get(0).getName(), objActual.getFields().get(0).getName());
	}
	
	@Test
	public void getFilterGenModelNegativeTest() throws Exception {
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.NOACCESS);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		objExpected.setFields(fields);
		Mockito.when(adminService.getInboxFilterGenmodel()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodel").header("Authorization", "Bearer "+token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	@Test
	public void getFilterGenModelNegativeTest1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(adminService.getInboxFilterGenmodel()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodel").header("Authorization", "Bearer "+token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	 
	@Test
	public void getOptionsByContextAndRolePositiveTest() throws Exception{
		List<GenModelOption> objExpected=new ArrayList<>();
		objExpected.add(new GenModelOption("SELECT","select", true));
		Mockito.when(webservice.getCamsContextDropdown(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/context/options").header("Authorization", "Bearer "+token)
				.param("context", "2").param("role","System Engineer");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);

		assertEquals(objExpected.get(0).getKey(), objActual.get(0).getKey());
	}
	@Test
	public void getOptionsByContextAndRoleNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(webservice.getCamsContextDropdown(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/context/options").header("Authorization", "Bearer "+token)
				.param("context", "2").param("role","System Engineer");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInLineFilterGenModelPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Filter By");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 objExpected.setFields(fields);
		
		//Mockito.when(adminService.getInboxInLineFilterGenmodel(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefilter/genmodel").header("Authorization", "Bearer " + token)
				.param("role", "Systems Engineer").param("country", "India").param("company", "Infosys");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	public void getInLineFilterGenModelNegativeTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.INVALID_INPUT);
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 objExpected.setFields(fields);		
		//Mockito.when(adminService.getInboxInLineFilterGenmodel(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefilter/genmodel").header("Authorization", "Bearer " + token)
				.param("role", "Systems Engineer").param("country", "India").param("company", "Infosys");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void getInLineFilterGenModelNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		//Mockito.when(adminService.getInboxInLineFilterGenmodel(Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefilter/genmodel").header("Authorization", "Bearer " + token)
				.param("role", "Systems Engineer").param("country", "India").param("company", "Infosys");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());

	}
	
	
	@Test
	public void getInboxGenmodelFilteredPositiveTestCase() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName("Please select role");
		Header header=new Header();
		header.setLabel("label");
		List<Header> headerList =new ArrayList<Header>();
		headerList.add(header);
		List<Row> row =new ArrayList<Row>();
		row.add(new Row(new AdminInboxRow(),1,new ArrayList<CardViewAction>()));
		objExpected.setRow(row);
		objExpected.setHeader(headerList);

		InboxFilter obj=new InboxFilter("Systems Engineer", "India", "Infosys", "");
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.getAdminInboxGenModelFiltered(Mockito.any(InboxFilter.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodelfiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
	    InboxView objActual = super.mapFromJson(content,InboxView.class);
		assertEquals(objExpected.getRow().get(0).getRowid(), objActual.getRow().get(0).getRowid());

	}
	@Test
	public void getInboxGenmodelFilteredNegativeTestCase() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName(Message.NOCASEFOUND);
		Header header=new Header();
		header.setLabel("label");
		List<Header> headerList =new ArrayList<Header>();
		headerList.add(header);
		List<Row> row =new ArrayList<Row>();
		objExpected.setRow(row);
		objExpected.setHeader(headerList);

		InboxFilter obj=new InboxFilter("Systems Engineer", "India", "Infosys", "");
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.getAdminInboxGenModelFiltered(Mockito.any(InboxFilter.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodelfiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(),objActual.get(0).getContent());
	}
	
	@Test
	public void getInboxGenmodelFilteredNegativeTestCase1() throws Exception {
		InboxView objExpected = new InboxView();
		List<Header> headerList =new ArrayList<Header>();
		objExpected.setHeader(headerList);
		
		InboxFilter obj=new InboxFilter("Systems Engineer", "India", "Infosys", "");
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.getAdminInboxGenModelFiltered(Mockito.any(InboxFilter.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodelfiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(),objActual.get(0).getValue());
	}
	
	@Test
	public void getInboxGenmodelFilteredNegativeTestCase2() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		InboxFilter obj=new InboxFilter("Systems Engineer", "India", "Infosys", "");
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.getAdminInboxGenModelFiltered(Mockito.any(InboxFilter.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/genmodelfiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(),objActual.get(0).getContent());
	}
	@Test
	public void getInboxInLineGenmodelFilteredPositiveTestCase() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName("Please select role");
		Header header=new Header();
		header.setLabel("label");
		List<Header> headerList =new ArrayList<Header>();
		headerList.add(header);
		List<Row> row =new ArrayList<Row>();
		row.add(new Row(new AdminInboxRow(),1,new ArrayList<CardViewAction>()));
		objExpected.setRow(row);
		objExpected.setHeader(headerList);

		GenModel obj=new GenModel("", new ArrayList<>(), new ArrayList<>());
	    String objJson=super.mapToJson(obj);
		//Mockito.when(adminService.getAdminInboxInLineFiltered(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
	    InboxView objActual = super.mapFromJson(content,InboxView.class);
		assertEquals(objExpected.getRow().get(0).getRowid(), objActual.getRow().get(0).getRowid());

	}
	

	@Test
	public void getInboxInLineGenmodelFilteredNegativeTestCase() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName(Message.NOCASEFOUND);
		Header header=new Header();
		header.setLabel("label");
		List<Header> headerList =new ArrayList<Header>();
		headerList.add(header);
		List<Row> row =new ArrayList<Row>();
		objExpected.setRow(row);
		objExpected.setHeader(headerList);

		GenModel obj=new GenModel("", new ArrayList<>(), new ArrayList<>());
	    String objJson=super.mapToJson(obj);
		//Mockito.when(adminService.getAdminInboxInLineFiltered(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void getInboxInLineGenmodelFilteredNegativeTestCase1() throws Exception {
		InboxView objExpected = new InboxView();
		objExpected.setName(Message.SOMEERROROCCURED);
		GenModel obj=new GenModel("", new ArrayList<>(), new ArrayList<>());
	    String objJson=super.mapToJson(obj);
		//Mockito.when(adminService.getAdminInboxInLineFiltered(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/inlinefiltered").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
		@Test
	public void getInboxActionGenModelPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Filter By");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 objExpected.setFields(fields);
		
		Mockito.when(adminService.getInboxActionForms(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/actiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("type", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	public void getInboxActionGenModelNegativeTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.CASENOTREGISTERED);
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 objExpected.setFields(fields);
		Mockito.when(adminService.getInboxActionForms(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/actiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("type", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	
	@Test
	public void getInboxActionGenModelNegativeTestCase1() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.SOMEERROROCCURED);
	
		
		Mockito.when(adminService.getInboxActionForms(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/inbox/actiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("type", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	

	
	
	@Test
	public void getCaseDetailsByCaseIdPositiveTestCase() throws Exception {
		List<CardViewField> fields  =new ArrayList<CardViewField>();
		fields.add(new CardViewField("Respondent Type", "", 14));
		Label label=new Label(fields);
		label.setFields(fields);
		
		LabelView objExpected =new LabelView("","labelview", null);
		objExpected.setView(label);
		
		Mockito.when(adminService.getCaseSummaryByCaseId(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/complaintdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		LabelView objActual = super.mapFromJson(content, LabelView.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	public void getCaseDetailsByCaseIdNegaitiveTestCase() throws Exception {
		LabelView objExpected =new LabelView();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<CardViewField> fields=new ArrayList<CardViewField>();
		Label label=new Label();
		label.setFields(fields);
		objExpected.setView(label);
		Mockito.when(adminService.getCaseSummaryByCaseId(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/complaintdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}

	@Test
	public void getCaseDetailsByCaseIdNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(adminService.getCaseSummaryByCaseId(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/complaintdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());

	}
    @Test
	public void getCaseEmployeeDetailsPositiveTestCase() throws Exception {
		List<CardViewField> fields  =new ArrayList<CardViewField>();
		fields.add(new CardViewField("Respondent Type", "", 14));
		Label label=new Label(fields);
		label.setFields(fields);
		
		LabelView objExpected =new LabelView("Employee details","labelview", null);
		objExpected.setView(label);
		
		Mockito.when(adminService.getCaseSummaryEmployeeDetails(Mockito.anyString(),Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employeedetails").header("Authorization", "Bearer " + token)
				.param(Constants.ACTOR, "R").param("transactionid", "0");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		LabelView objActual = super.mapFromJson(content, LabelView.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
    @Test
   	public void getCaseEmployeeDetailsPositiveTestCase1() throws Exception {
   		List<CardViewField> fields  =new ArrayList<CardViewField>();
   		fields.add(new CardViewField("Respondent Type", "", 14));
   		Label label=new Label(fields);
   		label.setFields(fields);
   		
   		LabelView objExpected =new LabelView("","labelview", null);
   		objExpected.setView(label);
   		
   		Mockito.when(adminService.getCaseSummaryEmployeeDetails(Mockito.anyString(),Mockito.anyInt())).thenReturn(objExpected);

   		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employeedetails").header("Authorization", "Bearer " + token)
   				.param(Constants.ACTOR, "R").param("transactionid", "1");

   		MvcResult result = mvc.perform(request).andReturn();
   		int status = result.getResponse().getStatus();
   		assertEquals(200, status);
   		String content = result.getResponse().getContentAsString();

   		LabelView objActual = super.mapFromJson(content, LabelView.class);
   		assertEquals(objExpected.getName(), objActual.getName());

   	}
	@Test
	public void getCaseEmployeeDetailsNegativeTestCase() throws Exception {
		LabelView objExpected =new LabelView();
		objExpected.setName("No employee details found.");
		List<CardViewField> fields=new ArrayList<CardViewField>();
		Label label=new Label();
		label.setFields(fields);
		objExpected.setView(label);
		
		Mockito.when(adminService.getCaseSummaryEmployeeDetails(Mockito.anyString(),Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employeedetails").header("Authorization", "Bearer " + token)
				.param(Constants.ACTOR, "R").param("transactionid", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	
	@Test
	public void getCaseEmployeeDetailsNegativeTestCase1() throws Exception {
		LabelView objExpected =new LabelView();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getCaseSummaryEmployeeDetails(Mockito.anyString(),Mockito.anyInt())).thenReturn(objExpected);

		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employeedetails").header("Authorization", "Bearer " + token)
				.param(Constants.ACTOR, "R").param("transactionid", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	
	@Test
	public void notifyCaseEmployeePositiveTestCase1() throws Exception {
		Response objExpected =new Response(Message.SUCCESS, "Successfully triggered notification mail");
		
		Mockito.when(adminService.triggerEmployeeNotificationMail(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(objExpected);

		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/notify").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1").param(Constants.ACTOR, "R").param("transactionid", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void notifyCaseEmployeeNegativeTestCase1() throws Exception {
		Response objExpected =new Response("unable to send");
		
		Mockito.when(adminService.triggerEmployeeNotificationMail(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(objExpected);

		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/notify").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1").param(Constants.ACTOR, "R").param("transactionid", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void notifyCaseEmployeeNegativeTestCase2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.triggerEmployeeNotificationMail(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenThrow(new CustomException());

		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/notify").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1").param(Constants.ACTOR, "R").param("transactionid", "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
		@Test
	public void getCaseSummaryEmployeeDropdownPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Case summary");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 objExpected.setFields(fields);
		
		Mockito.when(adminService.getCaseSummaryEmployeeDropDown(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employees").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("actor", "R");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	public void getCaseSummaryEmployeeDropdownNegativeTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.INVALID_INPUT);
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 objExpected.setFields(fields);
		
		Mockito.when(adminService.getCaseSummaryEmployeeDropDown(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employees").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("actor", "R");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void getCaseSummaryEmployeeDropdownNegativeTestCase1() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.SOMEERROROCCURED);
		 
		Mockito.when(adminService.getCaseSummaryEmployeeDropDown(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/employees").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("actor", "R");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
    @Test
	public void getpreviousComplaintsPositiveTestCase() throws Exception {
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView("", "Previous cases",new ArrayList<>());
	    objExpected.setCards(cardList);
		Mockito.when(adminService.viewPreviousComplaints(Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/previouscomplaints").header("Authorization", "Bearer " + token)
				.param("actor", "R").param("empno", "796601");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		CardView objActual = super.mapFromJson(content, CardView.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	public void getpreviousComplaintsNegativeTestCase() throws Exception {
		List<Card> cardList=new ArrayList<Card>();
		CardView objExpected=new CardView(Message.CASENOTREGISTERED, "Previous cases",new ArrayList<>());
	    objExpected.setCards(cardList);
		Mockito.when(adminService.viewPreviousComplaints(Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/previouscomplaints").header("Authorization", "Bearer " + token)
				.param("actor", "R").param("empno", "796601");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	
	@Test
	public void getpreviousComplaintsNegativeTestCase1() throws Exception {
		CardView objExpected=new CardView();
       objExpected.setName(Message.SOMEERROROCCURED);
		Mockito.when(adminService.viewPreviousComplaints(Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/previouscomplaints").header("Authorization", "Bearer " + token)
				.param("actor", "R").param("empno", "796601");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void addEmployeeGenModelPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Add Employee Details");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 objExpected.setFields(fields);
		 
		Mockito.when(adminService.addEmployeeGenModel(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployeegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "24").param("actor", "R");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());
	}
		@Test
		public void addEmployeeGenModelNegativeTestCase() throws Exception {
			GenModel objExpected = new GenModel();
			 objExpected.setName(Message.INVALID_INPUT);
		
			 List<GenModelField> fields=new ArrayList<GenModelField>();
			 objExpected.setFields(fields);
			 
			Mockito.when(adminService.addEmployeeGenModel(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

			RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployeegenmodel").header("Authorization", "Bearer " + token)
					.param(Constants.CASEID, "24").param("actor", "R");

			MvcResult result = mvc.perform(request).andReturn();
			int status = result.getResponse().getStatus();
			assertEquals(200, status);
			String content = result.getResponse().getContentAsString();

		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
	@Test
	public void addEmployeeGenModelNegativeTestCase1() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.SOMEERROROCCURED);
			 
		Mockito.when(adminService.addEmployeeGenModel(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployeegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "24").param("actor", "R");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	
	@Test
	public void addEmployeePositiveTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.SUCCESS);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addEmployee(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployee").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	
	@Test
	public void addEmployeeNegativeTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.ERROR);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addEmployee(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployee").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	@Test
	public void addEmployeeNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.SUCCESSPROCEED,Message.SOMEERROROCCURED));

		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addEmployee(Mockito.any(GenModel.class))).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addemployee").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	@Test
	public void removeEmployeePositiveTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.SUCCESS);
		objExpected.setContent(Message.SUCCESSFULLY);

		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 
		Mockito.when(adminService.removeEmployee(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/removeemployee").header("Authorization", "Bearer " + token)
				.param("transactionid", "12");
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	@Test
	public void removeEmployeeNegativeTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.ERROR);
		objExpected.setContent(Message.SOMEERROROCCURED);

		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "role", "Role", "", false, true));
		 
		Mockito.when(adminService.removeEmployee(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/removeemployee").header("Authorization", "Bearer " + token)
				.param("transactionid", "12");
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	@Test
	public void removeEmployeeNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.SUCCESSPROCEED,Message.SOMEERROROCCURED));
		 
		Mockito.when(adminService.removeEmployee(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/removeemployee").header("Authorization", "Bearer " + token)
				.param("transactionid", "12");
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());

	}
	@Test
	public void getLocationAndCategoryDetailsPositiveTestCase() throws Exception {
		List<CardViewField> fields  =new ArrayList<CardViewField>();
		fields.add(new CardViewField("Respondent Type", "", 14));
		Label label=new Label(fields);
		label.setFields(fields);
		
		LabelView objExpected =new LabelView("","labelview", null);
		objExpected.setView(label);
		
		Mockito.when(adminService.getLocationAndCategoryDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		LabelView objActual = super.mapFromJson(content, LabelView.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	public void getLocationAndCategoryDetailsNegativeTestCase() throws Exception {
		LabelView objExpected =new LabelView();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<CardViewField> fields=new ArrayList<CardViewField>();
		Label label=new Label();
		label.setFields(fields);
		objExpected.setView(label);
		
		Mockito.when(adminService.getLocationAndCategoryDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void getLocationAndCategoryDetailsNegativeTestCase1() throws Exception {
		LabelView objExpected =new LabelView();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getLocationAndCategoryDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationdetails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
@Test
	public void getLocationAndCategoryGenmodelPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Location and Category");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		 objExpected.setFields(fields);
		 
		
		Mockito.when(adminService.getLocationAndCategoryGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	@Test
	public void getLocationAndCategoryGenmodelNegativeTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.CASENOTREGISTERED);
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 objExpected.setFields(fields);
		Mockito.when(adminService.getLocationAndCategoryGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());


	}
	
	@Test
	public void getLocationAndCategoryGenmodelNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(adminService.getLocationAndCategoryGenmodel(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/locationgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void updateLocationAndCategoryDetailsPositiveTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.SUCCESS);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateLocationAndCategoryDetails(Mockito.any(GenModel.class))).thenReturn(objExpected);
	
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/updatelocation").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	
	}
	
	@Test
	public void updateLocationAndCategoryDetailsNegativeTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.ERROR);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateLocationAndCategoryDetails(Mockito.any(GenModel.class))).thenReturn(objExpected);
	
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/updatelocation").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	
	}
	@Test
	public void updateLocationAndCategoryDetailsNegativeTestCase1() throws Exception {
		Response objExpected=new Response();

		GenModel obj=new GenModel(Message.SOMEERROROCCURED,"",new ArrayList<>());
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateLocationAndCategoryDetails(Mockito.any(GenModel.class))).thenReturn(objExpected);
	
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/updatelocation").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getValue(), objActual.get(0).getValue());
	
	}
	
	@Test
	public void preliminaryDiscussionGenModelPositiveTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName("Add Discussion Details");
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(16, "discussedon", "Discussed On", "", false, true));
		 objExpected.setFields(fields);
		 
		Mockito.when(adminService.addPreliminaryDiscussionDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/preliminarydiscussiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "24");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}
	
	@Test
	public void preliminaryDiscussionGenModelNegativeTestCase() throws Exception {
		GenModel objExpected = new GenModel();
		 objExpected.setName(Message.CASENOTREGISTERED);
	
		 List<GenModelField> fields=new ArrayList<GenModelField>();
		 objExpected.setFields(fields);
		 
		Mockito.when(adminService.addPreliminaryDiscussionDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/preliminarydiscussiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "24");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());

	}
	@Test
	public void preliminaryDiscussionGenModelNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(adminService.addPreliminaryDiscussionDetails(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/preliminarydiscussiongenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "24");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}

	@Test
	public void addPreliminaryDiscussionPositiveTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.SUCCESS);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addPreliminaryDiscusionDetails(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addpreliminarydiscussion").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void addPreliminaryDiscussionNegativeTestCase() throws Exception {
		Response objExpected=new Response();
		objExpected.setType(Message.ERROR);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addPreliminaryDiscusionDetails(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addpreliminarydiscussion").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
	    List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void addPreliminaryDiscussionNegativeTestCase1() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		List<GenModelField> fields=new ArrayList<GenModelField>();
		 fields.add(new GenModelField(0, "success", "Success", "", false, true));
		 
		GenModel obj=new GenModel("", "", fields);
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addPreliminaryDiscusionDetails(Mockito.any(GenModel.class))).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/addpreliminarydiscussion").header("Authorization", "Bearer " + token).accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
	   
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	@Test
	public void getPreliminaryDiscussionsPositiveTestCase() throws Exception {
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView("", "Previous cases", new ArrayList<>());
	    objExpected.setCards(cardList);
		Mockito.when(adminService.getPreliminaryDiscussions(Mockito.anyInt(),Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/preliminarydiscussions").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12").param("showtop2", "2");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		CardView objActual = super.mapFromJson(content, CardView.class);
		assertEquals(objExpected.getName(), objActual.getName());

	}	
	
	@Test
	public void getPreliminaryDiscussionsNegativeTestCase() throws Exception {
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));

		Mockito.when(adminService.getPreliminaryDiscussions(Mockito.anyInt(),Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/casesummary/preliminarydiscussions").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12").param("showtop2", "2");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());

	}	
	@Test
	public void getActionsPositiveTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName("Actions");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		
		Mockito.when(adminService.getActions(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/actions").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	 
	@Test
	public void getActionsNegativeTestCase1() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(adminService.getActions(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/actions").header("Authorization", "Bearer " + token)
						.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus(); 
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	} 
  
	@Test
	public void getAccordionsPositiveTestCase() throws Exception{
		AccordionView objExpected = new AccordionView();
		objExpected.setName("name");
		Mockito.when(adminService.getAccordions(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/accordions").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		AccordionView objActual = super.mapFromJson(content, AccordionView.class);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getAccordionsNegativeTestCase() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(adminService.getAccordions(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/accordions").header("Authorization", "Bearer " + token)
						.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus(); 
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
		  
	} 
	
	@Test
	public void getUpdateCaseStatusGenModelPositiveTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName("name");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		Mockito.when(adminService.updateCaseStatusGenmodel(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatusgenmodel").header("Authorization", "Bearer " + token)
				.param("action", "R").param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());
	}
	@Test
	public void getUpdateCaseStatusGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
		objExpected.setFields(fields);
		Mockito.when(adminService.updateCaseStatusGenmodel(Mockito.anyInt(),Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatusgenmodel").header("Authorization", "Bearer " + token)
				.param("action", "R").param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
	@Test
	public void getUpdateCaseStatusGenModelNegativeTestCase1() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(adminService.updateCaseStatusGenmodel(Mockito.anyInt(),Mockito.anyString())).thenThrow(new RuntimeException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatusgenmodel").header("Authorization", "Bearer " + token)
				.param("action", "action").param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus(); 
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
		  
	} 
	
	@Test
	public void updateCaseStatusPositiveTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.SUCCESS);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateCaseStatus(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatus").header("Authorization", "Bearer " + token)
				.param("action", "R").param(Constants.CASEID, "34").accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());	
	} 
	
	@Test
	public void updateCaseStatusNegativeTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.ERROR);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateCaseStatus(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatus").header("Authorization", "Bearer " + token)
				.param("action", "R").param(Constants.CASEID, "34").accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void updateCaseStatusNegativeTestCase1() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.updateCaseStatus(Mockito.anyInt(),Mockito.anyString(),Mockito.anyString(),Mockito.any(GenModel.class))).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/updatecasestatus").header("Authorization", "Bearer " + token)
				.param("action", "R").param(Constants.CASEID, "34").accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());;
	} 
	
	@Test
	public void getAssignCaseGenModelPositiveTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName("name");
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    fields.add(new GenModelField(16, "discussedon", "Discussed On", "", false, true));
	    objExpected.setFields(fields);
		Mockito.when(adminService.getAssignCaseGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncasegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);
		assertEquals(objExpected.getName(), objActual.getName());
	}

	@Test
	public void getAssignCaseGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    objExpected.setFields(fields);
		Mockito.when(adminService.getAssignCaseGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncasegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
	@Test
	public void getAssignCaseGenModelNegativeTestCase1() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(adminService.getAssignCaseGenmodel(Mockito.anyInt())).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncasegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());  
	} 
	
	@Test
	public void assignCasePositiveTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.SUCCESS);;
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.assignCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncase").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());	
	} 
	
	@Test
	public void assignCaseNegativeTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.ERROR);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.assignCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncase").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void assignCaseNegativeTestCase1() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.assignCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/assigncase").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());;
	} 
	
	@Test
	public void getIdsForCamsContextDropdownPositiveTest() throws Exception{
		List<GenModelOption> objExpected=new ArrayList<>();
		objExpected.add(new GenModelOption("SELECT","select", true));
		Mockito.when(webservice.getIdsByModuleAndRole(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/context/members").header("Authorization", "Bearer "+token)
				.param("context", "2").param("role","System Engineer").param("value", "5");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);

		assertEquals(objExpected.get(0).getKey(), objActual.get(0).getKey());
	}
	
	@Test
	public void getIdsForCamsContextDropdownNegativeTest() throws Exception{
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		Mockito.when(webservice.getIdsByModuleAndRole(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/context/members").header("Authorization", "Bearer "+token)
				.param("context", "2").param("role","System Engineer").param("value", "5");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getSeekInputGenModelPositiveTest() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName("Seek Input");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		Mockito.when(adminService.seekInputGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinputgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual=super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getSeekInputGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    objExpected.setFields(fields);
		Mockito.when(adminService.seekInputGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinputgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	@Test
	public void getSeekInputGenModelNegativeTestCase1() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.SOMEERROROCCURED);
		Mockito.when(adminService.seekInputGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinputgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());  
	} 
	
	@Test
	public void seekinputPositiveTest() throws Exception{
		Response objExpected = new Response();
		objExpected.setType(Message.SUCCESS);
				 
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		
		Mockito.when(adminService.seekInput(Mockito.any(GenModel.class), Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinput").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void seekinputNegativeTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.ERROR);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.seekInput(Mockito.any(GenModel.class), Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinput").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void seekinputNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.seekInput(Mockito.any(GenModel.class), Mockito.anyString())).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/seekinput").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());;
	} 
	
	
	@Test
	public void communicationHistoryPositiveTest() throws Exception{
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView("", "Communication History",new ArrayList<>());
	    objExpected.setCards(cardList);
		Mockito.when(adminService.communicationHistory(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/history").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param("showtop2", "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		CardView objActual=super.mapFromJson(content, CardView.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void communicationHistoryNegativeTestCase() throws Exception{
		
		List<Card> cardList=new ArrayList<Card>();
		//cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView(Message.CASENOTREGISTERED, "Communication History",new ArrayList<>());
	    objExpected.setCards(cardList);
	    
		Mockito.when(adminService.communicationHistory(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/history").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("showtop2", "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	
	@Test
	public void communicationHistoryNegativeTestCase1() throws Exception{
		
		CardView objExpected= new CardView();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.communicationHistory(Mockito.anyInt(),Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/communications/history").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12").param("showtop2", "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());  
	} 
	
	@Test
	public void getInterimReliefGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel();
		objExpected.setName("Interim Relief");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		
		Mockito.when(adminService.getInterimReliefGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getInterimReliefGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    objExpected.setFields(fields);
		Mockito.when(adminService.getInterimReliefGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	@Test
	public void getInterimReliefGenModelNegativeTestCase1() throws Exception{
		
		GenModel objExpected= new GenModel();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getInterimReliefGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());  
	}
	
	@Test
	public void addInterimReliefPositiveTest() throws Exception{
		Response objExpected = new Response();
		objExpected.setType(Message.SUCCESS);
				 
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		
		Mockito.when(adminService.addInterimRelief(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/addinterimrelief").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addInterimReliefNegativeTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.ERROR);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addInterimRelief(Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/addinterimrelief").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addInterimReliefNegativeTestCase1() throws Exception{
		
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.addInterimRelief(Mockito.any(GenModel.class))).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/addinterimrelief").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());;
	} 
	
	@Test
	public void getInterimReliefPositiveTest() throws Exception{
		
		List<CardViewField> fields  =new ArrayList<CardViewField>();
		fields.add(new CardViewField("Respondent Type", "", 14));
		Label label=new Label(fields);
		label.setFields(fields);
		
		LabelView objExpected =new LabelView("","labelview", null);
		objExpected.setView(label);
		
		Mockito.when(adminService.getInterimRelief(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimrelief").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		LabelView objActual = super.mapFromJson(content, LabelView.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getInterimReliefNegativeTestCase() throws Exception{			    

		
		LabelView objExpected =new LabelView();
		objExpected.setName("Interim reliefs not submitted yet.");
		List<CardViewField> fields=new ArrayList<CardViewField>();
		Label label=new Label();
		label.setFields(fields);
		objExpected.setView(label);
		
		
		Mockito.when(adminService.getInterimRelief(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimrelief").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	
	@Test
	public void getInterimReliefNegativeTestCase1() throws Exception{
		
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		Mockito.when(adminService.getInterimRelief(Mockito.anyInt())).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimrelief").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());  
	}
	
	@Test
	public void getFirstContactMailGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel();
		objExpected.setName("Interim Relief");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		
		Mockito.when(adminService.getFirstContactGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmailgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getFirstContactMailGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    objExpected.setFields(fields);
		Mockito.when(adminService.getFirstContactGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmailgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}

	
	@Test
	public void getFirstContactMailGenModelNegativeTestCase1() throws Exception{
		
		GenModel objExpected= new GenModel();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getFirstContactGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmailgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());  
	}
	
	@Test
	public void sendFirstContactMailsPositiveTest() throws Exception{
		Response objExpected = new Response();
		objExpected.setType(Message.SUCCESS);
				 
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		
		Mockito.when(adminService.sendFirstContactMails(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfirstcontactmails").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void sendFirstContactMailsNegativeTestCase() throws Exception{
		Response objExpected= new Response();
		objExpected.setType(Message.ERROR);
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.sendFirstContactMails(Mockito.any(GenModel.class))).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfirstcontactmails").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void sendFirstContactMailsNegativeTestCase1() throws Exception{
		
		List<Response> objExpected=Arrays.asList(new Response(Message.ERROR,Message.SOMEERROROCCURED));
		
		GenModel obj=new GenModel();
	    String objJson=super.mapToJson(obj);
		Mockito.when(adminService.sendFirstContactMails(Mockito.any(GenModel.class))).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfirstcontactmails").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.get(0).getContent(), objActual.get(0).getContent());;
	}
	
	@Test
	public void getFirstContactMailsPositiveTest() throws Exception{
		List<Card> cardList=new ArrayList<Card>();
		cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView("", "First contact mail",new ArrayList<>());
	    objExpected.setCards(cardList);
		Mockito.when(adminService.getFirstContactMailsDetails(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmails").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("showtop2", "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		CardView objActual=super.mapFromJson(content, CardView.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getFirstContactMailsNegativeTestCase() throws Exception{
		
		List<Card> cardList=new ArrayList<Card>();
		//cardList.add(new Card(23, "with GRB", ""));
		CardView objExpected=new CardView(Message.CASENOTREGISTERED, "Communication History",new ArrayList<>());
	    objExpected.setCards(cardList);
	    
		Mockito.when(adminService.getFirstContactMailsDetails(Mockito.anyInt(),Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34").param("showtop2", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFirstContactMailsNegativeTestCase1() throws Exception{
		
		CardView objExpected= new CardView();
		objExpected.setName(Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getFirstContactMailsDetails(Mockito.anyInt(),Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/firstcontactmails").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12").param("showtop2", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());  
	} 
	
	@Test
	public void getInvestigationTypeGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel();
		objExpected.setName("Interim Relief");
		List<GenModelField> fields=new ArrayList<GenModelField>();
		fields.add(new GenModelField(18, "category", "Category Of Concern", "", false, true));
		objExpected.setFields(fields);
		
		Mockito.when(adminService.getInvestigationTypeGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/typegenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	public void getInvestigationTypeGenModelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel();
		objExpected.setName(Message.CASENOTREGISTERED);
		List<GenModelField> fields=new ArrayList<GenModelField>();
	    objExpected.setFields(fields);
		Mockito.when(adminService.getInvestigationTypeGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/typegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		assertEquals(objExpected.getName(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInvestigationTypeGenModelNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getInvestigationTypeGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/typegenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void takeActionOnInterimReliefPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.takeActionOnInterimRelief(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefaction").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void takeActionOnInterimReliefNegativeTestCase() throws Exception{
		Response objExpected= new Response("unable to take action");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.takeActionOnInterimRelief(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefaction").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void takeActionOnInterimReliefNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.takeActionOnInterimRelief(Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new CustomException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/interimreliefaction").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	} 
	
	@Test
	public void chooseInvestigationTypePositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.chooseInvestigationType(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/choosetype").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void chooseInvestigationTypeNegativeTestCase() throws Exception{
		Response objExpected= new Response("unable to take action");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.chooseInvestigationType(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/choosetype").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void chooseInvestigationTypeNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.chooseInvestigationType(Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/choosetype").header("Authorization", "Bearer " + token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson).contentType(MediaType.APPLICATION_JSON_VALUE);
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getInitiateConciliationGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getInitiateConciliationGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getInitiateConciliationGenmodelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel("", "", new ArrayList<>());
		
		Mockito.when(adminService.getInitiateConciliationGenmodel(Mockito.anyInt())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/genmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(Message.ERROR, objActual.get(0).getType());
		assertEquals(Message.CASENOTREGISTERED, objActual.get(0).getContent());
	}
	
	@Test
	public void getInitiateConciliationGenmodelNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getInitiateConciliationGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/genmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void initiateConciliationActionPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.initiateConciliation(Mockito.anyString(), Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void initiateConciliationActionNegativeTestCase() throws Exception{
		Response objExpected= new Response("unable to take action");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.initiateConciliation(Mockito.anyString(), Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void initiateConciliationActionNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.initiateConciliation(Mockito.anyString(), Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/initiateconciliation/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE).param(Constants.ACTION, "action");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
    @Test
	public void getConciliationConsentsPositiveTestCase() throws Exception {

		CardView objExpected=new CardView("", "", Arrays.asList(new Card()));

		Mockito.when(adminService.getConciliationConsents(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/consents").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		CardView objActual = super.mapFromJson(content, CardView.class);
		assertThat(objActual).hasSameClassAs(objExpected);

	}
	@Test
	public void getConciliationConsentsNegativeTestCase() throws Exception {
		Response objExpected=new Response(Message.ERROR, Message.CASENOTREGISTERED);

	    Mockito.when(adminService.getConciliationConsents(Mockito.anyInt())).thenReturn(new CardView("", "",new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/consents").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void getConciliationConsentsNegativeTestCase1() throws Exception {
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getConciliationConsents(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/consents").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());

	}
	
	@Test
	public void getConciliationReportGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getPrepareConciliationReport(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereportgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getConciliationReportGenmodelNegativeTestCase() throws Exception{
		GenModel objExpected = new GenModel("", "error message", new ArrayList<>());
		
		Mockito.when(adminService.getPrepareConciliationReport(Mockito.anyInt())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereportgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "34");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(Message.ERROR, objActual.get(0).getType());
		assertEquals(objExpected.getId(), objActual.get(0).getContent());
	}
	
	@Test
	public void getConciliationReportGenmodelNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getPrepareConciliationReport(Mockito.anyInt())).thenThrow(new RuntimeException());
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereportgenmodel").header("Authorization", "Bearer " + token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void submitConciliationReportPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.submitConciliationReport(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereport").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void submitConciliationReportNegativeTestCase() throws Exception{
		Response objExpected= new Response("unable to take action");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.submitConciliationReport(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereport").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void submitConciliationReportNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.submitConciliationReport(Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/preparereport").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getConciliationReportPositiveTest() throws Exception{
		LabelView objExpected = new LabelView("", Arrays.asList(new CardViewField()));
		
	    Mockito.when(adminService.getConciliationReport(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/report").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		LabelView objActual=super.mapFromJson(content, LabelView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getConciliationReportNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, "Conciliation report not prepared yet.");
		
		Mockito.when(adminService.getConciliationReport(Mockito.anyInt())).thenReturn(new LabelView("", Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/report").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getConciliationReportNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getConciliationReport(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/conciliation/report").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getMoveCaseGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.moveCaseGenModel(Mockito.anyString(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecasegenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTION, "action");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getMoveCaseGenModelNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.moveCaseGenModel(Mockito.anyString(), Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecasegenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTION, "action");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getMoveCaseGenModelNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.moveCaseGenModel(Mockito.anyString(), Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecasegenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTION, "action");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void moveCasePositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.moveCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecase").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void moveCaseNegativeTestCase() throws Exception{
		Response objExpected= new Response("unable to take action");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.moveCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecase").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void moveCaseNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.moveCase(Mockito.anyString(), Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/movecase").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getFindingGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingGenmodelNegativeTestCase2() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "5");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingGenmodelNegativeTestCase3() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "0").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingGenmodelNegativeTestCase4() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "").param("type", "3");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingGenmodelNegativeTestCase5() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.addFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void addOrUpdateFindingPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.addFindings(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addOrUpdateFindingNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.addFindings(Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addOrUpdateFindingNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.addFindings(Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteFindingPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.deleteFindings(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteFindingNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
	    Mockito.when(adminService.deleteFindings(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteFindingNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

	    Mockito.when(adminService.deleteFindings(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/finding/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingsPositiveTest1() throws Exception{
		InboxView objExpected = new InboxView("", "", "", Arrays.asList(new Header()), Arrays.asList(new Row()), 10, new ArrayList<>(), "");
		
	    Mockito.when(adminService.getFindings(Mockito.anyBoolean(), Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/findings").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new FindingFilter()))
				.contentType(MediaType.APPLICATION_JSON_VALUE).param("filter", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		InboxView objActual=super.mapFromJson(content, InboxView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getFindingsNegativeTest1() throws Exception{
		
		Response objExpected = new Response("nodata", "error message");
		
	    Mockito.when(adminService.getFindings(Mockito.anyBoolean(), Mockito.any())).thenReturn(new InboxView("error message", "", "", new ArrayList<>(), new ArrayList<>(), 10, new ArrayList<>(), ""));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/findings").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new FindingFilter()))
				.contentType(MediaType.APPLICATION_JSON_VALUE).param("filter", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingsNegativeTest2() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.NOCASEFOUND);
		
	    Mockito.when(adminService.getFindings(Mockito.anyBoolean(), Mockito.any())).thenReturn(new InboxView("", "", "", Arrays.asList(new Header()), Arrays.asList(), 10, new ArrayList<>(), ""));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/findings").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new FindingFilter()))
				.contentType(MediaType.APPLICATION_JSON_VALUE).param("filter", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFindingsNegativeTest3() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
	    Mockito.when(adminService.getFindings(Mockito.anyBoolean(), Mockito.any())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/findings").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new FindingFilter()))
				.contentType(MediaType.APPLICATION_JSON_VALUE).param("filter", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getRecommendedActionsGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsGenmodelNegativeTestCase2() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "5");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsGenmodelNegativeTestCase3() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "0").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsGenmodelNegativeTestCase4() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.INVALID_INPUT);
		
		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "").param("type", "2");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsGenmodelNegativeTestCase5() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getRecommendedActionsGenmodel(Mockito.anyInt(), Mockito.anyInt(), Mockito.anyString())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.TRANSACTIONID, "1").param("type", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void addOrUpdateRecommendedActionsPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.addOrUpdateRecommendedActions(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addOrUpdateRecommendedActionsNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.addOrUpdateRecommendedActions(Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void addOrUpdateRecommendedActionsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.addOrUpdateRecommendedActions(Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/addorupdate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteRecommendedActionsPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.deleteRecommendedActions(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1").param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteRecommendedActionsNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
	    Mockito.when(adminService.deleteRecommendedActions(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1").param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void deleteRecommendedActionsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

	    Mockito.when(adminService.deleteRecommendedActions(Mockito.anyInt(), Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/delete").header("Authorization", "Bearer "+token)
				.param(Constants.TRANSACTIONID, "1").param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
//	@Test
//	public void getGenModelOptionsByGroupIdPositiveTest() throws Exception{
//		
//	    Mockito.when(adminService.getGenModelOptionsBy(Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption()));
//
//		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/optionsbygroupid").header("Authorization", "Bearer "+token)
//				.param("moduleid", "2").param("groupid", "1");
//
//		MvcResult result = mvc.perform(request).andReturn();
//
//		int status = result.getResponse().getStatus();
//
//		assertEquals(200, status);
//
//		String content = result.getResponse().getContentAsString();
//		
//		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);
//
//		assertEquals(1, objActual.size());
//	}
//
//	
//	@Test
//	public void getGenModelOptionsByGroupIdNegativeTestCase1() throws Exception{
//		
//		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
//
//	    Mockito.when(adminService.getGenModelOptionsByGroupId(Mockito.anyString())).thenThrow(new RuntimeException());
//
//		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/optionsbygroupid").header("Authorization", "Bearer "+token)
//				.param("groupid", "1");
//		
//		MvcResult result = mvc.perform(request).andReturn();
//		int status = result.getResponse().getStatus();
//		assertEquals(200, status);
//		String content = result.getResponse().getContentAsString();
//		
//		List<Response> objActual=super.mapFromJsonList(content, Response.class);
//		
//		assertEquals(objExpected.getType(), objActual.get(0).getType());
//		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
//	}
//	
	@Test
	public void getRecommendedActionsPositiveTest() throws Exception{
		CardView objExpected = new CardView("", Arrays.asList(new Card()));
		
	    Mockito.when(adminService.getRecommendedActions(Mockito.anyInt(), Mockito.anyBoolean())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/cards").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("filter", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		CardView objActual=super.mapFromJson(content, CardView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getRecommendedActionsNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getRecommendedActions(Mockito.anyInt(), Mockito.anyBoolean())).thenReturn(new CardView("", Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/cards").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("filter", "true");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getRecommendedActionsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getRecommendedActions(Mockito.anyInt(), Mockito.anyBoolean())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/recommendedaction/cards").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("filter", "true");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getEmployeesByActorPositiveTest() throws Exception{
		
	    Mockito.when(adminService.getEmployeesByActor(Mockito.anyInt(), Mockito.anyString())).thenReturn(Arrays.asList(new GenModelOption()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/employees").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param(Constants.ACTOR, "R");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);

		assertEquals(1, objActual.size());
	}

	
	@Test
	public void getEmployeesByActorNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

	    Mockito.when(adminService.getEmployeesByActor(Mockito.anyInt(), Mockito.anyString())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/employees").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param(Constants.ACTOR, "R");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getIssueSummonsGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getIssueSummonGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummonsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getIssueSummonsGenModelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getIssueSummonGenmodel(Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummonsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getIssueSummonsGenModelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getIssueSummonGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummonsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void issueSummonsPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
				 
	    String objJson=super.mapToJson(new GenModel());
		
	    Mockito.when(adminService.issueSummon(Mockito.any(GenModel.class))).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummons").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void issueSummonsNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.issueSummon(Mockito.any(GenModel.class))).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummons").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void issueSummonsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		String objJson=super.mapToJson(new GenModel());
		
		Mockito.when(adminService.issueSummon(Mockito.any(GenModel.class))).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/issuesummons").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(objJson)
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getSummonsPositiveTest() throws Exception{
		CardView objExpected = new CardView("", Arrays.asList(new Card()));
		
	    Mockito.when(adminService.getIssuedSummons(Mockito.anyInt(), Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/summons").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("showtop2", "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		CardView objActual=super.mapFromJson(content, CardView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getSummonsNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getIssuedSummons(Mockito.anyInt(), Mockito.anyInt())).thenReturn(new CardView("", Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/summons").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("showtop2", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getSummonsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getIssuedSummons(Mockito.anyInt(), Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/summons").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param("showtop2", "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void sendFindingGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.sendFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfindinggenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void sendFindingGenModelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.sendFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfindinggenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void sendFindingGenModelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.sendFindingsGenmodel(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfindinggenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void sendFindingPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.sendFindings(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void sendFindingNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
		Mockito.when(adminService.sendFindings(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void sendFindingNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.sendFindings(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/sendfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12").param(Constants.ACTOR, "A").param("mailid", "suraj");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void consolidatedFindingsGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.consolidatedFindingsGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/consolidatedfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void consolidatedFindingsGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.consolidatedFindingsGenmodel(Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/consolidatedfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void consolidatedFindingsGenmodelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.consolidatedFindingsGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/consolidatedfinding").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void formalReportGenModelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getFormalReportGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void formalReportGenModelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getFormalReportGenmodel(Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void formalReportGenModelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getFormalReportGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void submitFormalReportPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.submitFormalReport(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void submitFormalReportNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, "error message");
		
		Mockito.when(adminService.submitFormalReport(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void submitFormalReportNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.submitFormalReport(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFormalReportDetailsPositiveTest() throws Exception{
		LabelView objExpected = new LabelView("", Arrays.asList(new CardViewField()));
		
	    Mockito.when(adminService.getFormalReportDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/details").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		LabelView objActual=super.mapFromJson(content, LabelView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getFormalReportDetailsNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getFormalReportDetails(Mockito.anyInt())).thenReturn(new LabelView("", Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/details").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFormalReportDetailsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getFormalReportDetails(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formalreport/details").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	
	@Test
	public void getCommentsLabelPositiveTest() throws Exception{
		LabelView objExpected = new LabelView("", Arrays.asList(new CardViewField()));
		
	    Mockito.when(adminService.getCommentsLabel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/commentslabel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param(Constants.STATUS.toLowerCase(), "1");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		LabelView objActual=super.mapFromJson(content, LabelView.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getCommentsLabelNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getCommentsLabel(Mockito.anyInt())).thenReturn(new LabelView("", Arrays.asList()));
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/commentslabel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param(Constants.STATUS.toLowerCase(), "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getCommentsLabelNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getCommentsLabel(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/commentslabel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "1").param(Constants.STATUS.toLowerCase(), "1");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getFormalReportCheckListGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getFormalReportCheckListGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getFormalReportCheckListGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getFormalReportCheckListGenmodel(Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getFormalReportCheckListGenmodelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getFormalReportCheckListGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/genmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void updateFormalReportCheckListPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.updateFormalReportCheckList(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void updateFormalReportCheckListNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, "error message");
		
		Mockito.when(adminService.updateFormalReportCheckList(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void updateFormalReportCheckListNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.updateFormalReportCheckList(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/formal/checklist/save").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getUploadApprovalsGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getUploadApprovalsGenmodel(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovalsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getUploadApprovalsGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		Mockito.when(adminService.getUploadApprovalsGenmodel(Mockito.anyInt())).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovalsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getUploadApprovalsGenmodelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getUploadApprovalsGenmodel(Mockito.anyInt())).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovalsgenmodel").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void uploadapprovalsPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.submitApprovals(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovals").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void uploadapprovalsNegativeTestCase() throws Exception{
		Response objExpected= new Response(Message.ERROR, "error message");
		
		Mockito.when(adminService.submitApprovals(Mockito.anyString(), Mockito.any())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovals").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void uploadapprovalsNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.submitApprovals(Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/investigation/uploadapprovals").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getDownloadTemplateGenmodelPositiveTest() throws Exception{
		
		GenModel objExpected = new GenModel("", "", Arrays.asList(new GenModelField()));
		
		Mockito.when(adminService.getDownloadTemplateGenmodel()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/templategenmodel").header("Authorization", "Bearer "+token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		GenModel objActual = super.mapFromJson(content, GenModel.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getDownloadTemplateGenmodelNegativeTestCase1() throws Exception{
		Response objExpected= new Response(Message.ERROR, Message.SOMETHING_WENT_WRONG);
		
		Mockito.when(adminService.getDownloadTemplateGenmodel()).thenReturn(new GenModel("", "", new ArrayList<>()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/templategenmodel").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getDownloadTemplateGenmodelNegativeTestCase2() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(adminService.getDownloadTemplateGenmodel()).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/templategenmodel").header("Authorization", "Bearer "+token);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent()); 
	}
	
	@Test
	public void downloadTemplatePositiveTest() throws Exception{
		DocumentData objExpected = new DocumentData("filename", "ahujdvbaufhvahfvbaihfgoabifoa");
		
	    Mockito.when(adminService.downloadTemplate(Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/downloadtemplate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		DocumentData objActual=super.mapFromJson(content, DocumentData.class);

		assertEquals(objExpected.getFilename(), objActual.getFilename());
		assertEquals(objExpected.getBase64file(), objActual.getBase64file());
	}
	
	@Test
	public void downloadTemplateNegativeTestCase() throws Exception{
		DocumentData objExpected= new DocumentData(Message.ERROR, "error message");
		
	    Mockito.when(adminService.downloadTemplate(Mockito.any())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/downloadtemplate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getFilename(), objActual.get(0).getType());
		assertEquals(objExpected.getBase64file(), objActual.get(0).getContent());
	}
	
	@Test
	public void downloadTemplateNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
	    Mockito.when(adminService.downloadTemplate(Mockito.any())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/downloadtemplate").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE);
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	
	@Test
	public void getWorkFlowPositiveTest() throws Exception{
		
		WorkFlow objExpected = new WorkFlow();
		
		Mockito.when(adminService.getWorkFlow(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/workflow/sla").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		WorkFlow objActual = super.mapFromJson(content, WorkFlow.class);

		assertThat(objActual).hasSameClassAs(objExpected);
	}
	
	@Test
	public void getWorkFlowNegativeTestCase() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.getWorkFlow(Mockito.anyInt())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/workflow/sla").header("Authorization", "Bearer "+token)
				.param(Constants.CASEID, "12");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void actionSLAExtensionPositiveTest() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, Message.SUCCESS);
		
	    Mockito.when(adminService.actionSLAExtension(Mockito.anyBoolean(), Mockito.anyBoolean(), Mockito.anyString(), Mockito.any())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/slaextension/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.param(Constants.TRANSACTIONID, "12").param("flgaction", "true").param("flgapprove", "true");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();
		
		List <Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void actionSLAExtensionNegativeTestCase() throws Exception{
		Response objExpected= new Response("error message");
		
		Mockito.when(adminService.actionSLAExtension(Mockito.anyBoolean(), Mockito.anyBoolean(), Mockito.anyString(), Mockito.any())).thenReturn(objExpected);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/slaextension/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.param(Constants.TRANSACTIONID, "12").param("flgaction", "true").param("flgapprove", "true");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual = super.mapFromJsonList(content,Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void actionSLAExtensionNegativeTestCase1() throws Exception{
		
		Response objExpected= new Response(Message.ERROR, Message.SOMEERROROCCURED);
		
		Mockito.when(adminService.actionSLAExtension(Mockito.anyBoolean(), Mockito.anyBoolean(), Mockito.anyString(), Mockito.any())).thenThrow(new RuntimeException());
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/slaextension/action").header("Authorization", "Bearer "+token)
				.accept(MediaType.APPLICATION_JSON_VALUE).content(super.mapToJson(new GenModel()))
				.contentType(MediaType.APPLICATION_JSON_VALUE)
				.param(Constants.TRANSACTIONID, "12").param("flgaction", "true").param("flgapprove", "true");
		
		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();
		
		List<Response> objActual=super.mapFromJsonList(content, Response.class);
		
		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}

}

