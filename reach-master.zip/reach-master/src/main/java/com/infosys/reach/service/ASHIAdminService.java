package com.infosys.reach.service ;


import java.util.List ;

import com.infosys.reach.exception.CustomException ;
import com.infosys.reach.model.ashiadmin.FindingFilter ;
import com.infosys.reach.model.ashiadmin.InboxFilter ;
import com.infosys.reach.model.generic.AccordionView ;
import com.infosys.reach.model.generic.CardView ;
import com.infosys.reach.model.generic.DocumentData ;
import com.infosys.reach.model.generic.GenModel ;
import com.infosys.reach.model.generic.GenModelOption ;
import com.infosys.reach.model.generic.InboxView ;
import com.infosys.reach.model.generic.LabelView ;
import com.infosys.reach.model.generic.LinkModel ;
import com.infosys.reach.model.generic.Response ;
import com.infosys.reach.model.generic.WorkFlow ;

public interface ASHIAdminService {
	
	//Inbox
	public GenModel getInboxFilterGenmodel()   throws CustomException;
	public GenModel getInboxInLineFilterGenmodel(String role,String country,String company,String type)  throws CustomException;	
	public InboxView getAdminInboxGenModelFiltered(InboxFilter filter)   throws CustomException;
	public InboxView getAdminInboxInLineFiltered(String role,String country,String company,String type, GenModel inLineFilter)   throws CustomException;
	public GenModel getInboxActionForms(int caseid, String type)  throws CustomException;
	
	public Response removeEmployee(int transactionid)  throws CustomException;
	public GenModel addEmployeeGenModel(int caseid, String type)  throws CustomException;
	public Response addEmployee(GenModel genmodel)  throws CustomException;
	public CardView viewPreviousComplaints(String actor, String empno)  throws CustomException;

	public LabelView getCaseSummaryByCaseId(int caseid)  throws CustomException;
	public GenModel getCaseSummaryEmployeeDropDown(int caseId, String actor)  throws CustomException;
	public LabelView getCaseSummaryEmployeeDetails(String actor, int transactionid)  throws CustomException;
	public LabelView getLocationAndCategoryDetails(int caseid)  throws CustomException;
	public GenModel getLocationAndCategoryGenmodel(int caseid)    throws CustomException;
	public Response updateLocationAndCategoryDetails(GenModel genmodel) throws CustomException;

	//Preliminary discussion
	public GenModel addPreliminaryDiscussionDetails(int caseId)  throws CustomException;
	public CardView getPreliminaryDiscussions(int caseId, int showtop2)  throws CustomException;
	public Response addPreliminaryDiscusionDetails(GenModel genmodel)  throws CustomException;
	
	//Dynamic actions and accordions
	public GenModel getActions(int caseid) throws CustomException;
	public AccordionView getAccordions(int caseid) throws CustomException;
	
	//Update case status
	public GenModel updateCaseStatusGenmodel(int caseid, String action) throws CustomException;
	public Response updateCaseStatus(int caseid, String action,  String empNo, GenModel genmodel)  throws CustomException;
	
	//Assign case
	public GenModel getAssignCaseGenmodel(int caseid)  throws CustomException;
	public Response assignCase(String empNo, GenModel genmodel)  throws CustomException;
	
	//Communication
	public GenModel seekInputGenmodel(int caseid) throws CustomException;
	public Response seekInput(GenModel genmodel, String mailId)  throws CustomException;
	public CardView communicationHistory(int caseid, int showtop2) throws CustomException;
	
	//Interim Relief
	public GenModel getInterimReliefGenmodel(int caseid) throws CustomException;
	public Response addInterimRelief(GenModel genmodel)  throws CustomException;
	public LabelView getInterimRelief(int caseid)  throws CustomException;
	public Response takeActionOnInterimRelief(String action, GenModel genmodel)  throws CustomException;
	
	//First Contact mails
	public GenModel getFirstContactGenmodel(int caseid) throws CustomException;
	public Response sendFirstContactMails(GenModel genmodel)  throws CustomException;
	public CardView getFirstContactMailsDetails(int caseid, int showtop2)  throws CustomException;
	
	//Choose investigation type
	public GenModel getInvestigationTypeGenmodel(int caseid) throws CustomException;
	public Response chooseInvestigationType(String empno, GenModel genmodel) throws CustomException;
	
	//Conciliation
	public GenModel getInitiateConciliationGenmodel(int caseid) throws CustomException;
	public Response initiateConciliation(String empNo, String action, GenModel genmodel)   throws CustomException;
	public CardView getConciliationConsents(int caseid) throws CustomException;
	public GenModel getPrepareConciliationReport(int caseid) throws CustomException;
	public Response submitConciliationReport(String empNo, GenModel genmodel)  throws CustomException;
	public LabelView getConciliationReport(int caseid) throws CustomException;
	
	//Move case
	public GenModel moveCaseGenModel(String action, int caseid) throws CustomException;
	public Response moveCase(String empNo, GenModel genmodel)  throws CustomException;

	
	//issue summons
	public List<GenModelOption> getEmployeesByActor(int caseid, String actor) throws CustomException;
	public GenModel getIssueSummonGenmodel(int caseid) throws CustomException;
	public Response issueSummon(GenModel genmodel)  throws CustomException;
	public CardView getIssuedSummons(int caseid, int showtop2)  throws CustomException;
	
	//Charge sheet
	public GenModel getChargeSheetGenModel(int caseid) throws CustomException;
	public Response saveChargeSheet(int caseid, String empNo,GenModel genModel) throws CustomException;
	public LabelView getChargeSheet(int caseid) throws CustomException;
	
	//Allegations and findings
	public GenModel addFindingsGenmodel(int caseid, String transactionid, int type) throws CustomException;
	public Response addFindings(GenModel genmodel) throws CustomException;
	public InboxView getFindings(boolean filter, FindingFilter findingFilter) throws CustomException;
	public Response deleteFindings(int transactionid) throws CustomException;
	public GenModel sendFindingsGenmodel(int caseid, String actor, String mailId) throws CustomException;
	public Response sendFindings(String sender, int caseid, String actor, String mailId)  throws CustomException;
	public GenModel consolidatedFindingsGenmodel(int caseid) throws CustomException;
	
	
	//Recommended actions
	public GenModel getRecommendedActionsGenmodel(int type, int caseid, String transactionid) throws CustomException;
	public Response addOrUpdateRecommendedActions(GenModel genmodel)  throws CustomException;
	public CardView getRecommendedActions(int caseid, boolean filter) throws CustomException;
	public Response deleteRecommendedActions(int caseid, int transactionid) throws CustomException;

	
	//formal report
	public GenModel getFormalReportGenmodel(int caseid) throws CustomException;
	public Response submitFormalReport(String empNo, GenModel genmodel)  throws CustomException;
	public GenModel getUploadApprovalsGenmodel(int caseid) throws CustomException;
	public Response submitApprovals(String empNo, GenModel genmodel)   throws CustomException;
	public LabelView getFormalReportDetails(int caseid) throws CustomException;
	public GenModel getFormalReportCheckListGenmodel(int caseid) throws CustomException;
	public Response updateFormalReportCheckList(String empNo, GenModel genmodel)  throws CustomException;
	
	//SLA extension request and approval
	public Response actionSLAExtension(boolean flgAction, boolean flgApprove, String transactionid, GenModel genmodel)  throws CustomException;
	
	//Other
	public Response triggerEmployeeNotificationMail(int caseid, String actor, int transactionid)   throws CustomException;
	public LabelView getCommentsLabel(int caseid) throws CustomException;
	public GenModel getDownloadTemplateGenmodel() throws CustomException;
	public DocumentData downloadTemplate(GenModel genmodel)   throws CustomException;
	public WorkFlow getWorkFlow(int caseid) throws CustomException;
	public LinkModel getLinkModel(int caseid) throws CustomException;
}
