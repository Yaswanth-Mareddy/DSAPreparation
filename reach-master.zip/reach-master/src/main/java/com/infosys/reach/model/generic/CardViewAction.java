package com.infosys.reach.model.generic;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonInclude(Include.NON_NULL)
public class CardViewAction {

	private String label;
	private String apiType;
	private String name;
	private String value;
	private String type;
	private String confirmationContent;
	private String input;
	private String uitype;
	private String uitypevalue;
	private List<CardViewAction> actions;
	private String content;
	
	public CardViewAction(int filter, String label, String apiType, String value, String type) {
		this(null, apiType, null, value, type, null, null, null, null, null,"");
		if(filter==1)
			this.label = label;
		if(filter==2)
			this.name = label;
	}
	
	public CardViewAction(String label, String type, String value, String apiType, String confirmationContent) {
		this(label, apiType, null, value, type, confirmationContent, null, null, null, null,"");
	}

	public CardViewAction(String name, String value, String input) {
		this(null, "", name, value, "navigate", null, input, null, null, null,"");
	}
	
	public CardViewAction(String type, String uitype, String uitypevalue, List<CardViewAction> actions) {
		this("", "", null, "", type, null, null, uitype, uitypevalue, actions,"");
	}
	
	public CardViewAction(String label, String name, String apiType, String value, String type, String uitypevalue, String confirmationContent) {
		this(label, apiType, name, value, type, confirmationContent, "", uitypevalue.isEmpty()? Constants.BUTTON : Constants.IMAGE, uitypevalue, null,"");
	}
	
}
