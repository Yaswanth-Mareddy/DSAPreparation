package com.infosys.reach.model.generic;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.ashi.InboxRow;
import com.infosys.reach.model.ashiadmin.AdminInboxRow;
import com.infosys.reach.model.ashiadmin.Findings;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Row {

	private Object oneRow;
	private int rowid;
	private String transactionid;
	@JsonProperty("isSelected")
	private boolean isSelected;

	@JsonProperty("isEditable")
	private boolean isEditable;
	private List<CardViewAction> actions;
	
	public Row(InboxCaseDetails oneRow, int rowid, List<CardViewAction> actions) {
		this(new InboxRow(oneRow), rowid, String.valueOf(oneRow.getTransId()), false, false, actions);
	}
	
	public Row(AdminInboxRow oneRow, int rowid, List<CardViewAction> actions) {
		this(oneRow, rowid, String.valueOf(oneRow.getCaseId()), false, false, actions);
	}
	
	public Row(Findings oneRow, int rowid, List<CardViewAction> actions) {
		this(oneRow, rowid, String.valueOf(oneRow.getSerialNo()), false, false, actions);
	}
	
	public Row(Findings oneRow, int rowid, String transactionid, List<CardViewAction> actions) {
		this(oneRow, rowid, transactionid, false, false, actions);
	}
	
}
