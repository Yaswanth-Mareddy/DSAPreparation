package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name="genmstpu")
public class GenMstPU {

	@Id
	@Column(name="intpuid")
	private int puId;	
	
	@Column(name="intsubunitid")
	private int subunitId;	
	
	@Column(name="txtpucode")
	private String puCode;
}
