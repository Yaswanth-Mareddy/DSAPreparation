package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class WorkFlow {

	private String heading;
	private String description;
	private String links;
	private List<Object> actions;
	private List<Object> fields;
	private List<WorkFlowItem> workflowitems;
	
	public WorkFlow(String heading, List<WorkFlowItem> workflowitems) {
		super();
		this.heading = heading;
		this.description = "";
		this.links = "";
		this.actions = new ArrayList<>();
		this.fields = new ArrayList<>();
		this.workflowitems = workflowitems;
	}
	
	
}
