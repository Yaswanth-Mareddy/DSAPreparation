package com.infosys.reach.util;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;





@Aspect
@Component
public class ExecutionTimeTracker {
	
	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();
	
	@Around("@annotation(com.infosys.reach.util.TrackExecutionTime)")
	public Object trackTime(ProceedingJoinPoint pjp) throws Throwable {
		long startTime=System.currentTimeMillis();
		Object object=pjp.proceed();
		long endTime=System.currentTimeMillis();
		Request telemetryRequest = new Request();
		telemetryRequest.put("Query method "+pjp.getSignature(), " Execution time :"+(endTime-startTime)+" miliseconds");
		lmaxWriter.submitMessage(telemetryRequest);
		return object;
	}
}
