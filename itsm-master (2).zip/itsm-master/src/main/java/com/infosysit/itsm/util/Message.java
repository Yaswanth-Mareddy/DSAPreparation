package com.infosysit.itsm.util;

import org.springframework.beans.factory.annotation.Value;

public class Message {
	private Message(){
		
	}
	@Value("${schema.sql}")
	protected static String schema;
	
	public static final String SUCCESSMYSQLDB="SuccessFully Connected to MYSQL";
	public static final String SUCCESSSQLDB="SuccessFully Connected to SQL";
	public static final String INSERTED="SuccessFully Inserted";

	public static final String SELECTED="SuccessFully Selected Data";

	public static final String STARTEDJOB="Started Job";
	
	public static final String ENDJOB="Ended Job";
	
	public static final String NODATAFOUND="No Data Found";
	
	public static final String UNAUTHORIZED="Authorization is required";
	
	public static final String INVALIDTOKEN="Invalid token";
	
	public static final String SOMEERROROCCURED="Some Error Occured";
	

	public static final String JWTEXPIRED = "Token has expired.";
	public static final String SUCCESSFULLY = "success";
	public static final String ERROR = "error";
	public static final String TIMEOUT = "Timeout";
	public static final String FALLBACK = "fallback";
	

	
}
