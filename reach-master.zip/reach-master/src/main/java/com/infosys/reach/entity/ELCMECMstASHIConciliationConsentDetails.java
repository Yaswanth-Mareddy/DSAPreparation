package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmecmstashiconciliationconsentdetails")
public class ELCMECMstASHIConciliationConsentDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtactor")
	private String actor;

	@Column(name="txtmailid")
	private String mailId;
	
	@Column(name="flgaccept")
	private int flgAccept;
	
	@Column(name="flgreject")
	private int flgReject;
	
	@Column(name="txtrole")
	private String role;

	@Column(name="txtissuedby")
	private String issuedBy;

	@Column(name="dtissueddate")
	private Timestamp issuedDate ;

	@Column(name="txtupdatedby")
	private String updatedBy;

	@Column(name="dtupdateddate")
	private Timestamp updatedDate ;

	public ELCMECMstASHIConciliationConsentDetails(int caseId, String actor, String mailId, String issuedBy, Timestamp issuedDate) {
		super();
		this.caseId = caseId;
		this.actor = actor;
		this.mailId = mailId;
		this.flgAccept = 0;
		this.flgReject = 0;
		this.role = "GRB";
		this.issuedBy = issuedBy;
		this.issuedDate = issuedDate;
	}
	
	
}
