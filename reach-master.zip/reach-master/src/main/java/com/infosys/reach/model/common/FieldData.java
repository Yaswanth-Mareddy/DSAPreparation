package com.infosys.reach.model.common;

import java.util.ArrayList;
import java.util.List;

import com.infosys.reach.model.ashimobile.CaseGenModelField;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.util.Constants;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class FieldData {

	private String name;
	private Object data;
	private List<GenModelOption> options;
	
	
	
	public List<FieldData> getFields(List<GenModelField> webfields, List<CaseGenModelField> mobfields){
		List<FieldData> fieldData=new ArrayList<>();
		for(GenModelField field:webfields) {
			if(field.getName().equals(Constants.COMPLAINT_CATEGORY) || field.getName().equals("mailTo")) {
				for(GenModelOption option:field.getOptions()) {
					if(option.getValue().equals(field.getData().toString()))
						fieldData.add(new FieldData(field.getName(), option.getKey()));
				}
			}
			else if(field.getType()==77 || field.getType()==151) {
				fieldData.add(new FieldData(field.getName(), field.getData(), field.getOptions()));
			}
			else
				fieldData.add(new FieldData(field.getName(), field.getData()));
		}
		for(CaseGenModelField field:mobfields) {
			fieldData.add(new FieldData(field.getName(), field.getData()));
		}
		
		return fieldData;
	}



	public FieldData(String name, Object data) {
		super();
		this.name = name;
		this.data = data;
	}
}
