package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmecmstheartaggedempdetails")
public class ELCMECMstHearTaggedEmpDetails {

	@Id
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="flgaccept")
	private int flgAccept;
	
	@Column(name="flgreject")
	private int flgReject;
	
	@Column(name="txtmailid")
	private String mailId;

	public ELCMECMstHearTaggedEmpDetails(int caseId, String mailId) {
		super();
		this.caseId = caseId;
		this.flgAccept = 0;
		this.flgReject = 0;
		this.mailId = mailId;
	}
	
	
}
