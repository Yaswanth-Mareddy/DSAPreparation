package com.infosys.reach.model.ashimobile;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class MobileComplaintInboxView {
	private String name;
	private String guid;
	private String type;
	private ComplaintField row;
}
