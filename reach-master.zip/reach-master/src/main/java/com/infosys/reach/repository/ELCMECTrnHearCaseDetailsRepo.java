package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnHearCaseDetails;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnHearCaseDetailsRepo extends JpaRepository<ELCMECTrnHearCaseDetails, Integer>{

	@TrackExecutionTime
	@Override
	<S extends ELCMECTrnHearCaseDetails> S save(S entity);
}
