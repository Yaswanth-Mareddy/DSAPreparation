package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnhierarchy")
public class CMSTrnHierarchy {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intnodeid")
	private int intNodeID;
	
	@Column(name="txtnodename")
	private String txtNodeName;
	
	@Column(name="flgnodetype")
	private String flgNodeType;
	
	@Column(name="intlevel")
	private int intLevel;
	
	@Column(name="intparentreference")
	private int intParentReference;
	
	@Column(name="flghierarchytype")
	private String flgHierarchyType;
	
	@Column(name="txtxpathtonode")
	private String txtXPathToNode;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy;
	
	@Column(name="dtmodifiedon")
	private String dtModifiedOn;
	

}
