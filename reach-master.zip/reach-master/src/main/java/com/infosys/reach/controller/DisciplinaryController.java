package com.infosys.reach.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.reach.model.common.InitiateCaseResponse;
import com.infosys.reach.model.disciplinary.CaseDetails;
import com.infosys.reach.util.AuthenticationClass;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * @author surajkumar.dewangan
 *
 */
@RestController
@Api(tags="Disciplinary Module")
@RequestMapping("/v2/api/disciplinary")
public class DisciplinaryController extends Logging{

	/**
	 * This method is used to initiate disciplinary case
	 * 
	 * @return InitiateCaseResponse model
	 */
	@PostMapping(value="/service/initiatecase", produces="application/json", consumes = "application/json")
	@ApiOperation(value="Initiate disciplinary case", tags="Disciplinary Module")
	public ResponseEntity<InitiateCaseResponse> initiateDisciplinaryCase(@RequestBody CaseDetails caseDetails){
		
		try {
			boolean checkIncidentDate = caseDetails.getIncidentDate().matches("^(([0-9])|([0-2][0-9])|([3][0-1]))\\-(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\-\\d{4}$");
			if(!checkIncidentDate) {
				telemetry.setLogEventData("Incident date format is invalid.");
				return new ResponseEntity<>(new InitiateCaseResponse(0, "Incident date format is invalid."), HttpStatus.OK);
			}

			InitiateCaseResponse response = discMobileService.initiateCase(Session.getTokenEMPNO(), AuthenticationClass.getUserMailFromLoginId(Session.getTokenMAILID()), caseDetails);
			return new ResponseEntity<>(response,HttpStatus.OK);
		}
		catch(Exception e) {
			telemetry.setExeceptionEventData(e);
			return new ResponseEntity<>(new InitiateCaseResponse(0, e.getMessage()), HttpStatus.OK);
		}
			
	}
}
