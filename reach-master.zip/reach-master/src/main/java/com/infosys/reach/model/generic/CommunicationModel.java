package com.infosys.reach.model.generic;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CommunicationModel {

	private String name;
	private String id;
	private String type;
	private List<GenModelField> fields;
	private List<CommentSummary> commentssummary;
}
