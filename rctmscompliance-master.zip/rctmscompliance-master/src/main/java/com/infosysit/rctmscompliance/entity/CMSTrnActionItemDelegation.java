package com.infosysit.rctmscompliance.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnactionitemdelegation")
public class CMSTrnActionItemDelegation {
	
	@Id
	@Column(name="intactionitemid")
	private int intActionItemId;
	
	@Column(name="dtactionitemduedate")
    private String dtActionItemDueDate;
	
	@Column(name="txtassigneefrom")
	private String txtAssigneeFrom;
	
	@Column(name="txtassigneeto")
	private String txtAssigneeTo;
	
	@Column(name="flgactive")
	private String flgActive;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy;
	
	@Column(name="dtmodifiedon")
	private Date dtModifiedOn;

}
