package com.infosysit.itsm.service;

import org.springframework.stereotype.Service;

import com.infosysit.itsm.exception.CustomException;

@Service
public interface ITSMService {
	public boolean decisionAnalysis() throws CustomException;
    public boolean autoResponse() throws CustomException;
}
