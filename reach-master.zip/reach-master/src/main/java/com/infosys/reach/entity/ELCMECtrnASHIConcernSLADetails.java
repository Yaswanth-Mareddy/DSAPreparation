package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmectrnashiconcernsladetails")
public class ELCMECtrnASHIConcernSLADetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intslaid")
	private int slaId;

	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtrole")
	private String role;

	@Column(name="intsladays")
	private int slaDays;

	@Column(name="dtslastartdate")
	private Timestamp slaStartDate;

	@Column(name="dtslaenddate")
	private Timestamp slaEndDate;

	@Column(name="flgactive")
	private int flgActive;

	@Column(name="flgslaextensionrequest")
	private int flgSLAExtensionRequest;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="txtmodifiedby")
	private String modifiedBy;

	@Column(name="dtcreatedon")
	private Timestamp createdOn;

	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;

	@Column(name="dtslaextension")
	private Timestamp slaExtensionDate;
	
	public ELCMECtrnASHIConcernSLADetails(int caseId, int slaDays, String role, Timestamp currentDateTime,
			Timestamp slaEndDate, String createdBy) {
		super();
		this.caseId = caseId;
		this.role = role;
		this.slaDays = slaDays;
		this.slaStartDate = currentDateTime;
		this.slaEndDate = slaEndDate;
		this.flgActive = 1;
		this.flgSLAExtensionRequest = 0;
		this.createdBy = createdBy;
		this.modifiedBy = "";
		this.createdOn = currentDateTime;
	}

}
