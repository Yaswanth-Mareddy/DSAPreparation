package com.infosysit.rctmscompliance.repo.read;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.rctmscompliance.entity.ViewCMSTrnEscalationDetails;
import com.infosysit.rctmscompliance.model.ComplianceEscalationDetails;

public interface ViewCMSTrnEscalationDetailsRepoRead extends JpaRepository<ViewCMSTrnEscalationDetails, Integer> {
	
	@Query(value="select distinct new com.infosysit.rctmscompliance.model.ComplianceEscalationDetails(view.intEscalationLevel,view.intEscalationInterval,view.txtMailId,view.dtAssignedDate,"
			+ "view.dtEscalatedDate) from ViewCMSTrnEscalationDetails view  where view.intComplianceID = :intComplianceID AND view.dtAssignedDate = :dtAssignedDate AND view.intEscalationLevel = :intEscalatedLevel")
	List<ComplianceEscalationDetails> getEscalationDetails(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate,@Param("intEscalatedLevel") int intEscalatedLevel);

}
