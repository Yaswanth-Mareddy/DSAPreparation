package com.infosys.reach.util;

public class QueryConstants {
	private QueryConstants() {

	}

	//Common
	public static final String GETEMPLOYEECASEDETAILS="Select new com.infosys.reach.model.common.CaseEmployeeDetails(hrm.empNo,v.mailId,hrm.empName, unit.unitCode, v.sbuCode , hrm.empBandCode, hrm.joinedDate," + 
			"  ge.duCode,hrc.roleDesc, al.projectCode," + 
			"  hrm.company,v.currentCity, g.city,(CASE when hrm.confirmedStatus='Y' then 'Yes' else 'No' end)," + 
			"  al.reportingManager)" + 
			"  From HRISMstEmployee hrm " + 
			"  Left Outer join ALCONTrnAllocations al on al.empNo=hrm.empNo and GETDATE() BETWEEN al.fromDate and al.toDate" + 
			"  Left Outer join HRISMstEmployee  mn on mn.empNo = al.reportingManager" + 
			"  Left Outer join ViewCurrEmpAllDetails v on hrm.empNo=v.empNo" + 
			"  Left Outer join GenMstInfosysEstablishments g on v.devCentreCode=g.establishmentCode" + 
			"  Left Outer join HRISMstRoleCapability hrc On hrm.currentRoleCapability=hrc.roleCode" + 
			"  Left Outer join GenMstEmpDetails ge on ge.empNo=hrm.empNo LEFT OUTER JOIN GenMstPU PU on v.sbuCode=PU.puCode" + 
			" INNER JOIN GenMstSubUnit SUBUNIT on PU.subunitId=SUBUNIT.subunitId  INNER JOIN GenMstUnit unit on unit.unitId=SUBUNIT.unitId" + 
			"  where  (hrm.empNo = :reporteesEmpNo or v.mailId = :reporteesEmpNo)";


	public static final String GETCATEGORYBYCASEID=" SELECT ISNULL(a.concernDesc, 'NULL') FROM ELCMECMstConcernModulesDetails a " + 
			"INNER JOIN ELCMECTrnHearCaseDetails b on b.categoryId = a.concernId WHERE b.caseId = :caseId ";

	public static final String GETMAILINFO="select new com.infosys.reach.model.common.MailContent(body,subject) from GenMstMailConfigHeader where eventCode=:eventCode and applicationCode='EMPCON'";

	public static final String GETBASELOCATION="select distinct gen.country from GenMstInfosysEstablishments gen" + 
			" inner join ViewCurrEmpAllDetails view on gen.establishmentCode=view.devCentreCode where view.empNo=:empNo";

	public static final String GETCOUNTRIES="select distinct new com.infosys.reach.model.hear.Countries(trim(countryCode),trim(countryName),moduleId) from ELCMECTrnReachCountryDetails where moduleId=:moduleId and isEnable=:isEnable";

	public static final String GETCITIES="select distinct new com.infosys.reach.model.hear.Cities(b.cityCode,trim(a.city)) from GENMstCity a inner join GenMstInfosysEstablishments b on a.cityCode =  b.cityCode " + 
			"where a.countryCode=:countryCode and b.cityCode IS NOT NULL and a.isActive=1 and b.isActive='Y' order by trim(a.city)";

	public static final String GETCONCERNDETAILSBYTWOPARAMS="select Distinct new com.infosys.reach.model.hear.Categories(moduleId,concernId,concern,trim(concernDesc),company,countryCode) from ELCMECMstConcernModulesDetails where moduleId=:moduleId AND company=:company";

	public static final String GETCONCERNDETAILSBYTHREEPARAMS="select Distinct new com.infosys.reach.model.hear.Categories(moduleId,concernId,concern,concernDesc,company,countryCode) from ELCMECMstConcernModulesDetails where moduleId=:moduleId AND company=:company AND countryCode=:countryCode";

	public static final String GETCOUNTRYCODE="select Distinct sapCountryCode from  GenMstInfosysEstablishments where (country=:currentCountry or sapCountryCode=:currentCountry) and sapCountryCode is not null";

	public static final String GETACCORDIONSBYMODULEIDANDCASESTATUS = "select distinct new com.infosys.reach.model.common.AccordionModel(a.order,a.status,b.heading,c.apiType,c.value,c.type) from ELCMECTrnReachStatusAccordionsMapping a " + 
			"inner join ELCMECTrnReachAccordions b on a.accordionId=b.accordionId and a.moduleId=b.moduleId " + 
			"inner join ELCMECTrnReachAccordionActions c on a.actionId=c.actionId  and a.moduleId=c.moduleId " + 
			"where a.flgActive=1 and b.flgActive=1 and c.flgActive=1 and a.status=:status and a.moduleId=:moduleId order by a.order asc";

	//ASHI

	public static final String GETEMPLOYEEBYEMPNOORMAILID="SELECT distinct v from ViewCurrEmpAllDetails v where v.empNo=:id or v.mailId=:id";


	public static final String GETCOMPLAINTDETAILSBYCASEID="select new com.infosys.reach.model.ashi.ComplaintDetails(e.caseId,e.respondentType,f.fromRole,f.statusDescription,e.createdOn,e.selectedCity,e.description) from ELCMECTrnASHICaseDetails e " + 
			" inner join ELCMECMstReachWorkFlow f on e.moduleId=f.moduleId and f.flgActive=1 and f.currentStatus=e.status where e.caseId=:caseId";

	public static final String GETCASEEMPLOYEEDETAILSBYCASEID="select new com.infosys.reach.model.common.EmployeeDetails(e.mailId,e.empNo,e.empName) from ELCMECMstASHICaseEmployeeDetails e where e.caseId=:caseId and e.actor in :actor and e.flgActive=1";

	public static final String GETCOCOMPLAINANTSDETAILSBYCASEID="select new com.infosys.reach.model.common.EmployeeDetails(c.mailId,v.empNo,v.empName) from ELCMECMstASHICocomplainantsDetails c  inner join ViewCurrEmpAllDetails v on c.mailId=v.mailId where c.caseId=:caseId and c.flgAccept=1 and c.flgReject=0";

	public static final String GETASHICOUNTRIES="select distinct new com.infosys.reach.model.generic.GenModelOption(countryCode,countryName) from ELCMECTrnReachCountryDetails where moduleId=:moduleId and isEnable=:isEnable";

	public static final String GETASHICITIES="select distinct new com.infosys.reach.model.generic.GenModelOption(b.cityCode,a.city) from GENMstCity a inner join GenMstInfosysEstablishments b on a.cityCode =  b.cityCode " + 
			" inner join ELCMECTrnReachCountryDetails c on a.countryCode=c.countryCode where c.countryName=:country and c.moduleId=2 and c.isEnable=1 and b.cityCode IS NOT NULL and a.isActive=1 and b.isActive='Y' order by a.city";

	public static final String GETEVIDENCESBASEDONCASEID="select e from ELCMECTrnASHIActionDetails e where e.caseActionId=(select min(caseActionId) from ELCMECTrnASHIActionDetails where caseId=:caseId)";

	public static final String GETASHICATEGORIES="select Distinct new com.infosys.reach.model.generic.GenModelOption(concernId,concernDesc) from ELCMECMstConcernModulesDetails where moduleId=:moduleId AND company=:company AND countryCode=:countryCode";

	public static final String GETGENMODELOPTIONSBYGROUPID="select distinct new com.infosys.reach.model.generic.GenModelOption(op.key,op.value) from ELCMECMstReachGenModelOptions op where op.moduleId = :moduleId and op.groupId = :groupId and op.flgActive=1 order by op.key asc";

	public static final String GETTAGGEDCASES="select distinct new com.infosys.reach.model.ashi.InboxCaseDetails(a.caseId,a.createdOn,f.fromRole,f.statusDescription,c.tranId,c.flgAccept) from ELCMECTrnASHICaseDetails a inner join ELCMECMstReachWorkFlow f on a.moduleId=f.moduleId and f.flgActive=1 and f.currentStatus=a.status inner join  ELCMECMstASHICocomplainantsDetails c  on a.caseId=c.caseId and c.flgActive=1 and c.flgReject=0 and c.mailId=:mailId order by a.caseId desc";
	
	public static final String GETCASESASRESPONDENT="select distinct new com.infosys.reach.model.ashi.InboxCaseDetails(a.caseId,a.createdOn, f.statusDescription,c.serialNo,c.flgAccept) from ELCMECTrnASHICaseDetails a inner join ELCMECMstReachWorkFlow f on a.moduleId=f.moduleId and f.flgActive=1 and f.currentStatus=a.status inner join  ELCMECMstASHIConciliationConsentDetails c  on a.caseId=c.caseId and c.flgAccept=0 and c.flgReject=0 and c.actor='R' and c.mailId=:mailId order by a.caseId desc";

	public static final String GETMYCASES="select distinct new com.infosys.reach.model.ashi.InboxCaseDetails(a.caseId,a.createdOn,f.fromRole,f.statusDescription) from ELCMECTrnASHICaseDetails a " + 
			"inner join ELCMECMstASHICaseEmployeeDetails e on a.caseId=e.caseId inner join ELCMECMstReachWorkFlow f on a.moduleId=f.moduleId and f.flgActive=1 and f.currentStatus=a.status where e.empNo=:empNo and e.flgValid=1 and e.flgActive=1 and e.actor='A' and a.raisedBy in :raisedBy  order by a.caseId desc";

	//ASHI ADMIN
	public static final String GETCASESUMMARY="select new com.infosys.reach.model.ashiadmin.CaseSummary(c.respondentType, f.fromRole, c.createdOn, c.raisedBy, c.description)  from ELCMECTrnASHICaseDetails c inner join ELCMECMstReachWorkFlow f on c.moduleId=f.moduleId and f.flgActive=1 and f.currentStatus=c.status where c.caseId=:caseid";

	public static final String GETPRELIMINARYDISCUSSIONDETAILS="select new com.infosys.reach.model.ashiadmin.PreliminaryDiscussionDetails(e.serialNo,e.createdDate,e.discussedWith,e.role,e.discussionSummary,e.dmsFileName) from ELCMECMstASHIPreliminaryDiscussionDetails e where e.caseId=:caseId order by e.serialNo desc";

	public static final String GETCASESUMMARYDROPDOWN="select distinct new com.infosys.reach.model.generic.GenModelOption(a.serialNo,a.empName) from ELCMECMstASHICaseEmployeeDetails a where a.caseId = :caseId and a.actor in :actor and a.flgActive=1";

	public static final String GETEMPLOYEES="select new com.infosys.reach.model.generic.GenModelOption(mailId,empName) from ELCMECMstASHICaseEmployeeDetails where actor in :actor and flgActive=1 and flgValid=1 and caseId=:caseId";

	public static final String GETLOCATIONS="select distinct new com.infosys.reach.model.generic.GenModelOption(a.selectedCity,a.selectedCity) from ELCMECTrnASHICaseDetails a inner join ELCMECTrnReachCountryDetails c on c.moduleId=a.moduleId and c.isEnable=1 and a.selectedCountry = c.countryName where c.countryCode = :country order by a.selectedCity";


	public static final String GETSTATUS="select distinct new com.infosys.reach.model.generic.GenModelOption(w.statusDescription,w.statusDescription) from ELCMECTrnASHICaseDetails c "
			+" inner join ELCMECMstReachWorkFlow w on c.moduleId=w.moduleId and c.status=w.currentStatus where w.fromRole = :role order by w.statusDescription";

	public static final String GETADMININBOXROWS = "select distinct new com.infosys.reach.model.ashiadmin.AdminInboxRow(a.caseId,a.createdOn,a.createdBy,coalesce(a.selectedCity,''),coalesce(c.concernDesc,''),a.status+','+w.statusDescription, s.slaEndDate) from ELCMECTrnASHICaseDetails a "
			+ "inner join ELCMECMstASHICaseEmployeeDetails e on a.caseId=e.caseId inner join ELCMECTrnASHIActionDetails b on a.caseId=b.caseId and b.caseActionId="
			+ "(select max(caseActionId) from ELCMECTrnASHIActionDetails where caseId=a.caseId)  and b.status=a.status "
			+" inner join ELCMECMstReachWorkFlow w on a.moduleId=w.moduleId and a.status=w.currentStatus and w.flgActive=1 "
			+" inner join ELCMECTrnReachCountryDetails d on d.moduleId=a.moduleId and d.isEnable=1 and d.countryName=a.selectedCountry "
			+" left outer join ELCMECMstConcernModulesDetails c on a.moduleId=c.moduleId and a.categoryId=c.concernId and c.company=:company "
			+" AND c.countryCode=:country left outer join ELCMECtrnASHIConcernSLADetails s on a.caseId=s.caseId and s.role=:role where e.flgValid=1 and e.flgActive=1 and e.actor = 'I' and d.countryCode=:country and e.company=:company ";

	
	public static final String ASSIGNEE_LOCATION_FILTER = " and b.assigneeLocation in :assigneeLocation";
	
	public static final String NOTINCASEFILTER = " and w.fromRole=:role and a.status not in :status" ;
	
	public static final String INCASEFILTER = " and a.status in :status" ;

	public static final String ORDERBY = " order by a.caseId desc" ;
	
	public static final String GETADMININBOXROWS_SLAAPPROVALCASES = "select distinct new com.infosys.reach.model.ashiadmin.AdminInboxRow(a.createdOn,a.caseId,a.createdBy,coalesce(a.selectedCity,''),coalesce(c.concernDesc,''),a.status+','+w.statusDescription, s.slaEndDate) from ELCMECTrnASHICaseDetails a "
			+ "inner join ELCMECMstASHICaseEmployeeDetails e on a.caseId=e.caseId inner join ELCMECMstReachWorkFlow w on a.moduleId=w.moduleId and a.status=w.currentStatus and w.flgActive=1 "
			+" inner join ELCMECTrnReachCountryDetails d on d.moduleId=a.moduleId and d.isEnable=1 and d.countryName=a.selectedCountry left outer join ELCMECMstConcernModulesDetails c"
			+" on a.moduleId=c.moduleId and a.categoryId=c.concernId and c.company=:company AND c.countryCode=:country "
			+" inner join ELCMECtrnASHIConcernSLADetails s on a.caseId=s.caseId and s.role=:role and s.flgSLAExtensionRequest=1";
	
	public static final String GETADMININBOXROWS_INTERIMAPPROVALCASES = "select distinct new com.infosys.reach.model.ashiadmin.AdminInboxRow(a.createdOn,a.createdBy,a.caseId,coalesce(a.selectedCity,''),coalesce(c.concernDesc,''),a.status+','+w.statusDescription, s.slaEndDate) from ELCMECTrnASHICaseDetails a "
			+ "inner join ELCMECMstASHICaseEmployeeDetails e on a.caseId=e.caseId "
			+ "inner join ELCMECMstReachWorkFlow w on a.moduleId=w.moduleId and a.status=w.currentStatus and w.flgActive=1 "
			+" inner join ELCMECTrnReachCountryDetails d on d.moduleId=a.moduleId and d.isEnable=1 and d.countryName=a.selectedCountry left outer join ELCMECMstConcernModulesDetails c"
			+" on a.moduleId=c.moduleId and a.categoryId=c.concernId and c.company=:company AND c.countryCode=:country inner join "
			+" ELCMECTrnASHIInterimReliefDetails i on a.caseId=i.caseId and i.flgRelief=1 and i.flgActionTaken=0 "
			+" left outer join ELCMECtrnASHIConcernSLADetails s on a.caseId=s.caseId and s.role=:role";
			
	public static final String GETADMININBOXROWS_APPROVALCASES_FILTER = " where e.flgValid=1 and e.flgActive=1 and e.actor = 'I' and d.countryCode=:country and e.company=:company";
	
	public static final String GETPREVIOUSCASES = "select distinct new com.infosys.reach.model.generic.Card(c.caseId, w.statusDescription, cat.concernDesc) from ELCMECTrnASHICaseDetails c" + 
			" inner join ELCMECMstASHICaseEmployeeDetails e on c.caseId=e.caseId" + 
			" inner join ELCMECMstReachWorkFlow w on c.moduleId=w.moduleId and c.status=w.currentStatus and w.flgActive=1 " +
			" left outer join ELCMECMstConcernModulesDetails cat on c.categoryId=cat.concernId and cat.moduleId=2 AND cat.company='INFSYS' AND cat.countryCode='IN'" + 
			" where e.actor=:actor and e.empNo=:empNo and e.flgValid=1 and e.flgActive=1";
	
	public static final String GETCOCOMPLAINANTSBYCASEID="select distinct new com.infosys.reach.model.generic.GenModelOption(c.tranId,v.empName) from ELCMECMstASHICocomplainantsDetails c  inner join ViewCurrEmpAllDetails v on c.mailId=v.mailId where c.caseId=:caseId and c.flgAccept=0 and c.flgReject=0";
	
	public static final String GETLATESTACTIONBYCASEID="select distinct new com.infosys.reach.entity.ELCMECTrnASHIActionDetails(a, w.statusDescription, w.fromRole) from ELCMECTrnASHIActionDetails a "+
			" inner join ELCMECMstReachWorkFlow w on a.status=w.currentStatus and w.flgActive=1  where a.caseActionId=(select max(b.caseActionId) from ELCMECTrnASHIActionDetails b where b.caseId= :caseId) ";

	public static final String GETALLACTIONBYCASEID="select a from ELCMECTrnASHIActionDetails a where a.caseId=:caseId and a.caseActionId>=(select b.caseActionId from ELCMECTrnASHIActionDetails b where b.caseId= :caseId and b.status=:status) order by a.caseActionId asc";

	public static final String GETFINDINGSBYCASEIDANDACTORANDMAILID="select distinct new com.infosys.reach.model.ashiadmin.Findings(f.serialNo, f.allegation, f.finding, f.outcome, f.flgSentFindings) from ELCMECMstASHIAllegationsAndFindingsDetails f where f.caseId=:caseId and f.actor=:actor and f.mailId=:mailId";

	public static final String GETFINDINGSANDASSIGNEELOCATIONBYCASEIDANDACTORANDMAILID="select distinct new com.infosys.reach.model.ashiadmin.Findings(f.serialNo, f.allegation, f.finding, f.outcome, f.flgSentFindings, v.empName, a.assigneeLocation) from ELCMECMstASHIAllegationsAndFindingsDetails f "+
			"inner join ELCMECTrnASHIActionDetails a on f.caseId=a.caseId inner join ViewCurrEmpAllDetails v on v.mailId=f.mailId "+				
			"where f.caseId=:caseId and f.actor=:actor and f.mailId=:mailId and a.caseActionId = (select MAX(ai.caseActionId) from ELCMECTrnASHIActionDetails ai where ai.caseId=a.caseId)";
	
	public static final String GETDETAILSFORMAIL = "select distinct new com.infosys.reach.model.ashiadmin.MailEmployeeDetails(e.mailId, e.empName, e.empNo, v.mailId, coalesce(a.assigneeLocation,''), coalesce(s.slaEndDate,'')) from ELCMECTrnASHICaseDetails c inner join ELCMECMstASHICaseEmployeeDetails e on c.caseId=e.caseId inner join " + 
			"ELCMECTrnASHIActionDetails a on c.caseId=a.caseId and a.caseActionId=(select max(caseActionId) from ELCMECTrnASHIActionDetails where caseId=c.caseId) " + 
			"left outer join ViewCurrEmpAllDetails v on a.assigneeEmpNo=v.empNo " + 
			"left outer join ELCMECtrnASHIConcernSLADetails s on c.caseId=s.caseId and s.role=:role " +
			"where e.actor=:actor and e.flgActive=1 and e.flgValid=1 and c.caseId=:caseId";
	
	public static final String GETRECOMMENDEDACTIONBYCASEIDANDACTOR = "select distinct new com.infosys.reach.model.generic.GenModelOption(r.serialNo, r.mailId, r.actions) from ELCMECMstASHIRecommendationsDetails r where r.caseId=:caseid and r.actor=:actor";
	
	public static final String GETASSIGNEELOCATIONBYROLEANDCASEID="select a from ELCMECTrnASHIActionDetails a inner join ELCMECMstReachWorkFlow w on a.status=w.currentStatus and w.fromRole=:role and w.moduleId=2 " + 
			"where a.caseActionId = (select max(ai.caseActionId) from ELCMECTrnASHIActionDetails ai where ai.assigneeLocation is not null and ai.assigneeLocation<>'' and ai.caseId=:caseId)";
	
	public static final String GETCASEDETAILSFORAUTHORIZATION = "select distinct new com.infosys.reach.model.common.CaseDetailsAuthorization(a.moduleId, a.status, w.fromRole, d.countryCode, e.company, b.assigneeLocation, a) from ELCMECTrnASHICaseDetails a "
			+ "inner join ELCMECMstASHICaseEmployeeDetails e on a.caseId=e.caseId "
			+ "inner join ELCMECTrnASHIActionDetails b on a.caseId=b.caseId and b.caseActionId="
			+ "(select max(caseActionId) from ELCMECTrnASHIActionDetails where caseId=a.caseId) and b.status=a.status "
			+" inner join ELCMECMstReachWorkFlow w on a.moduleId=w.moduleId and a.status=w.currentStatus and w.flgActive=1 "
			+" inner join ELCMECTrnReachCountryDetails d on d.moduleId=a.moduleId and d.isEnable=1 and d.countryName=a.selectedCountry "
			+" where e.flgValid=1 and e.flgActive=1 and e.actor = 'I' and a.caseId=:caseid";

	//Disciplinary
	public static final String GETEMPCOUNTRYFORDISCANDBG = "select c.sapCountryCode from HRISTrnEmpInfosysLocation b inner join GenMstInfosysEstablishments c on c.establishmentCode = b.devCentreCode " + 
			"where b.serialNo = (SELECT max(serialNo) from HRISTrnEmpInfosysLocation d where d.empNo = b.empNo and :currentDate>=d.dtEffectiveDate and d.empNo=:empNo)";
}
