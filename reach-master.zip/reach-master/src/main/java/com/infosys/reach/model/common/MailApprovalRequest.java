package com.infosys.reach.model.common;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class MailApprovalRequest {
	@JsonProperty("URN")
    private String urn;
	
    @JsonProperty("ActionName")
    private String actionName;
    
    @JsonProperty("Remarks")
    private String remarks;
    
    @JsonProperty("Actor")
    private String actor;
    
    @JsonProperty("RequestID")
    private String requestID;
}
