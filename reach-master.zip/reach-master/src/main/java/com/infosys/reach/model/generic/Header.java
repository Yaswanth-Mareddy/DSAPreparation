package com.infosys.reach.model.generic;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Header {


	private String label;
	private String field;
	private String toolTip;
	@JsonProperty("isHyperlink")
	private boolean isHyperlink;
	private int type;
	private int isSortingEnabled;
	private String sortingType;
	private String isCollapsible;
	@JsonProperty("isParent")
	private boolean isParent;
	private String filterType;

}
