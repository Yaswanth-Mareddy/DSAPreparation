package com.infosysit.itsm.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosysit.itsm.controller.ITSMInterceptor;
import com.infosysit.itsm.exception.CustomException;
import com.infosysit.itsm.model.EDSTrnDepPassportDetailsModel;
import com.infosysit.itsm.model.ISLeapAutoResponseModel;
import com.infosysit.itsm.model.ISLeapTicket;
import com.infosysit.itsm.mysqldatasource.repository.ICMTicketsRepository;
import com.infosysit.itsm.mysqldatasource.repository.ISLeapMstAutoResponseRepository;
import com.infosysit.itsm.mysqldatasource.repository.ISLeapTrnRuleMappingRepository;
import com.infosysit.itsm.sqldatasource.repository.EDSTrnDepPassportDetailsRepository;



@Service
public class ITSMServiceImpl implements ITSMService {
	
	@Autowired
	private ICMTicketsRepository icmTicketsRepository;
	
	@Autowired
    private	ISLeapMstAutoResponseRepository isLeapAutoResponseRepository;
	
	@Autowired
	private ISLeapTrnRuleMappingRepository isLeapRuleMappingRepository;
	
	@Autowired
	private EDSTrnDepPassportDetailsRepository edsTrnDepPassportDetailsRepository;
	
	@Autowired
	private ITSMInterceptor itsmInterceptor;
	
	@Override
	public boolean decisionAnalysis() throws CustomException
    {
		try {
		List<ISLeapTicket> lstIcmTickets=icmTicketsRepository.getIcmOpenTickets();
		
		if(!lstIcmTickets.isEmpty())
		{
			for(ISLeapTicket icmTicket:lstIcmTickets)
			{
				String txtEmpNo=icmTicket.getCaller();
				String ticketNumber=icmTicket.getNumber();
				List<EDSTrnDepPassportDetailsModel> lstDependentPassportDetails=edsTrnDepPassportDetailsRepository.getDependentPassportDetails(txtEmpNo);
				String dependentNames="";
				String resolutionSteps="";
				if(!lstDependentPassportDetails.isEmpty()) {
					StringBuilder dependentNamesBuilder = new StringBuilder();
					for(EDSTrnDepPassportDetailsModel record:lstDependentPassportDetails) {
						dependentNamesBuilder.append(record.getTxtRelationDesc()+",");
					}
					dependentNames=dependentNamesBuilder.toString();
					dependentNames=dependentNames.substring(0,dependentNames.length()-1)+".";
					resolutionSteps="The details of below dependents are present in Harmony. If details of any dependent is not present, kindly add in Harmony and then raise new travel request. If travel request is already submitted, please recall and raise new travel request. Name of Dependents in harmony are :"+ dependentNames;
				}
				else 
				{
					resolutionSteps="There are no dependent details present in harmony.kindly add dependent details in Harmony and then raise new travel request.";
				}
				icmTicketsRepository.updateIcmTicketsUsingNumber(ticketNumber,resolutionSteps);
			}
			return true;
		}
		return false;
		}
		catch(Exception e)
		{
			itsmInterceptor.setExeceptionEventData("Message "+e.getMessage(),"StackTrace "+ Arrays.toString(e.getStackTrace()), "DecisionAnalysis");
			return false;
		}
	}
	
	@Override
	public boolean autoResponse() throws CustomException
    {
		try {
	    List<String> lstTicketNumbers=icmTicketsRepository.getIcmOpenTicketNumbers();
	    
	    if(!lstTicketNumbers.isEmpty())
	    {
	    	for(String ticketNo : lstTicketNumbers) {
	    		String ruleNo=isLeapRuleMappingRepository.getRuleUsingTickerNumber(ticketNo);
	    		ISLeapAutoResponseModel resolutionSolution=isLeapAutoResponseRepository.getResolutionDetails(ruleNo);
	    		
	    		if(resolutionSolution!=null)
	    		{
	    			
	    			String subcategory= resolutionSolution.getStatus().trim() +","+resolutionSolution.getNewCategoryName().trim()+","+resolutionSolution.getDeptName().trim();
	    			if(resolutionSolution.getTransfer().equalsIgnoreCase("Not Required"))
	    				icmTicketsRepository.updateIcmTicketsNotRequired(ticketNo,resolutionSolution.getSuggestion().trim(),subcategory);
	    			else if(resolutionSolution.getTransfer().equalsIgnoreCase("Required"))
	    				icmTicketsRepository.updateIcmTicketsRequired(ticketNo,resolutionSolution.getSuggestion().trim(),subcategory);
	    			
	    		}
	    	}
	    	return true;
		}
		return false;
		}
		catch(Exception e)
		{
			itsmInterceptor.setExeceptionEventData("Message "+e.getMessage(),"StackTrace "+ Arrays.toString(e.getStackTrace()), "AutoResponse");
			return false;
		}
	}
	
		
	
}
