package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstconfigurabledetails")
public class CMSMstConfigurableDetails {

	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="txtname")
	private String txtName;
	
	@Column(name="txtvalue")
	private String txtValue;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intidentity")
	private String intIdentity;
}
