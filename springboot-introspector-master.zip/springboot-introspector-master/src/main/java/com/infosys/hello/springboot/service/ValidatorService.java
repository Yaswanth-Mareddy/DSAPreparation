package com.infosys.hello.springboot.service;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.infosys.hello.springboot.config.CustomMessageSourceConfiguration;
import com.infosys.hello.springboot.dto.ValidatorDTO;
import com.infosys.hello.springboot.repository.ValidatorRepository;

@Service
public class ValidatorService {
	
	@Value("${phoneNumber.usa")
	private String invalidUSAPhoneNumber;
	
	@Value("${phoneNumber.india")
	private String invalidIndiaPhoneNumber;
	
	@Value("${validatordto.validate}")
	private String validatorSuccess;
	
	@Autowired
	ValidatorRepository validatorRepository;
	
	@Autowired
	CustomMessageSourceConfiguration configuration;
	
	public String customValidation(String region, ValidatorDTO reqDto) {
		if(region.equalsIgnoreCase(Region.USA.toString()) && reqDto.getPhoneNumber().length()!=Region.USA.getPhoneNumber()) {
//			return invalidUSAPhoneNumber;
			return configuration.messageSource().getMessage("invalidUSAPhoneNumber", null, "Invalid Phone Number", null);
		}
		else if(region.equalsIgnoreCase(Region.INDIA.toString()) && reqDto.getPhoneNumber().length()!=Region.INDIA.getPhoneNumber()) {
//			 return invalidIndiaPhoneNumber;
			return configuration.messageSource().getMessage("invalidIndiaPhoneNumber", null, "Invalid Phone Number", null);
		}
		else {
//			return validatorSuccess;
			return configuration.messageSource().getMessage("validationSuccess", null, "validation success", null);
		}
	}
	
	public ValidatorDTO getObj(String name) {
		ValidatorDTO req = validatorRepository.getValidateDTO(name);
		return req;
	}

	public String save(@Valid @NotNull ValidatorDTO obj) {
		return validatorRepository.save(obj);
	}
	
	enum Region{
		USA(6), INDIA(10);
		
		private int phoneNumber;
		
		public int getPhoneNumber() {
			return this.phoneNumber;
		}
		
		private Region(int phNumber) {
			this.phoneNumber = phNumber;
		}
	}

}
