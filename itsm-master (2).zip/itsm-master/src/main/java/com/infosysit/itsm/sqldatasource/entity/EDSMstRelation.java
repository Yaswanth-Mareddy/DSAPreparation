package com.infosysit.itsm.sqldatasource.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="edsmstrelation")
public class EDSMstRelation {
	
	@Id
	@Column(name="intRelSeqNo")
	private int intRelSeqNo;
	
	@Column(name="txtRelationDesc")
	private String txtRelationDesc;
	
	@Column(name="txtRelationCode")
	private String txtRelationCode;
	
	@Column(name="dtLastModified")
	private Date dtLastModified;
}
