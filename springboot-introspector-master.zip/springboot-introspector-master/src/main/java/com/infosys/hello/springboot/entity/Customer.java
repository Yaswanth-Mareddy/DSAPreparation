package com.infosys.hello.springboot.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "customer_details")
public class Customer {
	
	/**
	 * Primary key of the entity - Auto generated
	 */
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "customer_id")
	private int id;

	/**
	 * Name of the customer
	 */
	@NotEmpty(message="Name cannot be empty") 
	@NotNull
	@Column(name = "name")
	private String name;

	/**
	 * Location of the customer
	 */
	@NotEmpty(message="Location cannot be empty") 
	@NotNull
	@Column(name = "location")
	private String location;

	/**
	 * Created date 
	 */
	@Column(name = "created_date")
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdDate = new Date();

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
}
