package com.infosysit.rctmscompliance.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnactionitemtracking")
public class CMSTrnActionItemTracking {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intactionitemid")
	private int intActionItemId ;
	
	@Column(name="txtactionitemowner")
	private String txtActionItemOwner ;
	
	@Column(name="txtactionitemdescription")
	private String txtActionItemDescription ;
	
	@Column(name="txtactionitemassignee")
	private String txtActionItemAssignee ;
	
	@Column(name="dtactionitemduedate")
	private String dtActionItemDueDate ;
	
	@Column(name="dtactionitemreminderinterval")
	private int dtActionItemReminderInterval;
	
	@Column(name="txtactionitemstatus")
	private String txtActionItemStatus;
	
	@Column(name="intnoticemappedto")
	private int intNoticeMappedTo;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy ;
	
	@Column(name="dtlastmodified")
	private String dtLastModified ;
	
	@Column(name="flgisassigneedelegated")
	private String flgIsAssigneeDelegated ;
	
	@Column(name="dtactionitemcreationdate")
	private String dtActionItemCreationDate ;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy ;
	
	@Column(name="dtmodifiedon")
	private Date dtModifiedOn ;
	
	@Column(name="intlinknoticeflg")
	private int intLinkNoticeflg;
	
	@Column(name="txtescalationowner")
	private String txtEscalationowner;
	
	@Column(name="intescatationinterval")
	private int intEscatationInterval;
	
	@Column(name="txtapplicationname")
	private String txtApplicationName ;
	
	@Column(name="txtmakerempno")
	private String txtMakerEmpNo ;
	
	@Column(name="txtcheckerempno")
	private String txtCheckerEmpNo;
	
	@Column(name="txttransactionid")
	private String txtTransactionID;
	
	@Column(name="intruleid")
	private int intRuleID;
	
	@Column(name="intbistrnID")
	private int intbistrnID ;
	
	@Column(name="intinternalflag")
	private int intInternalFlag;
	
	@Column(name="flgisreopended")
	private String flgIsReopended ;
}
