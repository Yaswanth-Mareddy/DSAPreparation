package com.infosys.reach;

import java.io.IOException;
import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringRunner.class)
@SpringBootTest
@WebAppConfiguration
public abstract class AbstractTest {
   protected MockMvc mvc;
   protected String token;
   
   
   @Autowired
   WebApplicationContext webApplicationContext;

   protected void setUp() {
      mvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      token="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJiMTg3NDYyNy1lMzlkLTQ5NzYtYjM3MC1hMGVlN2UzODNhMjQiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82M2NlN2Q1OS0yZjNlLTQyY2QtYThjYy1iZTc2NGNmZjVlYjYvIiwiaWF0IjoxNjE5MDEzODc4LCJuYmYiOjE2MTkwMTM4NzgsImV4cCI6MTYxOTAxNzc3OCwiYWNyIjoiMSIsImFpbyI6IkFYUUFpLzhUQUFBQTEzdER5WmhIVXovSCtkS0JRODIxRXB0VTdPbllwc3NpVUR3bUFDaXFxZjNNUDk0M3JIOU0zeHpNTkVBYXFycDB6YTdmWU9LcXJzOVZOaWxGd3RQZkwxTnB4djZlQ1ArckJmVVI1bDJnSStuSG9kZW5UT1dscmp4cjRvZHZ3U1cyQ2JSaFEyTGZaL3BGNVUwdTJtQytHQT09IiwiYW1yIjpbInJzYSIsIm1mYSJdLCJhcHBpZCI6ImIxODc0NjI3LWUzOWQtNDk3Ni1iMzcwLWEwZWU3ZTM4M2EyNCIsImFwcGlkYWNyIjoiMSIsImRldmljZWlkIjoiOGEwZDEzMDYtMGFlMi00NDA3LWE4OTgtNWE0MjdlYTlkODgxIiwiZmFtaWx5X25hbWUiOiJEZXdhbmdhbiIsImdpdmVuX25hbWUiOiJTdXJhaiBLdW1hciIsImlwYWRkciI6IjEyNS4yMi4xOTMuMTQ4IiwibmFtZSI6IlN1cmFqIEt1bWFyIERld2FuZ2FuIiwib2lkIjoiNWY1M2Q3YmMtMzhhOS00OWNhLTkzOWQtMTdiYjkyYWY5ZjA5Iiwib25wcmVtX3NpZCI6IlMtMS01LTIxLTI2Njc0OTk0MC0xNjM3OTY0NDQ0LTkyOTcwMTAwMC0zNTk2MzQ4IiwicmgiOiIwLkFRWUFXWDNPWXo0dnpVS296TDUyVFA5ZXRpZEdoN0dkNDNaSnMzQ2c3bjQ0T2lRR0FDRS4iLCJzY3AiOiJVc2VyLlJlYWQiLCJzdWIiOiJleGV6UVBSZzY3eXlGOG94WWZ0VE5xV1VpeFVmelY5WlNlb1kwRmFzNDFvIiwidGlkIjoiNjNjZTdkNTktMmYzZS00MmNkLWE4Y2MtYmU3NjRjZmY1ZWI2IiwidW5pcXVlX25hbWUiOiJzdXJhamt1bWFyLmRld2FuZ2FuQGFkLmluZm9zeXMuY29tIiwidXBuIjoic3VyYWprdW1hci5kZXdhbmdhbkBhZC5pbmZvc3lzLmNvbSIsInV0aSI6InllQzRIZGdocWtTVFlQOEJQRXdmQUEiLCJ2ZXIiOiIxLjAiLCJFbXBObyI6IjEwMzA4MTYifQ.mNy9U6wEcdKIdoCPO9Mhb5tY-UiMpiQhVEew6W-gwJV8eirHnbA38zxBItrj2FiDGV-d0tdumF4o6iRz1RyNGee3zCdhiShIwBhPEFLbvXSqIaBLvKUQYK2nLIQcS3gxeSJUK_Xj024lHyQGvMt1d2lop4G4dCV6CuayobaDhVORmgbnwxGM0esn1zKZl_jMIgUUJrkz2UZd_GoTTWZzVjmtrR84o0vxGuhOcs3QREE7m8J08l2CFv4KslRKikbk9aHJooeaFw7YS7759nO0ekSFIVincK-b_SiRR2R07C8R983z15JeqTK8jB0wbXM0-n0fP1m1JMqKBZYJofa_mQ";
   }
   protected String mapToJson(Object obj) throws JsonProcessingException {
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.writeValueAsString(obj);
   }
   protected <T> T mapFromJson(String json, Class<T> clazz)
      throws JsonParseException, JsonMappingException, IOException {
      
      ObjectMapper objectMapper = new ObjectMapper();
      return objectMapper.readValue(json, clazz);
   }
   
   protected <T> List<T> mapFromJsonList(String json, Class<T> clazz)
		   throws JsonParseException, JsonMappingException, IOException {

	   ObjectMapper objectMapper = new ObjectMapper();
	   return objectMapper.readValue(json, objectMapper.getTypeFactory().constructCollectionType(List.class, clazz));
   }
}

