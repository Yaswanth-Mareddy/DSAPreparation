package com.example.demoInfyApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoInfyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoInfyAppApplication.class, args);
	}

}
