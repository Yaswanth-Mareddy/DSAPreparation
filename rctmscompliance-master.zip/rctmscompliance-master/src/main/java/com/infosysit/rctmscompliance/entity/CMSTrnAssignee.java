package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmstrnassignee")
public class CMSTrnAssignee {

	@Id
	@Column(name="intcomplianceid")
	private int intComplianceID;
	
	@Column(name="dtassigneddate")
	private String dtAssignedDate;
	
	@Column(name="txtassigneeid")
	private String txtAssigneeID;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
	
	@Column(name="txtmodifiedby")
	private String txtModifiedBy;
	
	@Column(name="dtmodifiedon")
	private String dtModifiedOn;
}
