package com.infosysit.rctmscompliance.exception;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class CustomException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 195154807111992L;

	public CustomException(String message) {
		super(message);
	}
	
	
}
