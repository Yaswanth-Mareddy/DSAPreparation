package com.infosys.reach;

import static org.junit.Assert.assertEquals;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.ASHIAccess;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.ashi.InboxCaseDetails;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.TabView;
import com.infosys.reach.model.ashi.ValidatedCaseDetails;
import com.infosys.reach.model.ashimobile.CaseFormGenModel;
import com.infosys.reach.model.ashimobile.CaseGenModelFormData;
import com.infosys.reach.model.ashimobile.ComplaintField;
import com.infosys.reach.model.ashimobile.EmployeeCard;
import com.infosys.reach.model.ashimobile.EmployeeCardView;
import com.infosys.reach.model.ashimobile.EvidenceCard;
import com.infosys.reach.model.ashimobile.EvidenceCardView;
import com.infosys.reach.model.ashimobile.EvidenceField;
import com.infosys.reach.model.ashimobile.MobileComplaintInboxView;
import com.infosys.reach.model.ashimobile.MobileInboxAction;
import com.infosys.reach.model.ashimobile.MobileInboxView;
import com.infosys.reach.model.ashimobile.MobileRow;
import com.infosys.reach.model.common.DPServiceOutput;
import com.infosys.reach.service.ASHIMobileServiceImpl;
import com.infosys.reach.service.ASHIServiceImpl;
import com.infosys.reach.service.CommonServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

class ASHIMobileControllerTests extends AbstractTest {
	static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));


	@MockBean
	ASHIMobileServiceImpl service;
	
	@MockBean
	ASHIServiceImpl service1;
	
	@MockBean
	CommonServiceImpl webservice;

	@Override
	@BeforeEach
	public void setUp() {
		super.setUp();
	}

	@Test
	void initiateCaseFormPositiveTest() throws Exception {
		CaseFormGenModel objExpected = new CaseFormGenModel("Initiate Case", "", new CaseGenModelFormData(),
				new CaseGenModelFormData(), new ArrayList<>());
		Mockito.when(service.initiateCaseForm()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/initiatemobilecaseform").header("Authorization",
				"Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		CaseFormGenModel objActual = super.mapFromJson(content, CaseFormGenModel.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}

	@Test
	void initiateCaseFormNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);
		Mockito.when(service.initiateCaseForm()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/initiatemobilecaseform").header("Authorization",
				"Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}

	@Test
	void getCaseEmployeeDetailsPositiveTest1() throws Exception {
		List<EmployeeCard> cards = new ArrayList<>();
		cards.add(new EmployeeCard("a", new ArrayList<>()));
		EmployeeCardView objExpected = new EmployeeCardView("Employee details", cards);

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecaseemployeedetails")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		EmployeeCardView objActual = super.mapFromJson(content, EmployeeCardView.class);

		assertEquals(objExpected.getCards().get(0).getHeading(), objActual.getCards().get(0).getHeading());
	}
	
	@Test
	void getCaseEmployeeDetailsPositiveTest2() throws Exception {
		
		Response objExpected = new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		EmployeeCardView serviceReturn = new EmployeeCardView("Employee details", new ArrayList<>());

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecaseemployeedetails")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getCaseEmployeeDetailsNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getCaseEmployeeDetails(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecaseemployeedetails")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}

	@Test
	void getEvidencesPositiveTest1() throws Exception {
		List<EvidenceCard> cards = new ArrayList<>();
		List<EvidenceField> fields = new ArrayList<>();
		fields.add(new EvidenceField("abc",""));
		cards.add(new EvidenceCard(fields));
		EvidenceCardView objExpected = new EvidenceCardView("Evidences", cards);

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobileevidences")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		EvidenceCardView objActual = super.mapFromJson(content, EvidenceCardView.class);

		assertEquals(objExpected.getCards().get(0).getFields().get(0).getFileName(),
				objActual.getCards().get(0).getFields().get(0).getFileName());
	}
	
	@Test
	void getEvidencesPositiveTest2() throws Exception {
		
		Response objExpected = new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		EvidenceCardView serviceReturn = new EvidenceCardView("Evidences", new ArrayList<>());

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobileevidences")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getEvidencesNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getEvidences(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobileevidences")
				.header("Authorization", "Bearer " + token).param("caseid", "2");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}

	@Test
	void getCaseDetailsByCaseIdPositiveTest1() throws Exception {
		MobileComplaintInboxView objExpected = new MobileComplaintInboxView("Complaint details", "",
				Constants.INBOXVIEW, new ComplaintField());

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecomplaintdetails")
				.header("Authorization", "Bearer " + token).param("caseid", "123");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MobileComplaintInboxView objActual = super.mapFromJson(content, MobileComplaintInboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
	}
	
	@Test
	void getCaseDetailsByCaseIdPositiveTest2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.CASENOTREGISTERED);
		
		MobileComplaintInboxView serviceReturn = new MobileComplaintInboxView("Complaint details", "",
				Constants.INBOXVIEW, null);

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecomplaintdetails")
				.header("Authorization", "Bearer " + token).param("caseid", "123");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getCaseDetailsByCaseIdNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getComplaintDetails(Mockito.anyInt())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobilecomplaintdetails")
				.header("Authorization", "Bearer " + token).param("caseid", "123");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}

	@Test
	void getInboxInitiatedByMePositiveTest1() throws Exception {
		List<MobileRow> rowList = new ArrayList<>();
		List<MobileInboxAction> actions = Arrays.asList(
				(new MobileInboxAction(Constants.CASE_ID, "GET", "",
						"Are you sure you want to be tagged as a co-complainant?")),
				(new MobileInboxAction(Constants.CASE_ID, "GET", "", "No")));
		rowList.add(new MobileRow(new InboxCaseDetails(1, "01-01-2020", "a", "a"), actions));
		MobileInboxView objExpected = new MobileInboxView("Tab - Initiated by me", "", Constants.INBOXVIEW, rowList);

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbyme")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MobileInboxView objActual = super.mapFromJson(content, MobileInboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	void getInboxInitiatedByMePositiveTest2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.NOCASEFOUND);

		MobileInboxView serviceReturn = new MobileInboxView("Tab - Initiated by me", "", Constants.INBOXVIEW, new ArrayList<>());

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbyme")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getInboxInitiatedByMeNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getCasesInitiatedByMe(Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbyme")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void submitASHICasePositiveTest1() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, "Done! Your case is submitted with Case id 123.");

		GMFields caseDetails = new GMFields(); 
		ValidatedCaseDetails validatedCaseDetails = new ValidatedCaseDetails();
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(true, "", validatedCaseDetails);

		Mockito.when(service1.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service1.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);
		Mockito.when(service1.initiateASHICase( Mockito.any())).thenReturn(objExpected);

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/mobilesubmitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void submitASHICasePositiveTest2() throws Exception{
		Response objExpected = new Response(Message.ERROR, "You don't have access to use this application.");

		Mockito.when(service1.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(false));

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/mobilesubmitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void submitASHICasePositiveTest3() throws Exception{
		Response objExpected = new Response(Message.ERROR, Message.INVALID_INPUT);

		GMFields caseDetails = new GMFields(); 
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(false, Message.INVALID_INPUT);

		Mockito.when(service1.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service1.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);
		Mockito.when(service1.initiateASHICase( Mockito.any())).thenReturn(objExpected);

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/mobilesubmitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void submitASHICaseNegativeTest() throws Exception{
		Response objExpected=new Response(Message.ERROR,Message.SOMEERROROCCURED);

		GMFields caseDetails = new GMFields(); 
		ValidatedCaseDetails validatedCaseDetails = new ValidatedCaseDetails();
		CaseDetailsValidationResponse validateResponse = new CaseDetailsValidationResponse(true, "", validatedCaseDetails);

		Mockito.when(service1.checkHearAccess(Mockito.anyString())).thenReturn(new ASHIAccess(true));
		Mockito.when(webservice.convertGenModelToObject(Mockito.any(), Mockito.anyInt())).thenReturn(caseDetails);
		Mockito.when(service1.validateCaseDetails(Mockito.anyString(), Mockito.any(), Mockito.anyString())).thenReturn(validateResponse);
		Mockito.when(service1.initiateASHICase( Mockito.any())).thenThrow(new CustomException());

		String json=super.mapToJson(new GenModel("Initiate Case", "", new ArrayList<>(), new ArrayList<>()));
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/mobilesubmitcase").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8).content(json);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void getDPStatusPositiveTest1() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, "", "", "true");
		DPServiceOutput objReturned=new DPServiceOutput("true");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getDPStatusPositiveTest2() throws Exception{
		Response objExpected = new Response(Message.SUCCESS, "", "", "false");
		DPServiceOutput objReturned=new DPServiceOutput("false");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getDPStatusPositiveTest3() throws Exception{
		Response objExpected = new Response(Message.ERROR, Message.NOACCESS);
		DPServiceOutput objReturned=new DPServiceOutput("NA");

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenReturn(objReturned);
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getDPStatusNegativeTest() throws Exception{
		Response objExpected=new Response(Message.ERROR,Message.SOMEERROROCCURED);

		Mockito.when(webservice.dpService(Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/dpstatus").header("Authorization", "Bearer "+token);


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual=super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getInboxInitiatedByGRBPositiveTest1() throws Exception {
		List<MobileRow> rowList = new ArrayList<>();

		rowList.add(new MobileRow(new InboxCaseDetails(1, "01-01-2020", "a", "a"), new ArrayList<>()));
		MobileInboxView objExpected = new MobileInboxView("Tab - Initiated by GRB", "", Constants.INBOXVIEW, rowList);

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbygrb")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MobileInboxView objActual = super.mapFromJson(content, MobileInboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	void getInboxInitiatedByGRBPositiveTest2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.NOCASEFOUND);

		MobileInboxView serviceReturn = new MobileInboxView("Tab - Initiated by GRB", "", Constants.INBOXVIEW, new ArrayList<>());

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbygrb")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getInboxInitiatedByGRBNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getCasesInitiatedByGRB(Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/initiatedbygrb")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getInboxAllCasesPositiveTest1() throws Exception {
		List<MobileRow> rowList = new ArrayList<>();

		rowList.add(new MobileRow(new InboxCaseDetails(1, "01-01-2020", "a", "a"), new ArrayList<>()));
		MobileInboxView objExpected = new MobileInboxView("Tab - All", "", Constants.INBOXVIEW, rowList);

		Mockito.when(service.getAllCases(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/all")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MobileInboxView objActual = super.mapFromJson(content, MobileInboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	void getInboxAllCasesPositiveTest2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.NOCASEFOUND);

		MobileInboxView serviceReturn = new MobileInboxView("Tab - All", "", Constants.INBOXVIEW, new ArrayList<>());

		Mockito.when(service.getAllCases(Mockito.anyString())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/all")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getInboxAllCasesNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getAllCases(Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/all")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getInboxInitiatedByCocomplainantPositiveTest1() throws Exception {
		List<MobileRow> rowList = new ArrayList<>();
		List<MobileInboxAction> actions = Arrays.asList(
				(new MobileInboxAction(Constants.CASE_ID, "GET", "",
						"Are you sure you want to be tagged as a co-complainant?")),
				(new MobileInboxAction(Constants.CASE_ID, "GET", "", "No")));
		rowList.add(new MobileRow(new InboxCaseDetails(1, "01-01-2020", "a", "a"), actions));
		MobileInboxView objExpected = new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, rowList);

		Mockito.when(service.getCasesInitiatedByCoComplainant(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/cocomplainant")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		MobileInboxView objActual = super.mapFromJson(content, MobileInboxView.class);

		assertEquals(objExpected.getName(), objActual.getName());
		assertEquals(objExpected.getRow().size(), objActual.getRow().size());
	}
	
	@Test
	void getInboxInitiatedByCocomplainantPositiveTest2() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.NOCASEFOUND);

		MobileInboxView serviceReturn = new MobileInboxView("Tab - As a Co-complainant", "", Constants.INBOXVIEW, new ArrayList<>());

		Mockito.when(service.getCasesInitiatedByCoComplainant(Mockito.anyString())).thenReturn(serviceReturn);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/cocomplainant")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}

	@Test
	void getInboxInitiatedByCocomplainantNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getCasesInitiatedByCoComplainant(Mockito.anyString())).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinbox/cocomplainant")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	@Test
	void getInboxTabsPositiveTest() throws Exception {
		List<TabView> objExpected = new ArrayList<>();
		objExpected.add(new TabView("All", "service url"));

		Mockito.when(service.getInboxTabs()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinboxtabs")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<TabView> objActual = super.mapFromJsonList(content, TabView.class);

		assertEquals(objExpected.size(), objActual.size());
		assertEquals(objExpected.get(0).getName(), objActual.get(0).getName());
		assertEquals(objExpected.get(0).getValue(), objActual.get(0).getValue());
	}

	@Test
	void getInboxTabsNegativeTest() throws Exception {
		Response objExpected = new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(service.getInboxTabs()).thenThrow(new CustomException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/mobile/myinboxtabs")
				.header("Authorization", "Bearer " + token);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);

		String content = result.getResponse().getContentAsString();

		Response objActual = super.mapFromJson(content, Response.class);

		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());	
	}
	
	

}
