package com.infosys.reach.service;

import java.util.List;

import com.infosys.reach.model.common.FileGenerationServiceResponse;
import com.infosys.reach.model.generic.DocumentData;

public interface FileGenerationService {

	public FileGenerationServiceResponse pdfGenerator(String tempStoragePath,String targetFileName,String letterContent);
	
	public FileGenerationServiceResponse addAttachmentsToPDF(String tempStoragePath, String sourceFileName, String targetFileName, List<DocumentData> attachments);
}
