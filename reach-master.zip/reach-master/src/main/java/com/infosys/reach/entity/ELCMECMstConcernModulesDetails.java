package com.infosys.reach.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmecmstconcernmodulesdetails")
public class ELCMECMstConcernModulesDetails {

	@Id
	@Column(name="intconcernid")
	private int concernId;
	
	@Column(name="intparentid")
	private int moduleId;
	
	@Column(name="txtconcern")
	private String concern;
	
	@Column(name="txtconcerndesc")
	private String concernDesc;
	
	@Column(name="txtcompany")
	private String company;
	
	@Column(name="txtcountrycode")
	private String countryCode;
}
