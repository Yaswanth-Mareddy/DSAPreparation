package com.infosys.reach.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="elcmectrnreachcountrydetails")
public class ELCMECTrnReachCountryDetails {

	@Id
	@Column(name="intmoduleid")
	private int moduleId;
	
	@Column(name="txtcountrycode")
	private String countryCode;
	
	@Column(name="txtcountryname")
	private String countryName;
	
	@Column(name="flgenable")
	private int isEnable;
}
