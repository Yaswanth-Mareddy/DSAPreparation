package com.infosysit.rctmscompliance;

import static org.junit.Assert.assertEquals;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.ComplianceInbox;
import com.infosysit.rctmscompliance.service.ComplianceDetailsServiceImp;
import com.infosysit.rctmscompliance.service.ComplianceInboxServiceImp;

public class ControllerTests extends AbstractTest {

	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(),
			MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));

	private String token;

	@MockBean
	ComplianceDetailsServiceImp service;
	
	@MockBean 
	ComplianceInboxServiceImp serviceInbox;

	@Override
	@Before
	public void setUp() {
		super.setUp();
		token="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6IjVPZjlQNUY5Z0NDd0NtRjJCT0hIeEREUS1EayIsImtpZCI6IjVPZjlQNUY5Z0NDd0NtRjJCT0hIeEREUS1EayJ9.eyJhdWQiOiJiMTg3NDYyNy1lMzlkLTQ5NzYtYjM3MC1hMGVlN2UzODNhMjQiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC82M2NlN2Q1OS0yZjNlLTQyY2QtYThjYy1iZTc2NGNmZjVlYjYvIiwiaWF0IjoxNjEwMDAwMTYyLCJuYmYiOjE2MTAwMDAxNjIsImV4cCI6MTYxMDAwNDA2MiwiYWNyIjoiMSIsImFpbyI6IkFYUUFpLzhTQUFBQWZZMTdyS20yUDR3b1IyZWcvb0F4U3lCV09PQk1VL0xzOGhxdFUrMVVBUmZDOTBjZ3Nnc0VGRVdsMTdlVlVEa1JlQnlFTXhqTC9ha3NLZngxNFVjNENLWWhOcnkwcFVBeVBUV3c5ZWExZEFESEdsZXpmbDFFUmVEUENVbVpVbXlVTGRrbklkZW9HR3Jobmxxb1h4TTJ5dz09IiwiYW1yIjpbIndpYSIsIm1mYSJdLCJhcHBpZCI6ImIxODc0NjI3LWUzOWQtNDk3Ni1iMzcwLWEwZWU3ZTM4M2EyNCIsImFwcGlkYWNyIjoiMSIsImRldmljZWlkIjoiZTY0YzBlNjItNTNlMy00ZDE5LTkzZDYtYWMyMTE5ZmVkYWIyIiwiZmFtaWx5X25hbWUiOiJQYXRoYWsiLCJnaXZlbl9uYW1lIjoiU2h1YmhhbSIsImlwYWRkciI6IjE3MS43Ni4xMzguMTMiLCJuYW1lIjoiU2h1YmhhbSBQYXRoYWsiLCJvaWQiOiJlNWZhYjk3ZS02YzFhLTQ5ODItYTdmNi0wNGE4NmU3ZGM4MjkiLCJvbnByZW1fc2lkIjoiUy0xLTUtMjEtMjY2NzQ5OTQwLTE2Mzc5NjQ0NDQtOTI5NzAxMDAwLTM1NzY5MDMiLCJyaCI6IjAuQVFZQVdYM09ZejR2elVLb3pMNTJUUDlldGlkR2g3R2Q0M1pKczNDZzduNDRPaVFHQU5zLiIsInNjcCI6IlVzZXIuUmVhZCIsInN1YiI6Inc3aGxsWU81UHh5N0RQWWJ5ZFB0TEZyM3EtcjJzeHFhQmVqVDJqRU9FRWciLCJ0aWQiOiI2M2NlN2Q1OS0yZjNlLTQyY2QtYThjYy1iZTc2NGNmZjVlYjYiLCJ1bmlxdWVfbmFtZSI6InNodWJoYW0ucGF0aGFrMDJAYWQuaW5mb3N5cy5jb20iLCJ1cG4iOiJzaHViaGFtLnBhdGhhazAyQGFkLmluZm9zeXMuY29tIiwidXRpIjoiSTdTVG5oa096VUNzQjh0eXZENEhBZyIsInZlciI6IjEuMCIsIkVtcE5vIjoiMTAyNzgyMiJ9.cMb0m9PDZOZMWI6uFVDRcH5gZqFEFX0a0LMXfPfQC8_Am-vItfHtf5z3DhCFiDKiHoLGZSY-x9pWgccYPNCCbOehLo5CpmgjXQgTVIK2PgAB3msdSlvhC8b_0nMS5HaV913M68U8INpf2nHHjggQH9f-itJQDbTLoXto9u7SKXcFSbVeOdFnjkq9VoGDcgCoomiZml9fjCLIqV8mvxTQQ5GOCwHUWk18x__5aBn1Gw-Ikbt1YImAGfS97nTQ-scMM1lKy9r2wHsyTMeFdzqO2nl2DYeiVqfkcvi7gZnlyZT0V05e7-HeGzNcyJuo5I93WKo2visrIQ46ypwspXs3Ig";
	}
	
	@Test
	public void getComplianceInboxDetailsNegativeTestCase() throws Exception {

		//GenModel objExpected = new GenModel("name", "", "", new ArrayList<>(), new ArrayList<>());
		//List<ComplianceInbox> objExpected= new ArrayList<>();
		String objExpected = "\"Bad Request\"";
		Mockito.when(serviceInbox.viewComplianceInbox(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenThrow(new CustomException());
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		  params.add("txtStatus", "All");
		  params.add("txtpendingstatus", "Pending with me");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/rctms/compliance/getAllComplianceInboxForUser")
				.header("Authorization", "Bearer " + token).queryParams(params);

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(400, status);
		String objActual = super.mapToJson(objExpected);
		assertEquals(objExpected.substring(1, 11), objActual.substring(3, 13));
	}
	
	@Test
	public void getComplianceInboxDetailsPositiveTestCase() throws Exception {

		//GenModel objExpected = new GenModel("name", "", "", new ArrayList<>(), new ArrayList<>());
		List<ComplianceInbox> objExpected= new ArrayList<>();
		ComplianceInbox objInbox=new ComplianceInbox();
		objInbox.setTxtComplianceName("Dev env1");
		objExpected.add(objInbox);
		Mockito.when(serviceInbox.viewComplianceInbox(Mockito.anyString(), Mockito.anyString(),Mockito.anyString())).thenReturn(objExpected);
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
		  params.add("txtStatus", "All");
		  params.add("txtpendingstatus", "Pending with me");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/rctms/compliance/getAllComplianceInboxForUser")
				.header("Authorization", "Bearer " + token).queryParams(params);

		MvcResult result = mvc.perform(request).andReturn();
		int status = result.getResponse().getStatus();
		assertEquals(200, status);
		
		String content = result.getResponse().getContentAsString();
		List<ComplianceInbox> objActual = super.mapFromJsonList(content, ComplianceInbox.class);
		assertEquals(objExpected.get(0).getTxtComplianceName(), objActual.get(0).getTxtComplianceName());
	}

}
