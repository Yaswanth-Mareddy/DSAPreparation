package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECMstConcernModulesDetails;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstConcernModulesDetailsRepository extends JpaRepository<ELCMECMstConcernModulesDetails, Integer> {
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCONCERNDETAILSBYTWOPARAMS)
	List<Categories> findDistinctByModuleIdAndCompany(@Param("moduleId") int moduleId,@Param("company") String company);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCONCERNDETAILSBYTHREEPARAMS)
	List<Categories> findDistinctByModuleIdAndCompanyAndCountryCode(@Param("moduleId") int moduleId,@Param("company") String company,@Param("countryCode")String countryCode);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCATEGORYBYCASEID)
	String findCategoryByCaseId(@Param("caseId") int caseId);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETASHICATEGORIES)
	List<GenModelOption> findASHICategories(@Param("moduleId") int moduleId,@Param("company") String company,@Param("countryCode")String countryCode);
	
	Optional<ELCMECMstConcernModulesDetails> findByModuleIdAndConcernIdAndCompanyAndCountryCode(int module, int concernId, String company, String countryCode);

}
 