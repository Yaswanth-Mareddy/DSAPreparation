package com.infosysit.rctmscompliance.repo.read;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSTrnComplianceInstance;
import com.infosysit.rctmscompliance.entity.ComplianceInstanceCompPKey;
import com.infosysit.rctmscompliance.model.OldAssigneeRem;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSTrnComplianceInstanceRepoRead extends JpaRepository<CMSTrnComplianceInstance, ComplianceInstanceCompPKey>{

	@Query(value="select comp.compPKey.intComplianceID from CMSTrnComplianceInstance comp "
			+ "where comp.compPKey.intComplianceID = :intComplianceID and comp.compPKey.dtAssignedDate = :dtAssignedDate")
	String findComplianceId(@Param("intComplianceID") int intComplianceID, @Param("dtAssignedDate") String dtAssignedDate);
	
	@Query(value="select CI.intNoOfCycles from CMSTrnComplianceInstance as CI where CI.compPKey.intComplianceID= :intComplianceID and CI.compPKey.dtAssignedDate= :dtAssignedDate")
	int getNoOfCycle(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);

	@Query(value="select CI.intEscalatedLevel from CMSTrnComplianceInstance as CI where CI.compPKey.intComplianceID= :intComplianceID and CI.compPKey.dtAssignedDate= :dtAssignedDate")
	int getEscalationLevel(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
	
	@Query(value=CustomQueries.GETOLDASSIGNEEREM)
	OldAssigneeRem getOldAssigneeRem(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
	
	@Query(value=CustomQueries.GETCOMPISWITH)
	String getPendingWith(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
}
