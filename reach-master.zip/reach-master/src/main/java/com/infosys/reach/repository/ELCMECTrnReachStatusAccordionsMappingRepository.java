package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECTrnReachStatusAccordionsMapping;
import com.infosys.reach.model.common.AccordionModel;
import com.infosys.reach.util.QueryConstants;

public interface ELCMECTrnReachStatusAccordionsMappingRepository extends JpaRepository<ELCMECTrnReachStatusAccordionsMapping, Integer> {

	@Query(value = QueryConstants.GETACCORDIONSBYMODULEIDANDCASESTATUS)
	List<AccordionModel> findAccordionsByModuleIdAndStatus(@Param("moduleId") int moduleId, @Param("status") String status);
}
