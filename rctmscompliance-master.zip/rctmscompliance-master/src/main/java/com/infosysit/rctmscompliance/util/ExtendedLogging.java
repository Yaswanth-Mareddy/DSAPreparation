package com.infosysit.rctmscompliance.util;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ExtendedLogging {

	@Value("${extendedlogging}")
	private boolean isExtendedlogging;
	
	Logger logger=LoggerFactory.getLogger(ExtendedLogging.class);
	
	public void log(String message) {
		if(isExtendedlogging)
			logger.info(message);
	}
	
	public void log(Exception e) {
		if(isExtendedlogging)
			logger.info("Exception : {} at {}",e.getMessage(),Arrays.asList(e.getStackTrace()).stream().filter(a -> a.getClassName().contains("com.infosys.reach")).findFirst());
	}
	
	public void log(String methodname,Object... params) {
		StringBuilder message=new StringBuilder(methodname).append(" { ");
		if(isExtendedlogging) {
			for(int i=0;i<params.length;i++) {
				message.append(params[i]);
				message.append(i%2==0?" = ":", ");
			}
			message.replace(message.length()-2, message.length(), " }");
		}
		String msg=message.toString();
			logger.info(msg);
	}
	
	public void log(String methodname, Object inputbody) {
		String message=new StringBuilder(methodname).append(" ").append(inputbody.toString()).toString();
		if(isExtendedlogging)
			logger.info(message);
	}
}

