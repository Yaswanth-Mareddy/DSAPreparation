package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstescalationdetails")
public class CMSMstEscalationDetails {
	
	@EmbeddedId
	EscalationDetailsCompPKey compId;
	
	@Column(name="intescalationinterval")
	private int intEscalationInterval;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;
}
