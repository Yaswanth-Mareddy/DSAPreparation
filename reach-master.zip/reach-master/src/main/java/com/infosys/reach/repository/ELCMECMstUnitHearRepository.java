package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.infosys.reach.entity.ELCMECMstUnitHear;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstUnitHearRepository extends JpaRepository<ELCMECMstUnitHear, String> {
	
	@TrackExecutionTime
	@Query(value="select emailId from ELCMECMstUnitHear where unit='CH'")
	List<String> findUnitHearMailIds();
}
