package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.GENMstCity;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface GENMstCityRepository extends JpaRepository<GENMstCity, String> {
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCITIES)
	List<Cities> getCitiesByCountryCode(@Param("countryCode") String countryCode);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETASHICITIES)
	List<GenModelOption> getCitiesByCountryCodeNew(@Param("country") String country);
}
