package com.infosys.reach;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.nio.charset.Charset;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.service.WebServiceImpl;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;

public class WebServiceTests extends AbstractTest{
	
	public static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	@MockBean
	ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;
	
	@MockBean
	Property property;
	
//	@MockBean
//	CommonServiceImpl commonservice;
	
	@Autowired
	WebServiceImpl webservice;
	
	
	@Override
	@Before
	public void setUp() {
		super.setUp();
		}
	
	
	@Test
	public void dmsServiceTest1() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(ashiActionDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHIActionDetails(1, "CIN", "cabhiajb", "WE", "file.pdf", "1030816", null)));
		Mockito.when(property.getDmsDownloadURL()).thenReturn("https://isgatewaytst.ad.infosys.com/pfapis/dmsdwn/dmsdownload/document");
		Mockito.when(property.getDmsASHICaseDocFolder()).thenReturn("ASHI/Case Docs/");
		Mockito.when(property.getDmsApplicationName()).thenReturn("EMPCON");
		Mockito.when(property.getDmsApplicationID()).thenReturn("ecf66ecd-5b0d-4f34-8e1e-6db24ea4fbd1");
		Mockito.when(property.getDmsStorageURL()).thenReturn("http://172.25.105.219/sites/EmployeeConcerns/");
		Mockito.when(property.getDmsDocumentPath()).thenReturn("Employee Concerns/");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", "file.pdf");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void dmsServiceTest2() throws Exception{
		Response objExpected=new Response(Message.ERROR, Message.SOMEERROROCCURED);

		Mockito.when(ashiActionDetailsRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(new ELCMECTrnASHIActionDetails(1, "CIN", "cabhiajb", "WE", "file.pdf", "1030816", null)));
		
		Mockito.when(property.getDmsDownloadURL()).thenReturn("abc");
		
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/downloadfiles").header("Authorization", "Bearer "+token).param("type", "A").param("transactionid", "123").param("filename", "file.pdf");


		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Response> objActual=super.mapFromJsonList(content, Response.class);

		assertEquals(objExpected.getType(), objActual.get(0).getType());
		assertEquals(objExpected.getContent(), objActual.get(0).getContent());
	}
	
	@Test
	public void getOptionsByContextAndRolePositiveTest() throws Exception{
		
		Mockito.when(property.getCamsContextURL()).thenReturn("http://10.82.5.132:8928/api/Contexts");
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/admin/context/options").header("Authorization", "Bearer "+token)
				.param("context", "Location").param("role","IC");

		MvcResult result = mvc.perform(request).andReturn();

		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<GenModelOption> objActual=super.mapFromJsonList(content, GenModelOption.class);

		assertFalse(objActual.isEmpty());
	}
	
	
	@Test
	public void fileValidatorServiceTest1() throws CustomException {
		//Give path of a jpg file if this test is failing
		String filepath = "D:\\Reference docs\\Documents\\Proxy setting.JPG";
		
		boolean actual = webservice.filevalidationService("http://10.82.5.92:9701/filevalidator/validatefile?appcode=Reach&context=Reach_AFC", filepath);
		
		assertTrue(actual);
	}
	
	@Test
	public void fileValidatorServiceTest2() throws CustomException {
		assertThrows(CustomException.class, () -> webservice.filevalidationService("http://10.82.5.92:9701/filevalidator/validatefile?appcode=Reach&context=Reach_AFC", ""));

	}
	

}
