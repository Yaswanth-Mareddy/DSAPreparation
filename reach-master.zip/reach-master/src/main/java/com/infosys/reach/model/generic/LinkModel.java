package com.infosys.reach.model.generic;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class LinkModel {

	private String moduleName;
	private String moduleDescription;
	private List<Link> links;	
	
}
