package com.infosys.reach.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECtrnASHIConcernSLADetails;

public interface ELCMECtrnASHIConcernSLADetailsRepository
		extends JpaRepository<ELCMECtrnASHIConcernSLADetails, Integer> {
	
	Optional<ELCMECtrnASHIConcernSLADetails> findByCaseIdAndRole(int caseId, String role);

}
