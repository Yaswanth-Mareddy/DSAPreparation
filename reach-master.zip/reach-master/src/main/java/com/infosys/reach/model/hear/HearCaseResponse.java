package com.infosys.reach.model.hear;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class HearCaseResponse {

	private int caseId;
	private String message;
}
