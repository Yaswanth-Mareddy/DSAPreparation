package com.infosys.reach.entity;


import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name="hrismstemployee")
public class HRISMstEmployee {

	@Id
	@Column(name="txtempno")
	private String empNo;
	
	@Column(name="txtempname")
	private String empName;
	
	@Column(name="txtcurrentemppsb")
	private String empBandCode;
	
	@Column(name="dtjoineddate")
	private Date joinedDate;
	
	@Column(name="txtcompany")
	private String company;
	
	@Column(name="txtconfirmed")
	private String confirmedStatus;
	
	@Column(name="txtcurrentrolecapability")
	private String currentRoleCapability;
}
