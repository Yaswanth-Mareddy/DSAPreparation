package com.infosys.reach;

import static org.junit.Assert.assertEquals;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.hear.CaseDetailsValidationResponse;
import com.infosys.reach.model.hear.Categories;
import com.infosys.reach.model.hear.Cities;
import com.infosys.reach.model.hear.ConcernDetailsInput;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.model.hear.HearAccess;
import com.infosys.reach.model.hear.HearCaseDetails;
import com.infosys.reach.model.hear.HearCaseResponse;
import com.infosys.reach.model.hear.Policy;
import com.infosys.reach.model.hear.SubmitCaseOutput;
import com.infosys.reach.service.HearServiceImpl;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;

class HearControllerTests extends AbstractTest{

	static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	private Response exceptionResponse = new Response(Message.SOMEERROROCCURED);
	@MockBean
	HearServiceImpl service;
	
	@Override
	@BeforeEach
	public void setUp() {
	    super.setUp();

	}
	

	@Test
	void getCategoriesPositiveTest() throws Exception{
		List<Categories> objExpected=new ArrayList<>();
		objExpected.add(new Categories(3, 11, "Others", "Others", "INFSYS", "IN"));
		Mockito.when(service.getConcernModuleDetails(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(objExpected);
		
		String json=super.mapToJson(new ConcernDetailsInput(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/categorydisplay").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();

		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Categories> objActual=super.mapFromJsonList(content, Categories.class);
		
		assertEquals(objExpected.get(0).getConcernId(), objActual.get(0).getConcernId());
	}
	
	@Test
	void getCategoriesNegativeTest() throws Exception{
		Response objExpected=new Response(Message.NO_DATA_FOUND);
		
		Mockito.when(service.getConcernModuleDetails(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(new ArrayList<>());
		
		String json=super.mapToJson(new ConcernDetailsInput(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/categorydisplay").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void getCategoriesExceptionTest() throws Exception{
		
		Mockito.when(service.getConcernModuleDetails(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString())).thenReturn(null);
		
		String json=super.mapToJson(new ConcernDetailsInput(Mockito.anyInt(), Mockito.anyString(), Mockito.anyString()));

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/categorydisplay").header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(exceptionResponse.getType(), objActual.getType());
		assertEquals(exceptionResponse.getContent(), objActual.getContent());
	}
	
	@Test
	void initiateHearCasePositiveTest() throws Exception{
		HearCaseResponse objExpected = new HearCaseResponse(7, "Done! Your appeal is submitted under \"Discrimination / Harassment\" category with id 7.");
		HearCaseDetails caseDetails=new HearCaseDetails(3, 11, "", "", "Test", "pavankumar_ga", "pavankumar_ga", 1, 1, 1, "", "", "", "india", "pune", 0);
		CaseDetailsValidationResponse validationObj=new CaseDetailsValidationResponse(true, "Test");
		validationObj.setTaggedEmpMailIdList(new ArrayList<>());
		validationObj.setCaseDetails(caseDetails);
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(validationObj);

		Mockito.when(service.initiateHearCase(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyList())).thenReturn(objExpected);

		String json=super.mapToJson(caseDetails);

		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/employee/submitcase")
								.header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);					   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);

		
		String content = result.getResponse().getContentAsString();
		
		SubmitCaseOutput objActual = super.mapFromJson(content, SubmitCaseOutput.class);
		assertEquals(objExpected.getCaseId(), objActual.getCaseid());
		assertEquals(objExpected.getMessage(), objActual.getMessage());
		assertEquals("SUCCESS", objActual.getStatus());
		
	}
	
	@Test
	void initiateHearCaseNegativeTest()throws Exception{

		HearCaseDetails caseDetails=new HearCaseDetails(3, 11, "1030910", "1030900", "Test", "pavankumar_ga", "pavankumar_ga", 0, 0, 0, "test", "test", "test", "india", "pune", 0);
		CaseDetailsValidationResponse validationObj=new CaseDetailsValidationResponse(false, "Test");
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(validationObj);
		
		String json=super.mapToJson(caseDetails);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/employee/submitcase")
								.header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);;
													   		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);
	
		String content = result.getResponse().getContentAsString();
		
		SubmitCaseOutput objActual = super.mapFromJson(content, SubmitCaseOutput.class);
		
		assertEquals(0, objActual.getCaseid());
		assertEquals(Constants.FAILURE.trim(), objActual.getStatus());
	}
	
	@Test
	void initiateHearCaseExceptionTest()throws Exception{
		SubmitCaseOutput expectedObj = new SubmitCaseOutput(0,Message.SOMETHING_WENT_WRONG,Constants.FAILURE);
		HearCaseDetails caseDetails=new HearCaseDetails(3, 11, "", "", "Test", "pavankumar_ga", "pavankumar_ga", 1, 1, 1, "", "", "", "india", "pune", 0);
		CaseDetailsValidationResponse validationObj=new CaseDetailsValidationResponse(true, "Test");
		validationObj.setTaggedEmpMailIdList(new ArrayList<>());
		validationObj.setCaseDetails(caseDetails);
		Mockito.when(service.validateCaseDetails(Mockito.anyString(), Mockito.anyString(), Mockito.any())).thenReturn(validationObj);

		Mockito.when(service.initiateHearCase(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(), Mockito.anyList())).thenThrow(new CustomException("Exception"));
		
		String json=super.mapToJson(caseDetails);
		
		RequestBuilder request = MockMvcRequestBuilders.post("/v2/api/employee/submitcase")
								.header("Authorization", "Bearer "+token).contentType(APPLICATION_JSON_UTF8)
					            .content(json);;
													   		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
	
		String content = result.getResponse().getContentAsString();
		
		SubmitCaseOutput objActual = super.mapFromJson(content, SubmitCaseOutput.class);
		
		assertEquals(expectedObj.getCaseid(), objActual.getCaseid());
		assertEquals(expectedObj.getStatus(), objActual.getStatus());
		assertEquals(expectedObj.getMessage(), objActual.getMessage());
	}
	
	@Test
	void getCountriesByModuleIdPositiveTest()throws Exception{
		List<Countries> objExpected=new ArrayList<>();
		objExpected.add(new Countries("IN", "INDIA", 3));
		Mockito.when(service.getCountriesByModuleId(Mockito.anyInt())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/countriesbymoduleid").param("moduleId", "3").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Countries> objActual=super.mapFromJsonList(content, Countries.class);
		
		assertEquals(objExpected.get(0).getCountryCode(), objActual.get(0).getCountryCode());
	}
	
	@Test
	void getCountriesByModuleIdNegativeTest()throws Exception{
		Response objExpected=new Response("No country found.");

		Mockito.when(service.getCountriesByModuleId(Mockito.anyInt())).thenReturn(new ArrayList<>());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/countriesbymoduleid").param("moduleId", "3").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void getCountriesByModuleIdExceptionTest()throws Exception{

		Mockito.when(service.getCountriesByModuleId(Mockito.anyInt())).thenReturn(null);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/countriesbymoduleid").param("moduleId", "3").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(exceptionResponse.getType(), objActual.getType());
		assertEquals(exceptionResponse.getContent(), objActual.getContent());
	}
	
	@Test
	void getCitiesByCountryCodePositiveTest()throws Exception{
		List<Cities> objExpected=new ArrayList<>();
		objExpected.add(new Cities(1, "RAJNANDGAON"));
		Mockito.when(service.getCitiesByCountryCode(Mockito.anyString())).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/locationbasedoncountry").param("countryCode", "IN").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		List<Cities> objActual=super.mapFromJsonList(content, Cities.class);
		
		assertEquals(objExpected.get(0).getCity(), objActual.get(0).getCity());
	}
	
	@Test
	void getCitiesByCountryCodeNegativeTest()throws Exception{
		Response objExpected=new Response("No city found.");
		Mockito.when(service.getCitiesByCountryCode(Mockito.anyString())).thenReturn(new ArrayList<>());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/locationbasedoncountry").param("countryCode", "IN").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(objExpected.getType(), objActual.getType());
		assertEquals(objExpected.getContent(), objActual.getContent());
	}
	
	@Test
	void getCitiesByCountryCodeExceptionTest()throws Exception{
		Mockito.when(service.getCitiesByCountryCode(Mockito.anyString())).thenReturn(null);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/locationbasedoncountry").param("countryCode", "IN").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(exceptionResponse.getType(), objActual.getType());
		assertEquals(exceptionResponse.getContent(), objActual.getContent());
	}
	
	@Test
	void getHearModulePolicyPositiveTest()throws Exception{
		Policy objExpected=new Policy();

		Mockito.when(service.getHearPolicy()).thenReturn(objExpected);

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/policy").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		assertEquals(200, status);

		String content = result.getResponse().getContentAsString();

		Policy objActual=super.mapFromJson(content, Policy.class);
		
		assertEquals(objExpected.getHearModulePolicy(), objActual.getHearModulePolicy());
	}
	
	@Test
	void getHearModulePolicyExceptionTest()throws Exception{

		Mockito.when(service.getHearPolicy()).thenThrow(new RuntimeException());

		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/policy").header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(exceptionResponse.getType(), objActual.getType());
		assertEquals(exceptionResponse.getContent(), objActual.getContent());
	}
	
	@Test
	void CheckHearAccessPositiveTest()throws Exception{
		HearAccess objExpected = new HearAccess(true,"");
		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/employee/checkaccess")
								.header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);

		
		String content = result.getResponse().getContentAsString();
		
		HearAccess objActual = super.mapFromJson(content, HearAccess.class);
		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}
	
	@Test
	void CheckHearAccessNegativeTest()throws Exception{
		HearAccess objExpected = new HearAccess(false,"");
		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(objExpected);
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/employee/checkaccess")
								.header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(200, status);

		
		String content = result.getResponse().getContentAsString();
		
		HearAccess objActual = super.mapFromJson(content, HearAccess.class);
		assertEquals(objExpected.isHasAccess(), objActual.isHasAccess());
	}
	
	@Test
	void CheckHearAccessExceptionTest()throws Exception{
		Mockito.when(service.checkHearAccess(Mockito.anyString())).thenReturn(null);
		RequestBuilder request = MockMvcRequestBuilders.get("/v2/api/employee/checkaccess")
								.header("Authorization", "Bearer "+token);
													   
		
		MvcResult result = mvc.perform(request).andReturn();
		
		int status = result.getResponse().getStatus();
		
		assertEquals(400, status);
		String content = result.getResponse().getContentAsString();		
		Response objActual = super.mapFromJson(content, Response.class);
		assertEquals(exceptionResponse.getType(), objActual.getType());
		assertEquals(exceptionResponse.getContent(), objActual.getContent());
	}

}
