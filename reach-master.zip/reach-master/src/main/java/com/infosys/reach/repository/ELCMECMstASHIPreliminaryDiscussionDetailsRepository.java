package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.infosys.reach.entity.ELCMECMstASHIPreliminaryDiscussionDetails;
import com.infosys.reach.model.ashiadmin.PreliminaryDiscussionDetails;
import com.infosys.reach.util.QueryConstants;

@Repository
public interface ELCMECMstASHIPreliminaryDiscussionDetailsRepository  extends JpaRepository<ELCMECMstASHIPreliminaryDiscussionDetails, Integer> {

	
	
	@Query(value=QueryConstants.GETPRELIMINARYDISCUSSIONDETAILS)
	List<PreliminaryDiscussionDetails> findByIntCaseID(@Param("caseId") int caseId);
	
}
