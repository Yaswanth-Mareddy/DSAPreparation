package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosysit.rctmscompliance.entity.ViewCurrEmpAllDetails;
import com.infosysit.rctmscompliance.util.CustomQueries;

public interface ViewCurrEmpAllDetailsRepoRead extends JpaRepository<ViewCurrEmpAllDetails, String> {

	@Query(value = CustomQueries.GETEMPLOYEEMAILID)
	String getEmployeeMailId(@Param("txtEmpNo") String txtEmpNo);
}
