package com.infosys.reach.exception;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ErrorDetails {
	@Override
	public String toString() {
		return "ErrorDetails [createdDate=" + createdDate + ", message=" + message + ", details=" + details + "]";
	}

	private Date createdDate;
	private String message;
	private String details;
	
	
	
	public ErrorDetails(String message) {
		super();
		this.message = message;
	}

	public ErrorDetails(String message,String details) {
		this.createdDate = new Date();
		this.message = message;
		this.details = details;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}
	
	
	
}
