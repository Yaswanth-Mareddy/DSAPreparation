package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ComplianceDetailsForUserDateNotNull {

	private String txtComplianceName;
	private String txtNodeName;
	private String txtDescription;
	private String txtLocationName;
	private String txtGroupName;
	private String txtFrequency;
	private String dtEndDate;
	private int intDaysBeforeStart;
	private int intReminderInterval;
	private String txtAName;
	private String txtVName;
	private String txtOName;
	private String txtStatus;
	private String dtAssignedDate;
	private String dtDueDate;
	private String dtFiledDate;
	private int intEscalatedLevel;
	private String txtAssigneeRemarks;
	private String txtVerifierApprovalRemarks;
	private String txtOwnerRemarks;
	private String txtAttachmentList;
	private String txtVerifierRejectRemark;
	private String txtAssigneeFileRemark;
	private String txtAssigneeAfterRejectRemark;
	private int intNoOfCycles;
	private String txtAttachmentListVerifier;
	private String txtAttachmentListOwner;
	private String txtAttachmentListFile;
	private String dtActualFilingDate;
	private String txtType;
	private String dtEscalatedDate;
	private String txtAssignee;
	private String txtVerifier;
	private String txtOwner;
}
