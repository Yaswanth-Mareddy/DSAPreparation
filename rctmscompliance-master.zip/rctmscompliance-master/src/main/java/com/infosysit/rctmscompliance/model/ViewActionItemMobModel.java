package com.infosysit.rctmscompliance.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
@Setter
public class ViewActionItemMobModel {

	private List<ActionItemMobile> actionItem;
	private List<InputFieldsMob> inputFields;
	
	public ViewActionItemMobModel(List<ActionItemMobile> actionItem,List<InputFieldsMob> inputFields) {
		
		this.actionItem=(actionItem!=null && !actionItem.isEmpty())?new ArrayList<>(actionItem):null;
		this.inputFields=(inputFields!=null && !inputFields.isEmpty())?new ArrayList<>(inputFields):null;
	}
	
	
}
