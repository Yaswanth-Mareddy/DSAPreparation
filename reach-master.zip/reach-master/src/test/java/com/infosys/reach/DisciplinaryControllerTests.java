package com.infosys.reach;

import static org.junit.Assert.assertTrue;

import java.nio.charset.Charset;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;

import com.infosys.reach.service.DisciplinaryServiceImpl;

class DisciplinaryControllerTests extends AbstractTest{

static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(), Charset.forName("utf8"));
	
	@MockBean
	DisciplinaryServiceImpl discService;
	
	@Override
	@BeforeEach
	public void setUp() {
	    super.setUp();
	}
	

	@Test
	void Test() throws Exception{
		
		assertTrue(true);
		
	}

}
