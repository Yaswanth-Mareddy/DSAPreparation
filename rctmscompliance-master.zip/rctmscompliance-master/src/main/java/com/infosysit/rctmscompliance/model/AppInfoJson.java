package com.infosysit.rctmscompliance.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@JsonInclude(value = Include.NON_NULL)
@ToString
public class AppInfoJson {

	@JsonProperty(value="Compliance Name")
	private String compName;
	
	@JsonProperty(value="Compliance Description")
	private String compDesc;
	
	@JsonProperty(value="Due Date")
	private String dtDueDate;
	
	@JsonProperty(value="Escalation Details")
	private String escDetail;
	
	@JsonProperty(value="Assignee Remarks")
	private String assiRemark;
	
	@JsonProperty(value="Verifier Remarks")
	private String veriRemark;
	
	@JsonProperty(value="Verifier Reject Remark")
	private String veriRejRemark;
	
	@JsonProperty(value="Approve_Btn")
	private BtnAction approveBtn;
	
	@JsonProperty(value="Reject_Btn")
	private BtnAction rejectBtn;
}
