package com.infosys.reach.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECTrnConcernActionDetails;

public interface ELCMECTrnConcernActionDetailsRepository extends JpaRepository<ELCMECTrnConcernActionDetails, Integer> {

}
