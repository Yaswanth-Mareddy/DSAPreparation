package com.infosysit.rctmscompliance.service;

import java.util.List;

import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.ActionItemMobile;
import com.infosysit.rctmscompliance.model.AuditParam;
import com.infosysit.rctmscompliance.model.CMSRemarkDTO;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserFinal;
import com.infosysit.rctmscompliance.model.InputFieldsMob;
import com.infosysit.rctmscompliance.model.MobileControlModel;
import com.infosysit.rctmscompliance.model.SubmitAndRejectResponse;
import com.infosysit.rctmscompliance.model.ViewActionItemMobModel;

public interface ComplianceDetailsService {
	
	public ComplianceDetailsForUserFinal getComplianceDetailsForUser(int intComplianceID,String dtAssignedDate) throws CustomException;
	public int getComplianceID(String txtComplianceName) throws CustomException;
	public int createAudit(AuditParam param) throws CustomException;
	public void updateAudit(int intAuditID,String txtStatus) throws CustomException;
	public SubmitAndRejectResponse submitAssigneeRemark(CMSRemarkDTO remark) throws CustomException;
	public SubmitAndRejectResponse submitVerifierRemark(CMSRemarkDTO remark) throws CustomException;
	public SubmitAndRejectResponse submitVerifierRejectRemark(CMSRemarkDTO remark) throws CustomException;
	public SubmitAndRejectResponse submitOwnerRemark(CMSRemarkDTO remark) throws CustomException;
	public String returnCurrentDate() throws CustomException;
	public InputFieldsMob populateInputFieldsModel(String txtPlaceholder, MobileControlModel control,List<String> optionsList,boolean isNoticePresent,String data) throws CustomException;
	public ViewActionItemMobModel getActionItemDetails(int intActionItemId) throws CustomException;
	public List<String> getReason(String txtFinding) throws CustomException;
	public String trimData(String data) throws CustomException;
	public MobileControlModel isTextBoxVisible(MobileControlModel control,String data)throws CustomException;
	public MobileControlModel isActionItemDropDownVisible(MobileControlModel control,boolean isNoticePresent) throws CustomException;
	public String getPlaceHolder(String value) throws CustomException;
	public List<ActionItemMobile> getButtonsForViewActionItem(String status, String assignee,String owner)throws CustomException;
	public boolean checkIfActionItemExists(int intActionItemId)throws CustomException;
	public String getActionItemLatestComments(String comment) throws CustomException;
	public String attachTimeStampAndPrevComments(String newComment,String oldComment) throws CustomException;
	public String returnRemarkStampDate() throws CustomException;
}
