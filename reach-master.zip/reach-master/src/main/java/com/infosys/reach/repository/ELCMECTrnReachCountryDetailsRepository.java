package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECTrnReachCountryDetails;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.hear.Countries;
import com.infosys.reach.util.QueryConstants;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECTrnReachCountryDetailsRepository extends JpaRepository<ELCMECTrnReachCountryDetails, Integer> {
	@TrackExecutionTime
	@Query(value=QueryConstants.GETCOUNTRIES)
	List<Countries> findDistinctByModuleIdAndIsEnable(@Param("moduleId") int moduleId,@Param("isEnable") int isEnable);
	
	@TrackExecutionTime
	@Query(value=QueryConstants.GETASHICOUNTRIES)
	List<GenModelOption> findDistinctByModuleIdAndIsEnableNew(@Param("moduleId") int moduleId,@Param("isEnable") int isEnable);

}
