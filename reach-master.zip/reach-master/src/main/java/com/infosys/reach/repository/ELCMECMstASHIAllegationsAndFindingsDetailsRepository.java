package com.infosys.reach.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.infosys.reach.entity.ELCMECMstASHIAllegationsAndFindingsDetails;
import com.infosys.reach.model.ashiadmin.Findings;
import com.infosys.reach.util.QueryConstants;

public interface ELCMECMstASHIAllegationsAndFindingsDetailsRepository
		extends JpaRepository<ELCMECMstASHIAllegationsAndFindingsDetails, Integer> {

	@Query(value = QueryConstants.GETFINDINGSBYCASEIDANDACTORANDMAILID)
	List<Findings> findByCaseIdAndActorAndMailId(@Param("caseId") int caseid, @Param("actor") String actor, @Param("mailId") String mailId);
	
	@Query(value = QueryConstants.GETFINDINGSANDASSIGNEELOCATIONBYCASEIDANDACTORANDMAILID)
	List<Findings> findFindingsByCaseIdAndActorAndMailId(@Param("caseId") int caseid, @Param("actor") String actor, @Param("mailId") String mailId);
	
	List<ELCMECMstASHIAllegationsAndFindingsDetails> findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(int caseid);
	
	List<ELCMECMstASHIAllegationsAndFindingsDetails> findBySerialNoIn(List<Integer> serialNos);

}
