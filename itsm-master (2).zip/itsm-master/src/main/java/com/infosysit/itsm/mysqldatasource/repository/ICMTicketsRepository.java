package com.infosysit.itsm.mysqldatasource.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.infosysit.itsm.model.ISLeapTicket;
import com.infosysit.itsm.mysqldatasource.entity.ICMTickets;
import com.infosysit.itsm.util.QueryConstants;

public interface ICMTicketsRepository extends JpaRepository<ICMTickets, Integer> {
	
	@Query(value=QueryConstants.GETICMOPENTICKETSDETAILS)
	List<ISLeapTicket> getIcmOpenTickets();
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSUSINGNUMBER)
	void updateIcmTicketsUsingNumber(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps);
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSNOTREQUIRED)
	void updateIcmTicketsNotRequired(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps,@Param("subCategory") String subCategory);
	
	@Transactional
	@Modifying
	@Query(value=QueryConstants.UPDATEICMTICKETSREQUIRED)
	void updateIcmTicketsRequired(@Param("number") String number,@Param("resolutionSteps") String resolutionSteps,@Param("subCategory") String subCategory);
	
	@Query(value=QueryConstants.GETICMOPENTICKETSNUMBERS)
	List<String> getIcmOpenTicketNumbers();
	

}