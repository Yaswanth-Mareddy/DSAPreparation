package com.infosysit.rctmscompliance.entity;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name="cmsmstlocation")
public class CMSMstLocation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="intlocationid")
	private int intLocationID;
	
	@Column(name="txtlocationname")
	private String txtLocationName;
	
	@Column(name="txtlastmodifiedby")
	private String txtLastModifiedBy;
	
	@Column(name="dtlastmodified")
	private String dtLastModified;

}
