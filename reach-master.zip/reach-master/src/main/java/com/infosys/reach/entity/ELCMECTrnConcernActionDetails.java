package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.disciplinary.CaseDetails;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name="elcmectrnconcernactiondetails")
public class ELCMECTrnConcernActionDetails {
	@Id
	@GeneratedValue(strategy =  GenerationType.IDENTITY)
	@Column(name="intcaseactionid")
	private int caseActionId;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="txtrole")
	private String role;
	
	@Column(name="txtcomments")
	private String comments;
	
	@Column(name="txtstatus")
	private String status;
	
	@Column(name="txtassigneeempno")
	private String assigneeEmoNo;
	
	@Column(name="flgsentforopinion")
	private int flgSentForOpinion;
	
	@Column(name="txtdmsfilename")
	private String dmsFilename;
	
	@Column(name="flgreassign")
	private int flgReAssign;
	
	@Column(name="txtcreatedby")
	private String createdBy;
	
	@Column(name="txtmodifiedby")
	private String modifiedBy;
	
	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;
	
	@Column(name="txtunithrmailid")
	private String unitHRMailId;

	public ELCMECTrnConcernActionDetails(int caseId, CaseDetails caseDetails, String createdBy, Timestamp createdOn) {
		super();
		this.caseId = caseId;
		this.role = "CIN";
		this.comments = caseDetails.getDescription();
		this.status = "IM";
		this.flgSentForOpinion = 0;
		this.dmsFilename = caseDetails.getDmsFilenames();
		this.flgReAssign = 0;
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
		this.unitHRMailId = caseDetails.getUnitHRMailId();
	}
	
	
}
