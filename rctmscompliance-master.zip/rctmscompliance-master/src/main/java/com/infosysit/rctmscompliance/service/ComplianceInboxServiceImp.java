package com.infosysit.rctmscompliance.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.ComplianceInbox;
import com.infosysit.rctmscompliance.repo.read.ViewCMSMstInboxDetailsWithEmpIDRepoRead;

@Transactional(rollbackFor = CustomException.class)
@Service
public class ComplianceInboxServiceImp implements ComplianceInboxService {

	@Autowired
	private ViewCMSMstInboxDetailsWithEmpIDRepoRead inboxDetailRepoRead;
	
	@Override
	public List<ComplianceInbox> viewComplianceInbox(String txtEmpNo, String txtStatus, String txtpendingstatus) throws CustomException {
		try {
			List<ComplianceInbox> compInbox;
			if(txtpendingstatus.equalsIgnoreCase("pending with me"))
			{
				if(txtStatus.equalsIgnoreCase("all")) 
					compInbox=inboxDetailRepoRead.viewComplianceinboxPendingWithEmp(txtEmpNo);
				else
					compInbox= inboxDetailRepoRead.viewComplianceinboxPendingWithEmpByStatus(txtEmpNo, txtStatus); 
			}
			else {
				if(txtStatus.equalsIgnoreCase("all"))
					compInbox= inboxDetailRepoRead.viewComplianceinboxAllWithEmp(txtEmpNo);
				else
					compInbox= inboxDetailRepoRead.viewComplianceinboxAllWithEmpByStatus(txtEmpNo, txtStatus);
			}
			return compInbox;
		} catch (Exception e) {
			throw new CustomException(e.toString());
		}
	}
	

}
