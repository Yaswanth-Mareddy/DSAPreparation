package com.infosys.reach.swagger2;


import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.RequestMethod;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ApiKey;
import springfox.documentation.service.AuthorizationScope;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.service.SecurityReference;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@Profile({"dev","test"})
public class SwaggerConfig {

	List<ResponseMessage> responseMessages = Arrays.asList(
	        new ResponseMessageBuilder().code(401).message("Unauthorized").build(),
	        new ResponseMessageBuilder().code(403).message("Forbidden").build(),
	        new ResponseMessageBuilder().code(400).message("Bad Request").build(),
	        new ResponseMessageBuilder().code(500).message("Internal server error or some error occured").build());

	
	@Bean
	public Docket api() {
		String ashiServices = "ASHI Services";
		return new Docket(DocumentationType.SWAGGER_2)
				.tags(new Tag("Hear Module : InfyMe Mobile", "Hear Services"),new Tag("Disciplinary Module", "Disciplinary Services"),new Tag("ASHI Module : Employee Hub", ashiServices),new Tag("ASHI Module : InfyMe Mobile", ashiServices), new Tag("ASHI Admin Module : Employee Hub", ashiServices))
				.securitySchemes(Arrays.asList(apiKey()))
	            .securityContexts(Collections.singletonList(securityContext())).select().apis(RequestHandlerSelectors.basePackage("com.infosys.reach.controller")).build().useDefaultResponseMessages(false).globalResponseMessage(RequestMethod.POST, responseMessages)
		        .globalResponseMessage(RequestMethod.GET, responseMessages).apiInfo(metaData());
	}
	
    private SecurityContext securityContext() {
        return SecurityContext.builder().securityReferences(defaultAuth()).forPaths(PathSelectors.ant("/v2/api/**")).build();
      }

    private List<SecurityReference> defaultAuth() {
      final AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
      final AuthorizationScope[] authorizationScopes = new AuthorizationScope[]{authorizationScope};
      return Collections.singletonList(new SecurityReference("Bearer", authorizationScopes));
    }

    private ApiKey apiKey() {
      return new ApiKey("Bearer", "Authorization", "header");
    }
	
	private ApiInfo metaData() {
        return new ApiInfoBuilder()
                .title("REACH")
                .description("\"Reach Application using Spring Microservices.\"")
                .version("2.0.0")
                .build();
    }
}