package com.infosysit.rctmscompliance.service;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosysit.rctmscompliance.controller.TokenValidator;
import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.AppInfoJson;
import com.infosysit.rctmscompliance.model.BtnAction;
import com.infosysit.rctmscompliance.model.CMSRemarkDTO;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserFinal;
import com.infosysit.rctmscompliance.model.InbayDelActionItem;
import com.infosysit.rctmscompliance.model.InbayDeleteDTO;
import com.infosysit.rctmscompliance.model.InbayInsertActionItem;
import com.infosysit.rctmscompliance.model.InbayInsertDTO;
import com.infosysit.rctmscompliance.repo.read.CMSMstComplianceDetailsRepoRead;
import com.infosysit.rctmscompliance.util.Constants;
import com.infosysit.rctmscompliance.util.ExtendedLogging;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.beans.factory.annotation.Value;

@Service
public class InbayServiceImp implements InbayService {
	
	@Autowired
	RestTemplate restTemplate;
	
	@Value("${INBAYAPPROVALURL}")
	private String inbayAppUrl;
	
	@Value("${INBAYACTIONITEMURL}")
	private String inbayActionItemUrl;
	
	@Autowired
	@Qualifier("extendedLogging")
	private ExtendedLogging log;

	
	@Autowired
	ComplianceDetailsServiceImp compServ;
	
	@Autowired
	CMSMstComplianceDetailsRepoRead compDetailRead;

	@Override
	public void assigneeDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException {
		try {
			String strAppTransactionIDAD=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			InbayDeleteDTO inbayAD=new InbayDeleteDTO(Constants.APPLICATIONCODE, Constants.APPASSIGNEECATID, strAppTransactionIDAD, requester, 
					approver, Constants.ASSIGNEETRANSACTIONTITLE);
			inbayDeleteRequest(inbayAppUrl, inbayAD);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in assigneeDeleteApprovalItem method-InbayServices");
		}
	}
	
	@Override
	public void assigneeInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException {
		try {
			LocalDateTime nowAI = LocalDateTime.now();
			String dtSubmissionAI = getZuluDateTime(nowAI);
			String dtExpiredAI = getZuluDateTime(nowAI.plusDays(30));
			String strAppTransactionIDAI=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			AppInfoJson appjsAI=appJsonInfoAssigneeAndVerifier(compObj, intComplianceID);
			String strApplicationInfoJSONAI="["+mapToJson(appjsAI)+"]";
			String strAppTransactionURLAI="NA";
			
			InbayInsertDTO inbayAI=new InbayInsertDTO(Constants.APPLICATIONCODE, Constants.APPASSIGNEECATID, strAppTransactionIDAI, 
					requester,approver, strAppTransactionURLAI, Constants.ASSIGNEETRANSACTIONTITLE, Constants.ASSIGNEETRANSACTIONDESCRIPTION, 
					dtSubmissionAI, dtExpiredAI, strApplicationInfoJSONAI);
			
			inbayInsertRequest(inbayAppUrl,inbayAI);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in assigneeInsertApprovalItem method-InbayServices");
		}
		
	}
	
	@Override
	public void ownerDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException {
		try {
			String strAppTransactionIDOD=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			InbayDeleteDTO inbayOD=new InbayDeleteDTO(Constants.APPLICATIONCODE, Constants.APPOWNERCATID, strAppTransactionIDOD, requester, 
					approver, Constants.OWNERTRANSACTIONTITLE);
			inbayDeleteRequest(inbayAppUrl, inbayOD);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in ownerDeleteApprovalItem method-InbayServices");
		}
	}
	
	@Override
	public void ownerInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException {
		try {
			LocalDateTime nowOI = LocalDateTime.now();
			String dtSubmissionOI = getZuluDateTime(nowOI);
			String dtExpiredOI = getZuluDateTime(nowOI.plusDays(30));
			String strAppTransactionIDOI=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			AppInfoJson appjsOI=appJsonInfoOwner(compObj,intComplianceID);
			String strApplicationInfoJSONOI="["+mapToJson(appjsOI)+"]";
			String strAppTransactionURLOI="NA";
			
			InbayInsertDTO inbayOI=new InbayInsertDTO(Constants.APPLICATIONCODE, Constants.APPOWNERCATID, strAppTransactionIDOI, 
					requester,approver, strAppTransactionURLOI, Constants.OWNERTRANSACTIONTITLE, Constants.OWNERTRANSACTIONDESCRIPTION, 
					dtSubmissionOI, dtExpiredOI, strApplicationInfoJSONOI);
			
			inbayInsertRequest(inbayAppUrl,inbayOI);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in ownerInsertApprovalItem method-InbayServices");
		}
	}
	
	@Override
	public void verifierDeleteApprovalItem(CMSRemarkDTO remark,String requester,String approver,int intComplianceID) throws CustomException {
		try {
			String strAppTransactionIDVD=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			InbayDeleteDTO inbayVD=new InbayDeleteDTO(Constants.APPLICATIONCODE, Constants.APPVERIFIERCATID, strAppTransactionIDVD, requester, 
					approver, Constants.VERIFIERTRANSACTIONTITLE);
			inbayDeleteRequest(inbayAppUrl, inbayVD);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in verifierDeleteApprovalItem method-InbayServices");
		}
	}
	
	@Override
	public void verifierInsertApprovalItem(CMSRemarkDTO remark,String requester,String approver,ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException {
		try {
			LocalDateTime nowVI = LocalDateTime.now();
			String dtSubmissionVI = getZuluDateTime(nowVI);
			String dtExpiredVI = getZuluDateTime(nowVI.plusDays(30));
			String strAppTransactionIDVI=getTransactionID(intComplianceID, remark.getDtAssignedDate());
			AppInfoJson appjsVI=appJsonInfoAssigneeAndVerifier(compObj, intComplianceID);
			BtnAction btnactVI=new BtnAction();
			btnactVI.setIntComplianceID(intComplianceID);
			btnactVI.setDtAssignedDate(compObj.getDtAssignedDate());
			appjsVI.setRejectBtn(btnactVI);
			String strApplicationInfoJSONVI="["+mapToJson(appjsVI)+"]";
			
			String strAppTransactionURLVI="NA";
			
			InbayInsertDTO inbayVI=new InbayInsertDTO(Constants.APPLICATIONCODE, Constants.APPVERIFIERCATID, strAppTransactionIDVI, 
					requester,approver, strAppTransactionURLVI, Constants.VERIFIERTRANSACTIONTITLE, Constants.VERIFIERTRANSACTIONDESCRIPTION, 
					dtSubmissionVI, dtExpiredVI, strApplicationInfoJSONVI);
			
			inbayInsertRequest(inbayAppUrl,inbayVI);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in verifierInsertApprovalItem method-InbayServices");
		}
	}
	
	@Override
	public String inbayInsertRequest(String requestUrl,Object inbay) throws CustomException {
		try {
			String requestBodyI = mapToJson(inbay);
			HttpHeaders authenticationHeadersI = getHeaders();
			String bearerTokenI=TokenValidator.getJwtTOKEN();
			if(!bearerTokenI.contains("Bearer"))
				bearerTokenI="Bearer "+bearerTokenI;
			authenticationHeadersI.set("Authorization", bearerTokenI);
			HttpEntity<String> requestEntityI = new HttpEntity<>(requestBodyI,authenticationHeadersI);
			ResponseEntity<String> reqResponseI = restTemplate.exchange(requestUrl+"/insertitem",HttpMethod.POST, requestEntityI, String.class);
			if(reqResponseI.getStatusCode().equals(HttpStatus.OK))
				return "Inbay "+reqResponseI.getBody();
			else {
				log.log("Approval Insert failed,inbyaInsertRequest method-InbayServces: "+reqResponseI.getBody());
				return null;
			}
		} catch (Exception e) {
			log.log(e.getMessage());
			return null;
		} 
	}
	
	@Override
	public String inbayDeleteRequest(String requestUrl, Object inbay) throws CustomException {
		try {
			String requestBodyD = mapToJson(inbay);
			HttpHeaders authenticationHeadersD = getHeaders();
			String bearerTokenD=TokenValidator.getJwtTOKEN();
			if(!bearerTokenD.contains("Bearer"))
				bearerTokenD="Bearer "+bearerTokenD;
			authenticationHeadersD.add("Authorization", bearerTokenD);
			HttpEntity<String> requestEntityD = new HttpEntity<>(requestBodyD,authenticationHeadersD);
			ResponseEntity<String> reqResponseD = restTemplate.exchange(requestUrl+"/DeleteItem",HttpMethod.POST, requestEntityD, String.class);
			
			if(reqResponseD.getStatusCode().equals(HttpStatus.OK))
				return "Inbay "+reqResponseD.getBody();
			else
			{
				log.log("Approval Insert failed,inbayDeleteRequest method-InbayServces: "+reqResponseD.getBody());
				return null;
			}
		} catch (Exception e) {
			log.log(e.getMessage());
			return null;
		} 
	}
	
	@Override
	public String mapToJson(Object obj) throws CustomException {
	      try {
			ObjectMapper objectMapper = new ObjectMapper();
			  return objectMapper.writeValueAsString(obj);
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in mapToJson method-InbayServices");
		}
	   }
	
	@Override
	public String getZuluDateTime(LocalDateTime now) throws CustomException {
		try {
			DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"); 
			return now.format(format);
		} catch (Exception e) {
			throw new CustomException(e.getMessage()+" Error in getZuluDateTime method-InbayServices");
		}
	}
	
	@Override
	public HttpHeaders getHeaders() throws CustomException{
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.set("Content-Type", MediaType.APPLICATION_JSON_VALUE);
			headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
			return headers;
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in getHeaders method-InbayServices");
		}
	}
	
	@Override
	public String normalDate(String date) throws CustomException {
		try {
			DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			DateTimeFormatter format2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			if(!(date.isEmpty() || date==null))
			{
				LocalDateTime parsedDate=LocalDateTime.parse(date,format1);
				return parsedDate.format(format2);
			}
			return "NA";
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in normalDate method-InbayServices");
		}
	}
	
	@Override
	public AppInfoJson appJsonInfoAssigneeAndVerifier(ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException {
		AppInfoJson appJson=new AppInfoJson();
		try {
			appJson.setCompName(compObj.getCompName()); 
			if(compObj.getCompDesc()!=null && !compObj.getCompDesc().isEmpty())
				appJson.setCompDesc(compObj.getCompDesc());
			appJson.setDtDueDate(normalDate(compObj.getDtDueDate()));
			appJson.setEscDetail(compObj.getCompEsc());

			if(compObj.getAssigneeAfterRejectRemarks()!=null && !compObj.getAssigneeAfterRejectRemarks().isEmpty()){
				appJson.setAssiRemark(compObj.getAssigneeAfterRejectRemarks());
				}
			else {
				if(compObj.getAssigneeRemarks()!=null && !compObj.getAssigneeRemarks().isEmpty())
					appJson.setAssiRemark(compObj.getAssigneeRemarks());
			}
			if(compObj.getVerifierRejectRemarks()!=null && !compObj.getVerifierRejectRemarks().isEmpty())
				appJson.setVeriRejRemark(compObj.getVerifierRejectRemarks());
				
			BtnAction btnact=new BtnAction();
			btnact.setIntComplianceID(intComplianceID);
			btnact.setDtAssignedDate(compObj.getDtAssignedDate());
			appJson.setApproveBtn(btnact);
			
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in creating appJsonInfoAssigneeAndVerifier method-InbayServices");
		}
		return appJson;
	}
	@Override
	public AppInfoJson appJsonInfoOwner(ComplianceDetailsForUserFinal compObj,int intComplianceID) throws CustomException {
		AppInfoJson appJsonO=new AppInfoJson();
		try {
			appJsonO.setCompName(compObj.getCompName()); 
			if(compObj.getCompDesc()!=null && !compObj.getCompDesc().isEmpty())
				appJsonO.setCompDesc(compObj.getCompDesc());
			appJsonO.setDtDueDate(normalDate(compObj.getDtDueDate()));
			appJsonO.setEscDetail(compObj.getCompEsc());

			if(compObj.getAssigneeAfterRejectRemarks()!=null && !compObj.getAssigneeAfterRejectRemarks().isEmpty()){
				appJsonO.setAssiRemark(compObj.getAssigneeAfterRejectRemarks());
				}
			else {
				if(compObj.getAssigneeRemarks()!=null && !compObj.getAssigneeRemarks().isEmpty())
					appJsonO.setAssiRemark(compObj.getAssigneeRemarks());
			}
			
			if(compObj.getVerifierApprovalRemarks()!=null && !compObj.getVerifierApprovalRemarks().isEmpty())
					appJsonO.setVeriRemark(compObj.getVerifierApprovalRemarks());
			
			BtnAction btnactO=new BtnAction();
			btnactO.setIntComplianceID(intComplianceID);
			btnactO.setDtAssignedDate(compObj.getDtAssignedDate());
			appJsonO.setApproveBtn(btnactO);
			
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in creating appJsonInfoOwner method-InbayServices");
		}
		return appJsonO;
	}
	
	@Override
	public String getTransactionID(int intComplainceID, String dtAsisgnedDate) throws CustomException {
		String date=getTransactionDate(dtAsisgnedDate);
		date=date.replace("-", "");
		return intComplainceID+" "+date;
	}
	
	public String getTransactionDate(String date) throws CustomException {
		try {
			SimpleDateFormat format2 =new SimpleDateFormat("yyyy-MM-dd");
			if(!(date.isEmpty() || date==null))
			{
				Date parsedDate=format2.parse(date);
				return format2.format(parsedDate);
			}
			return "NA";
		} catch (Exception ex) {
			throw new CustomException(ex.getMessage()+" Error in getTransactionDate method-InbayServices");
		}
	}
	
	@Override
	public void deleteActionItem(String strAppTransactionID,String strEmpNo) throws CustomException {
		try {
			InbayDelActionItem inbay=new InbayDelActionItem(Constants.APPLICATIONCODE, Constants.APPSURVEYACTIONCATID, strAppTransactionID,strEmpNo);
			inbayDeleteRequest(inbayActionItemUrl+"DeleteItem", inbay);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in deleteActionItem method-InbayServices");
		}
	}
	
	@Override
	public void insertActionItem(int actionItemId,String strEmpNo) throws CustomException {
		try {
			LocalDateTime currTime = LocalDateTime.now();
			String dtSubmission = getZuluDateTime(currTime);
			String dtExpired = getZuluDateTime(currTime.plusDays(30));
			InbayInsertActionItem inbay=new InbayInsertActionItem(Constants.APPLICATIONCODE, Constants.APPSURVEYACTIONCATID, String.valueOf(actionItemId), 
					strEmpNo, "NA", Constants.ACTIONITEMTRANSACTIONTITLE, Constants.ACTIONITEMTRANSACTIONDESC, 
					dtSubmission, dtExpired, String.valueOf("["+actionItemId+"]"));
			inbayInsertRequest(inbayActionItemUrl+"insertitem", inbay);
		} catch (Exception e) {
			log.log(e.getMessage()+" Error in deleteActionItem method-InbayServices");
		}
	}
}
