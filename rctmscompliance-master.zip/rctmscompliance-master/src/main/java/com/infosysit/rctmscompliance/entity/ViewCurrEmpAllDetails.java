package com.infosysit.rctmscompliance.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Immutable
@Table(name="viewcurrempalldetails")
public class ViewCurrEmpAllDetails {

	@Id
	@Column(name="txtempno")
	private String txtEmpNo;
	
	@Column(name="txtempname")
	private String txtEmpName;
	
	@Column(name="txtmailid")
	private String txtMailId;
}
