package com.infosys.reach.model.common;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class DMSModel {

	private String applicationName;
	private String applicationID;
	private String storageURL;
	private String documentPath;
	private String documentName;
	private String documentBytes;
	private String userID;
	private String documentID;
	
	public DMSModel(String applicationName, String applicationID, String storageURL, String documentPath,
			String documentName) {
		super();
		this.applicationName = applicationName;
		this.applicationID = applicationID;
		this.storageURL = storageURL;
		this.documentPath = documentPath;
		this.documentName = documentName;
		this.documentBytes = "";
		this.userID = "";
	}
	

	

}
