package com.infosys.reach.service;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.WordUtils;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.reach.controller.Session;
import com.infosys.reach.entity.ELCMECMstASHIAllegationsAndFindingsDetails;
import com.infosys.reach.entity.ELCMECMstASHICaseEmployeeDetails;
import com.infosys.reach.entity.ELCMECMstASHICocomplainantsDetails;
import com.infosys.reach.entity.ELCMECMstASHICommunicationDetails;
import com.infosys.reach.entity.ELCMECMstASHIConciliationConsentDetails;
import com.infosys.reach.entity.ELCMECMstASHIFormalInvestigationReportDetails;
import com.infosys.reach.entity.ELCMECMstASHIPreliminaryDiscussionDetails;
import com.infosys.reach.entity.ELCMECMstASHIRecommendationsDetails;
import com.infosys.reach.entity.ELCMECMstASHISummonsDetails;
import com.infosys.reach.entity.ELCMECMstConcernModulesDetails;
import com.infosys.reach.entity.ELCMECMstReachWorkFlow;
import com.infosys.reach.entity.ELCMECMstSysParams;
import com.infosys.reach.entity.ELCMECTrnASHIActionDetails;
import com.infosys.reach.entity.ELCMECTrnASHICaseDetails;
import com.infosys.reach.entity.ELCMECTrnASHIConciliationReportDetails;
import com.infosys.reach.entity.ELCMECTrnASHIFirstContactMailsDetails;
import com.infosys.reach.entity.ELCMECTrnASHIInterimReliefDetails;
import com.infosys.reach.entity.ELCMECtrnASHIConcernSLADetails;
import com.infosys.reach.entity.ELCMECtrnASHISLAAuditTrial;
import com.infosys.reach.entity.HRISMstEmployee;
import com.infosys.reach.entity.ViewCurrEmpAllDetails;
import com.infosys.reach.exception.CustomException;
import com.infosys.reach.model.ashi.CaseDetailsValidationResponse;
import com.infosys.reach.model.ashi.GMFields;
import com.infosys.reach.model.ashiadmin.AdminInboxRow;
import com.infosys.reach.model.ashiadmin.CaseSummary;
import com.infosys.reach.model.ashiadmin.FindingFilter;
import com.infosys.reach.model.ashiadmin.Findings;
import com.infosys.reach.model.ashiadmin.InboxFilter;
import com.infosys.reach.model.ashiadmin.MailEmployeeDetails;
import com.infosys.reach.model.ashiadmin.PreliminaryDiscussionDetails;
import com.infosys.reach.model.ashiadmin.UpdateCaseStatusReturn;
import com.infosys.reach.model.common.AccordionModel;
import com.infosys.reach.model.common.CaseEmployeeDetails;
import com.infosys.reach.model.common.DMSModel;
import com.infosys.reach.model.common.EmployeeDetails;
import com.infosys.reach.model.common.FileGenerationServiceResponse;
import com.infosys.reach.model.common.MailContent;
import com.infosys.reach.model.common.MailInfo;
import com.infosys.reach.model.common.MailerAssistRequest;
import com.infosys.reach.model.common.MailerAssistResponse;
import com.infosys.reach.model.common.PlaceHolder;
import com.infosys.reach.model.generic.Accordion;
import com.infosys.reach.model.generic.AccordionView;
import com.infosys.reach.model.generic.Card;
import com.infosys.reach.model.generic.CardView;
import com.infosys.reach.model.generic.CardViewAction;
import com.infosys.reach.model.generic.CardViewField;
import com.infosys.reach.model.generic.DocumentData;
import com.infosys.reach.model.generic.GenModel;
import com.infosys.reach.model.generic.GenModelField;
import com.infosys.reach.model.generic.GenModelOption;
import com.infosys.reach.model.generic.GenModelValidation;
import com.infosys.reach.model.generic.Header;
import com.infosys.reach.model.generic.InboxView;
import com.infosys.reach.model.generic.LabelView;
import com.infosys.reach.model.generic.Link;
import com.infosys.reach.model.generic.LinkModel;
import com.infosys.reach.model.generic.NonGrpPlaceHolder;
import com.infosys.reach.model.generic.Response;
import com.infosys.reach.model.generic.Row;
import com.infosys.reach.model.generic.WorkFlow;
import com.infosys.reach.model.generic.WorkFlowItem;
import com.infosys.reach.repository.ELCMECMstASHIAllegationsAndFindingsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICaseEmployeeDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICocomplainantsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHICommunicationDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIConciliationConsentDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIFormalInvestigationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIPreliminaryDiscussionDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHIRecommendationsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstASHISummonsDetailsRepository;
import com.infosys.reach.repository.ELCMECMstConcernModulesDetailsRepository;
import com.infosys.reach.repository.ELCMECMstReachGenModelOptionsRepository;
import com.infosys.reach.repository.ELCMECMstReachWorkFlowRepository;
import com.infosys.reach.repository.ELCMECMstSysParamsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIActionDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHICaseDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIConciliationReportDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIFirstContactMailsDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnASHIInterimReliefDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachCountryDetailsRepository;
import com.infosys.reach.repository.ELCMECTrnReachStatusAccordionsMappingRepository;
import com.infosys.reach.repository.ELCMECtrnASHIConcernSLADetailsRepository;
import com.infosys.reach.repository.ELCMECtrnASHISLAAuditTrialRepository;
import com.infosys.reach.repository.GenMstMailConfigHeaderRepository;
import com.infosys.reach.repository.HRISMstEmployeeRepository;
import com.infosys.reach.util.Constants;
import com.infosys.reach.util.Message;
import com.infosys.reach.util.Property;


/**
 * @author surajkumar.dewangan
 *
 **/
@Service
@Transactional(rollbackFor = Exception.class)
public class ASHIAdminServiceImpl implements ASHIAdminService {
	
	@Autowired
	private FileGenerationServiceImpl fileGenerationService;

	@Autowired
	private Property property;

	private Timestamp currentDateTime=new Timestamp(ZonedDateTime.now(ZoneId.of("Asia/Kolkata")).toInstant().toEpochMilli() + 19800000);

	@Autowired
	private CommonServiceImpl commonService;

	@Autowired
	private ASHIServiceImpl ashiService;

	@Autowired
	private ELCMECTrnASHICaseDetailsRepository caseDetailsRepository;

	@Autowired
	private ELCMECMstASHICaseEmployeeDetailsRepository caseEmployeeDetailsRepository;

	@Autowired
	private ELCMECTrnASHIActionDetailsRepository ashiActionDetailsRepository;

	@Autowired
	private ELCMECTrnReachCountryDetailsRepository reachCountryDetailsRepository;

	@Autowired
	private ELCMECMstConcernModulesDetailsRepository concernModulesDetailsRepository;

	@Autowired
	private ELCMECMstASHIPreliminaryDiscussionDetailsRepository preliminaryDiscussionDetailsRepository;

	@Autowired
	private HRISMstEmployeeRepository hrisMstEmployeeRepository;

	@Autowired
	private GenMstMailConfigHeaderRepository mailConfigHeaderRepository;

	@Autowired
	private ELCMECMstASHICocomplainantsDetailsRepository ashiCocomplainantsDetailsRepository;

	@Autowired
	private ELCMECMstASHICommunicationDetailsRepository communicationRepository;

	@Autowired
	private ELCMECMstReachGenModelOptionsRepository genModelOptionsRepository;

	@Autowired
	private ELCMECTrnASHIInterimReliefDetailsRepository interimReliefRepository;

	@Autowired
	private ELCMECTrnASHIFirstContactMailsDetailsRepository firstContactMailsRepository;

	@Autowired
	private ELCMECMstASHIConciliationConsentDetailsRepository conciliationConsentDetailsRepository;

	@Autowired
	private ELCMECTrnASHIConciliationReportDetailsRepository conciliationReportDetailsRepository;

	@Autowired
	private ELCMECMstASHIRecommendationsDetailsRepository recommendationsDetailsRepository;

	@Autowired
	private ELCMECMstASHISummonsDetailsRepository summonsDetailsRepository;

	@Autowired
	private ELCMECMstASHIFormalInvestigationReportDetailsRepository formalInvestigationReportDetailsRepository;

	@Autowired
	private ELCMECMstASHIAllegationsAndFindingsDetailsRepository allegationsAndFindingsDetailsRepository;

	@Autowired
	private ELCMECtrnASHIConcernSLADetailsRepository slaDetailsRepository;

	@Autowired
	private ELCMECtrnASHISLAAuditTrialRepository slaAuditTrialRepository;

	@Autowired
	private ELCMECMstSysParamsRepository elcmecMstSysParamsRepository;

	@Autowired
	private ELCMECMstReachWorkFlowRepository workFlowRepository;
	
	@Autowired
	private ELCMECTrnReachStatusAccordionsMappingRepository accordionsMappingRepository;
	
	@Override
	public GenModel getInboxFilterGenmodel() throws CustomException {
		List<GenModelField> fields = new ArrayList<>();
		List<GenModelOption> roleOptions = commonService.getCAMSRoles("2", "Yes", new ArrayList<>());
		String selectedRole = "";
		
		if(!roleOptions.isEmpty()) {
			if(roleOptions.stream().anyMatch(a -> a.getKey().equals("GRB"))) {
				selectedRole = "GRB";
			}
			else {
				selectedRole = roleOptions.get(0).getKey();
			}
		}

		GenModelField roleField=new GenModelField( 39, Constants.ROLE.toLowerCase(), Constants.ROLE, Constants.SELECT, "", roleOptions, true);
		roleField.setData(selectedRole);
		fields.add(roleField);


		List<GenModelOption> countryOptions = commonService.getCamsContextDropdown("GRB", "2", "", "", "", "Yes");
		List<GenModelOption> companyOptions = commonService.getCamsContextDropdown("GRB", "2", "IN", "", "", "Yes");

		GenModelField countryField=new GenModelField( 39, Constants.COUNTRY.toLowerCase(), Constants.COUNTRY, Constants.ROLE.toLowerCase(), "", true);
		countryField.setDependantAction(MessageFormat.format(property.getContextURL(), "2", "{0}", "", "", "", "Yes") + "|" + Constants.POST);
		countryField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COUNTRY)));
		if(!countryOptions.isEmpty()) {
			countryField.setData(countryOptions.get(0).getKey());
			countryField.setOptions(countryOptions);
		}
		fields.add(countryField);

		GenModelField companyField=new GenModelField( 39, Constants.COMPANY.toLowerCase(), Constants.COMPANY, Constants.ROLE.toLowerCase() + "," + Constants.COUNTRY.toLowerCase(), "", true);
		companyField.setDependantAction(MessageFormat.format(property.getContextURL(), "2", "{0}", "{1}", "", "", "Yes") + "|" + Constants.POST);
		companyField.setValidations(Arrays.asList(new GenModelValidation("0", "1", "Please select "+Constants.COMPANY)));
		if(!companyOptions.isEmpty()) {
			companyField.setData(companyOptions.get(0).getKey());
			companyField.setOptions(companyOptions);
		}
		fields.add(companyField);	

		List<GenModelOption> casetypeOption = commonService.getGenModelOptionsByModuleIdAndGroupId(2, "CTGRB");
		GenModelField casetype=new GenModelField( 39, "caseType", "Case Type", Constants.ROLE.toLowerCase(), "", true);
		
		if(!casetypeOption.isEmpty()) {
			casetype.setOptions(casetypeOption);
			casetype.setData(casetypeOption.get(0).getKey());
		}
		casetype.setDependantAction(MessageFormat.format(property.getGenmodelOptionsByGroupIdURL(), "CT{0}", "2")+"|"+Constants.POST);
		fields.add(casetype);

		return new GenModel("Admin Inbox", fields, Arrays.asList(new CardViewAction(1, "SUBMIT", Constants.POST, property.getInboxGMFilteredURL(), Constants.SERVICEURL)));
	}


	@Override
	public GenModel getInboxInLineFilterGenmodel(String role,String country,String company,String type) throws CustomException{
		List<GenModelField> fields = new ArrayList<>();

		List<GenModelOption> locationOptions=caseDetailsRepository.getLocation(country); 
		List<GenModelOption> statusOptions=caseDetailsRepository.getStatus(role);

		GenModelField location=new GenModelField(0, 5, Constants.LOCATION.toLowerCase(), Constants.LOCATION, "", "", "", "", false, new ArrayList<>(),  new ArrayList<>(), false, "", "", true,  locationOptions, false, true, "", "");
		fields.add(location);

		GenModelField status=new GenModelField(1, 5, Constants.STATUS.toLowerCase(), Constants.STATUS, "", "", "", "", true, new ArrayList<>(),  new ArrayList<>(), false, "", "", true,statusOptions, false, true, "", "");
		fields.add(status);

		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(1, "Apply", Constants.POST, MessageFormat.format(property.getInboxILFilteredURL(), role, country, company, type),"apply"));
		actions.add(new CardViewAction(1, Constants.CANCEL, "", "",Constants.CANCELMODELPOPUP));

		return new GenModel("Filter By", fields,actions);
	}

	public List<AdminInboxRow> getAdminInboxRows(String role, String country, String company, String type) throws CustomException{
		List<AdminInboxRow> rows = new ArrayList<>();
		List<String> closedCaseStatus = Arrays.asList("OI","CLN","DM","CLF","CLC");
		
		if(role.equals("IC") && type.equals("1")) {
			//need to check for country and company filter
			List<GenModelOption> icLocations = commonService.getCamsContextDropdown("IC", "2", country, company, "", "Yes");
			List<String> locations =new ArrayList<>(); 
			icLocations.forEach(l -> locations.add(l.getValue().trim()));
			if(!locations.isEmpty())
				rows = caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompanyAndAssigneeLocation("IC", country, company, locations, closedCaseStatus);
		}

		else if(role.equals("GRB")) {
			//Open cases
			if(type.equals("1"))
				rows = caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany("GRB", country, company, closedCaseStatus);
			
			//closed cases
			else if(type.equals("2")) {
				rows = caseDetailsRepository.findClosedCasesByCaseStatusAndCountryAndCompanyAndStatus("GRB", country, company, closedCaseStatus);
			}
			
			//SLA approval cases
			else if(type.equals("3")) {
				rows = caseDetailsRepository.findSLAApprovalCasesByCaseStatusAndCountryAndCompany("IC", country, company, closedCaseStatus);
			}
			
			// Interim relief approval cases
			else if(type.equals("4")) {
				rows = caseDetailsRepository.findInterimApprovalCasesByCaseStatusAndCountryAndCompany("IC", country, company, closedCaseStatus);
			}
		}

		else if(role.equals("ERH")) {
			//Open cases
			if(type.equals("1"))
				rows = caseDetailsRepository.findCasesByCaseStatusAndCountryAndCompany("ERH", country, company, closedCaseStatus);
			
			//closed cases
			else if(type.equals("2")) {
				rows = caseDetailsRepository.findClosedCasesByCaseStatusAndCountryAndCompanyAndStatus("ERH", country, company, closedCaseStatus);
			}
		}
		
		return rows;
	}
	
	@Override
	public InboxView getAdminInboxGenModelFiltered(InboxFilter filter) throws CustomException {

		List<AdminInboxRow> rows = this.getAdminInboxRows(filter.getRole(), filter.getCountry(), filter.getCompany(), filter.getCaseType());
		boolean isApproval = false;
		
		if(filter.getRole().equals("GRB") && Arrays.asList("3","4").contains(filter.getCaseType())) {
			isApproval = true;
		}

		return this.getAdminInboxView(rows, filter, isApproval);


	}

	@Override
	public InboxView getAdminInboxInLineFiltered(String role,String country,String company,String type, GenModel inLineFilter) throws CustomException {
		List<AdminInboxRow> rows = this.getAdminInboxRows(role, country, company, type);
		GMFields fields = commonService.convertGenModelToObject(inLineFilter, 0);
		
		List<AdminInboxRow> filteredRows = rows.stream().filter(x -> x.filterByStatusAndLocation(fields.getStatus(), fields.getLocation())).collect(Collectors.toList());

		return this.getAdminInboxView(filteredRows, new InboxFilter(fields.getRole(), fields.getCountry(), fields.getCompany(), ""), false);
	

	}

	private InboxView getAdminInboxView(List<AdminInboxRow> rows, InboxFilter filter, boolean isApproval){
		List<String> erhMID = new ArrayList<>();
		List<String> grbMID = new ArrayList<>();
		List<String> icMID = new ArrayList<>();
		String caseNavigationMID = commonService.getUIModuleId("ADCS");

		if(filter.getRole().equals("ERH")) {
			erhMID.add(commonService.getUIModuleId("DAAC"));
			erhMID.add(commonService.getUIModuleId("DAOI"));
		}

		else if(filter.getRole().equals("GRB")) {
			grbMID.add(commonService.getUIModuleId("INEX"));
			grbMID.add(commonService.getUIModuleId("INIR"));
			grbMID.add(commonService.getUIModuleId("INCI"));
			grbMID.add(commonService.getUIModuleId("INCR"));
			grbMID.add(commonService.getUIModuleId("INDM"));
		}

		else if(filter.getRole().equals("IC")) {
			icMID.add(commonService.getUIModuleId("INEX"));
		}

		List<Header> headerList = Arrays.asList(new Header("Case No", "caseId", "", true, 58, 0, "", "", false, ""),
				new Header("Reported On", "reportedOn", "", false, 14, 0, "", "", false, ""),
				new Header("Reported By", "reportedBy", "", false, 14, 0, "", "", false, ""),
				new Header(Constants.LOCATION, Constants.LOCATION.toLowerCase(), "", false, 14, 0, "", "", false, ""),
				new Header("Category", "category", "", false, 14, 0, "", "", false, ""),
				new Header("SLA Expiry", "slaExpiry", "", false, 14, 0, "", "", false, ""),
				new Header(Constants.STATUS, "statusDesc", "", false, 14, 0, "", "", false, ""));
		List<Row> rowList = new ArrayList<>();
		if (rows.isEmpty()) 
			return new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(),"");

		int i = 0;

		String filterService = "";
		if(!isApproval) {
			filterService = MessageFormat.format(property.getInboxILFilterGenModelURL(), filter.getRole(), filter.getCountry(), filter.getCompany(), filter.getCaseType()) + ";" + Constants.POST;
		}
		for (AdminInboxRow row : rows) {
			List<CardViewAction> inlineactions = new ArrayList<>();
			if(!isApproval) {
				inlineactions.add(new CardViewAction(1, Constants.CASE_ID, Constants.GET, caseNavigationMID, Constants.REDIRECTID));
			}

			if(filter.getRole().equals("ERH")) {
				inlineactions.addAll(this.getERHInboxActions(row.getStatus().trim(), erhMID));
			}

			else if(filter.getRole().equals("GRB")) {
				inlineactions.addAll(this.getGRBInboxActions(row.getStatus().trim(), grbMID, row.isFlgSLA(), row.isFlgInterim()));
			}

			else if(filter.getRole().equals("IC")) {
				inlineactions.addAll(this.getICInboxActions(row.getCaseId(), icMID));
			}

			rowList.add(new Row(row, ++i, inlineactions));
		}

		return new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, new ArrayList<>(), filterService);

	}


	private List<CardViewAction> getERHInboxActions(String status, List<String> moduleIds){
		List<CardViewAction> actions = new ArrayList<>();
		List<CardViewAction> moreActions = new ArrayList<>();

		if(status.equals("WE")) {
			moreActions.add(new CardViewAction("Assign case to GRB", Constants.POST, null, moduleIds.get(0), Constants.POPOVERFORM, null, null, "", null, null, ""));
			moreActions.add(new CardViewAction("Mark for offline investigation", Constants.POST, null, moduleIds.get(1), Constants.POPOVERFORM, null, null, "", null, null, ""));
		}

		actions.add(new CardViewAction("more", Constants.IMAGE, "more", moreActions));
		return actions;
	}

	private List<CardViewAction> getGRBInboxActions(String status, List<String> moduleIds, boolean flgSLA, boolean flgInterim){
		List<CardViewAction> actions = new ArrayList<>();
		List<CardViewAction> moreActions = new ArrayList<>();

		if(flgSLA) {
			actions.add(new CardViewAction("Approve SLA Extension", Constants.POST, null, moduleIds.get(0), Constants.POPOVERFORM, null, null, Constants.BUTTON, null, null, ""));
		}

		if(flgInterim) {
			actions.add(new CardViewAction("Approve Interim Relief", Constants.POST, null, moduleIds.get(1), Constants.POPOVERFORM, null, null, Constants.BUTTON, null, null, ""));
		}

		if(status.equals("CIA")) {
			String label = "Approve Conciliation Initiation";
			moreActions.add(new CardViewAction(label, Constants.POST, null, moduleIds.get(2), Constants.POPOVERFORM, null, null, "", null, null, ""));
		}

		else if(status.equals("DMRI")) {
			String label = "Approve Case Dismissal";
			moreActions.add(new CardViewAction(label, Constants.POST, null, moduleIds.get(4), Constants.POPOVERFORM, null, null, "", null, null, ""));

		}

		actions.add(new CardViewAction("more", Constants.IMAGE, "more", moreActions));
		return actions;
	}
	
	private List<CardViewAction> getICInboxActions(int caseid, List<String> moduleIds){
		List<CardViewAction> actions = new ArrayList<>();
		List<CardViewAction> moreActions = new ArrayList<>();

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = slaDetailsRepository.findByCaseIdAndRole(caseid, "IC");
		if(slaDetails.isPresent() && slaDetails.get().getFlgSLAExtensionRequest()!=1) {
			actions.add(new CardViewAction("SLA Extension", Constants.POST, null, moduleIds.get(0), Constants.POPOVERFORM, null, null, Constants.BUTTON, null, null, ""));
		}

		actions.add(new CardViewAction("more", Constants.IMAGE, "more", moreActions));
		return actions;
	}

	@Override
	public LabelView getCaseSummaryByCaseId(int caseid) throws CustomException {
		List<CaseSummary> caseSummary = caseDetailsRepository.findCaseSummaryByCaseId(caseid);

		List<CardViewField> fieldList=new ArrayList<>();
		if(!caseSummary.isEmpty()) {

			fieldList.add(new CardViewField("Respondent Type", caseSummary.get(0).getRespondentType(), 14));
			fieldList.add(new CardViewField("Assigned To", caseSummary.get(0).getAssignedTo(), 14));
			fieldList.add(new CardViewField(Constants.REPORTEDONLABEL, caseSummary.get(0).getReportedOn(), 14));
			fieldList.add(new CardViewField("Sla Expiry", caseSummary.get(0).getSlaExpiry(), 14));
			fieldList.add(new CardViewField("Raised By", caseSummary.get(0).getRaisedBy(), 14));
			fieldList.add(new CardViewField(Constants.DESCRIPTION, caseSummary.get(0).getDescription(), 54));


			Optional<ELCMECTrnASHIActionDetails> actionDetails = ashiActionDetailsRepository.findevidencesByCaseId(caseid);
			if(actionDetails.isPresent() && this.notNullOrEmpty(actionDetails.get().getDmsFileName())) {
				fieldList.add(new CardViewField(Constants.DOCUMENTS, "", 88));
				String[] documents = actionDetails.get().getDmsFileName().split(",");
				for(String document : documents) {
					fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "A", actionDetails.get().getCaseActionId(), document.trim()), 35));
				}
				
				if(documents.length>1)
					fieldList.add(new CardViewField(Constants.DOWNLOADALL, MessageFormat.format(property.getDownloadURL(), "A", actionDetails.get().getCaseActionId(), Constants.ALL), 87));
			}
			else {
				fieldList.add(new CardViewField(Constants.DOCUMENTS, "No evidence uploaded.", 14));
			}


		}
		return new LabelView(Constants.CASE_DETAILS,fieldList);
	}

	/*
	Actor:
		A	-	Complainant
		R	-	Respondent
		W	-	Witness
		T	-	Co-complainant
		S	-	Stakeholder
	 */
	@Override
	public GenModel getCaseSummaryEmployeeDropDown(int caseId, String actor) {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		List<String> actors = new ArrayList<>();
		String displayname = this.getEmployeeType(actor)+" Details";
		if(actor.equals("A"))
			actors.addAll(Arrays.asList(actor,"T"));
		else
			actors.add(actor);


		List<GenModelOption> options = new ArrayList<>();

		if(actor.equals("T")) {
			List<GenModelOption> employees = ashiCocomplainantsDetailsRepository.findCocomplainanats(caseId);
			options.addAll(employees);

		}
		else {
			List<GenModelOption> employees = caseEmployeeDetailsRepository.getCaseSummaryDropDownByCaseIdAndActor(caseId, actors);
			options.addAll(employees);
		}

		
		if(!options.isEmpty()) {
			GenModelField employees=new GenModelField( 39, this.getEmployeeType(actor).toLowerCase(), displayname, "", "", options, true);
			employees.setDependantAction(property.getEmployeeLabelURL() + actor + "|" + Constants.POST);
			fields.add(employees);
		}
		else {
			GenModelField employees=new GenModelField(14, "emptydropdown", displayname, "Case has no " + this.getEmployeeType(actor).toLowerCase(), false, true);
			fields.add(employees);
		}


		

		if(Arrays.asList("A", "R", "W").contains(actor) && commonService.checkIsActionEnabled("2", "ADDEMP", Session.getCaseDetails().getStatus())) {
			actions.add(new CardViewAction(1, "Add New " + this.getEmployeeType(actor), Constants.POST, commonService.getUIModuleId("ADN"+actor), Constants.GENERICMODELPOPUP));
		}

		return new GenModel(displayname, fields, actions, caseId);

	}

	@Override
	public LabelView getCaseSummaryEmployeeDetails(String actor, int transactionid) throws CustomException {
		if(actor.equals("T")) {
			Optional<ELCMECMstASHICocomplainantsDetails> employeeDetails = ashiCocomplainantsDetailsRepository.findById(transactionid);
			
			if(employeeDetails.isPresent() && employeeDetails.get().getFlgActive()==1 && employeeDetails.get().getFlgAccept()==0 && employeeDetails.get().getFlgReject()==0) {
				List<CaseEmployeeDetails> details = hrisMstEmployeeRepository.findCaseEmployeeDetails(employeeDetails.get().getMailId().trim());

				return this.getCaseSummaryEmployeeDetailsLabels(employeeDetails.get().getCaseId(), details.get(0), 1, actor, transactionid);
			}
		}
		else {
			Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = caseEmployeeDetailsRepository.findById(transactionid);
			if(employeeDetails.isPresent() && (employeeDetails.get().getActor().equals(actor) || (employeeDetails.get().getActor().equals("T") && actor.equals("A"))) && employeeDetails.get().getFlgActive()==1) {

				CaseEmployeeDetails details = new CaseEmployeeDetails(employeeDetails.get());

				return this.getCaseSummaryEmployeeDetailsLabels(employeeDetails.get().getCaseId(), details, employeeDetails.get().getFlgValid(), actor, transactionid);
			}

		}

		return new LabelView(Constants.CASEEMPLOYEE_DETAILS, Constants.LABELVIEW_TYPE1, new ArrayList<>());

	}
	
	private LabelView getCaseSummaryEmployeeDetailsLabels(int caseid, CaseEmployeeDetails details, int flgValid, String actor, int transactionid) throws CustomException {

		commonService.checkCaseAuthorization(caseid, true);
		
		List<CardViewField> fieldList=new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(1, "Hide Details", "", "", "hide"));

		if(flgValid==1) {
			fieldList.add(new CardViewField("Employee No", this.checkNull(details.getEmpNo()), 14));
			fieldList.add(new CardViewField("Employee ID", this.checkNull(details.getMailId()), 14));

			if(actor.equals("S")) {
				fieldList.add(new CardViewField("Designation", this.checkNull(details.getRoleDesc().split("|")[0]), 14));
				fieldList.add(new CardViewField("Selected Role", this.checkNull(details.getRoleDesc().split("|")[1]), 14));
			}
			else
				fieldList.add(new CardViewField("Designation", this.checkNull(details.getRoleDesc()), 14));

			fieldList.add(new CardViewField("Date Of Joining", details.getJoinedDate()!=null ? new DateTime(details.getJoinedDate().getTime()).toString(Constants.DATE_FORMAT):"NA", 14));
			fieldList.add(new CardViewField("Job Level", this.checkNull(details.getEmpBandCode()), 14));
			fieldList.add(new CardViewField("Project Code", this.checkNull(details.getProjectCode()), 14));
			fieldList.add(new CardViewField("Unit", this.checkNull(details.getUnit()), 14));
			fieldList.add(new CardViewField("PU", this.checkNull(details.getSbuCode()), 14));
			fieldList.add(new CardViewField("Current Location", details.getCurrentCity()!=null && !details.getCurrentCity().isEmpty() ? WordUtils.capitalize(details.getCurrentCity().toLowerCase()):"NA", 14));
			fieldList.add(new CardViewField("Confirmation Status", this.checkNull(details.getConfirmationStatus()), 14));


		}

		if(flgValid==0) {
			fieldList.add(new CardViewField("Non-Infoscion details", this.checkNull(details.getEmpName()), 14));

		}
		
		actions.addAll(this.addEMployeeLableActions(caseid, transactionid, actor, flgValid));

		return new LabelView(Constants.CASEEMPLOYEE_DETAILS, Constants.LABELVIEW_TYPE1, fieldList, actions, details.getEmpNo());
	}

	private List<CardViewAction> addEMployeeLableActions(int caseid, int transactionid, String actor, int flgValid){
		List<CardViewAction> actions = new ArrayList<>();
		
		if(Arrays.asList("T", "R").contains(actor) && flgValid==1) {
			actions.add(new CardViewAction("Notify", Constants.SERVICEURL, MessageFormat.format(property.getNotifyEmployeeURL(), String.valueOf(caseid), actor, String.valueOf(transactionid)), Constants.POST, "Are you sure you want to notify this " + this.getEmployeeType(actor).toLowerCase() + Constants.YES_NO));
		}

		if(Arrays.asList("A", "R", "W").contains(actor) && flgValid==1) {
			actions.add(new CardViewAction(1, "View Previous Complaints", Constants.POST, commonService.getUIModuleId("VPC"+actor), Constants.GENERICMODELPOPUP));
		}

		if((Arrays.asList("R", "W").contains(actor) || (actor.equals("A") && flgValid==0)) && commonService.checkIsActionEnabled("2", "RMVEMP", Session.getCaseDetails().getStatus())) {
			actions.add(new CardViewAction("Remove " + this.getEmployeeType(actor), Constants.SERVICEURL, MessageFormat.format(property.getRemoveEmployeeURL(), String.valueOf(transactionid)), Constants.POST, "Are you sure you want to remove this " + this.getEmployeeType(actor).toLowerCase() + Constants.YES_NO));
		}
		
		return actions;
	}


	private String getEmployeeType(String type) {
		if(type.equals("A"))
			return Constants.COMPLAINANT;
		else if(type.equals("R"))
			return Constants.RESPONDENT;
		else if(type.equals("W"))
			return Constants.WITNESS;
		else if(type.equals("T"))
			return Constants.CO_COMPLAINANT;
		else if(type.equals("S"))
			return Constants.STAKEHOLDER;
		else
			return "";
	}

	private String getActor(String type) {
		if(type.equals(Constants.COMPLAINANT))
			return "A";
		else if(type.equals(Constants.RESPONDENT))
			return "R";
		else if(type.equals(Constants.WITNESS))
			return "W";
		else if(type.equals(Constants.CO_COMPLAINANT))
			return "T";
		else
			return "";
	}

	private String checkNull(String str) {
		if(str!=null && !str.isEmpty())
			return str.trim();
		else
			return "NA";
	}

	private boolean notNullOrEmpty(String str) {

		return str!=null && !str.isEmpty();
	}

	private boolean nullOrEmptyOrSelect(String str) {

		return str==null || str.isEmpty() || str.equalsIgnoreCase(Constants.SELECT);
	}

	private boolean isNullOrEmpty(String str) {

		return str==null || str.isEmpty();
	}


	@Override
	public LabelView getLocationAndCategoryDetails(int caseid) {
		ELCMECTrnASHICaseDetails caseDetails = Session.getCaseDetails().getCaseDetails();
		List<CardViewAction> actions = new ArrayList<>();

		List<CardViewField> fieldList=new ArrayList<>();

		fieldList.add(new CardViewField("Incident Date", new SimpleDateFormat(Constants.DATE_FORMAT).format(caseDetails.getIncidentDate()), 14));
		fieldList.add(new CardViewField("Location Of Complainant", this.notNullOrEmpty(caseDetails.getSelectedCity()) ? caseDetails.getSelectedCity().trim() : Message.NOTAVAILABLE, 14));

		List<GenModelOption> categoryOptions=concernModulesDetailsRepository.findASHICategories(2, Session.getCaseDetails().getCompany(), Session.getCaseDetails().getCountry());
		GenModelOption selectedCategory = categoryOptions.stream().filter(a -> a.getKey().equals(String.valueOf(caseDetails.getCategoryId()))).findFirst().orElse(null);
		fieldList.add(new CardViewField("Category of Concern", selectedCategory!=null ? selectedCategory.getValue().trim() : Message.NOTAVAILABLE, 14));

		fieldList.add(new CardViewField("Case Classification", this.notNullOrEmpty(caseDetails.getPlaceOfIncident()) ? caseDetails.getPlaceOfIncident().trim() : Message.NOTAVAILABLE, 14));

		if(commonService.checkIsActionEnabled("2", "UDILCP", Session.getCaseDetails().getStatus()))
			actions.add(new CardViewAction(1, Constants.UPDATE, Constants.POST, commonService.getUIModuleId("LC"), Constants.GENERICMODELPOPUP));


		return new LabelView(Constants.CASE_DETAILS, "labelview", fieldList, actions, String.valueOf(caseid));

	}


	@Override
	public GenModel getLocationAndCategoryGenmodel(int caseid) throws CustomException {
		List<GenModelField> fields=new ArrayList<>();

		ELCMECTrnASHICaseDetails caseDetails = Session.getCaseDetails().getCaseDetails();

		if(this.notNullOrEmpty(caseDetails.getSelectedCountry()) && this.notNullOrEmpty(caseDetails.getSelectedCity())) {
			GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
			caseidField.setEditable(false);
			fields.add(caseidField);
			
			GenModelField discussedOn =new GenModelField(15, "incidentDate", "Incident Date", "", false, true);
			discussedOn.setData(new SimpleDateFormat(Constants.DATE_FORMAT).format(caseDetails.getIncidentDate()));
			fields.add(discussedOn);

			List<GenModelOption> countryOptions=reachCountryDetailsRepository.findDistinctByModuleIdAndIsEnableNew(2, 1);
			countryOptions.add(0, new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

			GenModelOption selectedCountry = countryOptions.stream().filter(a -> a.getValue().equals(caseDetails.getSelectedCountry().trim())).findFirst().orElse(new GenModelOption(Constants.SELECT, WordUtils.capitalize(Constants.SELECT), true));

			GenModelField country=new GenModelField( 11, Constants.COUNTRY.toLowerCase(), Constants.COUNTRY, caseDetails.getSelectedCountry(), "", countryOptions, true);
			fields.add(country);

			List<GenModelOption> cities = ashiService.getCitiesByCountryCode(selectedCountry.getValue());

			GenModelField city=new GenModelField( 11, "baseLocation", "Base Location", caseDetails.getSelectedCity(), Constants.COUNTRY.toLowerCase(), cities, true);
			city.setDependantAction(property.getBaselocationbycountrycodeURL());
			fields.add(city);

			List<GenModelOption> categoryOptions=concernModulesDetailsRepository.findASHICategories(2, Session.getCaseDetails().getCompany(), Session.getCaseDetails().getCountry());
			GenModelOption selectedCategory = categoryOptions.stream().filter(a -> a.getKey().equals(String.valueOf(caseDetails.getCategoryId()))).findFirst().orElse(categoryOptions.get(0));


			GenModelField complaintCategory=new GenModelField( 18, Constants.COMPLAINT_CATEGORY, "Category Of Concern", caseDetails.getCategoryId()==0?"":selectedCategory.getValue(), "",categoryOptions, true);
			fields.add(complaintCategory);


			List<GenModelOption> placeOfIncidentOptions=new ArrayList<>();
			placeOfIncidentOptions.add(new GenModelOption(1, "Workplace"));
			placeOfIncidentOptions.add(new GenModelOption(2, "Extended workplace"));

			GenModelField placeOfIncident=new GenModelField( 18, "placeOfIncident", "Case Classification", this.notNullOrEmpty(caseDetails.getPlaceOfIncident())?caseDetails.getPlaceOfIncident():"", "",placeOfIncidentOptions, true);
			fields.add(placeOfIncident);
		}

		return new GenModel("Location and Category", fields, Arrays.asList(new CardViewAction(1, "Save", Constants.POST, property.getUpdateLocationURL(), Constants.SERVICEURL)));
	}

	@Override
	public Response updateLocationAndCategoryDetails(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		
		commonService.checkCaseAuthorization(fields.getCaseid(), true);
		if(!Session.isAuthorized())
			return new Response(Message.ACCESSDENIED);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(caseDetails.isPresent()) {
			
			if(this.nullOrEmptyOrSelect(fields.getIncidentDate()))
				return new Response("Please provide incident date.");
			
			if(this.nullOrEmptyOrSelect(fields.getCountry()))
				return new Response("Please select country.");

			if(this.nullOrEmptyOrSelect(fields.getBaseLocation()))
				return new Response("Please select base location.");

			if(fields.getComplaintCategory()<1)
				return new Response("Please select valid complaint category.");

			if(this.nullOrEmptyOrSelect(fields.getPlaceOfIncident()))
				return new Response("Please select case classification.");

			ELCMECTrnASHICaseDetails updatedCaseDetails = caseDetails.get();
			updatedCaseDetails.setIncidentDate(new Timestamp(DateTimeFormat.forPattern(Constants.DATE_FORMAT).parseMillis(fields.getIncidentDate())));
			updatedCaseDetails.setSelectedCountry(fields.getCountry());
			updatedCaseDetails.setSelectedCity(fields.getBaseLocation());
			updatedCaseDetails.setCategoryId(fields.getComplaintCategory());
			updatedCaseDetails.setPlaceOfIncident(fields.getPlaceOfIncident());
			updatedCaseDetails.setModifiedBy(Session.getTokenEMPNO());
			updatedCaseDetails.setModifiedOn(currentDateTime);
			caseDetailsRepository.save(updatedCaseDetails);

			return new Response(Constants.SUCCESSHIDEFORM, "Successfully updated.");
		}

		return new Response(Message.CASENOTREGISTERED);
	}


	@Override
	public GenModel addPreliminaryDiscussionDetails(int caseId) throws CustomException{
		List<GenModelField> fields = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseId, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> complainants=caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseId, Arrays.asList("A","T"));
		complainants.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT, true));

		GenModelField discussedOn =new GenModelField(16, "discussedOn", "Discussed On", "", false, true);
		fields.add(discussedOn);

		GenModelField discussedWith=new GenModelField( 11, "discussedWith", "With", Constants.SELECT, "",complainants, true);
		fields.add(discussedWith);

		GenModelField summaryOfDiscussion=new GenModelField( 1, "summaryOfDiscussion", "Summary of discussion","", "","Enter summary/outcome of the meeting", true);
		fields.add(summaryOfDiscussion);

		//Document form

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField evidences=new GenModelField( 60, Constants.DOCUMENTS.toLowerCase(), "Add Document",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);
		fields.add(evidences);

		List<CardViewAction> actions = Arrays.asList(new CardViewAction(1, "Add", Constants.POST, property.getAddPreliminaryDiscussionURL(), Constants.SERVICEURL), new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));

		return new GenModel("Add Discussion Details", fields, actions);

	}

	@Override
	public CardView getPreliminaryDiscussions(int caseId, int showtop2) throws CustomException{

		List<PreliminaryDiscussionDetails> preliminaryDiscussionDetails=preliminaryDiscussionDetailsRepository.findByIntCaseID(caseId);
		List<Card> discussions = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		String addPreliminaryDiscussionMID = commonService.getUIModuleId("ADPD");
		String viewAllPreliminaryDiscussionMID = commonService.getUIModuleId("VAPD");

		if(preliminaryDiscussionDetails.size()>2 && showtop2==1) {
			actions.add(new CardViewAction(2, Constants.VIEW_ALL, Constants.POST, viewAllPreliminaryDiscussionMID, Constants.GENERICMODELPOPUP));
			preliminaryDiscussionDetails = preliminaryDiscussionDetails.subList(0, 2);
		}

		for(PreliminaryDiscussionDetails discussion : preliminaryDiscussionDetails) {
			List<CardViewField> fields = new ArrayList<>();
			fields.add(new CardViewField("Discussed On", discussion.getCreatedOn(), 14));
			fields.add(new CardViewField("Discussed With", discussion.getDiscussedWith(), 14));
			fields.add(new CardViewField("Updated By", discussion.getRole(), 14));
			fields.add(new CardViewField("Summary Of Discussion", discussion.getDiscussionSummary(), 54));

			if(!discussion.getDocuments().isEmpty()) {
				fields.add(new CardViewField(Constants.DOCUMENTS, "", 88));
				for(String document : discussion.getDocuments()) {
					fields.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "P", discussion.getTransactionid(), document.trim()), 35));
				}
				
				if(discussion.getDocuments().size()>1)
					fields.add(new CardViewField(Constants.DOWNLOADALL, MessageFormat.format(property.getDownloadURL(), "P", discussion.getTransactionid(), Constants.ALL), 87));
			}


			discussions.add(new Card("", fields));
		}

		if(preliminaryDiscussionDetails.isEmpty())
			discussions.add(new Card("", Arrays.asList(new CardViewField("", "No discussion details added yet.", 54))));

		if(showtop2==1 && commonService.checkIsActionEnabled("2", "ADDPD", Session.getCaseDetails().getStatus()))
			actions.add(new CardViewAction(2, "Add Discussion Details", Constants.POST, addPreliminaryDiscussionMID, Constants.GENERICMODELPOPUP));


		return new CardView("", discussions, "Discussion With complainant", caseId, actions);
	}


	@Override
	public Response addPreliminaryDiscusionDetails(GenModel genmodel) throws CustomException{
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(this.nullOrEmptyOrSelect(fields.getDiscussedOn()))
			return new Response("Please provide when discussion was happened.");

		if(this.nullOrEmptyOrSelect(fields.getDiscussedWith()))
			return new Response("Please provide with whom discussion was happened.");

		if(this.nullOrEmptyOrSelect(fields.getDiscussionSummary()))
			return new Response("Please provide summary of the discussion.");


		String dmsFiles=commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIPreliminaryDiscussionFolder());

		if(dmsFiles.startsWith(Message.INVALID_FILE))
			return new Response(dmsFiles);

		ELCMECMstASHIPreliminaryDiscussionDetails obj=new ELCMECMstASHIPreliminaryDiscussionDetails(fields, Session.getTokenEMPNO(), "GRB", dmsFiles);
		preliminaryDiscussionDetailsRepository.save(obj);   
		this.updateLastActionTaken(caseDetails.get(), "Preliminary discussion by GRB");
		return new Response(Constants.SUCCESSHIDEFORM, "Successfully Added Discussion Details");
	}

	@Override
	public GenModel getInboxActionForms(int caseid, String type) {
		if(type.equalsIgnoreCase("SLA")) {
			return this.getSLAExtension(caseid);
		}
		else if(type.equalsIgnoreCase("IRA")) {
			return this.getInterimReliefForApproval(caseid);
		}
		else if(type.equalsIgnoreCase("CIA")) {
			return this.getConciliationInitiationForApproval(caseid);
		}
		else if(type.equalsIgnoreCase("CRA")) {
			return this.getConciliationReportForApproval(caseid);
		}
		
		else if(type.equalsIgnoreCase("DMRI")) {
			return this.updateCaseStatusGenmodel(caseid, "DMRI");
		}
		else
			return new GenModel();
	}

	private GenModel getSLAExtension(int caseid) {	
		List<GenModelField> sLAFieldList = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		
		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		sLAFieldList.add(caseidField);

		GenModelField slaEndDate=new GenModelField(14, "slaEndDate", "SLA Expiry Date", "", "", "", true);

		GenModelField extendtill=new GenModelField(16, "slaExtendDate", "Extend till", "", "", "", true);

		List<GenModelOption> extensionReasonOptions=genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "ER");

		GenModelField extensionReason=new GenModelField( 11, "extensionReason", "Please select reason for SLA extension request", extensionReasonOptions.get(0).getValue(), "", extensionReasonOptions, true);


		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = slaDetailsRepository.findByCaseIdAndRole(caseid, "IC");

		if(slaDetails.isPresent()) {
			slaEndDate.setData(new SimpleDateFormat("dd MMM, yyyy").format(slaDetails.get().getSlaEndDate()));

			if(slaDetails.get().getFlgSLAExtensionRequest()==1) {
				Optional<ELCMECtrnASHISLAAuditTrial> slaExtensionDetails = slaAuditTrialRepository.findBySlaIdAndStatus(slaDetails.get().getSlaId(), "Requested");

				if(slaExtensionDetails.isPresent()) {
					extendtill.setType(14);
					extendtill.setData(new SimpleDateFormat("dd MMM, yyyy").format(slaExtensionDetails.get().getSlaExtensionDate()));

					extensionReason.setType(14);
					extensionReason.setData(slaExtensionDetails.get().getReason());

					GenModelField commentByIC=new GenModelField(14, "commentByIC", "Comment by IC","","", "", true);
					commentByIC.setData(slaExtensionDetails.get().getRemarks());
					sLAFieldList.add(commentByIC);

					actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getSlaExtensionActionURL(), true, true, String.valueOf(slaExtensionDetails.get().getExtensionId())), Constants.SERVICEURL));
					actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getSlaExtensionActionURL(), true, false, String.valueOf(slaExtensionDetails.get().getExtensionId())), Constants.SERVICEURL));
				}
			}

			else if(slaDetails.get().getFlgSLAExtensionRequest()!=1) {
				actions.add(new CardViewAction(1, Constants.SUBMIT, Constants.POST, MessageFormat.format(property.getSlaExtensionActionURL(), false, true, ""), Constants.SERVICEURL));
				actions.add(new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));
			}


		}

		sLAFieldList.add(slaEndDate);
		sLAFieldList.add(extendtill);

		sLAFieldList.add(extensionReason);

		GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		sLAFieldList.add(comments);

		return new GenModel("SLA Extension", sLAFieldList, actions);
	}


	private GenModel getInterimReliefForApproval(int caseid) {
		List<GenModelField> interimReliefList = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		interimReliefList.add(caseidField);

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = interimReliefRepository.findByCaseIdAndFlgReliefAndFlgActionTaken(caseid, 1, 0);

		if(interimRelief.isPresent()) {
			List<GenModelOption> reliefs = new ArrayList<>();
			for(String relief : interimRelief.get().getReliefs().split(",")) {
				reliefs.add(new GenModelOption(relief, relief));
			}

			GenModelField reliefField=new GenModelField(120, "interimReliefs", "", "", "", "", true);
			reliefField.setOptions(reliefs);
			interimReliefList.add(reliefField);

			GenModelField reason=new GenModelField(14, "reason", Constants.REASON, "", "", "", true);
			reason.setData(interimRelief.get().getRemarks());
			interimReliefList.add(reason);

			GenModelField comments=new GenModelField(0, Constants.COMMENTS.toLowerCase(), Constants.COMMENTS,"","", "", true);
			comments.setPlaceHolder(Constants.COMMENTS_PH);
			interimReliefList.add(comments);

			actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getInterimReliefActionURL(), Constants.APPROVED), Constants.SERVICEURL));
			actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getInterimReliefActionURL(), Constants.REJECTED), Constants.SERVICEURL));
		}

		return new GenModel(Constants.INTERIM_RELIEF, interimReliefList, actions);

	}

	@Override
	public Response takeActionOnInterimRelief(String action, GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(this.isNullOrEmpty(fields.getComments()))
			return new Response("Kindly provide comments");

		if(!Arrays.asList(Constants.APPROVED,Constants.REJECTED).contains(action))
			return new Response("Invalid action.");

		Optional<ELCMECTrnASHIInterimReliefDetails> interimRelief = interimReliefRepository.findByCaseId(fields.getCaseid());

		if(interimRelief.isPresent()) {
			if(interimRelief.get().getFlgActionTaken()==0) {
				ELCMECTrnASHIInterimReliefDetails updatedInterimRelief = interimRelief.get();
				updatedInterimRelief.setApprovalStatus(action);
				updatedInterimRelief.setApprovedBy(Session.getTokenEMPNO());
				updatedInterimRelief.setApprovedDate(currentDateTime);
				updatedInterimRelief.setApproverRemarks(fields.getComments());
				updatedInterimRelief.setApproverRole("GRB");
				updatedInterimRelief.setFlgActionTaken(1);

				interimReliefRepository.save(updatedInterimRelief);
				this.triggerInterimReliefMail(updatedInterimRelief.getCaseId(), updatedInterimRelief.getApprovalStatus());

				return new Response(Constants.SUCCESSHIDEFORM, Message.SUCCESSFULLY_NEW + action);
			}
			else
				return new Response("Already " + interimRelief.get().getApprovalStatus().trim());
		}
		else
			return new Response("Interim relief not submitted yet");
	}
	
	private void triggerInterimReliefMail(int caseid, String action) throws CustomException {
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(caseid, "IC");
		MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(action.isEmpty() ? "ASHIIR" : "ASHIIRAR");
		
		if(mailInfo==null || !assigneeDetails.isPresent())
			throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);

		String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
		String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
		String subject = mailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.ACTION_PH, action.toLowerCase());
		String body = mailInfo.getBody().replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, assigneeDetails.get().getAssigneeLocation().trim()).replace(Constants.ACTION_PH, action.toLowerCase());
		MailInfo interimReliefMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), "", "");
		
		if(action.isEmpty()) {
			interimReliefMailInfoObj.setToId(grbIds);
			interimReliefMailInfoObj.setCcId(icIds);
		}
		else {
			interimReliefMailInfoObj.setToId(icIds);
			interimReliefMailInfoObj.setCcId(grbIds);
		}
		
		PlaceHolder[] interimReliefPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

		MailerAssistRequest mailObj=new MailerAssistRequest(interimReliefMailInfoObj, interimReliefPlaceHolders);

		MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
		if(mailerResponse.getCode()!=0)
			throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
	}

	private GenModel getConciliationInitiationForApproval(int caseid) {
		List<GenModelField> conciliationReportList = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(caseid);

		if(actionObj.isPresent() && actionObj.get().getStatus().equals("CIA")) {
			GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
			caseidField.setEditable(false);
			conciliationReportList.add(caseidField);

			GenModelField conciliationReason=new GenModelField(14, "conciliationReason", Constants.REASON_FOR_CONCILIATION, "", "", "", true);
			conciliationReason.setData(actionObj.get().getComments());
			conciliationReportList.add(conciliationReason);

			GenModelField comments=new GenModelField(0, Constants.REMARKS.toLowerCase(), Constants.COMMENTS,"","", "", true);
			comments.setPlaceHolder(Constants.COMMENTS_PH);
			conciliationReportList.add(comments);

			actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "PCR"), Constants.SERVICEURL));
			actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "CIR"), Constants.SERVICEURL));
		}

		return new GenModel("", conciliationReportList, actions);

	}

	private GenModel getConciliationReportForApproval(int caseid) {
		List<GenModelField> conciliationReportList = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		conciliationReportList.add(caseidField);

		Optional<ELCMECTrnASHIConciliationReportDetails> report = conciliationReportDetailsRepository.findByCaseId(caseid);

		if(report.isPresent()) {

			String[] files = report.get().getAgreementDocs().split(",");

			for(String file : files) {
				GenModelField conciliationReport=new GenModelField(82, "conciliationReport", file, "", MessageFormat.format(property.getDownloadURL(), "CRA", String.valueOf(report.get().getSerialNo()), file), "", true);
				conciliationReportList.add(conciliationReport);
			}

		}


		GenModelField comments=new GenModelField(0, Constants.REMARKS.toLowerCase(), Constants.COMMENTS,"","", "", true);
		comments.setPlaceHolder(Constants.COMMENTS_PH);
		conciliationReportList.add(comments);

		List<CardViewAction> actions = new ArrayList<>();
		actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "WEC"), Constants.SERVICEURL));
		actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "CRR"), Constants.SERVICEURL));

		return new GenModel("", conciliationReportList, actions);

	}

	@Override
	public Response removeEmployee(int transactionid) throws CustomException{
		Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = caseEmployeeDetailsRepository.findById(transactionid);
		if(employeeDetails.isPresent() && employeeDetails.get().getFlgActive()==1) {
		
			if(employeeDetails.get().getFlgValid()==1) {
				ELCMECMstASHICaseEmployeeDetails updatedEmployeeDetails = employeeDetails.get();
				updatedEmployeeDetails.setFlgActive(0);
				caseEmployeeDetailsRepository.save(updatedEmployeeDetails);
				StringBuilder message = new StringBuilder("Successfully removed ").append(this.getEmployeeType(updatedEmployeeDetails.getActor())).append(" ").append(updatedEmployeeDetails.getEmpName().trim());

				return new Response(Message.SUCCESS, message.toString());
			}
			else if(employeeDetails.get().getFlgValid()==0) {
				caseEmployeeDetailsRepository.delete(employeeDetails.get());
				StringBuilder message = new StringBuilder("Successfully removed ").append(this.getEmployeeType(employeeDetails.get().getActor())).append(" ").append(employeeDetails.get().getEmpName().trim());

				return new Response(Message.SUCCESS, message.toString());
			}

		}
		return new Response("Details not found.");
			
	}

	@Override
	public GenModel addEmployeeGenModel(int caseid, String type) {
		List<GenModelField> fieldList=new ArrayList<>();
		List<CardViewAction> actionList=new ArrayList<>();

		String name = "";
		String displayname = "";
		String title = "";
		if(type.equals("A")) {
			name = "cocomplainants";
			displayname = "Co-Complainants of the case";
			title = "Add Co-Complainant";
		}
		else if(type.equals("R")) {
			name = "respondentsInfy";
			displayname = "Respondents of the case";
			title = "Add Respondent";
		}
		else if(type.equals("W")) {
			name = "witnesses";
			displayname = "Witnesses of the case";
			title = "Add Witness";
		}

		if(!name.isEmpty() && !displayname.isEmpty()) {
			GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
			caseidField.setEditable(false);
			fieldList.add(caseidField);

			GenModelField employeeField=new GenModelField( 46, name, displayname, "", property.getEmployeeSearchURL(), Message.EMPID_OR_EMPNO, true);
			fieldList.add(employeeField);

			actionList.add(new CardViewAction(1, "Add", Constants.POST, property.getAddEmployeeURL(), Constants.SERVICEURL));
			actionList.add(new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));
		}
		return new GenModel(title, fieldList, actionList);
	}

	@Override
	public Response addEmployee(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		String actor = "";
		String idString = "";
		if(this.notNullOrEmpty(fields.getWitnesses())) {
			actor = "W";
			idString = fields.getWitnesses();
		}

		else if(this.notNullOrEmpty(fields.getRespondentsInfy())) {
			actor = "R";
			idString = fields.getRespondentsInfy();
		}

		else if(this.notNullOrEmpty(fields.getCocomplainants())) {
			actor = "T";
			idString = fields.getCocomplainants();
		}

		List<ViewCurrEmpAllDetails> ids = new ArrayList<>();
		if(!actor.isEmpty()) {
			CaseDetailsValidationResponse response = commonService.validateEmployeeDetails(idString, this.getEmployeeType(actor));

			if(!response.isStatus())
				return new Response(response.getMessage());

			ids.addAll(response.getIds());

			String msg = this.validateCaseEmployeeDuplicacy(fields.getCaseid(), response.getIds(), Arrays.asList("R","W","A"));

			if(!msg.isEmpty())
				return new Response(msg);
		}

		if(actor.equals("R") || actor.equals("W")) {


			this.insertOrUpdateEmployeeDetails(caseDetails.get(), ids, actor);

			return new Response(Constants.SUCCESSHIDEFORM, "New " + this.getEmployeeType(actor) + " successfully added.");
		}
		else if(actor.equals("T")) {

			List<ELCMECMstASHICocomplainantsDetails> ashiCocomplainantsDetailsList=new ArrayList<>();

			for(ViewCurrEmpAllDetails id : ids) {
				ashiCocomplainantsDetailsList.add(new ELCMECMstASHICocomplainantsDetails(fields.getCaseid(), id.getMailId()));
			}		
			ashiCocomplainantsDetailsRepository.saveAll(ashiCocomplainantsDetailsList);

			return new Response(Constants.SUCCESSHIDEFORM, "New " + this.getEmployeeType(actor) + " successfully added.");
		}
		else
			return new Response("Invalid input");
	}


	private String validateCaseEmployeeDuplicacy(int caseid, List<ViewCurrEmpAllDetails> ids, List<String> comparisonTypes) {
		for(ViewCurrEmpAllDetails id : ids) {
			List<ELCMECMstASHICaseEmployeeDetails> details = caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActorIn(caseid, id.getMailId(), 1, 1, comparisonTypes);

			if(!details.isEmpty()) {
				return "Id " + id.getMailId() + " has already been added as " + this.getEmployeeType(details.get(0).getActor());
			}
		}

		return "";
	}

	private void insertOrUpdateEmployeeDetails(ELCMECTrnASHICaseDetails caseDetails, List<ViewCurrEmpAllDetails> ids, String type) throws CustomException{
		List<ELCMECMstASHICaseEmployeeDetails> employeeList = new ArrayList<>();

		for(ViewCurrEmpAllDetails id : ids) {
			Optional<ELCMECMstASHICaseEmployeeDetails> details = caseEmployeeDetailsRepository.findByCaseIdAndMailIdAndFlgActiveAndFlgValidAndActor(caseDetails.getCaseId(), id.getMailId(), 0, 1, type);

			if(details.isPresent()) {
				ELCMECMstASHICaseEmployeeDetails updatedDetails = details.get();
				updatedDetails.setFlgActive(1);
				employeeList.add(updatedDetails);
				
			}
			else {
				List<CaseEmployeeDetails> complainantDetails=hrisMstEmployeeRepository.findCaseEmployeeDetails(id.getEmpNo());
				if(!complainantDetails.isEmpty())
					employeeList.add(new ELCMECMstASHICaseEmployeeDetails(caseDetails.getCaseId(), complainantDetails.get(0), type, ""));
				else
					throw new CustomException("Details for id "+id.getMailId()+Constants.UNAVAILABLE);

			}

		}

		if(!employeeList.isEmpty())
			caseEmployeeDetailsRepository.saveAll(employeeList);
	}

	@Override
	public CardView viewPreviousComplaints(String actor, String empno) {
		String employeeName = "";
		String adminInboxModuleId = commonService.getUIModuleId("ADCS");
		Optional<HRISMstEmployee> employee = hrisMstEmployeeRepository.findById(empno);
		if(employee.isPresent()) {
			employeeName = WordUtils.capitalize(employee.get().getEmpName().toLowerCase().trim());
		}
		else
			employeeName = empno;
		List<Card> previousCases=caseDetailsRepository.findPreviousCaseByActorAndEmpno(empno, actor);

		for(Card card : previousCases) {
			card.setActions(Arrays.asList(new CardViewAction("View All Details", adminInboxModuleId, "caseid="+card.getCardID())));
		}

		return new CardView("Previous cases", "Previous Complaints of " + employeeName, previousCases);
	}


	@Override
	public GenModel getActions(int caseid) {
		List<CardViewAction> actions = new ArrayList<>();

		List<ELCMECMstReachWorkFlow> workflows = workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveOrderByActionLabelAsc(2, Session.getCaseDetails().getStatus(), 1);

		for(ELCMECMstReachWorkFlow workflow : workflows) {
			if(this.notNullOrEmpty(workflow.getActionLabel())) {
				actions.add(new CardViewAction(1, workflow.getActionLabel().trim(), Constants.POST, String.valueOf(workflow.getUiModuleId()), workflow.getType().trim()));
			}
		}
		
		if(commonService.checkIsActionEnabled("2", "DLFRP", Session.getCaseDetails().getStatus())) {
			actions.add(new CardViewAction(1, "Download Report", Constants.POST, MessageFormat.format(property.getDownloadformalReportURL(), caseid), "downloaddocument"));
		}

		return new GenModel("", new ArrayList<>(), actions);
	}
	
	@Override
	public AccordionView getAccordions(int caseid) {
		List<Accordion> accordions = new ArrayList<>();
		List<AccordionModel> accordionModels = accordionsMappingRepository.findAccordionsByModuleIdAndStatus(2, Session.getCaseDetails().getStatus());
		boolean isInterimReliefPresent = interimReliefRepository.existsByCaseId(caseid);
		
		for(AccordionModel accordionModel : accordionModels) {

			if(accordionModel.getHeading().equals(Constants.INTERIM_RELIEF)) {
				if(isInterimReliefPresent && accordionModel.getType().equals(Constants.LABELVIEW_TYPE1))
					accordions.add(new Accordion(accordionModel.getHeading(), Arrays.asList(new CardViewAction(2, "", accordionModel.getApiType(), accordionModel.getValue().replace(Constants.CASEID_PH, String.valueOf(caseid)), Constants.LABELVIEW_TYPE1))));

				else if(!isInterimReliefPresent && accordionModel.getType().equals(Constants.GENMODEL))
					accordions.add(new Accordion(accordionModel.getHeading(), Arrays.asList(new CardViewAction(2, "", accordionModel.getApiType(), accordionModel.getValue().replace(Constants.CASEID_PH, String.valueOf(caseid)), Constants.GENMODEL))));
			}
			else {

				Optional<Accordion> accordion = accordions.stream().filter(a -> a.getHeading().equals(accordionModel.getHeading())).findFirst();

				if(accordion.isPresent()) {
					List<CardViewAction> actions = new ArrayList<>();
					actions.addAll(accordion.get().getActions());
					actions.add(new CardViewAction(2, "", accordionModel.getApiType(), accordionModel.getValue().replace(Constants.CASEID_PH, String.valueOf(caseid)), accordionModel.getType()));
							
					accordion.get().setActions(actions);
				}
				else {
					accordions.add(new Accordion(accordionModel.getHeading(), Arrays.asList(new CardViewAction(2, "", accordionModel.getApiType(), accordionModel.getValue().replace(Constants.CASEID_PH, String.valueOf(caseid)), accordionModel.getType()))));
				}
			}
		}

		return new AccordionView("", "accordionfromapp", accordions);

	}
	

	@Override
	public GenModel updateCaseStatusGenmodel(int caseid, String action) {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		String displayName = "";
		String placeholder = "";
		String message = "";

		if(action.equals("CLN")) {
			displayName = "Reason for closing the case";
			placeholder = "Provide explanation for closing the case in more than 100 words";
			message = "Once closed, the case cannot be reopened. Are you sure you want to close the case?";
			actions.add(new CardViewAction(1, "No", "", "", ""));
			actions.add(new CardViewAction(1, "Yes, Close Case", Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(caseid), action), Constants.SERVICEURL));
		}
		else if(action.equals("DM")) {
			displayName = "Reason for dismissal";
			placeholder = "Provide explanation for dismissal of the case in more than 100 words";
			message = "Once dismissed, the case cannot be reopened. Are you sure you want to dismiss the case?";
			actions.add(new CardViewAction(1, "No", "", "", ""));
			actions.add(new CardViewAction(1, "Yes, Dismiss Case", Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(caseid), action), Constants.SERVICEURL));
		}
		else if(action.equals("OI")) {
			displayName = "Reason for offline investigation";
			placeholder = "Provide explanation in more than 100 words";
			message = "Once marked, it cannot be undone. Are you sure you want to mark the case for offline investigation?";
			actions.add(new CardViewAction(1, "No", "", "", ""));
			actions.add(new CardViewAction(1, "Yes, Mark Case", Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(caseid), action), Constants.SERVICEURL));
		}
		else if(action.equals("DMRI")) {
			displayName = "Reason for dismissal";
			placeholder = "";
			message = "Once dismissed, the case cannot be reopened. Are you sure you want to approve the case dismissal?";
			actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(caseid), "DM"), Constants.SERVICEURL));
			actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getUpdateCaseStatusURL(), String.valueOf(caseid), "WI"), Constants.SERVICEURL));
		}

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, displayName,"", "","", true);
		comments.setPlaceHolder(placeholder);
		fields.add(comments);

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField documents=new GenModelField( 60, Constants.DOCUMENTS.toLowerCase(), "Add Documents",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);

		if(!action.equals("OI"))
			fields.add(documents);

		GenModelField messagefield=new GenModelField( 54, "", "","", "","", true);
		messagefield.setData(message);
		fields.add(messagefield);

		return new GenModel("", fields, actions);
	}

	@Override
	public Response updateCaseStatus(int caseid, String action, String empNo, GenModel genmodel) throws CustomException {
		String adminInboxMID = commonService.getUIModuleId("ADIN");

		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(caseid);
		if(this.isNullOrEmpty(fields.getComments()))
			return new Response("Please provide comments");

		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(caseid);
		if(actionObj.isPresent() && Arrays.asList("CLN", "DM", "OI").contains(actionObj.get().getStatus())) {
				return new Response("Unable to take action. Current case status is "+actionObj.get().getStatusDesc());

		}

		String dmsFiles=commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIInvestigationDocsFolder());

		if(dmsFiles.startsWith(Message.INVALID_FILE))
			return new Response(dmsFiles);

		if(caseDetails.isPresent()) {
			UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, fields.getComments(), dmsFiles, action, "", "");
			if(response.isSuccess()) {
				this.triggerMails(caseid, response.getAssigneeLocation(), response.getMailEventCode(), fields.getComments());
				return new Response(Message.SUCCESSPROCEED, response.getMessage(), "", adminInboxMID);
			}
			else
				return new Response(Message.UNABLE_TO_PROCEED);
		}
		else
			return new Response(Message.CASENOTREGISTERED);
	}
	
	
	@Override
	public GenModel getAssignCaseGenmodel(int caseid) throws CustomException {
		List<GenModelField> fields = new ArrayList<>();
		ELCMECTrnASHICaseDetails caseDetails = Session.getCaseDetails().getCaseDetails();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> roleOptions = new ArrayList<>();
		String selectedRole = "";
		if(caseDetails.getStatus().trim().equals("WE")) {
			roleOptions = commonService.getCAMSRoles("2", "No", Arrays.asList("GRB"));
			selectedRole = "GRB";
		}
		else if(caseDetails.getStatus().trim().equals("WG")) {
			roleOptions = commonService.getCAMSRoles("2", "No", Arrays.asList("IC"));
			selectedRole = "IC";
		}

		GenModelField assignedRoleField=new GenModelField( 11, "assignedRole", "Assign Case To", selectedRole, "", roleOptions, true);
		fields.add(assignedRoleField);

		if(caseDetails.getStatus().trim().equals("WG")) {
			GenModelField assignedLocationField=new GenModelField( 11, "assignedLocation", "Choose Location", "", "assignedRole", new ArrayList<>(), true);
			assignedLocationField.setDependantAction(MessageFormat.format(property.getContextURL(), Session.getCaseDetails().getModuleId(), "IC", Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "", "No") + "|" + Constants.POST);
			fields.add(assignedLocationField);
		}


		GenModelField commentsForIC=new GenModelField( 1, Constants.COMMENTS, "Comments","", "","", true);
		fields.add(commentsForIC);

		return new GenModel(Constants.ASSIGN_CASE, fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getAssignCaseURL(), Constants.SERVICEURL)));
	}


	@Override
	public Response assignCase(String empNo, GenModel genmodel) throws CustomException {
		String adminInboxMID = commonService.getUIModuleId("ADIN");
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(this.nullOrEmptyOrSelect(fields.getAssignedRole()))
			return new Response("Please select role");

		if(fields.getAssignedRole().equals("IC") && this.nullOrEmptyOrSelect(fields.getAssignedLocation()))
			return new Response("Please select location");

		if(this.isNullOrEmpty(fields.getComments()))
			return new Response("Please provide comments");

		String status = "";
		String assigneeLocation = "";
		if(fields.getAssignedRole().equals("GRB")) {
			status = "WG";
		}
		else if(fields.getAssignedRole().equals("IC")) {
			status = "WI";
			assigneeLocation = fields.getAssignedLocation();
		}

		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(fields.getCaseid());
		if(actionObj.isPresent() && status.equals(actionObj.get().getStatus().trim()))
			return new Response("Case is already "+actionObj.get().getStatusDesc());



		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, fields.getComments(), "", status, "", assigneeLocation);
		if(response.isSuccess()) {
			this.triggerMails(caseDetails.get().getCaseId(), response.getAssigneeLocation(), response.getMailEventCode(), fields.getComments());
			return new Response(Message.SUCCESSPROCEED, MessageFormat.format(response.getMessage(), String.valueOf(fields.getCaseid()), WordUtils.capitalize(assigneeLocation)), "", adminInboxMID);
		}

		return new Response("Can't assign case to " + fields.getAssignedRole());
	}


	@Override
	public GenModel seekInputGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> complainants=caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("A","T"));
		complainants.add(0, new GenModelOption(Constants.SELECT, Constants.SELECT, true));

		GenModelField complainant=new GenModelField( 39, "complainant", "Choose Complainant", Constants.SELECT, "",complainants, true);
		fields.add(complainant);

		GenModelField comments=new GenModelField( 1, Constants.COMMENTS, "Seek Inputs from Complainant","", "","Enter your query here", true);
		fields.add(comments);


		return new GenModel("Inputs from Complainant", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getSeekInputsURL(), Constants.SERVICEURL),new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP)));
	}

	@Override
	public Response seekInput(GenModel genmodel, String mailId) throws CustomException{
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(this.nullOrEmptyOrSelect(fields.getComplainant()))
			return new Response("Please select complainant");

		CaseDetailsValidationResponse complainantResponse = commonService.validateEmployeeDetails(fields.getComplainant().trim(), Constants.COMPLAINANT);
		if(!complainantResponse.isStatus())
			return new Response(complainantResponse.getMessage());

		if(this.isNullOrEmpty(fields.getComments()))
			return new Response("Please enter your query");

		ELCMECMstASHICommunicationDetails communicationObj = new ELCMECMstASHICommunicationDetails(fields.getCaseid(), mailId, "IC", fields.getComments(), complainantResponse.getIds().get(0).getMailId(), "A", currentDateTime);

		communicationRepository.save(communicationObj);
		
		Optional<ELCMECTrnASHIActionDetails> action = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(fields.getCaseid());
		MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHISI");
		
		if(mailInfo!=null && action.isPresent()) {
			String subject = mailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(fields.getCaseid()));
			String body = mailInfo.getBody().replace(Constants.CASEIDPH, String.valueOf(fields.getCaseid())).replace(Constants.EMPNAME_PH, complainantResponse.getIds().get(0).getEmpName()).replace(Constants.ICLOCATION_PH, action.get().getAssigneeLocation().trim()).replace("#Query#", fields.getComments());
			MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), complainantResponse.getIds().get(0).getMailId() + property.getInfyDomain(), "");
			PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

			MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
			else
				return new Response(Constants.SUCCESSHIDEFORM, "Request for additional inputs submitted successfully to complainant "+complainantResponse.getIds().get(0).getMailId());

		}
		else
			throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);
			
		
	}

	@Override
	public CardView communicationHistory(int caseid, int showtop2) {
		List<ELCMECMstASHICommunicationDetails> communications = communicationRepository.findByCaseIdOrderBySerialNoDesc(caseid);
		List<Card> comms = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		String addCommunicationMID = commonService.getUIModuleId("ADCM");
		String viewAllCommunicationMID = commonService.getUIModuleId("VACM");

		if(communications.size()>2 && showtop2==1) {
			communications = communications.subList(0, 2);
			actions.add(new CardViewAction(2, Constants.VIEW_ALL, Constants.POST, viewAllCommunicationMID, Constants.GENERICMODELPOPUP));
		}

		for(ELCMECMstASHICommunicationDetails comm : communications) {
			List<CardViewField> fields = new ArrayList<>();
			fields.add(new CardViewField("Date", new SimpleDateFormat(Constants.DATETIME_FORMAT).format(comm.getCreatedDate()), 14));
			fields.add(new CardViewField("Complainant", comm.getRespondedBy().trim(), 14));
			fields.add(new CardViewField("Query", comm.getComments().trim(), 54));

			if(comm.getFlgResponded()==1) {
				fields.add(new CardViewField("Responded On", new SimpleDateFormat(Constants.DATETIME_FORMAT).format(comm.getUpdatedDate()), 14));
				fields.add(new CardViewField("Response", comm.getResponse().trim(), 54));
			}
			else
				fields.add(new CardViewField("Response", "Not responded yet.", 54));

			comms.add(new Card("", fields));
		}

		if(communications.isEmpty())
			comms.add(new Card("", Arrays.asList(new CardViewField("", "No communications happened yet.", 54))));
		
		if(showtop2==1 && commonService.checkIsActionEnabled("2", "SEEKIP", Session.getCaseDetails().getStatus()))
			actions.add(new CardViewAction(2, "Seek Inputs", Constants.POST, addCommunicationMID, Constants.GENERICMODELPOPUP));

		return new CardView("", comms, "", caseid, actions);
	}

	@Override
	public GenModel getInterimReliefGenmodel(int caseid) {
		String dependentTo = "flgRelief|Yes";
		List<GenModelField> fields = new ArrayList<>();


		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> flgReliefOptions=new ArrayList<>();
		flgReliefOptions.add(new GenModelOption(1, "Yes"));
		flgReliefOptions.add(new GenModelOption(2, "No"));
		GenModelField flgRelief=new GenModelField( 18, "flgRelief", "Interim Relief Required?", "", "",flgReliefOptions, true);

		fields.add(flgRelief);

		List<GenModelOption> options = genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "IR");
		GenModelField reliefs = new GenModelField( 77, "reliefs", "Choose The Relief Options", new ArrayList<String>(), dependentTo,options, false);

		fields.add(reliefs);

		GenModelField otherRelief=new GenModelField( 1, "otherRelief", "If any other, please specify",dependentTo, "","", false);
		otherRelief.setPlaceHolder("Others");
		otherRelief.setHintMessage("Please specify separated by comma if there are more than one.");

		fields.add(otherRelief);

		GenModelField remarks=new GenModelField( 1, Constants.REMARKS.toLowerCase(), Constants.REMARKS,"", "","", true);
		remarks.setPlaceHolder("Enter the reason/ justification");

		fields.add(remarks);

		List<GenModelField> documentFields = new ArrayList<>();

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
		GenModelField documents=new GenModelField( 60, Constants.DOCUMENTS.toLowerCase(), "Supporting Documents",new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);
		documents.setDependantTo(dependentTo);
		documents.setVisibleOnPageLoad(false);
		documentFields.add(documents);

		return new GenModel(Constants.INTERIM_RELIEF, fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getInterimReliefSubmitURL(), Constants.SERVICEURL)));
	}

	public Response addInterimRelief(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(fields.getCaseid());
		if(actionObj.isPresent() && Arrays.asList("CLN", "DM", "OI").contains(actionObj.get().getStatus()))
			return new Response("Unable to take action. Current case status is "+actionObj.get().getStatusDesc());


		if(interimReliefRepository.existsByCaseId(fields.getCaseid()))
			return new Response("Already added interim relief details");

		if(fields.getFlgRelief()==0)
			return new Response("Please select an option for Interim relief required? field.");

		if(fields.getFlgRelief()==1 && (this.isNullOrEmpty(fields.getReliefs())))
			return new Response("Please select atleast an option from given interim relief options or provide other relief details.");

		if(this.isNullOrEmpty(fields.getRemarks()))
			return new Response("Please provide your remarks.");

		String dmsFiles = "";
		if(fields.getFlgRelief()==1 && !fields.getDocuments().isEmpty()) {
			dmsFiles=commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIInterimReliefFolder());

			if(dmsFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsFiles);
		}

		ELCMECTrnASHIInterimReliefDetails interimRelief = new ELCMECTrnASHIInterimReliefDetails(fields, Session.getTokenEMPNO(), currentDateTime, dmsFiles);

		interimReliefRepository.save(interimRelief);
		this.triggerInterimReliefMail(fields.getCaseid(), "");
		return new Response(Message.SUCCESS, "Successfully added interim relief details.");




	}

	public LabelView getInterimRelief(int caseid) throws CustomException {
		Optional<ELCMECTrnASHIInterimReliefDetails> relief = interimReliefRepository.findByCaseId(caseid);

		List<CardViewField> fieldList=new ArrayList<>();
		if(!relief.isPresent())
			return new LabelView(Constants.INTERIM_RELIEF,fieldList);

		fieldList.add(new CardViewField("Interim relief required? ", relief.get().getFlgRelief()==1 ? "Yes" : "No", 14));

		if(relief.get().getFlgRelief()==1)
			fieldList.add(new CardViewField("Relief options", relief.get().getReliefs(), 120));

		fieldList.add(new CardViewField(Constants.REMARKS, relief.get().getRemarks(), 14));

		if(relief.get().getFlgRelief()==1) {
			if(relief.get().getFlgActionTaken()==1) {
				fieldList.add(new CardViewField(Constants.STATUS, WordUtils.capitalize(relief.get().getApprovalStatus().toLowerCase()) + "by GRB", 14));
				fieldList.add(new CardViewField("Approval remarks", relief.get().getApproverRemarks().trim(), 14));
			}
			else {
				fieldList.add(new CardViewField(Constants.STATUS, "Submitted to GRB for approval", 14));
			}
		}

		if(this.notNullOrEmpty(relief.get().getDmsFiles())) {
			fieldList.add(new CardViewField(Constants.DOCUMENTS, "", 88));
			String[] documents = relief.get().getDmsFiles().split(",");
			for(String document : documents) {
				fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "IR", relief.get().getSerialNo(), document.trim()), 35));
			}
			
			if(documents.length>1)
				fieldList.add(new CardViewField(Constants.DOWNLOADALL, MessageFormat.format(property.getDownloadURL(), "IR", relief.get().getSerialNo(), Constants.ALL), 87));
		}
		return new LabelView(Constants.INTERIM_RELIEF,fieldList);
	}

	@Override
	public GenModel getFirstContactGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();


		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> mailToOptions=new ArrayList<>();
		mailToOptions.add(new GenModelOption(Constants.COMPLAINANT, Constants.COMPLAINANT + "(s)"));
		mailToOptions.add(new GenModelOption(Constants.RESPONDENT, Constants.RESPONDENT + "(s)"));
		GenModelField mailTo=new GenModelField( 18, "mailTo", "Mail To", "", "",mailToOptions, true);

		fields.add(mailTo);

		return new GenModel("First contact mails", fields, Arrays.asList(new CardViewAction(1, "Initiate Mail", Constants.POST, property.getSendFirtContactMailsURL(), Constants.SERVICEURL)));
	}

	@Override
	public Response sendFirstContactMails(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		List<GenModelOption> employees = null;
		StringBuilder toIds = new StringBuilder();
		StringBuilder recipeints = new StringBuilder();

		if(fields.getMailTo().equals(Constants.COMPLAINANT)) {
			employees = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(fields.getCaseid(), Arrays.asList("A","T"));

		}

		else if(fields.getMailTo().equals(Constants.RESPONDENT)) {
			employees = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(fields.getCaseid(), Arrays.asList("R"));

		}

		else {
			return new Response("Please select valid option");
		}


		for(GenModelOption employee : employees) {
			toIds.append(employee.getKey().trim()).append(property.getInfyDomain()).append(";");
			recipeints.append(", ").append(WordUtils.capitalize(employee.getValue().trim().split(" ")[0].toLowerCase()));

		}

		
		if(this.isNullOrEmpty(toIds.toString()))
			return new Response("No "+fields.getMailTo()+"(s) found to trigger mails.");
		
		recipeints = recipeints.delete(0, 2);
		if(this.isNullOrEmpty(recipeints.toString()))
			throw new CustomException("Empty recipeints.");

		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(fields.getCaseid());
		if(actionObj.isPresent()) {
			if(this.isNullOrEmpty(actionObj.get().getAssigneeLocation()))
				throw new CustomException("IC mapped location not found.");

			this.triggerFirstContactMails(fields.getCaseid(), toIds.toString(), recipeints.toString(), fields.getMailTo(), actionObj.get().getAssigneeLocation());
			ELCMECTrnASHIFirstContactMailsDetails mails = new ELCMECTrnASHIFirstContactMailsDetails(fields.getCaseid(), this.getActor(fields.getMailTo()), fields.getMailTo(), Session.getTokenEMPNO(), currentDateTime);
			firstContactMailsRepository.save(mails);
			return new Response(Message.SUCCESS, "Successfully sent emails to "+fields.getMailTo()+"(s)");

		}	
		else
			throw new CustomException("Action details not found.");
	}

	private void triggerFirstContactMails(int caseid, String toIds, String recipeints, String mailTo, String icLocation) throws CustomException {
		StringBuilder complainantsNames = new StringBuilder();


		MailContent mailInfo = null;
		if(mailTo.equals(Constants.COMPLAINANT)) {
			mailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIFCC");
		}

		else if(mailTo.equals(Constants.RESPONDENT)) {
			mailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIFCR");
			List<GenModelOption> complainants = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("A","T"));
			for(int i=0; i<complainants.size();i++) {
				if(complainants.size()>1 && i==complainants.size()-1)
					complainantsNames.append(" and ").append(WordUtils.capitalize(complainants.get(i).getValue().toLowerCase().trim()));
				else
					complainantsNames.append(", ").append(WordUtils.capitalize(complainants.get(i).getValue().toLowerCase().trim()));
			}
			if(complainantsNames.length()>0) {
				complainantsNames = complainantsNames.delete(0, 2);
			}

		}

		if(mailInfo!=null) {
			String ccIds =  commonService.getIdStringByRoleAndModule("IC", "2", "IN", "INFSYS", icLocation);
			String mailSubject=mailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseid));
			String mailBody=mailInfo.getBody().replace("#EmployeeName#", recipeints).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.toLowerCase())).replace("#Complainants#", complainantsNames);
			mailInfo.setBody(mailBody);
			mailInfo.setSubject(mailSubject);

			MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), toIds, ccIds);
			PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, mailInfo.getSubject())),new PlaceHolder(Constants.BODYPH, mailInfo.getBody())};

			MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException("First contact mails to " + mailTo + "(s) " + Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
		}
	}

	@Override
	public CardView getFirstContactMailsDetails(int caseid, int showtop2) throws CustomException {
		List<Card> cards = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<ELCMECTrnASHIFirstContactMailsDetails> mails = firstContactMailsRepository.findByCaseIdOrderBySerialNoDesc(caseid);

		if(mails.isEmpty()) {
			cards.add(new Card(new ArrayList<>(), Arrays.asList(new CardViewField("No mail sent yet.", "", 54))));
		}
		else {

			if(mails.size()>2 && showtop2==1) {
				mails = mails.subList(0, 2);
				actions.add(new CardViewAction(2, Constants.VIEW_ALL, Constants.POST, commonService.getUIModuleId("VAFC"), Constants.GENERICMODELPOPUP));
			}

			for(ELCMECTrnASHIFirstContactMailsDetails mail : mails) {
				List<CardViewField> fields = new ArrayList<>();
				fields.add(new CardViewField("Issued On", new SimpleDateFormat(Constants.DATETIME_FORMAT).format(mail.getIssuedDate()), 14));
				fields.add(new CardViewField("Mail Sent To", this.getEmployeeType(mail.getActor())+"s", 14));
				fields.add(new CardViewField("Updated By", mail.getRole().trim()+" (E# "+mail.getIssuedBy().trim()+")", 14));
				fields.add(new CardViewField("Description", mail.getDescription(), 54));

				cards.add(new Card(new ArrayList<>(), fields));
			}

		}
		return new CardView("", cards, "First contact mails", caseid, actions);

	}

	@Override
	public GenModel getInvestigationTypeGenmodel(int caseid) {

		List<GenModelField> fields = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> investigationTypes=new ArrayList<>();
		investigationTypes.add(new GenModelOption(1, Constants.CONCILIATION));
		investigationTypes.add(new GenModelOption(0, Constants.PROCEED_FI));
		GenModelField investigationTypeField=new GenModelField( 18, Constants.INVESTIGATION_TYPE_NAME, Constants.INVESTIGATION_TYPE, "", "",investigationTypes, true);

		fields.add(investigationTypeField);

		return new GenModel(Constants.INVESTIGATION_TYPE, fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getChooseInvestigationTypeURL(), Constants.SERVICEURL),new CardViewAction(1, "Clear", "", "", "Clear")));
	}

	@Override
	public Response chooseInvestigationType(String empno, GenModel genmodel) {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		String nextStatus = "";
		
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(fields.getInvestigationType().equals(Constants.CONCILIATION))
			nextStatus = "WIC";
		else if(fields.getInvestigationType().equals(Constants.PROCEED_FI))
			nextStatus = "WIF";
		else
			return new Response("Please choose valid investigation type.");

		if(StringUtils.isBlank(caseDetails.get().getInvestigationType()))
			caseDetails.get().setInvestigationType(fields.getInvestigationType());

		else if(Arrays.asList("CIR", "CCR", "CRR").contains(caseDetails.get().getStatus().trim())) 
			caseDetails.get().setInvestigationType(Constants.FORMAL);

		else
			return new Response("Already selected investigation type - " + caseDetails.get().getInvestigationType());

		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empno, "", "", nextStatus, "", "");
		if(response.isSuccess()) {
			return new Response(Message.SUCCESS, "Successfully updated investigation type.", "", "");
		}

		else
			return new Response(Message.UNABLE_TO_PROCEED);
		
	}

	@Override
	public GenModel getInitiateConciliationGenmodel(int caseid) {
		List<CardViewAction> actions = new ArrayList<>();

		List<GenModelField> fields = new ArrayList<>();
		
		if(!caseDetailsRepository.existsById(caseid))
			return new GenModel("", fields, actions);
		
		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(caseid);

		if(actionObj.isPresent()) {
			GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
			caseidField.setEditable(false);

			if(actionObj.get().getStatus().equals("WIC")) {
				fields.add(caseidField);

				GenModelField remarks=new GenModelField( 0, Constants.REMARKS.toLowerCase(), "Remarks on conciliation","", "","", true);
				remarks.setPlaceHolder("Enter the remarks");
				fields.add(remarks);

				actions.add(new CardViewAction(1, "Initiate Conciliation", Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "CIA"), Constants.SERVICEURL));
			}

			else if(actionObj.get().getStatus().equals("CIA")) {
				fields.add(caseidField);

				GenModelField status=new GenModelField( 14, Constants.STATUS.toLowerCase(), Constants.STATUS,"", "","", true);
				status.setData(actionObj.get().getStatusDesc());
				fields.add(status);

				GenModelField remarksByIC=new GenModelField( 14, "remarksByIC", "Remarks by IC","", "","", true);
				remarksByIC.setData(actionObj.get().getComments());
				fields.add(remarksByIC);

				GenModelField remarks=new GenModelField( 0, Constants.REMARKS.toLowerCase(), Constants.REMARKS,"", "","", true);
				remarks.setPlaceHolder("Enter the remarks");
				fields.add(remarks);

				actions.add(new CardViewAction(1, Constants.APPROVE, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "PCR"), Constants.SERVICEURL));
				actions.add(new CardViewAction(1, Constants.REJECT, Constants.POST, MessageFormat.format(property.getInitiateConciliationURL(), "CIR"), Constants.SERVICEURL));
			}

			else if(actionObj.get().getStatus().equals("PCR")) {
				fields.add(caseidField);

				GenModelField status=new GenModelField( 14, Constants.STATUS.toLowerCase(), Constants.STATUS,"", "","", true);
				status.setData(actionObj.get().getStatusDesc());
				fields.add(status);

				GenModelField remarksByGrB=new GenModelField( 14, "remarksByGRB", "Remarks by GRB","", "","", true);
				remarksByGrB.setData(actionObj.get().getComments());
				fields.add(remarksByGrB);
			}

			else if(actionObj.get().getStatus().equals("CIR") || actionObj.get().getStatus().equals("CRR")) {
				fields.add(caseidField);

				GenModelField investigationTypeField=new GenModelField( 14, Constants.INVESTIGATION_TYPE_NAME, Constants.INVESTIGATION_TYPE, Constants.PROCEED_FI, "",new ArrayList<>(), false);
				investigationTypeField.setEditable(false);
				fields.add(investigationTypeField);

				GenModelField status=new GenModelField( 14, Constants.STATUS.toLowerCase(), Constants.STATUS,"", "","", true);
				status.setData(actionObj.get().getStatusDesc());
				fields.add(status);

				GenModelField remarks=new GenModelField( 14, Constants.REMARKS.toLowerCase(), Constants.REMARKS,"", "","", true);
				remarks.setData(actionObj.get().getComments());
				fields.add(remarks);

				actions.add(new CardViewAction(1, Constants.PROCEED_FI, Constants.POST, property.getChooseInvestigationTypeURL(), Constants.SERVICEURL));
			}
		}

		return new GenModel("", fields, actions);
	}

	@Override
	public LabelView getConciliationReport(int caseid) {
		List<CardViewField> fieldList=new ArrayList<>();


		Optional<ELCMECTrnASHIConciliationReportDetails> report = conciliationReportDetailsRepository.findByCaseId(caseid);

		if(report.isPresent()) {
			fieldList.add(new CardViewField(Constants.REASON_FOR_CONCILIATION, report.get().getConciliationReason(), 54));
			fieldList.add(new CardViewField("Key findings about the incident", report.get().getKeyFindings(), 54));
			fieldList.add(new CardViewField(Constants.ANY_OTHER_RECOMMENDATION, report.get().getRecommendations(), 54));
			
			if(this.notNullOrEmpty(report.get().getAgreementDocs())) {
				fieldList.add(new CardViewField("Conciliation Agreement", "", 88));
				String[] agreementDocuments = report.get().getAgreementDocs().split(",");
				for(String document : agreementDocuments) {
					fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "CRA", report.get().getSerialNo(), document.trim()), 35));
				}
			}

			if(this.notNullOrEmpty(report.get().getOtherDocs())) {
				fieldList.add(new CardViewField("Other Docs", "", 88));
				String[] otherDocuments = report.get().getOtherDocs().split(",");
				for(String document : otherDocuments) {
					fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "CRO", report.get().getSerialNo(), document.trim()), 35));
				}
			}

		}




		return new LabelView("Conciliation report",fieldList);
	}

	@Override
	public Response initiateConciliation(String empNo, String action, GenModel genmodel) throws CustomException {
		String adminInboxMID = commonService.getUIModuleId("ADIN");
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);
		
		if(this.isNullOrEmpty(fields.getRemarks()))
			return new Response("Please provide remarks.");
		
		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, fields.getRemarks(), "", action, "", "");
		if(response.isSuccess()) {
			this.triggerMails(fields.getCaseid(), response.getAssigneeLocation(), response.getMailEventCode(), "");
			return new Response(Message.SUCCESSPROCEED, response.getMessage(), "", adminInboxMID);
		}
		else
			return new Response(Message.UNABLE_TO_PROCEED);

	}


	@Override
	public CardView getConciliationConsents(int caseid) {
		List<Card> cards = new ArrayList<>();
		String initiateCaseModuleId = commonService.getUIModuleId("PO");

		List<ELCMECMstASHIConciliationConsentDetails> consents = conciliationConsentDetailsRepository.findByCaseId(caseid);

		if(consents.isEmpty()) {
			cards.add(new Card(new ArrayList<>(), Arrays.asList(new CardViewField("No consent sent yet.", "", 12))));
		}
		else {
			for(ELCMECMstASHIConciliationConsentDetails consent : consents) {
				List<CardViewField> fields = new ArrayList<>();
				fields.add(new CardViewField(this.getEmployeeType(consent.getActor())+" :", consent.getMailId(), 14));
				fields.add(new CardViewField("Date :", new SimpleDateFormat("dd MMM yyyy").format(consent.getIssuedDate()), 14));

				String consentStatus="";
				if(consent.getFlgAccept()==0 && consent.getFlgReject()==0)
					consentStatus = "Pending with the " + this.getEmployeeType(consent.getActor());

				else if(consent.getFlgAccept()==1 && consent.getFlgReject()==0)
					consentStatus = "Accepted by the " + this.getEmployeeType(consent.getActor());

				else
					consentStatus = Constants.REJECTED;

				fields.add(new CardViewField("Consent", consentStatus, 14));

				cards.add(new Card(new ArrayList<>(), fields, this.conciliationConsentCardAction(consents, consent, initiateCaseModuleId)));
			}

		}	
		return new CardView("Conciliation consents", cards);
	}

	private List<CardViewAction> conciliationConsentCardAction(List<ELCMECMstASHIConciliationConsentDetails> consents, ELCMECMstASHIConciliationConsentDetails currentConsent, String initiateCaseModuleId){
		List<CardViewAction> actions = new ArrayList<>();

		if(!consents.isEmpty()) {
			String status = this.checkConciliationStatus(consents);

			if(status.equals("PR") && currentConsent.getFlgAccept()==0 && currentConsent.getFlgReject()==1) {
				return Arrays.asList(new CardViewAction("Initiate new complaint", initiateCaseModuleId, ""));
			}
		}

		return actions;
	}


	public String checkConciliationStatus(List<ELCMECMstASHIConciliationConsentDetails> consents) {
		long complainants = consents.stream().filter(x -> x.getActor().equals("A")).count();
		long respondents = consents.stream().filter(x -> x.getActor().equals("R")).count();
		long rejectedComplainants = consents.stream().filter(x -> (x.getActor().equals("A") && x.getFlgAccept()==0 && x.getFlgReject()==1)).count();
		long rejectedRespondents = consents.stream().filter(x -> x.getActor().equals("R") && x.getFlgAccept()==0 && x.getFlgReject()==1).count();
		long pendingConsents = consents.stream().filter(x -> (x.getFlgAccept()==0 && x.getFlgReject()==0)).count();

		String status = "NI";

		boolean condition = (rejectedComplainants==0 && rejectedRespondents<=1 && respondents>1) || (rejectedComplainants<=1 && rejectedRespondents==0 && complainants>1);

		if(pendingConsents>0) {
			return "PA";
		}

		if(complainants==1 && respondents==1) {
			if(rejectedComplainants==0 && rejectedRespondents==0)
				status = "PR";
		}

		else {
			if(condition) {
				status = "PR";
			}
		}

		return status;
	}

	@Override
	public GenModel getPrepareConciliationReport(int caseid) {
		List<GenModelField> fields = new ArrayList<>();

		List<ELCMECMstASHIConciliationConsentDetails> consents = conciliationConsentDetailsRepository.findByCaseId(caseid);

		if(!consents.isEmpty()) {
			String status = this.checkConciliationStatus(consents);
			if(status.equals("PR")) {
				GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
				caseidField.setEditable(false);
				fields.add(caseidField);

				GenModelField conciliationReason=new GenModelField( 1, "conciliationReason", Constants.REASON_FOR_CONCILIATION,"", "","", true);
				conciliationReason.setPlaceHolder("Enter summary of the investigation here.");
				fields.add(conciliationReason);

				GenModelField conciliationFindings=new GenModelField( 1, "conciliationFindings", "Key findings abount the incident","", "","", true);
				conciliationFindings.setPlaceHolder("Provide your inputs on the findings of the investigation.");
				fields.add(conciliationFindings);

				List<GenModelValidation> validations=new ArrayList<>();
				validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
				validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
				validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
				validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));

				GenModelField conciliationAggrementDocs=new GenModelField( 60, "conciliationAggrementDocs", "Upload Conciliation Aggrement",new ArrayList<DocumentData>(),"","", validations);
				fields.add(conciliationAggrementDocs);

				GenModelField otherDocs=new GenModelField( 60, "documents", "Other Documents",new ArrayList<DocumentData>(),"","(Statement copies, MOMs)", validations);
				fields.add(otherDocs);

				GenModelField conciliationRecommendations=new GenModelField( 1, "conciliationRecommendations", Constants.ANY_OTHER_RECOMMENDATION,"", "","", true);
				conciliationRecommendations.setPlaceHolder("Write your conclusion statements and recommendations here.");
				fields.add(conciliationRecommendations);

				return new GenModel("", fields, Arrays.asList(new CardViewAction(1, Constants.BACK_TO_CASE_SUMMARY, Constants.POST, commonService.getUIModuleId("ADCS"), Constants.NAVIGATE), new CardViewAction(1, "Submit to GRB", Constants.POST, property.getSubmitConciliationReportURL(), Constants.SERVICEURL)));
			}
			else if (status.equals("NI")) {
				GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
				caseidField.setEditable(false);
				fields.add(caseidField);

				List<GenModelOption> investigationTypes=new ArrayList<>();
				investigationTypes.add(new GenModelOption(1, Constants.CONCILIATION));
				investigationTypes.add(new GenModelOption(0, Constants.PROCEED_FI));
				GenModelField investigationTypeField=new GenModelField( 18, Constants.INVESTIGATION_TYPE_NAME, Constants.INVESTIGATION_TYPE, Constants.PROCEED_FI, "",investigationTypes, true);
				investigationTypeField.setEditable(false);
				fields.add(investigationTypeField);

				return new GenModel("Proceed with normal investigation", fields, Arrays.asList(new CardViewAction(1, Constants.PROCEED_FI, Constants.POST, property.getChooseInvestigationTypeURL(), Constants.SERVICEURL)));
			}
			else {
				return new GenModel("", "Please obtain consent from both the parties before proceeding with conciliation.", fields);
			}
		}
		else {
			return new GenModel("", "Conciliation has not initiated or approved yet.", fields);
		}


	}

	@Override
	public Response submitConciliationReport(String empNo, GenModel genmodel) throws CustomException {
		String adminInboxMID = commonService.getUIModuleId("ADIN");

		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(conciliationReportDetailsRepository.existsByCaseId(fields.getCaseid()))
			return new Response("Already submitted conciliation report");

		if(this.isNullOrEmpty(fields.getConciliationReason()))
			return new Response("Please provide reason for conciliation.");

		if(this.isNullOrEmpty(fields.getConciliationFindings()))
			return new Response("Please provide key findings abount the incident.");

		if(this.isNullOrEmpty(fields.getConciliationRecommendations()))
			return new Response("Please provide your recommendations.");

		if(fields.getConciliationAggrementDocs().isEmpty())
			return new Response("Please upload conciliation agreement documents.");

		String dmsConciliationAggrementFiles = "";
		if(!fields.getConciliationAggrementDocs().isEmpty()) {
			dmsConciliationAggrementFiles=commonService.validateAndUploadDocumentsToDMS(fields.getConciliationAggrementDocs(), property.getDmsASHIInvestigationDocsFolder());

			if(dmsConciliationAggrementFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsConciliationAggrementFiles);
		}

		String dmsOtherFiles = "";
		if(!fields.getDocuments().isEmpty()) {
			dmsOtherFiles=commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIInvestigationDocsFolder());

			if(dmsOtherFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsOtherFiles);
		}

		ELCMECTrnASHIConciliationReportDetails conciliationReportDetails = new ELCMECTrnASHIConciliationReportDetails(fields, dmsConciliationAggrementFiles, dmsOtherFiles);
		conciliationReportDetailsRepository.save(conciliationReportDetails);

		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, "", "", "CRA", "", "");
		if(response.isSuccess()) {
			this.triggerMails(fields.getCaseid(), response.getAssigneeLocation(), response.getMailEventCode(), "");
			return new Response(Message.SUCCESSPROCEED, "Successfully submittted conciliation report.", "", adminInboxMID);
		}
		else
			return new Response(Message.UNABLE_TO_PROCEED);
	}

	@Override
	public GenModel moveCaseGenModel(String action, int caseid) {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();
		String placeholder = "Write your conclusion statements and recommendations here…";

		ELCMECTrnASHICaseDetails caseDetails = Session.getCaseDetails().getCaseDetails();

		Optional<ELCMECMstReachWorkFlow> workflow = workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveAndDirection(2, caseDetails.getStatus().trim(), 1, action);
		if(workflow.isPresent()) {
			GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
			caseidField.setEditable(false);
			fields.add(caseidField);

			GenModelField actionField=new GenModelField( 14, "action", "", workflow.get().getNextStatus(), true, false);
			actionField.setEditable(false);
			fields.add(actionField);

			GenModelField comments=new GenModelField( 1, Constants.COMMENTS.toLowerCase(), workflow.get().getFromRole()+" "+Constants.COMMENTS,"", "","", true);
			comments.setPlaceHolder(placeholder);
			fields.add(comments);

			List<GenModelValidation> validations=new ArrayList<>();
			validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
			validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
			validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
			validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));
			GenModelField documents=new GenModelField( 60, Constants.DOCUMENTS.toLowerCase(), Constants.CLOSURE_DOCUMENTS,new ArrayList<DocumentData>(),"",Message.FILESIZE, validations);

			if(workflow.get().getNextStatus().equals("CLF"))
				fields.add(documents);
			else if(Arrays.asList("CRA", "WGU").contains(workflow.get().getCurrentStatus()) && action.equals("F")) {
				documents.setDisplayName("Attach GRB Panel Approvals");
				fields.add(documents);
			}

			actions.add(new CardViewAction(1, Constants.CANCEL, "", "", ""));
			actions.add(new CardViewAction(1, workflow.get().getActionLabel(), Constants.POST, property.getMoveCaseURL(), Constants.SERVICEURL));
		}

		return new GenModel("", fields, actions);

	}


	@Override
	public Response moveCase(String empNo, GenModel genmodel) throws CustomException {
		String adminInboxMID = commonService.getUIModuleId("ADIN");
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(this.isNullOrEmpty(fields.getComments()))
			return new Response("Please provide your comments.");

		if(fields.getAction().equals("CLF") && fields.getDocuments().isEmpty())
			return new Response("Please upload closure documents.");
		
		if(Arrays.asList("WEC","WCC").contains(fields.getAction()) && fields.getDocuments().isEmpty())
			return new Response("Please upload GRB Panel approvals.");


		String dmsOtherFiles = "";
		if(!fields.getDocuments().isEmpty()) {
			dmsOtherFiles=commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIInvestigationDocsFolder());

			if(dmsOtherFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsOtherFiles);
		}
		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, fields.getComments(), dmsOtherFiles, fields.getAction(), "", "");
		if(response.isSuccess()) {
			this.triggerMails(fields.getCaseid(), response.getAssigneeLocation(), response.getMailEventCode(), fields.getComments());
			return new Response(Message.SUCCESSPROCEED, response.getMessage(), "", adminInboxMID);
		}
		else
			return new Response(Message.UNABLE_TO_PROCEED);

	}

	@Override
	public GenModel getRecommendedActionsGenmodel(int type, int caseid, String transactionid) throws CustomException {
		List<GenModelField> fields = new ArrayList<>();
		String actionLabel = "Add";
		if(type==1) {
			commonService.checkCaseAuthorization(caseid, true);
		}
			

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);

		GenModelField transactionidField=new GenModelField( 14, "transactionid", "", transactionid, true, false);
		transactionidField.setEditable(false);


		List<GenModelOption> actionAgainstOptions=new ArrayList<>();
		actionAgainstOptions.add(new GenModelOption("A", Constants.COMPLAINANT));
		actionAgainstOptions.add(new GenModelOption("R", Constants.RESPONDENT));
		actionAgainstOptions.add(new GenModelOption("W", Constants.WITNESS));
		GenModelField actionAgainst=new GenModelField( 18, "actionAgainst", "Action Against", Constants.COMPLAINANT, "",actionAgainstOptions, true);


		List<GenModelOption> complainantsOption = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("A","T"));
		GenModelField complainants=new GenModelField( 39, Constants.COMPLAINANT.toLowerCase(), Constants.CHOOSE + Constants.COMPLAINANT, complainantsOption.isEmpty()?"":complainantsOption.get(0).getKey(), "actionAgainst|Complainant", complainantsOption, true);


		List<GenModelOption> respondentsOption = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("R"));
		GenModelField respondents=new GenModelField( 39, Constants.RESPONDENT.toLowerCase(), Constants.CHOOSE + Constants.RESPONDENT, respondentsOption.isEmpty()?"":respondentsOption.get(0).getKey(), "actionAgainst|Respondent", respondentsOption, false);


		List<GenModelOption> witnessesOption = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("W"));
		GenModelField witnesses=new GenModelField( 39, Constants.WITNESS.toLowerCase(), Constants.CHOOSE + Constants.WITNESS, witnessesOption.isEmpty()?"":witnessesOption.get(0).getKey(), "actionAgainst|Witness", witnessesOption, false);


		List<GenModelOption> severityLevelOption = genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "RAL");
		GenModelField severityLevel=new GenModelField( 39, "severityLevel", "Severity Level", "", "", severityLevelOption, true);


		GenModelField recommendedActions=new GenModelField( 77, "recommendedActions", "Choose actions from below", "", "severityLevel", new ArrayList<>(), true);
		recommendedActions.setDependantAction(property.getGenmodelOptionsByGroupIdURL().replace("{1}", "2")+"|"+Constants.POST);
		
		GenModelField remarks=new GenModelField( 1, Constants.REMARKS.toLowerCase(), Constants.REMARKS,"", "","", true);

		if(type==2 && this.notNullOrEmpty(transactionid)) {
			actionLabel = Constants.UPDATE;
			Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = recommendationsDetailsRepository.findById(Integer.valueOf(transactionid));

			if(recommendedActionsObj.isPresent()) {
				commonService.checkCaseAuthorization(recommendedActionsObj.get().getCaseId(), true);
				
				caseidField.setData(recommendedActionsObj.get().getCaseId());

				actionAgainst.setData(this.getEmployeeType(recommendedActionsObj.get().getActor().trim()));
				actionAgainst.setEditable(false);

				if(recommendedActionsObj.get().getActor().equals("A")) {
					complainants.setData(recommendedActionsObj.get().getMailId());
					complainants.setOptions(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(recommendedActionsObj.get().getCaseId(), Arrays.asList("A","T")));
					complainants.setVisibleOnPageLoad(true);
					respondents.setVisibleOnPageLoad(false);
					witnesses.setVisibleOnPageLoad(false);
				}
				else if(recommendedActionsObj.get().getActor().equals("R")) {
					respondents.setData(recommendedActionsObj.get().getMailId());
					respondents.setOptions(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(recommendedActionsObj.get().getCaseId(), Arrays.asList("R")));
					complainants.setVisibleOnPageLoad(false);
					respondents.setVisibleOnPageLoad(true);
					witnesses.setVisibleOnPageLoad(false);
				}
				else if(recommendedActionsObj.get().getActor().equals("W")) {
					witnesses.setData(recommendedActionsObj.get().getMailId());
					witnesses.setOptions(caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(recommendedActionsObj.get().getCaseId(), Arrays.asList("W")));
					complainants.setVisibleOnPageLoad(false);
					respondents.setVisibleOnPageLoad(false);
					witnesses.setVisibleOnPageLoad(true);
				}

				complainants.setEditable(false);
				respondents.setEditable(false);
				witnesses.setEditable(false);

				severityLevel.setData(recommendedActionsObj.get().getSeverityLevel());

				List<GenModelOption> recommendedActionOptions = commonService.getGenModelOptionsByModuleIdAndGroupId(2, recommendedActionsObj.get().getSeverityLevel());

				recommendedActions.setData(recommendedActionOptions, recommendedActionsObj.get().getActions());
				recommendedActions.setOptions(recommendedActionOptions);
				
			}
		}
		fields.add(caseidField);
		fields.add(transactionidField);
		fields.add(actionAgainst);
		fields.add(complainants);
		fields.add(respondents);
		fields.add(witnesses);
		fields.add(severityLevel);
		fields.add(recommendedActions);
		fields.add(remarks);
		


		return new GenModel("Recommended Actions", fields, Arrays.asList(new CardViewAction(1, actionLabel, Constants.POST, property.getRecommendationAddOrUpdateURL(), Constants.SERVICEURL)));
	}



	@Override
	public Response addOrUpdateRecommendedActions(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(this.isNullOrEmpty(fields.getActionAgainst()))
			return new Response("Please select action against");

		if(fields.getActionAgainst().equals(Constants.COMPLAINANT) && this.isNullOrEmpty(fields.getComplainant()))
			return new Response("Please select complainant");

		if(fields.getActionAgainst().equals(Constants.RESPONDENT) && this.isNullOrEmpty(fields.getRespondent()))
			return new Response("Please select respondent");

		if(fields.getActionAgainst().equals(Constants.WITNESS) && this.isNullOrEmpty(fields.getWitness()))
			return new Response("Please select witness");

		if(this.isNullOrEmpty(fields.getSeverityLevel()))
			return new Response("Please select severity level");

		if(this.isNullOrEmpty(fields.getRecommendedActions()))
			return new Response("Please select atleast one action");
		
		if(fields.getSeverityLevel().equals("RALO") && (fields.getRecommendedActions().contains("No Action") || fields.getRecommendedActions().contains("Not substantiated")) && this.isNullOrEmpty(fields.getRemarks()))
			return new Response("Please provide remarks");

		return this.addOrUpdateRecommendedActionsQuery(fields);
		
	}
	
	private Response addOrUpdateRecommendedActionsQuery(GMFields fields) {
		if(this.isNullOrEmpty(fields.getTransactionid())) {
			ELCMECMstASHIRecommendationsDetails recommendedActionsObj = new ELCMECMstASHIRecommendationsDetails(fields, this.getActor(fields.getActionAgainst()), currentDateTime);
			
			if(recommendationsDetailsRepository.findByCaseIdAndMailIdAndActor(fields.getCaseid(), recommendedActionsObj.getMailId(), recommendedActionsObj.getActor()).isPresent())
				return new Response("Already added action for " + this.getEmployeeType(recommendedActionsObj.getActor()) + " " + recommendedActionsObj.getMailId());
			
			ELCMECMstASHIRecommendationsDetails recommendations = recommendationsDetailsRepository.save(recommendedActionsObj);

			return new Response(Constants.SUCCESSHIDEFORM, "Successfully added recommendations for " + this.getEmployeeType(recommendations.getActor()) + " " + recommendations.getMailId());
		}
		else {
			Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = recommendationsDetailsRepository.findBySerialNoAndCaseId(Integer.valueOf(fields.getTransactionid()), fields.getCaseid());

			if(recommendedActionsObj.isPresent()) {
				ELCMECMstASHIRecommendationsDetails updatedRecommendedActionsObj = recommendedActionsObj.get();
				updatedRecommendedActionsObj.setSeverityLevel(fields.getSeverityLevel());
				updatedRecommendedActionsObj.setActions(fields.getRecommendedActions());
				updatedRecommendedActionsObj.setRemarks(fields.getRemarks());
				updatedRecommendedActionsObj.setUpdatedBy(Session.getTokenEMPNO());
				updatedRecommendedActionsObj.setUpdatedDate(currentDateTime);

				ELCMECMstASHIRecommendationsDetails recommendations = recommendationsDetailsRepository.save(updatedRecommendedActionsObj);

				return new Response(Constants.SUCCESSHIDEFORM, "Successfully updated recommendations for " + this.getEmployeeType(recommendations.getActor()) + " " + recommendations.getMailId());
			}
			else
				return new Response(Message.INVALID_INPUT);

		}
	}

	@Override
	public CardView getRecommendedActions(int caseid, boolean filter) {

		List<Card> cards = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<ELCMECMstASHIRecommendationsDetails> recommendations = recommendationsDetailsRepository.findByCaseId(caseid);
		String addRecommendationsModuleId = commonService.getUIModuleId("FRAR");
		String editRecommendationsModuleId = commonService.getUIModuleId("FRER");
		if(!recommendations.isEmpty()){

			for(ELCMECMstASHIRecommendationsDetails recommendation : recommendations) {
				List<CardViewField> fields = new ArrayList<>();
				fields.add(new CardViewField(this.getEmployeeType(recommendation.getActor())+" :", recommendation.getMailId(), 14));

				fields.add(new CardViewField("", recommendation.getActions(), 120));
				
				if(this.notNullOrEmpty(recommendation.getRemarks()))
					fields.add(new CardViewField(Constants.REMARKS, recommendation.getRemarks(), 14));

				cards.add(new Card(String.valueOf(recommendation.getSerialNo()), fields, 
						(filter && !Session.getCaseDetails().getStatus().equals("WCC")) ? 
					Arrays.asList(new CardViewAction("", "Edit", Constants.POST, editRecommendationsModuleId, Constants.GENERICMODELPOPUP, "", ""),
							new CardViewAction("", "Delete", Constants.POST, MessageFormat.format(property.getRecommendationDeleteURL(), String.valueOf(caseid), String.valueOf(recommendation.getSerialNo())), "confirmationpopup", "", "Are you sure you want to delete this recommendation for " + this.getEmployeeType(recommendation.getActor()).toLowerCase() + "?Yes|No"))
					: new ArrayList<>() ));

			}

		}

		else {
			cards.add(new Card(new ArrayList<>(), Arrays.asList(new CardViewField("No recommendations added yet.", "", 54))));

		}
		if(filter && !Session.getCaseDetails().getStatus().equals("WCC"))
			actions.add(new CardViewAction(2, "Add Recommendation", Constants.POST, addRecommendationsModuleId, Constants.GENERICMODELPOPUP));


		return new CardView("", cards, "", caseid, actions);
	}

	@Override
	public Response deleteRecommendedActions(int caseid, int transactionid) {

		if(caseDetailsRepository.existsById(caseid)) {
			Optional<ELCMECMstASHIRecommendationsDetails> recommendedActionsObj = recommendationsDetailsRepository.findBySerialNoAndCaseId(transactionid, caseid);

			if(recommendedActionsObj.isPresent()) {
				recommendationsDetailsRepository.delete(recommendedActionsObj.get());
				return new Response(Message.SUCCESS, "Successfully deleted recommendations for " + this.getEmployeeType(recommendedActionsObj.get().getActor()) + " " + recommendedActionsObj.get().getMailId());
			}
			else
				return new Response(Message.INVALID_INPUT);
		}
		else
			return new Response(Message.CASENOTREGISTERED);
	}

	@Override
	public GenModel getIssueSummonGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();
		if(!caseDetailsRepository.existsById(caseid))
			return new GenModel("", "", fields);

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelOption> summonsToOptions=new ArrayList<>();
		summonsToOptions.add(new GenModelOption("A", Constants.COMPLAINANT));
		summonsToOptions.add(new GenModelOption("R", Constants.RESPONDENT));

		GenModelField summonsTo=new GenModelField( 18, "summonsTo", "Issue Summons to", "A", "",summonsToOptions, true);
		fields.add(summonsTo);

		GenModelField summonsWith=new GenModelField( 39, "summonsWith", "Choose the recipient", "", "summonsTo", new ArrayList<>(), true);
		summonsWith.setDependantAction(property.getEmployeeOptionURL() + String.valueOf(caseid) + "|" + Constants.POST);
		fields.add(summonsWith);

		return new GenModel("Issue summons", fields, Arrays.asList(new CardViewAction(1, Constants.ISSUE_SUMMONS, Constants.POST, property.getIssueSummonURL(), Constants.SERVICEURL)));

	}

	@Override
	public Response issueSummon(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(this.isNullOrEmpty(fields.getSummonsTo()))
			return new Response("Please select Issue Summons to");

		if(this.isNullOrEmpty(fields.getSummonsWith()))
			return new Response("Please select Summons With");

		if(summonsDetailsRepository.findByCaseIdAndActorAndMailId(fields.getCaseid(), this.getActor(fields.getSummonsTo()), fields.getSummonsWith()).isPresent())
			return new Response("Already issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());

		ELCMECMstASHISummonsDetails summonsDetails = new ELCMECMstASHISummonsDetails(fields.getCaseid(), this.getActor(fields.getSummonsTo()), fields.getSummonsWith(), "IC", Session.getTokenEMPNO(), currentDateTime);
		summonsDetailsRepository.save(summonsDetails);
		this.triggerSummons(fields.getCaseid(), this.getActor(fields.getSummonsTo()), fields.getSummonsWith());
		return new Response(Message.SUCCESS, "Successfully issued summons to " + fields.getSummonsTo() + " " + fields.getSummonsWith());
	}
	
	private void triggerSummons(int caseid, String actor, String mailid) throws CustomException {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIIS");
			Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(caseid);
	
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			if(actionObj.isPresent()) {
				subject = subject.replace(Constants.CASEIDPH, String.valueOf(caseid));
				body = body.replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, actionObj.get().getAssigneeLocation().trim()).replace(Constants.KEYWORD_PH, actor.equals("A") ? "Your complainant" : "A complaint that was registered against you");
			}

			MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), mailid + property.getInfyDomain(), "");
			PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

			MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
		
	}

	@Override
	public CardView getIssuedSummons(int caseid, int showtop2) throws CustomException {
		List<Card> cards = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<ELCMECMstASHISummonsDetails> summons = summonsDetailsRepository.findByCaseIdOrderBySerialNoDesc(caseid);

		if(summons.size()>2 && showtop2==1) {
			summons = summons.subList(0, 2);
			actions.add(new CardViewAction(2, Constants.VIEW_ALL, Constants.POST, commonService.getUIModuleId("VAIS"), Constants.GENERICMODELPOPUP));
		}

		for(ELCMECMstASHISummonsDetails summon : summons) {
			List<CardViewField> fields = new ArrayList<>();
			fields.add(new CardViewField("Issued On :", new SimpleDateFormat(Constants.DATETIME_FORMAT).format(summon.getIssuedDate()), 14));
			fields.add(new CardViewField("Summons to", this.getEmployeeType(summon.getActor().trim()) + " - " + summon.getMailId(), 14));
			fields.add(new CardViewField("Status", "With " + this.getEmployeeType(summon.getActor().trim()), 14));

			cards.add(new Card(new ArrayList<>(), fields));
		}		

		if(summons.isEmpty()) {
			cards.add(new Card(new ArrayList<>(), Arrays.asList(new CardViewField("No summon issued yet.", "", 54))));
		}

		return new CardView("", cards, "Summons", caseid, actions);
	}

	@Override
	public List<GenModelOption> getEmployeesByActor(int caseid, String actor) {
		List<String> actors = new ArrayList<>();

		if(actor.equals("A") || actor.equals(Constants.COMPLAINANT)) {
			actors.add("A");
			actors.add("T");
		}
		else if(actor.equals("R") || actor.equals(Constants.RESPONDENT)) {
			actors.add("R");
		}
		else if(actor.equals("W") || actor.equals(Constants.WITNESS)) {
			actors.add("W");
		}

		if(!actors.isEmpty())
			return caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, actors);
		else
			return new ArrayList<>();
	}

	@Override
	public GenModel getFormalReportGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		GenModelField formalCaseSummary=new GenModelField( 1, "formalCaseSummary", "Case summary of the investigation","", "","", true);
		formalCaseSummary.setPlaceHolder("Enter summary of the investigation here...");
		formalCaseSummary.setHintMessage("Enter summary of the investigation here...");


		GenModelField formalOtherRecommendation=new GenModelField( 1, "formalOtherRecommendation", Constants.ANY_OTHER_RECOMMENDATION,"", "","", true);
		formalOtherRecommendation.setPlaceHolder("Write your conclusion statements and recommendations here…");


		Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findByCaseId(caseid);

		if(reportDetails.isPresent()) {
			formalCaseSummary.setData(reportDetails.get().getSummary());
			formalOtherRecommendation.setData(reportDetails.get().getOtherRecommendations());
		}

		fields.add(formalCaseSummary);
		fields.add(formalOtherRecommendation);

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));

		GenModelField formalInvestigationDocs=new GenModelField( 60, "formalInvestigationDocs", "Case Investigation Documents",new ArrayList<DocumentData>(),"","", validations);
		fields.add(formalInvestigationDocs);

		return new GenModel("Formal Report", fields, Arrays.asList(new CardViewAction(1, Constants.BACK_TO_CASE_SUMMARY, Constants.POST, commonService.getUIModuleId("ADCS"), Constants.NAVIGATE), new CardViewAction(1, "Save Report", Constants.POST, property.getSaveFormalReportURL(), Constants.SERVICEURL)));
	}

	@Override
	public Response submitFormalReport(String empNo, GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		if(this.isNullOrEmpty(fields.getFormalCaseSummary()))
			return new Response("Please provide case summary");

		String dmsOtherFiles = "";
		if(fields.getFormalInvestigationDocs().isEmpty())
			return new Response("Please upload case investigation documents");

		
		else {
			dmsOtherFiles=commonService.validateAndUploadDocumentsToDMS(fields.getFormalInvestigationDocs(), property.getDmsASHIInvestigationDocsFolder());

			if(dmsOtherFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsOtherFiles);
		}

		UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, "", "", "FRP", "", "");
		if(response.isSuccess()) {
			ELCMECMstASHIFormalInvestigationReportDetails reportDetails = new ELCMECMstASHIFormalInvestigationReportDetails(fields, dmsOtherFiles, Session.getTokenEMPNO(), currentDateTime);
			formalInvestigationReportDetailsRepository.save(reportDetails);
			return new Response(Message.SUCCESSPROCEED, "Successfully saved report.", "", commonService.getUIModuleId("ADCS") + "/" + fields.getCaseid());
		}
		else
			return new Response(Message.UNABLE_TO_PROCEED);	
	}

	@Override
	public LabelView getFormalReportDetails(int caseid) {
		List<CardViewField> fieldList=new ArrayList<>();
		List<CardViewAction> actions=new ArrayList<>();

		Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findByCaseId(caseid);
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(caseid);
		
		if(caseDetails.isPresent() && reportDetails.isPresent()) {
			fieldList.add(new CardViewField("Summary of Investigation", reportDetails.get().getSummary(), 54));
			fieldList.add(new CardViewField("Other Recommendations", reportDetails.get().getOtherRecommendations(), 54));

			if(this.notNullOrEmpty(reportDetails.get().getDmsInvestigationDocs())) {
				fieldList.add(new CardViewField("Case Investigation Documents", "", 88));
				String[] documents = reportDetails.get().getDmsInvestigationDocs().split(",");
				for(String document : documents) {
					fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "IID", reportDetails.get().getSerialNo(), document.trim()), 35));
				}
				
				if(documents.length>1)
					fieldList.add(new CardViewField(Constants.DOWNLOADALL, MessageFormat.format(property.getDownloadURL(), "IID", reportDetails.get().getSerialNo(), Constants.ALL), 87));
			}

			fieldList.addAll(this.getDocumentFields1(reportDetails.get()));
			
			if(caseDetails.get().getStatus().trim().equals("CLF")) {
				fieldList.addAll(this.getDocumentFields2(reportDetails.get()));
			}
		}

		return new LabelView(Constants.CASE_DETAILS, Constants.LABELVIEW_TYPE1, fieldList, actions, "");
	}

	private List<CardViewField> getDocumentFields1(ELCMECMstASHIFormalInvestigationReportDetails investigationDetails){
		List<CardViewField> fieldList=new ArrayList<>();

		if(investigationDetails.getFlgInvestigationPanelApproval()==1) {
			fieldList.add(new CardViewField("GRB Panel Approvals", "", 88));
			String[] files = investigationDetails.getDmsInvestigationPanelApprovals().split(",");
			for(String file : files) {
				fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "ADI", String.valueOf(investigationDetails.getSerialNo()), file.trim()), 35));
			}
		}
		else if(this.notNullOrEmpty(investigationDetails.getInvestigationPanelReason())){
			fieldList.add(new CardViewField("Reason for not uploading the approvals from Investigation Panel", investigationDetails.getInvestigationPanelReason().trim(), 54));
		}

		if(investigationDetails.getFlgPresidingOfficersApproval()==1) {
			fieldList.add(new CardViewField("Presiding Officers Approvals", "", 88));
			String[] files = investigationDetails.getDmsPresidingOfficersApprovals().split(",");
			for(String file : files) {
				fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "ADP", String.valueOf(investigationDetails.getSerialNo()), file.trim()), 35));
			}
		}
		else if (this.notNullOrEmpty(investigationDetails.getPresidingOfficersReason())){
			fieldList.add(new CardViewField("Reason for not uploading the approvals from Presiding Officers", investigationDetails.getPresidingOfficersReason().trim(), 54));
		}

		if(investigationDetails.getFlgExtICMembersApproval()==1) {
			fieldList.add(new CardViewField("External IC Members Approvals", "", 88));
			String[] files = investigationDetails.getDmsExtICMembersApprovals().split(",");
			for(String file : files) {
				fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "ADE", String.valueOf(investigationDetails.getSerialNo()), file.trim()), 35));
			}
		}
		else if(this.notNullOrEmpty(investigationDetails.getExtICMembersReason())){
			fieldList.add(new CardViewField("Reason for not uploading the approvals from External IC Members", investigationDetails.getExtICMembersReason().trim(), 54));
		}

		return fieldList;
	}
	
	private List<CardViewField> getDocumentFields2(ELCMECMstASHIFormalInvestigationReportDetails investigationDetails){
		List<CardViewField> fieldList=new ArrayList<>();

		Optional<ELCMECTrnASHIActionDetails> actionDetails = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(investigationDetails.getCaseId());
		if(actionDetails.isPresent() && this.notNullOrEmpty(actionDetails.get().getDmsFileName())) {
			fieldList.add(new CardViewField(Constants.CLOSURE_DOCUMENTS, "", 88));
			String[] files = actionDetails.get().getDmsFileName().split(",");
			for(String file : files) {
				fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "ID", String.valueOf(actionDetails.get().getCaseActionId()), file.trim()), 35));
			}
		}
		if(this.notNullOrEmpty(investigationDetails.getDmsActionImplementaionDocs())) {
			fieldList.add(new CardViewField("Action Implementation Documents", "", 88));
			String[] files = investigationDetails.getDmsActionImplementaionDocs().split(",");
			for(String file : files) {
				fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "AID", String.valueOf(investigationDetails.getSerialNo()), file.trim()), 35));
			}
		}
		return fieldList;
	}
	
	
	@Override
	public LabelView getCommentsLabel(int caseid) {
		List<CardViewField> fieldList=new ArrayList<>();
		List<CardViewAction> actions=new ArrayList<>();
		
		String status = "";
		if(Session.getCaseDetails().getCaseDetails().getInvestigationType().equals(Constants.CONCILIATION))
			status = "WEC";
		else if(Session.getCaseDetails().getCaseDetails().getInvestigationType().equals(Constants.FORMAL))
			status = "WGA";
		
		List<ELCMECTrnASHIActionDetails> actionList = ashiActionDetailsRepository.findByCaseIdAndGreaterThanCaseActionId(caseid, status);
		if(!actionList.isEmpty()) {
			for(ELCMECTrnASHIActionDetails actionObj : actionList) {
				if(this.notNullOrEmpty(actionObj.getComments())) {
					fieldList.add(new CardViewField(actionObj.getRole() + " " + Constants.COMMENTS, actionObj.getComments(), 54));
				}
				if(Arrays.asList("WEC","WCC").contains(actionObj.getStatus())) {
					fieldList.add(new CardViewField("GRB Panel Approvals", "", 88));
					String[] files = actionObj.getDmsFileName().split(",");
					for(String file : files) {
						fieldList.add(new CardViewField(file.trim(), MessageFormat.format(property.getDownloadURL(), "ID", String.valueOf(actionObj.getCaseActionId()), file.trim()), 35));
					}
				}
			}
		}

		return new LabelView(Constants.CASE_DETAILS, Constants.LABELVIEW_TYPE1, fieldList, actions, "");
	}

	@Override
	public GenModel getUploadApprovalsGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);

		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));

		GenModelField investigationPanelapprovals=new GenModelField( 60, "investigationPanelApprovals", "Approvals from Investigation Panel",new ArrayList<DocumentData>(),"","", validations);
		fields.add(investigationPanelapprovals);

		GenModelField flgInvestigationPanelApproval=new GenModelField( 45, "flgInvestigationPanelApproval", "I have uploaded approvals from Investigation Panel", 0, "", "",true);
		fields.add(flgInvestigationPanelApproval);

		GenModelField investigationPanelReason=new GenModelField( 1, "investigationPanelReason", Constants.REASON,"flgInvestigationPanelApproval|0", "","", true);
		investigationPanelReason.setPlaceHolder(Constants.REASON_PH);
		fields.add(investigationPanelReason);

		GenModelField presidingOfficersApprovals=new GenModelField( 60, "presidingOfficersApprovals", "Approvals from Presiding Officers",new ArrayList<DocumentData>(),"","", validations);
		fields.add(presidingOfficersApprovals);

		GenModelField flgPresidingOfficersApproval=new GenModelField( 45, "flgPresidingOfficersApproval", "I have uploaded approvals from Presiding Officers", 0, "", "",true);
		fields.add(flgPresidingOfficersApproval);

		GenModelField presidingOfficersReason=new GenModelField( 1, "presidingOfficersReason", Constants.REASON,"flgPresidingOfficersApproval|0", "","", true);
		presidingOfficersReason.setPlaceHolder(Constants.REASON_PH);
		fields.add(presidingOfficersReason);

		GenModelField extICMembersapprovals=new GenModelField( 60, "extICMembersapprovals", "Approvals from External IC Members",new ArrayList<DocumentData>(),"","", validations);
		fields.add(extICMembersapprovals);

		GenModelField flgExtICMembersApproval=new GenModelField(45, "flgExtICMembersApproval", "I have uploaded approvals from External IC Members", 0, "", "",true);
		fields.add(flgExtICMembersApproval);

		GenModelField extICMembersReason=new GenModelField( 1, "extICMembersReason", Constants.REASON,"flgExtICMembersApproval|0", "","", true);
		extICMembersReason.setPlaceHolder(Constants.REASON_PH);
		fields.add(extICMembersReason);

		return new GenModel("", fields, Arrays.asList(new CardViewAction(1, Constants.SUBMIT, Constants.POST, property.getUploadApprovalsURL(), Constants.SERVICEURL), new CardViewAction(1, Constants.BACK_TO_CASE_SUMMARY, Constants.POST, commonService.getUIModuleId("ADCS"), Constants.NAVIGATE)));

	}

	@Override
	public Response submitApprovals(String empNo, GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);

		Response validateResponse = this.validateApprovals(fields);

		if(validateResponse.getType().equals(Constants.FAILURE))
			return validateResponse;

		String investigationPanelApprovals = "";
		if(!fields.getInvestigationPanelApprovals().isEmpty()) {
			investigationPanelApprovals=commonService.validateAndUploadDocumentsToDMS(fields.getInvestigationPanelApprovals(), property.getDmsASHIInvestigationDocsFolder());

			if(investigationPanelApprovals.startsWith(Message.INVALID_FILE))
				return new Response(investigationPanelApprovals);
		}
		String presidingOfficersApprovals = "";
		if(!fields.getPresidingOfficersApprovals().isEmpty()) {
			presidingOfficersApprovals=commonService.validateAndUploadDocumentsToDMS(fields.getPresidingOfficersApprovals(), property.getDmsASHIInvestigationDocsFolder());

			if(presidingOfficersApprovals.startsWith(Message.INVALID_FILE))
				return new Response(presidingOfficersApprovals);
		}
		String extICMembersapprovals = "";
		if(!fields.getExtICMembersapprovals().isEmpty()) {
			extICMembersapprovals=commonService.validateAndUploadDocumentsToDMS(fields.getExtICMembersapprovals(), property.getDmsASHIInvestigationDocsFolder());

			if(extICMembersapprovals.startsWith(Message.INVALID_FILE))
				return new Response(extICMembersapprovals);
		}
		
		Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findByCaseId(fields.getCaseid());
		
		if(reportDetails.isPresent()) {
			ELCMECMstASHIFormalInvestigationReportDetails reportDetailsUpdated = new ELCMECMstASHIFormalInvestigationReportDetails(reportDetails.get(), fields, empNo, currentDateTime, investigationPanelApprovals, presidingOfficersApprovals, extICMembersapprovals);
			formalInvestigationReportDetailsRepository.save(reportDetailsUpdated);
			UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, "", "", "WGA", "", "");
			if(response.isSuccess()) {
				this.triggerMails(fields.getCaseid(), response.getAssigneeLocation(), response.getMailEventCode(), "");
				return new Response(Message.SUCCESSPROCEED, response.getMessage(), "", commonService.getUIModuleId("ADIN"));
			}
		}
		
		return new Response(Message.UNABLE_TO_PROCEED);
		
	}

	private Response validateApprovals(GMFields fields) {
		if(fields.getFlgInvestigationPanelApproval()==0 && this.isNullOrEmpty(fields.getInvestigationPanelReason()))
			return new Response("Please provide reason for not uploading approvals from Investigation Panel.");

		if(fields.getFlgInvestigationPanelApproval()==1 && fields.getInvestigationPanelApprovals().isEmpty())
			return new Response("Please upload approvals from Investigation Panel");

		if(fields.getFlgPresidingOfficersApproval()==0 && this.isNullOrEmpty(fields.getPresidingOfficersReason()))
			return new Response("Please provide reason for not uploading approvals from Presiding Officers.");

		if(fields.getFlgPresidingOfficersApproval()==1 && fields.getPresidingOfficersApprovals().isEmpty())
			return new Response("Please upload approvals from Presiding Officers");

		if(fields.getFlgExtICMembersApproval()==0 && this.isNullOrEmpty(fields.getExtICMembersReason()))
			return new Response("Please provide reason for not uploading approvals from External IC Members.");

		if(fields.getFlgExtICMembersApproval()==1 && fields.getExtICMembersapprovals().isEmpty())
			return new Response("Please upload approvals from External IC Members");

		return new Response(Message.SUCCESS, "");
	}

	@Override
	public Response actionSLAExtension(boolean flgAction, boolean flgApprove, String transactionid, GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(!flgAction && this.isNullOrEmpty(fields.getSlaExtendDate()))
			return new Response("Please provide SLA extension date");

		if(!flgAction && this.isNullOrEmpty(fields.getExtensionReason()))
			return new Response("Please select extension reason");

		if(this.isNullOrEmpty(fields.getComments())) {
			if(flgAction)
				return new Response("Please enter your comment.");
			else
				return new Response("Please enter reason(s) for SLA extension request.");
		}

		Optional<ELCMECtrnASHIConcernSLADetails> slaDetails = slaDetailsRepository.findByCaseIdAndRole(fields.getCaseid(), "IC");

		if(slaDetails.isPresent()) {


			if(flgAction) {
				return this.approveOrRejectSLAExtension(flgApprove, transactionid, slaDetails.get());
			}
			else {
				return this.requestSLAExtension(slaDetails.get(), fields);
			}
		}
		else
			return new Response("Unable to request");
	}

	private Response requestSLAExtension(ELCMECtrnASHIConcernSLADetails slaDetails, GMFields fields) throws CustomException {
		Timestamp extensionDate = new Timestamp(DateTimeFormat.forPattern(Constants.DATE_FORMAT).parseMillis(fields.getSlaExtendDate()));

		long days = TimeUnit.MILLISECONDS.toDays(extensionDate.getTime() - slaDetails.getSlaEndDate().getTime()); 
		


		if(days<=0)
			return new Response("Invalid Extended date.");
		
		int slaDays=0;
		Optional<ELCMECMstSysParams> slaLimit = elcmecMstSysParamsRepository.findByParamIdAndContextOrderByParamValueDesc("IC", "SLAEXT");

		if(slaLimit.isPresent()) {
			slaDays=Integer.parseInt(slaLimit.get().getParamValue());
			if(Math.toIntExact(days)>slaDays)
				return new Response("Extension can be requested for maximum " + slaDays + " days only at a time.");
		}

		if(slaDetails.getFlgSLAExtensionRequest()==1)
			return new Response("Already requested for SLA extension.");

		int noOfTime = slaAuditTrialRepository.countBySlaId(slaDetails.getSlaId());

		ELCMECtrnASHISLAAuditTrial slaExtensionDetails = new  ELCMECtrnASHISLAAuditTrial(slaDetails.getSlaId(), fields, Math.toIntExact(days), noOfTime, extensionDate);
		ELCMECtrnASHIConcernSLADetails slaDetailsUpdated = slaDetails;
		slaDetailsUpdated.setFlgSLAExtensionRequest(1);
		slaDetailsUpdated.setModifiedOn(currentDateTime);

		slaDetailsRepository.save(slaDetailsUpdated);
		slaAuditTrialRepository.save(slaExtensionDetails);
		
		this.triggerSLAMails(fields.getCaseid(), Math.toIntExact(days), slaDetails.getSlaDays(), new SimpleDateFormat(Constants.DATE_FORMAT).format(slaDetails.getSlaEndDate()), true, false);

		return new Response(Constants.SUCCESSPROCEED, "Successfully requested for SLA extension.", "", commonService.getUIModuleId("ADIN"));
	}

	private Response approveOrRejectSLAExtension(boolean flgApprove, String transactionid, ELCMECtrnASHIConcernSLADetails slaDetails) throws CustomException {

		if(this.isNullOrEmpty(transactionid))
			return new Response(Message.INVALID_INPUT);

		Optional<ELCMECtrnASHISLAAuditTrial> slaExtensionDetails = slaAuditTrialRepository.findByExtensionId(Integer.valueOf(transactionid));

		if(slaExtensionDetails.isPresent()) {

			if(slaExtensionDetails.get().getStatus().equals(Constants.APPROVED))
				return new Response("Request has been already approved.");

			else if(slaExtensionDetails.get().getStatus().equals(Constants.REJECTED))
				return new Response("Request has been already rejected.");

			String status = "";

			ELCMECtrnASHISLAAuditTrial slaExtensionDetailsUpdated = slaExtensionDetails.get();
			ELCMECtrnASHIConcernSLADetails slaDetailsUpdated = slaDetails;

			slaDetailsUpdated.setFlgSLAExtensionRequest(0);
			slaDetailsUpdated.setModifiedOn(currentDateTime);

			if(flgApprove) {
				status = Constants.APPROVED;
				slaDetailsUpdated.setSlaDays(slaDetailsUpdated.getSlaDays() + slaExtensionDetailsUpdated.getDays());
				slaDetailsUpdated.setSlaEndDate(slaExtensionDetailsUpdated.getSlaExtensionDate());
			}
			else
				status = Constants.REJECTED;

			slaExtensionDetailsUpdated.setStatus(status);
			slaExtensionDetailsUpdated.setModifiedBy("GRB");
			slaExtensionDetailsUpdated.setModifiedOn(currentDateTime);

			ELCMECtrnASHIConcernSLADetails newSLADetails = slaDetailsRepository.save(slaDetailsUpdated);
			slaAuditTrialRepository.save(slaExtensionDetailsUpdated);
			
			this.triggerSLAMails(newSLADetails.getCaseId(), 0, newSLADetails.getSlaDays(), new SimpleDateFormat(Constants.DATE_FORMAT).format(newSLADetails.getSlaEndDate()), false, flgApprove);

			return new Response(Constants.SUCCESSPROCEED, Message.SUCCESSFULLY_NEW + status + " SLA extension.", "", commonService.getUIModuleId("ADIN"));
		}
		else
			return new Response("Extension request not found");
	}
	
	private void triggerSLAMails(int caseid, int extensionDays, int currentSLADays, String slaEndDate, boolean flgRequest, boolean flgApprove) throws CustomException {
		Optional<ELCMECTrnASHIActionDetails> actionObj = ashiActionDetailsRepository.findByCaseIdAndMaxCaseActionId(caseid);
		if(!actionObj.isPresent()) 
			throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);
		
		List<MailContent> mailInfoList = new ArrayList<>();
		
		if(flgRequest) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIEXI");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();

			String ids =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEIDPH, String.valueOf(caseid));
			body = body.replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, actionObj.get().getAssigneeLocation().trim()).replace("#SLAExtensionDays#", String.valueOf(extensionDays)).replace("#SLACurrentDays#", String.valueOf(currentSLADays)).replace("#SLAEndDate#", slaEndDate);
			mailInfoList.add(new MailContent(body, subject, ids));


		}

		else {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIEXA");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();

			String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			subject = subject.replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.STATUS_PH, flgApprove ? Constants.APPROVED : Constants.REJECTED);
			body = body.replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.STATUS_PH, flgApprove ? Constants.APPROVED.toLowerCase() : Constants.REJECTED.toLowerCase()).replace("#RevisedSLA#", flgApprove ? "The revised SLA will expire in " + currentSLADays + " days by " + slaEndDate + "." : "<p>The SLA will expire in " + currentSLADays + " days i.e. by " + slaEndDate + ".</p>");
			mailInfoList.add(new MailContent(body, subject, ids));

		}
		
		for(MailContent mailDetails : mailInfoList) {

			MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), mailDetails.getRecipientMailId(), "");
			PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, mailDetails.getSubject())),new PlaceHolder(Constants.BODYPH, mailDetails.getBody())};

			MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
		}
	}


	/**
	 *Type
	 *	1	-	Prepare report inbox
	 *	2	-	Add allegation
	 *	3	-	View report inbox
	 * @throws CustomException 
	 */
	@Override
	public GenModel addFindingsGenmodel(int caseid, String transactionid, int type) throws CustomException {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		if(Arrays.asList(1,2,4).contains(type)) {
			commonService.checkCaseAuthorization(caseid, true);
		}
			

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);

		GenModelField transactionidField=new GenModelField( 14, Constants.TRANSACTIONID, "", transactionid, true, false);
		transactionidField.setEditable(false);


		List<GenModelOption> recipientTypeOptions=new ArrayList<>();
		recipientTypeOptions.add(new GenModelOption("A", Constants.COMPLAINANT));
		recipientTypeOptions.add(new GenModelOption("R", Constants.RESPONDENT));

		GenModelField recipientType=new GenModelField( 18, Constants.RECIPIENT_TYPE, "Choose The Recipient", Constants.COMPLAINANT, "",recipientTypeOptions, true);

		GenModelField recipient = null;

		if(Arrays.asList(2,3).contains(type)) {
			recipientType.setData("");
			recipient=new GenModelField(77, "recipient", "Choose Recipient", new ArrayList<String>(), Constants.RECIPIENT_TYPE, new ArrayList<>(), true);
			recipient.setDependantAction(property.getEmployeeOptionURL() + String.valueOf(caseid) + "|" + Constants.POST);
		}
		else {
			List<GenModelOption> recipientOptions = this.getEmployeesByActor(caseid, Constants.COMPLAINANT);

			recipient=new GenModelField(39, "recipient", "Choose Recipient", recipientOptions.isEmpty()?"":recipientOptions.get(0).getKey(), Constants.RECIPIENT_TYPE, recipientOptions, true);
			recipient.setDependantAction(property.getEmployeeOptionURL() + String.valueOf(caseid) + "|" + Constants.POST);
		}



		if(Arrays.asList(2,3).contains(type)) {
			String actionLabel = "Add";
			GenModelField allegationDesc=new GenModelField( 1, "allegationDesc", "Allegation","", "","", true);
			allegationDesc.setPlaceHolder("Please enter allegation description here...");

			GenModelField findings=new GenModelField( 1, "findings", "Findings","", "","", true);
			findings.setPlaceHolder("Please enter description of the key finding here...");


			List<GenModelOption> outcomeOptions=genModelOptionsRepository.getGenModelOptionsByGroupIdOrderByKeyAsc(2, "AO");

			GenModelField outcome=new GenModelField( 11, "outcome", "Outcome", "", "", outcomeOptions, true);

			if(type==3) {
				Optional<ELCMECMstASHIAllegationsAndFindingsDetails> finding = allegationsAndFindingsDetailsRepository.findById(Integer.valueOf(transactionid));

				if(finding.isPresent()) {
					commonService.checkCaseAuthorization(finding.get().getCaseId(), true);
					
					actionLabel = Constants.UPDATE;

					caseidField.setData(finding.get().getCaseId());
					transactionidField.setData(finding.get().getSerialNo());
					recipientType.setData(this.getEmployeeType(finding.get().getActor()));
					recipientType.setEditable(false);
					recipient.setData(Arrays.asList(finding.get().getMailId()));
					recipient.setOptions(this.getEmployeesByActor(finding.get().getCaseId(), this.getEmployeeType(finding.get().getActor())));
					recipient.setEditable(false);
					allegationDesc.setData(finding.get().getAllegation());
					findings.setData(finding.get().getFinding());
					outcome.setData(finding.get().getOutcome());
				}
			}



			fields.add(caseidField);
			fields.add(transactionidField);
			fields.add(recipientType);
			fields.add(recipient);
			fields.add(allegationDesc);
			fields.add(findings);
			fields.add(outcome);

			actions.add(new CardViewAction(1, actionLabel, Constants.POST, property.getFindingAddOrUpdateURL(), Constants.SERVICEURL));
			actions.add(new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));
		}
		else if(type==1){
			fields.add(caseidField);
			fields.add(recipientType);
			fields.add(recipient);


			actions.add(new CardViewAction(1, "Search", Constants.POST, property.getFindingSearchURL()+true, Constants.SERVICEURL));
			if(!Session.getCaseDetails().getStatus().equals("WCC"))
				actions.add(new CardViewAction(1, "Add Findings", Constants.POST, commonService.getUIModuleId("FRAF"), Constants.GENERICMODELPOPUP));
		}

		else if(type==4){
			fields.add(caseidField);
			fields.add(recipientType);
			fields.add(recipient);

			actions.add(new CardViewAction(1, "View Findings", Constants.POST, property.getFindingSearchURL()+false, Constants.SERVICEURL));
		}

		return new GenModel("", fields, actions, caseid);
	}

	@Override
	public Response addFindings(GenModel genmodel) {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(!caseDetailsRepository.existsById(fields.getCaseid()))
			return new Response(Message.CASENOTREGISTERED);

		if(this.nullOrEmptyOrSelect(fields.getRecipientType()))
			return new Response("Please select recipient type");

		if(this.nullOrEmptyOrSelect(fields.getRecipient()))
			return new Response("Please select recipient");

		if(this.nullOrEmptyOrSelect(fields.getAllegationDesc()))
			return new Response("Please enter Allegation description");

		if(this.nullOrEmptyOrSelect(fields.getFindings()))
			return new Response("Please enter findings");

		if(this.nullOrEmptyOrSelect(fields.getOutcome()))
			return new Response("Please select outcome");

		if(this.isNullOrEmpty(fields.getTransactionid())) {
			CaseDetailsValidationResponse recipientResponse = commonService.validateEmployeeDetails(fields.getRecipient(), "Recipient : " + fields.getRecipientType());
			if(!recipientResponse.isStatus())
				return new Response(recipientResponse.getMessage());

			List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = new ArrayList<>();

			for(ViewCurrEmpAllDetails recipient : recipientResponse.getIds()) {

				findings.add(new ELCMECMstASHIAllegationsAndFindingsDetails(fields, this.getActor(fields.getRecipientType()), recipient.getMailId(), Session.getTokenEMPNO(), currentDateTime));
			}

			allegationsAndFindingsDetailsRepository.saveAll(findings);
			return new Response(Constants.SUCCESSHIDEFORM, "Successfully added findings");
		}
		else {
			Optional<ELCMECMstASHIAllegationsAndFindingsDetails> finding = allegationsAndFindingsDetailsRepository.findById(Integer.valueOf(fields.getTransactionid()));

			if(finding.isPresent()) {
				ELCMECMstASHIAllegationsAndFindingsDetails updatedFinding = new ELCMECMstASHIAllegationsAndFindingsDetails(finding.get(), fields, Session.getTokenEMPNO(), currentDateTime);

				allegationsAndFindingsDetailsRepository.save(updatedFinding);

				return new Response(Constants.SUCCESSHIDEFORM, "Successfully updated finding");
			}

			else
				return new Response("Unable to update");
		}

	}

	@Override
	public InboxView getFindings(boolean filter, FindingFilter findingFilter) {

		if(this.nullOrEmptyOrSelect(findingFilter.getRecipientType()))
			return new InboxView("Please select recipient type");

		if(this.isNullOrEmpty(findingFilter.getRecipient()))
			return new InboxView("Please select recipient");

		List<CardViewAction> mainActions = new ArrayList<>();
		boolean flgSendFinding = false;
		List<Findings> findings = allegationsAndFindingsDetailsRepository.findByCaseIdAndActorAndMailId(findingFilter.getCaseid(), this.getActor(findingFilter.getRecipientType()), findingFilter.getRecipient());

		if(findings.isEmpty())
			return new InboxView("No findings found for " + findingFilter.getRecipientType() + " " + findingFilter.getRecipient());
		
		List<Header> headerList = Arrays.asList(new Header("Allegation", "allegation", "", true, 14, 0, "", "", false, ""),
				new Header("Finding", "finding", "", false, 14, 0, "", "", false, ""),
				new Header("Outcome", "outcome", "", false, 14, 0, "", "", false, ""));
		List<Row> rowList = new ArrayList<>();

		int i = 0;
		String addFindingsModuleId = commonService.getUIModuleId("FREF");
		for (Findings row : findings) {

			List<CardViewAction> actions = new ArrayList<>();

			if(filter && !Session.getCaseDetails().getStatus().equals("WCC")) {
				actions.add(new CardViewAction("EditFindings", "", Constants.NAVIGATE, addFindingsModuleId, Constants.GENMODELPOPUP, "icons\\default_icons\\icon-edit.png", ""));
				actions.add(new CardViewAction("Delete", "", Constants.POST, property.getFindingDeleteURL() + row.getSerialNo(), Constants.SERVICEURL, "delete-icon.png", "Are you sure you want to delete this finding details" + Constants.YES_NO));
			}

			rowList.add(new Row(row, ++i, String.valueOf(row.getSerialNo()), actions));

			if(row.getFlgFindingSent()==0)
				flgSendFinding = true;
		}

		if(flgSendFinding)
			mainActions.add(new CardViewAction("", "Send Findings", Constants.POST, MessageFormat.format(property.getSendFindingsGenmodelURL(), this.getActor(findingFilter.getRecipientType()), String.valueOf(findingFilter.getCaseid()), findingFilter.getRecipient()), "popup", "icon x-24 send-Icon", ""));
		mainActions.add(new CardViewAction("", "Consolidated report of allegations and findings", Constants.POST, property.getConsolidatedFindingsURL() + String.valueOf(findingFilter.getCaseid()), "popup", "icon x-24 send-Icon", ""));

		return new InboxView("", "", Constants.INBOXVIEW, headerList, rowList, 10, filter ? mainActions : new ArrayList<>(), "");
		
	}

	@Override
	public Response deleteFindings(int transactionid) {
		Optional<ELCMECMstASHIAllegationsAndFindingsDetails> finding = allegationsAndFindingsDetailsRepository.findById(transactionid);

		if(finding.isPresent()) {
			allegationsAndFindingsDetailsRepository.delete(finding.get());

			return new Response(Message.SUCCESS, "Successfully deleted finding");
		}

		else
			return new Response("Unable to delete finding");
	}


	@Override
	public GenModel sendFindingsGenmodel(int caseid, String actor, String mailId) {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();		

		List<Findings> findings = allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(caseid, actor, mailId);
		if(!findings.isEmpty()) {
			StringBuilder rows = new StringBuilder();
			int count=0;
			for(Findings finding : findings) {
				String row = Constants.SEND_FINDING_ROW.replace(Constants.SNO_PH, String.valueOf(++count)).replace(Constants.ALLEGATION_PH, finding.getAllegation().trim()).replace(Constants.FINDING_PH, finding.getFinding().trim()).replace(Constants.OUTCOME_PH, finding.getOutcome().trim());
				rows.append(row);
			}
			String content = Constants.SEND_FINDING.replace(Constants.RECIPIENTTYPE_PH, this.getEmployeeType(actor)).replace(Constants.KEYWORD_PH, actor.equals("A")?"by":Constants.AGAINST_KW).replace(Constants.RECIPIENT_PH, findings.get(0).getEmpName()).replace(Constants.ICLOCATION_PH, findings.get(0).getAssigneeLocation().trim()).replace("#Table#", Constants.SEND_FINDING_TABLE.replace(Constants.ROWS_PH, rows.toString()));
			
			GenModelField findingContentField=new GenModelField(54, "findingContent", "", content, false, true);
			fields.add(findingContentField);

			actions.add(new CardViewAction(1, Constants.SUBMIT, Constants.POST, MessageFormat.format(property.getSendFindingsURL(), actor, String.valueOf(caseid), mailId), Constants.SERVICEURL));
			actions.add(new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));
		}



		return new GenModel("", fields, actions);

	}


	@Override
	public Response sendFindings(String sender, int caseid, String actor, String mailId) throws CustomException {
		MailContent mailInfo=mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIADSF");
		List<Integer> serialNos= new ArrayList<>(); 
		if(mailInfo!=null) {
			List<Findings> findings = allegationsAndFindingsDetailsRepository.findFindingsByCaseIdAndActorAndMailId(caseid, actor, mailId);
			if(!findings.isEmpty()) {
				StringBuilder rows = new StringBuilder();
				int count=0;
				for(Findings finding : findings) {
					String row = Constants.SEND_FINDING_ROW.replace(Constants.SNO_PH, String.valueOf(++count)).replace(Constants.ALLEGATION_PH, finding.getAllegation().trim()).replace(Constants.FINDING_PH, finding.getFinding().trim()).replace(Constants.OUTCOME_PH, finding.getOutcome().trim());
					rows.append(row);
					serialNos.add(finding.getSerialNo());
				}
				String body = mailInfo.getBody().replace(Constants.RECIPIENT_PH, findings.get(0).getEmpName()).replace(Constants.KEYWORD_PH, actor.equals("A")?"by":Constants.AGAINST_KW).replace(Constants.ICLOCATION_PH, findings.get(0).getAssigneeLocation().trim()).replace("#ICMailId#", sender + property.getInfyDomain()).replace("#Table#", Constants.SEND_FINDING_TABLE.replace(Constants.ROWS_PH, rows.toString()));
				String subject = mailInfo.getSubject().replace("#CaseId#", String.valueOf(caseid));
				MailInfo mailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), mailId + property.getInfyDomain(), "");
				PlaceHolder[] placeHolders = {(new PlaceHolder(Constants.SUBJECTPH, subject)),new PlaceHolder(Constants.BODYPH, body)};

				MailerAssistRequest mailObj=new MailerAssistRequest(mailInfoObj, placeHolders);

				MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
				if(mailerResponse.getCode()!=0)
					throw new CustomException(mailId + " findings " + Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
				else {
					List<ELCMECMstASHIAllegationsAndFindingsDetails> findingsList = allegationsAndFindingsDetailsRepository.findBySerialNoIn(serialNos);
					findingsList.forEach(f -> {f.setFlgSentFindings(1);f.setUpdatedBy(sender);f.setUpdatedDate(currentDateTime);});
					
					allegationsAndFindingsDetailsRepository.saveAll(findingsList);
					return new Response(Constants.SUCCESSHIDEFORM, "Successfully sent findings to " + this.getEmployeeType(actor) + " " + mailId);
				}
			}
			else
				return new Response(Message.ERROR, "Finding details not found");
		}
		else
			return new Response(Message.ERROR, "Mail content not found");

		
	}


	@Override
	public GenModel consolidatedFindingsGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();
		List<CardViewAction> actions = new ArrayList<>();

		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(caseid);
		StringBuilder content = new StringBuilder(Constants.CONSOLIDATED_FINDING);
		StringBuilder rows = new StringBuilder();
		int count=0;
		for(int i=0; i<findings.size(); i++) {
			if(i!=0 && !(!findings.get(i).getActor().equals(findings.get(i-1).getActor()) && findings.get(i).getMailId().equals(findings.get(i-1).getMailId()))) {
				if(findings.get(i).getActor().equals(findings.get(i-1).getActor()) && findings.get(i).getMailId().equals(findings.get(i-1).getMailId())) {
					String row = Constants.SEND_FINDING_ROW.replace(Constants.SNO_PH, String.valueOf(++count)).replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation().trim()).replace(Constants.FINDING_PH, findings.get(i).getFinding().trim()).replace(Constants.OUTCOME_PH, findings.get(i).getOutcome().trim());
					rows.append(row);
				}
				else {
					content.append(Constants.CONSOLIDATED_FINDING_BLOCK.replace(Constants.RECIPIENTTYPE_PH, this.getEmployeeType(findings.get(i-1).getActor())).replace(Constants.RECIPIENT_PH, findings.get(i-1).getMailId()).replace(Constants.STATUS_PH, this.getConsolidatedTableStatus(findings.get(i-1).getFlgSentFindings(), findings.get(i-1).getCreatedDate(), findings.get(i-1).getUpdatedDate())).replace(Constants.ROWS_PH, rows.toString()));
					count = 0;
					rows = new StringBuilder();
					String row = Constants.SEND_FINDING_ROW.replace(Constants.SNO_PH, String.valueOf(++count)).replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation().trim()).replace(Constants.FINDING_PH, findings.get(i).getFinding().trim()).replace(Constants.OUTCOME_PH, findings.get(i).getOutcome().trim());
					rows.append(row);
				}
				
				if(i==(findings.size()-1))
					content.append(Constants.CONSOLIDATED_FINDING_BLOCK.replace(Constants.RECIPIENTTYPE_PH, this.getEmployeeType(findings.get(i).getActor())).replace(Constants.RECIPIENT_PH, findings.get(i).getMailId()).replace(Constants.STATUS_PH, this.getConsolidatedTableStatus(findings.get(i).getFlgSentFindings(), findings.get(i).getCreatedDate(), findings.get(i).getUpdatedDate())).replace(Constants.ROWS_PH, rows.toString()));
			}

			else {
				String row = Constants.SEND_FINDING_ROW.replace(Constants.SNO_PH, String.valueOf(++count)).replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation().trim()).replace(Constants.FINDING_PH, findings.get(i).getFinding().trim()).replace(Constants.OUTCOME_PH, findings.get(i).getOutcome().trim());
				rows.append(row);
			}
		}
		
		if(findings.size()==1) {
			content.append(Constants.CONSOLIDATED_FINDING_BLOCK.replace(Constants.RECIPIENTTYPE_PH, this.getEmployeeType(findings.get(0).getActor())).replace(Constants.RECIPIENT_PH, findings.get(0).getMailId()).replace(Constants.STATUS_PH, this.getConsolidatedTableStatus(findings.get(0).getFlgSentFindings(), findings.get(0).getCreatedDate(), findings.get(0).getUpdatedDate())).replace(Constants.ROWS_PH, rows.toString()));
		}
		
		GenModelField findingContentField=new GenModelField(54, "findingContent", "", content, false, true);
		fields.add(findingContentField);

		actions.add(new CardViewAction(1, Constants.CANCEL, "", "", Constants.CANCELMODELPOPUP));


		return new GenModel("", fields, actions);
	}
	
	private String getConsolidatedTableStatus(int flgSentFindings, Timestamp createdDate, Timestamp updatedDate) {
		
		if(flgSentFindings==1) {
			return "Findings sent on " + new SimpleDateFormat(Constants.DATE_FORMAT).format(updatedDate);
		}
		else {
			return "Findings added on " + new SimpleDateFormat(Constants.DATE_FORMAT).format(createdDate);
		}
		
	}


	@Override
	public GenModel getDownloadTemplateGenmodel() {
		List<GenModelField> fields = new ArrayList<>();
		List<GenModelOption> options = new ArrayList<>();
		options.add(new GenModelOption("TMGRB", "GRB"));
		options.add(new GenModelOption("TMIC", "IC"));
		GenModelField templateFor=new GenModelField( 18, "templateFor", "Template for", "", "",options, true);
		fields.add(templateFor);

		GenModelField chooseTemplate=new GenModelField( 39, "template", "Choose Template", "", "templateFor", new ArrayList<>(), true);
		chooseTemplate.setDependantAction(property.getGenmodelOptionsByGroupIdURL()+"|"+Constants.POST);
		fields.add(chooseTemplate);

		return new GenModel("", fields, Arrays.asList(new CardViewAction(1, Constants.DOWNLOAD, Constants.POST, property.getDownloadTemplateURL(), Constants.DOWNLOAD.toLowerCase())));
	}
	

	@Override
	public DocumentData downloadTemplate(GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		if(StringUtils.isEmpty(fields.getTemplate()))
			return new DocumentData(Message.ERROR, "Please select template.");
		
		DMSModel outputModel = commonService.dmsService(new DMSModel(property.getDmsApplicationName(), property.getDmsApplicationID(), property.getDmsStorageURL(), property.getDmsDocumentPath() + property.getDmsOfficialDocumentPath(), fields.getTemplate()), Constants.DOWNLOAD);
		return new DocumentData(outputModel.getDocumentName(), outputModel.getDocumentBytes());
	}
	
	
	public UpdateCaseStatusReturn updateCaseAndActionDetails(ELCMECTrnASHICaseDetails caseDetails, String empNo, String comment, String dmsfiles, String nextStatus, String assignedEmpNo, String assignedLocation) {
		String assigneeEmpNo = "";
		String assigneeLocation = "";

		Optional<ELCMECMstReachWorkFlow> workflow = null;
		if(nextStatus.isEmpty())
			workflow = workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActive(2, caseDetails.getStatus().trim(), 1);
		else
			workflow = workFlowRepository.findByModuleIdAndCurrentStatusAndFlgActiveAndNextStatus(2, caseDetails.getStatus().trim(), 1, nextStatus);

		if(workflow.isPresent()) {
			if(workflow.get().getNextStatus().equals("WI") && !workflow.get().getCurrentStatus().equals("DMRI")) {
				assigneeEmpNo = assignedEmpNo;
				assigneeLocation = assignedLocation;
			}

			Optional<ELCMECTrnASHIActionDetails> assigneeDetails = ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(caseDetails.getCaseId(), workflow.get().getToRole().trim());
			if(assigneeDetails.isPresent()) {
				assigneeEmpNo = assigneeDetails.get().getAssigneeEmpNo();
				assigneeLocation = assigneeDetails.get().getAssigneeLocation();
			}

			caseDetails.setStatus(workflow.get().getNextStatus());
			caseDetails.setModifiedBy(empNo);
			caseDetails.setModifiedOn(currentDateTime);
			
			if(Arrays.asList("CLN", "DM", "CLC", "CLF").contains(caseDetails.getStatus().trim()))
				caseDetails.setCaseClosedDate(currentDateTime);

			ELCMECTrnASHIActionDetails actionDetails = new ELCMECTrnASHIActionDetails(caseDetails.getCaseId(), workflow.get().getFromRole(), comment, workflow.get().getNextStatus(), dmsfiles, empNo, currentDateTime);
			actionDetails.setAssigneeEmpNo(assigneeEmpNo);
			actionDetails.setAssigneeLocation(assigneeLocation);

			caseDetailsRepository.save(caseDetails);

			ashiActionDetailsRepository.save(actionDetails);
			
			if(workflow.get().getSlaDays()!=0) {
				Timestamp slaEndDateTime=new Timestamp(System.currentTimeMillis()+19800000+TimeUnit.DAYS.toMillis(workflow.get().getSlaDays()));
				ELCMECtrnASHIConcernSLADetails slaDetails=new ELCMECtrnASHIConcernSLADetails(caseDetails.getCaseId(), workflow.get().getSlaDays(), workflow.get().getToRole(), currentDateTime, slaEndDateTime, Session.getTokenEMPNO());
				slaDetailsRepository.save(slaDetails);
			}

			return new UpdateCaseStatusReturn(true, workflow.get(), assignedLocation);
		}
		return new UpdateCaseStatusReturn(false);


	}

	@Override
	public GenModel getFormalReportCheckListGenmodel(int caseid) {
		List<GenModelField> fields = new ArrayList<>();

		if(!caseDetailsRepository.existsById(caseid))
			return new GenModel(Message.CASENOTREGISTERED, "", fields);

		GenModelField caseidField=new GenModelField( 14, Constants.CASEID, "", caseid, true, false);
		caseidField.setEditable(false);
		fields.add(caseidField);
		
		GenModelField closureHeading=new GenModelField( 54, "closureHeading", "", "<b>Confirm closure with Complainants and Respondents</b>", false, true);
		fields.add(closureHeading);
		
		GenModelField flgBothPartiesClosure=new GenModelField( 5, "flgBothPartiesClosure", "Closed with both the parties", 0, "", "",true);
		fields.add(flgBothPartiesClosure);
		
		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));

		GenModelField closureDocs=new GenModelField( 60, Constants.DOCUMENTS.toLowerCase(), Constants.CLOSURE_DOCUMENTS,new ArrayList<DocumentData>(),"","(Closure Emails/Letter, Warning letter etc.,)", validations);
		fields.add(closureDocs);
		
		GenModelField recommendationHeading=new GenModelField( 54, "recommendationHeading", "", "<b>Confirm if you have implemented all the recommended actions</b>", false, true);
		fields.add(recommendationHeading);
		
		List<GenModelOption> respondentRecommendations = recommendationsDetailsRepository.findByCaseIdAndActor(caseid, "R");
		if(!respondentRecommendations.isEmpty()) {
			GenModelField flgRecommendation=new GenModelField(151, "checklistRespondent", Constants.RESPONDENTS, "", "", "",true);
			flgRecommendation.setOptions(respondentRecommendations);
			fields.add(flgRecommendation);
		}
		
		List<GenModelOption> complainantRecommendations = recommendationsDetailsRepository.findByCaseIdAndActor(caseid, "A");
		if(!complainantRecommendations.isEmpty()) {
			GenModelField flgRecommendation=new GenModelField(151, "checklistComplainant", Constants.COMPLAINANTS, "", "", "",true);
			flgRecommendation.setOptions(complainantRecommendations);
			fields.add(flgRecommendation);
		}
		
		List<GenModelOption> witnessRecommendations = recommendationsDetailsRepository.findByCaseIdAndActor(caseid, "W");
		if(!witnessRecommendations.isEmpty()) {
			GenModelField flgRecommendation=new GenModelField(151, "checklistWitness", Constants.WITNESSES, "", "", "",true);
			flgRecommendation.setOptions(witnessRecommendations);
			fields.add(flgRecommendation);
		}

		GenModelField implementationDocs=new GenModelField( 60, "implementationDocs", "Action Implementation Documents",new ArrayList<DocumentData>(),"","(Communication to C&B, Unit HR, etc.,)", validations);
		fields.add(implementationDocs);

		return new GenModel("", fields, Arrays.asList(new CardViewAction(1, Constants.CLOSE_CASE, Constants.POST, property.getFormalReportChecklistSaveURL(), Constants.SERVICEURL)));
	}

	
	
	@Override
	public Response updateFormalReportCheckList(String empNo, GenModel genmodel) throws CustomException {
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);

		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(fields.getCaseid());
		if(!caseDetails.isPresent())
			return new Response(Message.CASENOTREGISTERED);
		
		if(fields.getFlgBothPartiesClosure()==0)
			return new Response("Closure with both the parties is mandatory before closing the case.");
		
		if(!fields.getUncheckedRecommendations().isEmpty())
			return new Response("All the recommended actions must be implemented before closing the case.");
		
		if(fields.getDocuments().isEmpty())
			return new Response("Please upload Closure document.");
		
		if(fields.getImplementationDocs().isEmpty())
			return new Response("Please upload Implementaion documents.");
		
		String closureDocuments = commonService.validateAndUploadDocumentsToDMS(fields.getDocuments(), property.getDmsASHIInvestigationDocsFolder());

		if(closureDocuments.startsWith(Message.INVALID_FILE))
			return new Response(closureDocuments);


		String implementationDocs = commonService.validateAndUploadDocumentsToDMS(fields.getImplementationDocs(), property.getDmsASHIInvestigationDocsFolder());

		if(implementationDocs.startsWith(Message.INVALID_FILE))
			return new Response(implementationDocs);


		
		List<ELCMECMstASHIRecommendationsDetails> recommendations = recommendationsDetailsRepository.findByCaseIdAndFlgImplemented(fields.getCaseid(), 0);
		
		for(ELCMECMstASHIRecommendationsDetails recommendation : recommendations) {
			if(fields.getCheckedRecommendations().contains(recommendation.getSerialNo())) {
				recommendation.setFlgImplemented(1);
				recommendation.setUpdatedBy(empNo);
				recommendation.setUpdatedDate(currentDateTime);
			}
		}
		
		long count = recommendations.stream().filter(r -> r.getFlgImplemented()==0).count();
		
		if(count>0)
			return new Response("All the recommended actions must be implemented before closing the case.");

		Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findByCaseId(fields.getCaseid());
		
		if(reportDetails.isPresent()) {
			reportDetails.get().setFlgClosedWithBothParties(fields.getFlgBothPartiesClosure());
			reportDetails.get().setDmsActionImplementaionDocs(implementationDocs);
			reportDetails.get().setUpdatedBy(empNo);
			reportDetails.get().setUpdatedDate(currentDateTime);
			
			UpdateCaseStatusReturn response = this.updateCaseAndActionDetails(caseDetails.get(), empNo, "", closureDocuments, "CLF", "", "");
			if(response.isSuccess()) {
				recommendationsDetailsRepository.saveAll(recommendations);
				formalInvestigationReportDetailsRepository.save(reportDetails.get());
				this.triggerMails(fields.getCaseid(), response.getAssigneeLocation(), response.getMailEventCode(), "");
				return new Response(Message.SUCCESSPROCEED, response.getMessage(), "", commonService.getUIModuleId("ADIN"));
			}
		}
		
		
		return new Response(Message.UNABLE_TO_PROCEED);

	}

	@Override
	public Response triggerEmployeeNotificationMail(int caseid, String actor, int transactionid) throws CustomException {
		
		List<MailContent> mailInfoList = new ArrayList<>();
		
		if(actor.equals("T")) {
			
			Optional<ELCMECMstASHICocomplainantsDetails> employeeDetails = ashiCocomplainantsDetailsRepository.findById(transactionid);
			List<EmployeeDetails> initiatorDetails = caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseid, Arrays.asList("I"));
			if(employeeDetails.isPresent() && !initiatorDetails.isEmpty()) {
				MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICC");
				String subject = mailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseid));
				String body = mailInfo.getBody().replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.EMPNAME_PH, employeeDetails.get().getMailId().trim()).replace("#InitiatorName#", initiatorDetails.get(0).getName().trim()).replace("#InitiatorId#", initiatorDetails.get(0).getEmpNo().trim());
				mailInfoList.add(new MailContent(body, subject, employeeDetails.get().getMailId().trim() + property.getInfyDomain()));
			}

			
		}
		
		else if(actor.equals("R")) {
			Optional<ELCMECMstASHICaseEmployeeDetails> employeeDetails = caseEmployeeDetailsRepository.findById(transactionid);
			List<EmployeeDetails> complainantDetails = caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseid, Arrays.asList("A","T"));
			StringBuilder complainantsName = new StringBuilder();
			complainantDetails.forEach(c -> complainantsName.append(c.getName().trim()).append(", "));
			
			if(employeeDetails.isPresent() && complainantsName.length()!=0) {
				MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIRS");
				String subject = mailInfo.getSubject().replace(Constants.CASEIDPH, String.valueOf(caseid));
				String body = mailInfo.getBody().replace(Constants.CASEIDPH, String.valueOf(caseid)).replace(Constants.EMPNAME_PH, employeeDetails.get().getEmpName().trim()).replace("#ComplainantsName#", complainantsName.substring(0, complainantsName.length()-2));
				mailInfoList.add(new MailContent(body, subject, employeeDetails.get().getMailId().trim() + property.getInfyDomain()));
			}
		}

		
		for(MailContent mailDetails : mailInfoList) {

			MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), mailDetails.getRecipientMailId(), "");
			PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, mailDetails.getSubject())),new PlaceHolder(Constants.BODYPH, mailDetails.getBody())};

			MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

			if(commonService.triggerMail(mailObj).getCode()==0)
				return new Response(Message.SUCCESS, "Successfully triggered notification mail to the " + this.getEmployeeType(actor));
		}
		
		return new Response("Unable to send mail. Please try again.");
	}
	

	
	
	public void triggerMails(int caseid, String assigneeLocation, List<String> mailEventCodes, String comment) throws CustomException {
		
		if(!mailEventCodes.isEmpty()) {
			
			List<MailContent> mailInfoList = new ArrayList<>(); 
			
			for(String mailEventCode : mailEventCodes) {
				mailInfoList.addAll(this.getMailContents1(caseid, mailEventCode, assigneeLocation, comment));
				mailInfoList.addAll(this.getMailContents2(caseid, mailEventCode, assigneeLocation, comment));
			}
			
			for(MailContent mailDetails : mailInfoList) {

				MailInfo cocomplainantMailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYI(), property.getTemplateIdFYI(), property.getFromId(), mailDetails.getRecipientMailId(), "");
				PlaceHolder[] cocomplainantPlaceHolders = {(new PlaceHolder(Constants.SUBJECTPH, mailDetails.getSubject())),new PlaceHolder(Constants.BODYPH, mailDetails.getBody())};

				MailerAssistRequest mailObj=new MailerAssistRequest(cocomplainantMailInfoObj, cocomplainantPlaceHolders);

				MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
				if(mailerResponse.getCode()!=0)
					throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
			}
		}
	}
	
	public List<MailContent> getMailContents1(int caseid, String mailEventCode, String icLocation, String comment) throws CustomException {

		List<MailContent> mailInfoList = new ArrayList<>();
		
		if(Arrays.asList("ASHIDM", "ASHICLN").contains(mailEventCode)) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(mailEventCode);
			List<MailEmployeeDetails> detailsList =  caseDetailsRepository.getDetailsForMail(caseid, "A", "");
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			for(MailEmployeeDetails details : detailsList) {
				subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
				body = body.replace(Constants.RECIPIENT_PH, WordUtils.capitalize(details.getEmpName().trim())).replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.COMMENT_PH, comment);
				mailInfoList.add(new MailContent(body, subject, details.getMailId() + property.getInfyDomain(), grbIds));
			}
			
		}
		
		else if(mailEventCode.equals("ASHIWG")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWG");
			String ids =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			List<MailEmployeeDetails> detailsList =  caseDetailsRepository.getDetailsForMail(caseid, "I", "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.EMPNAME_PH, detailsList.get(0).getEmpName()).replace(Constants.EMPNO_PH, detailsList.get(0).getEmpNo());
			mailInfoList.add(new MailContent(body, subject, ids));

		}

		else if(mailEventCode.equals("ASHIWI")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWI");
			String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			List<MailEmployeeDetails> detailsList =  caseDetailsRepository.getDetailsForMail(caseid, "I", "IC");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim())).replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.EMPNAME_PH, detailsList.get(0).getEmpName()).replace(Constants.EMPNO_PH, detailsList.get(0).getEmpNo()).replace(Constants.SLAENDDATE_PH, detailsList.get(0).getSlaEndDate());
			mailInfoList.add(new MailContent(body, subject, ids));

		}
		
		else if(mailEventCode.equals("ASHIDMRI")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIDMRI");
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim())).replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.COMMENT_PH, comment);
			mailInfoList.add(new MailContent(body, subject, grbIds, icIds));

		}
		
		else if(mailEventCode.equals("ASHIDMRA")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIDMRA");
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));

		}
		
		else if(mailEventCode.equals("ASHIDMRR")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIDMRR");
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));

		}

		else if(mailEventCode.equals("ASHICIA")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICIA");
			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();

			String ids =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, ids));


		}

		else if(mailEventCode.equals("ASHICIR")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICIR");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.STATUS_PH, Constants.REJECTED);
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, ids));

		}

		else if(mailEventCode.equals("ASHIPCR")) {
			this.triggerConciliationConsents(caseid);
			
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIPCR");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.STATUS_PH, Constants.APPROVED);
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, ids));

			
		}

		else if(mailEventCode.equals("ASHICRA")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICRA");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String ids =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, ids));
		}
		
		else if(mailEventCode.equals("ASHICRR")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICRR");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim())).replace(Constants.COMMENT_PH, comment);
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));
		}
		
		else if(mailEventCode.equals("ASHIWEC")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWEC");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String erhIds =  commonService.getIdStringByRoleAndModule("ERH", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, erhIds, grbIds + icIds));
		}
		
		else if(mailEventCode.equals("ASHICANI")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICANI");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String ids =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, ids));
		}
		
		return mailInfoList;
	}
	
	public List<MailContent> getMailContents2(int caseid, String mailEventCode, String icLocation, String comment) throws CustomException {

		List<MailContent> mailInfoList = new ArrayList<>();
		
		
		if(mailEventCode.equals("ASHICCEA")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHICCLNA");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));
		}
		
		else if(Arrays.asList("ASHICCEE", "ASHIFCIE").contains(mailEventCode)) {
			List<EmployeeDetails> complainants = caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseid, Arrays.asList("A"));
			List<EmployeeDetails> respondents = caseEmployeeDetailsRepository.findEmployeeDetailsByCaseId(caseid, Arrays.asList("R"));
			
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode(mailEventCode);

			for(EmployeeDetails complainant : complainants) {
				String subject = mailInfo.getSubject();
				String body = mailInfo.getBody();
				String toId = complainant.getMailId().trim() + property.getInfyDomain();
				String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
				subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
				body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.RECIPIENT_PH, WordUtils.capitalize(complainant.getName().trim())).replace(Constants.KEYWORD_PH, "by").replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
				mailInfoList.add(new MailContent(body, subject, toId, icIds));
			}
			
			for(EmployeeDetails respondent : respondents) {
				String subject = mailInfo.getSubject();
				String body = mailInfo.getBody();
				String toId = respondent.getMailId().trim() + property.getInfyDomain();
				String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
				subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
				body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.RECIPIENT_PH, WordUtils.capitalize(respondent.getName().trim())).replace(Constants.KEYWORD_PH, Constants.AGAINST_KW).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
				mailInfoList.add(new MailContent(body, subject, toId, icIds));
			}

		}
		
		else if(mailEventCode.equals("ASHIWGA")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWGA");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, grbIds, icIds));
		}
		
		else if(mailEventCode.equals("ASHIWER")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWER");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String erhIds =  commonService.getIdStringByRoleAndModule("ERH", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, erhIds, grbIds));
		}
		
		else if(mailEventCode.equals("ASHIWGU")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWGU");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, grbIds));
		}
		
		else if(mailEventCode.equals("ASHIWCC")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIWCC");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));
		}
		
		else if(mailEventCode.equals("ASHIRIF")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIRIF");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim())).replace(Constants.COMMENT_PH, comment);
			mailInfoList.add(new MailContent(body, subject, icIds, grbIds));
		}
		
		else if(mailEventCode.equals("ASHIRGF")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIRGF");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String erhIds =  commonService.getIdStringByRoleAndModule("ERH", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.COMMENT_PH, comment);
			mailInfoList.add(new MailContent(body, subject, grbIds, erhIds));
		}
		
		else if(mailEventCode.equals("ASHIPGF")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIPGF");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String icIds =  commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());
			String grbIds = commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid)).replace(Constants.ICLOCATION_PH, WordUtils.capitalize(icLocation.trim()));
			mailInfoList.add(new MailContent(body, subject, grbIds, icIds));
		}
		
		else if(mailEventCode.equals("ASHIPEF")) {
			MailContent mailInfo = mailConfigHeaderRepository.findSubjectAndBodyByApplicationCode("ASHIPEF");

			String subject = mailInfo.getSubject();
			String body = mailInfo.getBody();
			String erhIds =  commonService.getIdStringByRoleAndModule("ERH", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			String grbIds =  commonService.getIdStringByRoleAndModule("GRB", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), "");
			subject = subject.replace(Constants.CASEID_PH, String.valueOf(caseid));
			body = body.replace(Constants.CASEID_PH, String.valueOf(caseid));
			mailInfoList.add(new MailContent(body, subject, erhIds, grbIds));
		}
		
		
		return mailInfoList;
	}
	
	private void triggerConciliationConsents(int caseid) throws CustomException {
		List<GenModelOption> complainants = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("A","T"));
		List<GenModelOption> respondents = caseEmployeeDetailsRepository.getEmployeesByCaseIdAndActor(caseid, Arrays.asList("R"));

		List<ELCMECMstASHIConciliationConsentDetails> consents = new ArrayList<>();

		for(GenModelOption complainant : complainants) {
			consents.add(new ELCMECMstASHIConciliationConsentDetails(caseid, "A", complainant.getKey(), Session.getTokenEMPNO(), currentDateTime));
		}

		for(GenModelOption respondent : respondents) {
			consents.add(new ELCMECMstASHIConciliationConsentDetails(caseid, "R", respondent.getKey(), Session.getTokenEMPNO(), currentDateTime));
		}

		List<ELCMECMstASHIConciliationConsentDetails> savedConsents = conciliationConsentDetailsRepository.saveAll(consents);
		
		//trigger mail based approval mails for consents
		Optional<ELCMECTrnASHIActionDetails> assigneeDetails = ashiActionDetailsRepository.findAssigneeDetailsByRoleAndCaseId(caseid, "IC");
		if(!assigneeDetails.isPresent())
			throw new CustomException(Message.MAIL_DETAILS_NOTFOUND);
		
		String icIds = commonService.getIdStringByRoleAndModule("IC", Session.getCaseDetails().getModuleId(), Session.getCaseDetails().getCountry(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getAssigneeLocation());

		for(ELCMECMstASHIConciliationConsentDetails consent : savedConsents) {
			MailInfo mailInfoObj=new MailInfo(property.getAppCode(), property.getEventIdFYA2(), property.getTemplateIdFYA2(), property.getFromId(), consent.getMailId() + property.getInfyDomain(), icIds, property.getTransactionNameFYA2(), String.valueOf(consent.getSerialNo()));
			PlaceHolder[] placeHolders = {
					new PlaceHolder(Constants.RECIPIENTFYA_PH, consent.getMailId()),
					new PlaceHolder(Constants.ACTORNAME_PH, consent.getMailId() + property.getInfyDomain()),
					new PlaceHolder(Constants.ID_PH, String.valueOf(caseid)),
					new PlaceHolder(Constants.DESCRIPTION_PH, "Conciliation process, on a sexual harassment complaint made " + (consent.getActor().equals("R") ? "against you" : "") + " to GRB")};

			MailerAssistRequest mailObj=new MailerAssistRequest(mailInfoObj, placeHolders, new NonGrpPlaceHolder("Kindly check the policy to understand further about Conciliation process here: Sparsh > Policy Portal > Grievance Redressal > Policy on Prevention and Redressal of Sexual Harassment – India"));

			MailerAssistResponse mailerResponse = commonService.triggerMail(mailObj);
			if(mailerResponse.getCode()!=0)
				throw new CustomException(Message.MAIL_NOT_TRIGGERED + mailerResponse.getMessage());
		}

		
		
	}
	
	@Override
	public WorkFlow getWorkFlow(int caseid) {
		List<WorkFlowItem> items = new ArrayList<>();
		List<WorkFlowItem> parallel = new ArrayList<>();
		List<WorkFlowItem> series = new ArrayList<>();

		WorkFlowItem forwardedByGRB = new WorkFlowItem("Complaint forwarded by GRB", "GRB(07-Nov-2020)", "2 Days", "Proceed with investigation", "", true, new ArrayList<>(), new ArrayList<>());
		items.add(forwardedByGRB);

		WorkFlowItem allegationAndFindings = new WorkFlowItem("Allegations and Findings report", "SLA 2 Days : 17-Nov-2020", "", "", "", false, new ArrayList<>(), new ArrayList<>());
		series.add(allegationAndFindings);

		WorkFlowItem shareAllegation = new WorkFlowItem("Share Allegations", "SLA 10 Days : 29-Nov-2020", "", "", "", false, new ArrayList<>(), new ArrayList<>());
		series.add(shareAllegation);

		WorkFlowItem submitRecommendation = new WorkFlowItem("Submit recommendations & report", "SLA 2 Days : 01-Dec-2020", "", "", "", false, new ArrayList<>(), new ArrayList<>());
		series.add(submitRecommendation);

		WorkFlowItem conciliationInitiation = new WorkFlowItem("Conciliation initiation by IC", "SLA 2 Days : 19-Nov-2020", "", "", "", false, new ArrayList<>(), new ArrayList<>());
		parallel.add(conciliationInitiation);

		WorkFlowItem submitConciliation = new WorkFlowItem("Submit conciliation report", "SLA 10 Days : 29-Nov-2020", "", "", "", false, new ArrayList<>(), new ArrayList<>());
		parallel.add(submitConciliation);

		WorkFlowItem investigationByIC = new WorkFlowItem("Case Investigation by IC", "SLA 10 Days : 17-Nov-2020", "", "", "1", false, parallel, series);
		items.add(investigationByIC);
		return new WorkFlow("SLA for Investigation Stages", items);
	}


	@Override
	public LinkModel getLinkModel(int caseid) {
		List<Link> links = new ArrayList<>();
		
		Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(caseid);
		
		if(caseDetails.isPresent()) {
			String downloadTemplateModuleId = commonService.getUIModuleId("AALDT");
			Link downloadTemplateLink = new Link("Download Templates", "", "", downloadTemplateModuleId, Constants.POPOVERFORM, Constants.POST);
			links.add(downloadTemplateLink);
			
			String workFlowModuleId = commonService.getUIModuleId("AALWF");
			Link lastActionLink = new Link(caseDetails.get().getLastAction().trim(), new SimpleDateFormat(Constants.DATE_FORMAT).format(caseDetails.get().getLastActionDate()), "Last action taken", workFlowModuleId, Constants.GENERICMODELPOPUP, Constants.POST);
			links.add(lastActionLink);
			
			return new LinkModel("ASHI Case " + caseid, "", links);
		}
		
		else
			return new LinkModel("", "", links);
	}
	
	public void updateLastActionTaken(ELCMECTrnASHICaseDetails caseDetails, String lastAction) {
		
		caseDetails.setLastAction(lastAction);
		caseDetails.setLastActionDate(currentDateTime);
		
		caseDetailsRepository.save(caseDetails);
	}
	
	public DocumentData downloadFormalReport(int caseid) throws CustomException {
		List<DocumentData> docs = new ArrayList<>();
		StringBuilder eventTable = new StringBuilder();
		int eventCount = 0;
		
		String content1 = this.prepareReportDocument1(caseid);
		String content2 = this.prepareReportDocument2(caseid, content1);
		
		List<ELCMECTrnASHIActionDetails> actionDetails = ashiActionDetailsRepository.findByCaseIdOrderByCaseActionIdAsc(caseid);
		
		StringBuilder evidences = new StringBuilder();
		int count = 0;
		
		if(!StringUtils.isBlank(actionDetails.get(0).getDmsFileName())){
			for(String e : actionDetails.get(0).getDmsFileName().split(",")) {
				List<DocumentData> files = commonService.downloadDocuments("A", actionDetails.get(0).getCaseActionId(), e.trim());
				String filename = caseid + "_evidence_" + ++count + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				evidences.append(filename).append(Constants.BR_TAG);
			}
		}
		
		
		Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails = formalInvestigationReportDetailsRepository.findByCaseId(caseid);
		String content3 = this.prepareReportDocument3(eventTable, caseid, eventCount, content2, docs, actionDetails, reportDetails);
		String content4 = this.prepareReportDocument4(eventTable, caseid, eventCount, content3, docs, actionDetails, reportDetails);
		
		Optional<ELCMECMstConcernModulesDetails> category = concernModulesDetailsRepository.findByModuleIdAndConcernIdAndCompanyAndCountryCode(2, Session.getCaseDetails().getCaseDetails().getCategoryId(), Session.getCaseDetails().getCompany(), Session.getCaseDetails().getCountry());
		if(!category.isPresent())
			throw new CustomException("Category details not found");
		
		String content = content4
				.replace(Constants.CASEID_PH, String.valueOf(caseid))
				.replace("#IncidentDate#", new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(Session.getCaseDetails().getCaseDetails().getIncidentDate()))
				.replace("#ComplaintSummary#", Session.getCaseDetails().getCaseDetails().getDescription().trim())
				.replace("#IncidentLocation#", WordUtils.capitalize(Session.getCaseDetails().getCaseDetails().getSelectedCity().toLowerCase().trim() + ", " + Session.getCaseDetails().getCaseDetails().getSelectedCountry().toLowerCase().trim()))
				.replace("#Category#", category.get().getConcernDesc().trim())
				.replace("#Classification#", Session.getCaseDetails().getCaseDetails().getPlaceOfIncident().trim())
				.replace("#Evidence#", evidences.length()>0 ? evidences : "NA")
				.replace("#EventTable#", eventTable);
		
		String filenameTemp = caseid + "_" + "report_temp.pdf";
		FileGenerationServiceResponse response1 = fileGenerationService.pdfGenerator(property.getTempStoragePath(), filenameTemp, content);
		if(!response1.isStatus())
			throw new CustomException(response1.getMessage());

		String filenameFinal = caseid + "_" + "report.pdf";
		FileGenerationServiceResponse response2 = fileGenerationService.addAttachmentsToPDF(property.getTempStoragePath(), filenameTemp, filenameFinal, docs);
		if(!response2.isStatus())
			throw new CustomException(response2.getMessage());
		
		try {
			byte[] pdf = Files.readAllBytes(Paths.get(property.getTempStoragePath() + filenameFinal));
			byte[] encodedBytes = Base64.getEncoder().encode(pdf);
			String docBytes = new String(encodedBytes);
			return new DocumentData(filenameFinal, docBytes);

		} catch (IOException e1) {
			throw new CustomException(e1.getMessage());
		}
		finally {
			commonService.deleteFiles(Arrays.asList(filenameTemp, filenameFinal));
		}
	}
	
	private String prepareReportDocument1(int caseid) {
		List<ELCMECMstASHICaseEmployeeDetails> employees = caseEmployeeDetailsRepository.findByCaseId(caseid);
		List<ELCMECMstASHIRecommendationsDetails> actions = recommendationsDetailsRepository.findByCaseId(caseid);
		
		StringBuilder complainantTable = new StringBuilder();
		StringBuilder respondentTable = new StringBuilder();
		StringBuilder witnessTable = new StringBuilder();
		
		for(ELCMECMstASHICaseEmployeeDetails employee : employees) {
			int countA = 0;
			int countR = 0;
			int countW = 0;
			if(employee.getActor().equals("A")) {
				String content = Constants.REPORT_EMPLOYEE_TABLE.replace(Constants.SNO_PH, String.valueOf(++countA))
						.replace(Constants.EMPNAME_PH, WordUtils.capitalize(employee.getEmpName().trim()))
						.replace(Constants.EMPNO_PH, employee.getEmpNo().trim()).replace(Constants.EMPUNIT_PH, employee.getUnit().trim())
						.replace(Constants.EMPDOJ_PH, new SimpleDateFormat(Constants.DATE_FORMAT).format(employee.getJoinedDate()))
						.replace(Constants.EMPDESIGNATION_PH, employee.getRoleDesc()).replace(Constants.EMPLOCATION_PH, WordUtils.capitalize(employee.getCurrentCity().toLowerCase().trim()));
				complainantTable.append(content);
			}
			else if(employee.getActor().equals("R")) {
				String content = Constants.REPORT_EMPLOYEE_TABLE.replace(Constants.SNO_PH, String.valueOf(++countR))
						.replace(Constants.EMPNAME_PH, WordUtils.capitalize(employee.getEmpName().trim()))
						.replace(Constants.EMPNO_PH, employee.getEmpNo().trim()).replace(Constants.EMPUNIT_PH, employee.getUnit().trim())
						.replace(Constants.EMPDOJ_PH, new SimpleDateFormat(Constants.DATE_FORMAT).format(employee.getJoinedDate()))
						.replace(Constants.EMPDESIGNATION_PH, employee.getRoleDesc()).replace(Constants.EMPLOCATION_PH, WordUtils.capitalize(employee.getCurrentCity().toLowerCase().trim()));

				respondentTable.append(content);
			}
			
			else if(employee.getActor().equals("W")) {
				String content = Constants.REPORT_WITNESS_TABLE.replace(Constants.SNO_PH, String.valueOf(++countW)).replace(Constants.EMPNAME_PH, WordUtils.capitalize(employee.getEmpName())).replace(Constants.EMPNO_PH, employee.getEmpNo());
				witnessTable.append(content);
			}
		}
		
		int count = 0;
		StringBuilder actionTable = new StringBuilder();
		for(ELCMECMstASHIRecommendationsDetails action : actions) {
			count++;
			StringBuilder actionList = new StringBuilder();
			Arrays.asList(action.getActions().split(",")).forEach(a -> actionList.append(Constants.REPORT_ACTION_TAG.replace("#Action#", a)));
			String content = Constants.REPORT_ACTIONS_TABLE.replace(Constants.SNO_PH, String.valueOf(count)).replace(Constants.ACTOR_PH, this.getEmployeeType(action.getActor())).replace(Constants.EMPMAILID_PH, action.getMailId()).replace("#Actions#", actionList).replace(Constants.REMARKS_PH, StringUtils.isBlank(action.getRemarks()) ? "" : action.getRemarks().trim());
			actionTable.append(content);
		}
		
		return Constants.REPORT_TEMPLATE
		.replace("#ComplainantTable#", complainantTable)
		.replace("#RespondentTable#", respondentTable)
		.replace("#WitnessTable#", witnessTable)
		.replace("#ActionsTable#", actionTable);
	}
	
	private String prepareReportDocument2(int caseid, String content) {
		List<ELCMECMstASHIAllegationsAndFindingsDetails> findings = allegationsAndFindingsDetailsRepository.findByCaseIdOrderByActorAscMailIdAscSerialNoAsc(caseid);
		
		int count = 0;

		StringBuilder findingTable = new StringBuilder();
		StringBuilder rows = new StringBuilder();
		for(int i=0; i<findings.size(); i++) {
			if(i!=0 && !(!findings.get(i).getActor().equals(findings.get(i-1).getActor()) && findings.get(i).getMailId().equals(findings.get(i-1).getMailId()))) {
				if(findings.get(i).getActor().equals(findings.get(i-1).getActor()) && findings.get(i).getMailId().equals(findings.get(i-1).getMailId())) {
					String row = Constants.REPORT_FINDINGS_ROW.replace(Constants.SNO_PH, String.valueOf(++count))
							.replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation())
							.replace(Constants.FINDING_PH, findings.get(i).getFinding())
							.replace(Constants.OUTCOME_PH, findings.get(i).getOutcome());
					rows.append(row);
				}
				else {
					findingTable.append(Constants.REPORT_FINDINGS_TABLE.replace(Constants.ACTOR_PH, this.getEmployeeType(findings.get(i-1).getActor()))
							.replace(Constants.EMPMAILID_PH, findings.get(i-1).getMailId())
							.replace(Constants.ROWS_PH, rows.toString()));

					count = 0;
					rows = new StringBuilder();
					String row = Constants.REPORT_FINDINGS_ROW.replace(Constants.SNO_PH, String.valueOf(++count))
							.replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation())
							.replace(Constants.FINDING_PH, findings.get(i).getFinding())
							.replace(Constants.OUTCOME_PH, findings.get(i).getOutcome());
					rows.append(row);
				}
				
				if(i==(findings.size()-1))
					findingTable.append(Constants.REPORT_FINDINGS_TABLE.replace(Constants.ACTOR_PH, this.getEmployeeType(findings.get(i).getActor()))
							.replace(Constants.EMPMAILID_PH, findings.get(i).getMailId())
							.replace(Constants.ROWS_PH, rows.toString()));
			}

			else {
				String row = Constants.REPORT_FINDINGS_ROW.replace(Constants.SNO_PH, String.valueOf(++count))
						.replace(Constants.ALLEGATION_PH, findings.get(i).getAllegation())
						.replace(Constants.FINDING_PH, findings.get(i).getFinding())
						.replace(Constants.OUTCOME_PH, findings.get(i).getOutcome());
				rows.append(row);
			}
		}
		
		if(findings.size()==1) {
			findingTable.append(Constants.REPORT_FINDINGS_TABLE.replace(Constants.ACTOR_PH, this.getEmployeeType(findings.get(0).getActor()))
					.replace(Constants.EMPMAILID_PH, findings.get(0).getMailId())
					.replace(Constants.ROWS_PH, rows.toString()));
		}
		
		return content.replace("#FindingsTable#", findingTable);
	}
	
	private String prepareReportDocument3(StringBuilder eventTable, int caseid, int eventCount, String content, List<DocumentData> docs, List<ELCMECTrnASHIActionDetails> actionDetails, Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails) throws CustomException {
		
		ELCMECTrnASHIActionDetails actionWI = actionDetails.stream().filter(a -> a.getStatus().trim().equals("WI")).findFirst().orElse(null);
		if(actionWI==null)
			throw new CustomException(Message.NOTAVAILABLE);
		
		String event1 = Constants.REPORT_EVENT_TABLE.replace(Constants.SNO_PH, String.valueOf(++eventCount))
						.replace(Constants.EVENTDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(actionWI.getCreatedOn()))
						.replace(Constants.EVENT_PH, "IC received the complaint")
						.replace(Constants.REMARKS_PH, actionWI.getComments())
						.replace(Constants.DOCUMENTS_PH, "");
		eventTable.append(event1);
		
		List<ELCMECMstASHISummonsDetails> summons = summonsDetailsRepository.findByCaseIdOrderBySerialNoAsc(caseid);
		
		for(ELCMECMstASHISummonsDetails summon : summons) {
			String event = Constants.REPORT_EVENT_TABLE.replace(Constants.SNO_PH, String.valueOf(++eventCount))
							.replace(Constants.EVENTDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(summon.getIssuedDate()))
							.replace(Constants.EVENT_PH, "Summon issued to the " + this.getEmployeeType(summon.getActor()) + " " + summon.getMailId())
							.replace(Constants.REMARKS_PH, "").replace(Constants.DOCUMENTS_PH, "");
			eventTable.append(event);
		}
		
		int reportDetailsTranId = 0;
		Map<String, String> app = new HashMap<>();
		if(actionDetails.stream().anyMatch(a -> a.getStatus().trim().equals("WGA")) && reportDetails.isPresent()) {
			if(reportDetails.get().getFlgInvestigationPanelApproval()==1) {
				app.put("ADI,_investigation_panel_approval_", reportDetails.get().getDmsInvestigationPanelApprovals().trim());
			}
			if(reportDetails.get().getFlgPresidingOfficersApproval()==1) {
				app.put("ADP,_presiding_officers_approval_", reportDetails.get().getDmsPresidingOfficersApprovals().trim());
			}
			if(reportDetails.get().getFlgExtICMembersApproval()==1) {
				app.put("ADE,_external_IC_member_approval_", reportDetails.get().getDmsExtICMembersApprovals().trim());
			}
		
			reportDetailsTranId = reportDetails.get().getSerialNo();
		}
		
		StringBuilder approvals = new StringBuilder();
		for (Map.Entry<String, String> entry : app.entrySet()) {
			int doccount = 0;
			for(String e : entry.getValue().split(",")) {
				String[] key = entry.getKey().split(",");
				List<DocumentData> files = commonService.downloadDocuments(key[0], reportDetailsTranId, e.trim());
				String filename = caseid + key[1] + ++doccount + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				approvals.append(filename).append(Constants.BR_TAG);
			}
		}
		
		if(approvals.length()>0) {
			String event2 = Constants.REPORT_EVENT_TABLE.replace(Constants.SNO_PH, String.valueOf(++eventCount))
					.replace(Constants.EVENTDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(reportDetails.get().getUpdatedDate()))
					.replace(Constants.EVENT_PH, "IC uploaded panel approvals")
					.replace(Constants.REMARKS_PH, "")
					.replace(Constants.DOCUMENTS_PH, approvals);
			eventTable.append(event2);
		}

		return content.replace("#Location#", WordUtils.capitalize(actionWI.getAssigneeLocation().toLowerCase().trim()));
	}
	
	private String prepareReportDocument4(StringBuilder eventTable, int caseid, int eventCount, String content, List<DocumentData> docs, List<ELCMECTrnASHIActionDetails> actionDetails, Optional<ELCMECMstASHIFormalInvestigationReportDetails> reportDetails) throws CustomException {
	
		ELCMECTrnASHIActionDetails actionWCC = actionDetails.stream().filter(a -> a.getStatus().trim().equals("WCC")).findFirst().orElse(null);
		if(actionWCC!=null) {
			StringBuilder approvals = new StringBuilder();
			int doccount = 0;
			for(String e : actionWCC.getDmsFileName().trim().split(",")) {
				List<DocumentData> files = commonService.downloadDocuments("ID", actionWCC.getCaseActionId(), e.trim());
				String filename = caseid + "_GRB_panel_approval_" + ++doccount + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				approvals.append(filename).append(Constants.BR_TAG);
			}
			String event2 = Constants.REPORT_EVENT_TABLE.replace(Constants.SNO_PH, String.valueOf(++eventCount))
					.replace(Constants.EVENTDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(actionWCC.getCreatedOn()))
					.replace(Constants.EVENT_PH, "GRB uploaded panel approvals")
					.replace(Constants.REMARKS_PH, actionWCC.getComments())
					.replace(Constants.DOCUMENTS_PH, approvals);
			eventTable.append(event2);
		}
		
		boolean flgClosed = false;
		ELCMECTrnASHIActionDetails actionCLF = actionDetails.stream().filter(a -> a.getStatus().trim().equals("CLF")).findFirst().orElse(null);
		if(actionCLF!=null && reportDetails.isPresent()) {
			flgClosed = true;
			
			StringBuilder approvals = new StringBuilder();
			int doccount = 0;

			for(String e : reportDetails.get().getDmsActionImplementaionDocs().trim().split(",")) {
				List<DocumentData> files = commonService.downloadDocuments("AID", reportDetails.get().getSerialNo(), e.trim());
				String filename = caseid + "_action_implementation_document_" + ++doccount + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				approvals.append(filename).append(Constants.BR_TAG);
			}

			doccount = 0;
			for(String e : actionCLF.getDmsFileName().trim().split(",")) {
				List<DocumentData> files = commonService.downloadDocuments("ID", actionCLF.getCaseActionId(), e.trim());
				String filename = caseid + "_closure_document_" + ++doccount + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				approvals.append(filename).append(Constants.BR_TAG);
			}
			
			doccount = 0;
			StringBuilder investigationDocs = new StringBuilder();
			for(String e : reportDetails.get().getDmsInvestigationDocs().trim().split(",")) {
				List<DocumentData> files = commonService.downloadDocuments("IID", reportDetails.get().getSerialNo(), e.trim());
				String filename = caseid + "_case_investigation_document_" + ++doccount + "." + e.trim().split("\\.")[1];
				docs.add(new DocumentData(filename, files.get(0).getBase64file()));	
				investigationDocs.append(filename).append(Constants.BR_TAG);
			}

			String event2 = Constants.REPORT_EVENT_TABLE.replace(Constants.SNO_PH, String.valueOf(++eventCount))
					.replace(Constants.EVENTDATE_PH, new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(actionCLF.getCreatedOn()))
					.replace(Constants.EVENT_PH, "IC closed the case")
					.replace(Constants.REMARKS_PH, "")
					.replace(Constants.DOCUMENTS_PH, approvals);
			eventTable.append(event2);
			
			content = content.replace("#InvestigationSummary#", reportDetails.get().getSummary())
					.replace("#OtherRecommendations#", StringUtils.isBlank(reportDetails.get().getOtherRecommendations()) ? "NA" : reportDetails.get().getOtherRecommendations().trim())
					.replace("#InvestigationDocs#", investigationDocs);
		}
		
		return content.replace("#ClosureDate#", flgClosed ? "<p><b>Case Closure Date : " + new SimpleDateFormat(Constants.DATE_FORMAT_NEW).format(Session.getCaseDetails().getCaseDetails().getCaseClosedDate()) + "</b></p>" : "");
		

	}
	
	@Override
	public GenModel getChargeSheetGenModel(int caseid) {
		
		List<GenModelField> fields = new ArrayList<>();
		
		if(!caseDetailsRepository.existsById(caseid))
			return new GenModel("", "", fields);

		GenModelField chargeSheet=new GenModelField( 5, "chargesheet", "Charge Sheet issued","0",false, true);
		chargeSheet.setRequired(true);
		fields.add(chargeSheet);
		
		List<GenModelValidation> validations=new ArrayList<>();
		validations.add(new GenModelValidation("16", property.getFileValidationRegex(), Message.FILENAME_ERRORMESSAGE));
		validations.add(new GenModelValidation("15", "75", Message.FILENAMELENGTH_ERRORMESSAGE));
		validations.add(new GenModelValidation("10", Message.FILESIZE_LIMIT, Message.FILESIZE_ERRORMESSAGE));
		validations.add(new GenModelValidation("11", property.getFileValidationTypes(), Message.FILETYPES));

		GenModelField chargeSheetDocs=new GenModelField( 60, "uploadchargesheet", "Upload Charge Sheet", new ArrayList<DocumentData>(), "chargesheet|1", true, false, validations);
		fields.add(chargeSheetDocs);
		
		return new GenModel("Charge sheet", fields, Arrays.asList(new CardViewAction(1, "Save/Upload", Constants.POST, MessageFormat.format(property.getSaveChargeSheetURL(), String.valueOf(caseid) ) , Constants.SERVICEURL)));

	}
	
	@Override
	public Response saveChargeSheet(int caseid, String empNo,GenModel genmodel) throws CustomException {
		
		GMFields fields = commonService.convertGenModelToObject(genmodel, 0);
		
		String dmsOtherFiles="";
		
		if(fields.getChargeSheetIssued().equals("1") && fields.getUploadchargesheet().isEmpty())
				return new Response("Please upload charge sheet");
		
		else if (fields.getChargeSheetIssued().equals("1") && !fields.getUploadchargesheet().isEmpty()) {
			dmsOtherFiles=commonService.validateAndUploadDocumentsToDMS(fields.getUploadchargesheet(), property.getDmsASHIInvestigationDocsFolder());
			
			if(dmsOtherFiles.startsWith(Message.INVALID_FILE))
				return new Response(dmsOtherFiles);
		}


		ELCMECTrnASHICaseDetails updatedCaseDetails = Session.getCaseDetails().getCaseDetails();

		updatedCaseDetails.setFlgChargeSheet(Integer.parseInt(fields.getChargeSheetIssued()));
		if(fields.getChargeSheetIssued().equals("1")) 
			updatedCaseDetails.setDmsChargeSheets(dmsOtherFiles);
		updatedCaseDetails.setModifiedBy(empNo);
		updatedCaseDetails.setModifiedOn(currentDateTime);
		caseDetailsRepository.save(updatedCaseDetails);

		return new Response(Message.SUCCESSPROCEED, fields.getChargeSheetIssued().equals("1") ? "Charge Sheet Successfully uploaded" : "Successfully saved details");
	}
	
	@Override
    public LabelView getChargeSheet(int caseid) throws CustomException {
        
        List<CardViewField> fieldList=new ArrayList<>();
        List<CardViewAction> actions=new ArrayList<>();
        
        Optional<ELCMECTrnASHICaseDetails> caseDetails = caseDetailsRepository.findById(caseid);
        
        if(caseDetails.isPresent() && caseDetails.get().getFlgChargeSheet() == 1  && this.notNullOrEmpty(caseDetails.get().getDmsChargeSheets())) {    

            fieldList.add(new CardViewField("Charge Sheets", "", 88));
            String[] documents = caseDetails.get().getDmsChargeSheets().split(",");
            for(String document : documents) {
                fieldList.add(new CardViewField(document.trim(), MessageFormat.format(property.getDownloadURL(), "CS", caseDetails.get().getCaseId(), document.trim()), 35));    
            }
        }
        else {
            fieldList.add(new CardViewField(Constants.DOCUMENTS, "No Charge Sheet uploaded.", 14));
        }
        return new LabelView(Constants.CASE_DETAILS, Constants.LABELVIEW_TYPE1, fieldList, actions, "");
    }
	

}
