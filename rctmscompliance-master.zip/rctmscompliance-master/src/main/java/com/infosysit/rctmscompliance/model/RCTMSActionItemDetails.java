package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class RCTMSActionItemDetails {

	private int intActionItemId;
	private String txtActionItemOwner;
	private String txtactionitemdescription;
	private String txtActionItemAssignee;
	private String dtActionItemDueDate;
	private String txtActionItemAssigneeComments;
	private int intActionItemReminderInterval;
	private String txtActionItemStatus;
	private String txtReferenceNumber;
	private String dtNoticeDueDate;
	private String txtDescription;
	private int intLinkNoticeflg;
	private String txtEscalationowner;
	private int intEscatationInterval;
	private String txtFindings;
	private String txtReason;
	private String txtApplicationName;
	private String txtMakerEmpNo;
	private String txtCheckerEmpNo;
	private String txtTransactionID;
	private int intRuleID;
	private String txtCorrectiveAction;
	private String txtRemediation;
	private String txtOwnerRejectComments;
}
