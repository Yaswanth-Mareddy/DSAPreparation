package com.infosys.reach.model.ashimobile;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CaseGenModelForm {
	private List<CaseGenModelField> fields;
}
