package com.infosys.hello.springboot.api;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.infosys.hello.springboot.model.Employee;

@FeignClient(name="SPRINGBOOT-INTROSPECTOR")
public interface EmployeeServiceClient {
	
	@RequestMapping("/springboot/v1/employee/{id}")
	public Employee findById(@PathVariable(value="id") int id);
}

