package com.infosys.reach.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.infosys.reach.entity.ELCMECMstReachWorkFlow;
import com.infosys.reach.util.TrackExecutionTime;

public interface ELCMECMstReachWorkFlowRepository extends JpaRepository<ELCMECMstReachWorkFlow, Integer>{
	
	@TrackExecutionTime
	Optional<ELCMECMstReachWorkFlow> findByModuleIdAndCurrentStatusAndFlgActiveAndNextStatus(int moduleId, String currentStatus, int flgActive, String nextStatus);
	
	@TrackExecutionTime
	Optional<ELCMECMstReachWorkFlow> findByModuleIdAndCurrentStatusAndFlgActive(int moduleId, String currentStatus, int flgActive);
	
	@TrackExecutionTime
	Optional<ELCMECMstReachWorkFlow> findByModuleIdAndCurrentStatusAndFlgActiveAndDirection(int moduleId, String currentStatus, int flgActive, String direction);
	
	@TrackExecutionTime
	List<ELCMECMstReachWorkFlow> findByModuleIdAndCurrentStatusAndFlgActiveOrderByActionLabelAsc(int moduleId, String currentStatus, int flgActive);
	



}
