package com.infosysit.rctmscompliance.model;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.infosysit.rctmscompliance.exception.CustomException;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class ComplianceEscalationDetails {

	private int intEscalationLevelForDueDate;
	private int intEscalationInterval;
	private String txtEscMailId;
	private String dtDueDate;
	private String dtEscalatedDate;
	
	public String returnAsString() throws CustomException {
		try {
			return "Level: "+this.intEscalationLevelForDueDate+", EmailID: "+this.txtEscMailId.trim()+"\r\nEscalation Date: "+normalDate(this.dtEscalatedDate);
		} catch (Exception e) {
			throw new CustomException(e.getMessage()+" Error in toString method-ComplianceEscalationDetails");
		}
				
	}
	
	public String normalDate(String date) throws CustomException {
		try {
			DateTimeFormatter format1 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
			DateTimeFormatter format2 = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
			if(!(date.isEmpty() || date==null))
			{
				LocalDateTime parsedDate=LocalDateTime.parse(date,format1);
				return parsedDate.format(format2);
			}
			return "NA";
		} catch (Exception e) {
			throw new CustomException(e.getMessage()+" Error in normalDate method-ComplianceEscalationDetails");
		}
	}
}
