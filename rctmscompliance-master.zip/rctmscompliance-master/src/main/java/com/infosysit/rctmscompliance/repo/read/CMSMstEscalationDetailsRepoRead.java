package com.infosysit.rctmscompliance.repo.read;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.infosysit.rctmscompliance.entity.CMSMstEscalationDetails;
import com.infosysit.rctmscompliance.entity.EscalationDetailsCompPKey;

@Repository
public interface CMSMstEscalationDetailsRepoRead extends JpaRepository<CMSMstEscalationDetails, EscalationDetailsCompPKey> {

}
