package com.infosys.reach;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosys.reach.exception.CustomException;
import com.infosys.reach.repository.ELCMECTrnReachCaseDetailsRepository;
import com.infosys.reach.service.DisciplinaryServiceImpl;

@ExtendWith(MockitoExtension.class)
class DisciplinaryServiceTest {

	@InjectMocks
	DisciplinaryServiceImpl service;
	
	@Mock
	ELCMECTrnReachCaseDetailsRepository reachCaseDetailsRepository;
	
	@Test
	void Test() throws CustomException {
		assertTrue(true);
	}
}
