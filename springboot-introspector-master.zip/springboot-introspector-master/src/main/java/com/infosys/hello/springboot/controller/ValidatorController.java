package com.infosys.hello.springboot.controller;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.hello.springboot.dto.ValidatorDTO;
import com.infosys.hello.springboot.service.ValidatorService;

@Validated
@RestController
public class ValidatorController {
	
	@Autowired
	ValidatorService validatorService;

	@RequestMapping(value="/validate", method=RequestMethod.POST, consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.TEXT_PLAIN_VALUE )
	public String validate(@NotEmpty @NotNull @RequestParam("region") String region, @Valid @NotNull @RequestBody ValidatorDTO reqDto) {
		String result = validatorService.customValidation(region, reqDto);
		return result;
	}
	
	@RequestMapping(value="/user", method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<ValidatorDTO> getObject(@RequestParam("name") @NotNull @NotEmpty String name) {
		ValidatorDTO req = validatorService.getObj(name);
		return new ResponseEntity<ValidatorDTO>(req, HttpStatus.OK);
	}
	
	@RequestMapping(value="/customer", method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE,
			produces=MediaType.APPLICATION_JSON_VALUE )
	public ResponseEntity<String> save(@Valid @NotNull @RequestBody ValidatorDTO customer) {
	String response = validatorService.save(customer);
	return new ResponseEntity<String>(response,HttpStatus.OK);
	}


}

