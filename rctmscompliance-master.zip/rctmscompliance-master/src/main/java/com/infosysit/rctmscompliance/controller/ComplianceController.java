package com.infosysit.rctmscompliance.controller;


import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.base.Strings;
import com.infosysit.rctmscompliance.exception.CustomException;
import com.infosysit.rctmscompliance.model.CMSRemarkDTO;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserFinal;
import com.infosysit.rctmscompliance.model.ComplianceInbox;
import com.infosysit.rctmscompliance.model.Response;
import com.infosysit.rctmscompliance.model.ResponseModel;
import com.infosysit.rctmscompliance.model.SubmitAndRejectResponse;
import com.infosysit.rctmscompliance.model.ViewActionItemMobModel;
import com.infosysit.rctmscompliance.service.ComplianceDetailsServiceImp;
import com.infosysit.rctmscompliance.service.ComplianceInboxServiceImp;
import com.infosysit.rctmscompliance.service.InbayService;
import com.infosysit.rctmscompliance.util.Constants;
import com.infosysit.rctmscompliance.util.ExtendedLogging;
import com.infosysit.rctmscompliance.util.Message;
import com.netflix.hystrix.contrib.javanica.annotation.DefaultProperties;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;

import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Qualifier;


@CrossOrigin
@RequestMapping("/api")
@RestController
@DefaultProperties(defaultFallback = "defaultFallback")
public class ComplianceController {
	
	@Autowired
	private RctmsInterceptor audit;

	@Autowired
	@Qualifier("extendedLogging")
	private ExtendedLogging log;
	
	@Autowired
	private ComplianceInboxServiceImp compInboxSer;
	
	@Autowired
	private ComplianceDetailsServiceImp compService;
	
	@Autowired
	private InbayService inbayServ;
	
	@ApiOperation(value = "Fetch Inbox Details of User")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/getAllComplianceInboxForUser",produces = "application/json")
	public ResponseEntity<Object> getComplianceInboxDetails(@RequestParam(value="txtStatus") String txtStatus,
			  @RequestParam(value="txtpendingstatus") String txtpendingstatus) throws CustomException{
		try {
			log.log("/getAllComplianceInboxForUser");
			if(Strings.isNullOrEmpty(txtStatus))
				txtStatus="All";
			if(Strings.isNullOrEmpty(txtpendingstatus))
				txtpendingstatus="Pending with me";
			String empNo=TokenValidator.getTokenEMPNO();
			List<ComplianceInbox> compInbox= compInboxSer.viewComplianceInbox(empNo,txtStatus.trim() , txtpendingstatus.trim());
			if(compInbox.isEmpty()) {
				ResponseModel resCIDS=new ResponseModel();
				resCIDS.setStrStatus(Constants.SUCCESS);
				resCIDS.setStrMessage(Constants.INBOXEMPTY);
				log.log(Message.SUCCESSFULLY);
				audit.setLogEventData(Message.SUCCESSFULLY + " /getAllComplianceInboxForUser");
				return ResponseEntity.ok(resCIDS);
			}
			log.log(Message.SUCCESSFULLY);
			audit.setLogEventData(Message.SUCCESSFULLY + " /getAllComplianceInboxForUser");
			return (ResponseEntity.ok(compInbox));
		} catch (Exception e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /getAllComplianceInboxForUser");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Fetch Compliance Details of User")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/getAllComplianceForUser",produces = "application/json") 
	  public ResponseEntity<Object> getComplianceDetails(@RequestParam(value="ComplianceID") int intComplianceID,
			  @RequestParam(value="AssignedDate") String dtAssignedDate) throws CustomException{	
	  try {
		  log.log("/getAllComplianceForUser");
		  ComplianceDetailsForUserFinal compDetails= compService.getComplianceDetailsForUser(intComplianceID,dtAssignedDate);
		  if(!Strings.isNullOrEmpty(compDetails.getCompName())) {
			  log.log(Message.SUCCESSFULLY);
			  audit.setLogEventData(Message.SUCCESSFULLY + " /getAllComplianceForUser");
			  return ResponseEntity.ok(compDetails);
		  }
		  else {
			  ResponseModel resCDS=new ResponseModel();
			  resCDS.setStrStatus(Constants.SUCCESS);
			  resCDS.setStrMessage(Constants.COMPCLOSE);
			  if(compDetails.getCompDesc().equals("0"))
				  resCDS.setStrMessage("Compliance does not exist");
			  log.log(Message.SUCCESSFULLY);
			  audit.setLogEventData(Message.SUCCESSFULLY + "  /getAllComplianceForUser");
			  return ResponseEntity.ok(resCDS);
		  }
	} catch (Exception e) {
		log.log(e);
		audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /getAllComplianceForUser");
		return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
	}
	  
	  }
	 
	@ApiOperation(value = "Update Assignee Remark")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/updateARemark",produces = "application/json")
	  public ResponseEntity<Object> updateAssigneeRemarkAndStatus(@RequestBody List<CMSRemarkDTO> remark) throws CustomException {  
		  try {
			  log.log("/updateARemark");
			  StringBuilder outputResponseA=new StringBuilder();
			  for(CMSRemarkDTO remarkA:remark) {
				  String commentCheckA=checkComment(remarkA.getComments());
				  if(commentCheckA==null) {
				  SubmitAndRejectResponse resA=compService.submitAssigneeRemark(remarkA);
				  outputResponseA.append(resA.getResponseMessage());
				  ComplianceDetailsForUserFinal compObjA=compService.getComplianceDetailsForUser(remarkA.getIntComplianceID(), remarkA.getDtAssignedDate());
				  inbayServ.assigneeDeleteApprovalItem(remarkA, compObjA.getTxtVerifier(),compObjA.getTxtAssignee(),remarkA.getIntComplianceID());
				  if(resA.getResponseCode().equalsIgnoreCase("1"))
					  inbayServ.verifierInsertApprovalItem(remarkA, compObjA.getTxtAssignee(), compObjA.getTxtVerifier(),compObjA,remarkA.getIntComplianceID());
				  }
				  else
					  outputResponseA.append(commentCheckA);
			  }
			  ResponseModel resAS=new ResponseModel();
			  resAS.setStrStatus(Constants.SUCCESS);
			  resAS.setStrMessage(outputResponseA.toString());
			  log.log(Message.SUCCESSFULLY+" "+outputResponseA);
			  audit.setLogEventData(Message.SUCCESSFULLY +" /updateARemark");
			  return ResponseEntity.ok(resAS);
		} catch (Exception e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /updateARemark");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}  	  
	  }
	
	@ApiOperation(value = "Update Verifier reject Remark")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/updateVRRemark",produces = "application/json")
	  public ResponseEntity<Object> updateVerifierRejectRemarkAndStatus(@RequestBody List<CMSRemarkDTO> remark) throws CustomException {
		try {
			log.log("/updateVRRemark");
			StringBuilder outputResponseVR=new StringBuilder();
			log.log("submitVerifierRejectRemark()");
			for(CMSRemarkDTO remarkVR:remark) {
				String commentCheckVR=checkComment(remarkVR.getComments());
				  if(commentCheckVR==null) {
					  SubmitAndRejectResponse resVR=compService.submitVerifierRejectRemark(remarkVR);
				outputResponseVR.append(resVR.getResponseMessage());
				ComplianceDetailsForUserFinal compObjVR=compService.getComplianceDetailsForUser(remarkVR.getIntComplianceID(), remarkVR.getDtAssignedDate());
				inbayServ.verifierDeleteApprovalItem(remarkVR, compObjVR.getTxtAssignee(), compObjVR.getTxtVerifier(),remarkVR.getIntComplianceID());
				if(resVR.getResponseCode().equalsIgnoreCase("1"))
					inbayServ.assigneeInsertApprovalItem(remarkVR, compObjVR.getTxtVerifier(), compObjVR.getTxtAssignee(),compObjVR,remarkVR.getIntComplianceID());
				}
				  else
					  outputResponseVR.append(commentCheckVR);
				  
			}
			ResponseModel resVRS=new ResponseModel();
			resVRS.setStrStatus(Constants.SUCCESS);
			resVRS.setStrMessage(outputResponseVR.toString());
			log.log(Message.SUCCESSFULLY+" "+outputResponseVR);
			audit.setLogEventData(Message.SUCCESSFULLY + " /submitVerifierRejectRemark");
			return ResponseEntity.ok(resVRS);
		} catch (Exception e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /submitVerifierRejectRemark");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Update Verifier Remark")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/updateVRemark",produces = "application/json")
	  public ResponseEntity<Object> updateVerifierRemarkAndStatus(@RequestBody List<CMSRemarkDTO> remark) throws CustomException {
		try {
			log.log("/updateVRemark");
			StringBuilder outputResponseV=new StringBuilder();
			log.log("submitVerifierRemark()");
			for(CMSRemarkDTO remarkV:remark) {
				String commentCheckV=checkComment(remarkV.getComments());
				if(commentCheckV==null) {
				SubmitAndRejectResponse resV=compService.submitVerifierRemark(remarkV);
				outputResponseV.append(resV.getResponseMessage());
				ComplianceDetailsForUserFinal compObjV=compService.getComplianceDetailsForUser(remarkV.getIntComplianceID(), remarkV.getDtAssignedDate());
				inbayServ.verifierDeleteApprovalItem(remarkV, compObjV.getTxtAssignee(), compObjV.getTxtVerifier(),remarkV.getIntComplianceID());
				if(resV.getResponseCode().equalsIgnoreCase("1"))
					inbayServ.ownerInsertApprovalItem(remarkV, compObjV.getTxtVerifier(), compObjV.getTxtOwner(),compObjV,remarkV.getIntComplianceID());				
				}
				else
					outputResponseV.append(commentCheckV);
			}
			ResponseModel resVS=new ResponseModel();
			resVS.setStrStatus(Constants.SUCCESS);
			resVS.setStrMessage(outputResponseV.toString().substring(outputResponseV.toString().indexOf('0')>=0?1:0));
			log.log(Message.SUCCESSFULLY+" "+outputResponseV);
			audit.setLogEventData(Message.SUCCESSFULLY + " /updateVRemark");
			return ResponseEntity.ok(resVS);
		} catch (Exception e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /updateVRemark");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Update Owner Remark")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	  @PostMapping(path="/updateORemark",produces = "application/json")
	  public ResponseEntity<Object> updateOwnerRemarkAndStatus(@RequestBody List<CMSRemarkDTO> remark) throws CustomException {
		try {
			log.log("/updateORemark()");
			StringBuilder outputResponseO=new StringBuilder();
			for(CMSRemarkDTO remarkO:remark) {
				String commentCheckO=checkComment(remarkO.getComments());
				if(commentCheckO==null) {
				outputResponseO.append(compService.submitOwnerRemark(remarkO).getResponseMessage());
				ComplianceDetailsForUserFinal compObjO=compService.getComplianceDetailsForUser(remarkO.getIntComplianceID(), remarkO.getDtAssignedDate());
				inbayServ.ownerDeleteApprovalItem(remarkO, compObjO.getTxtVerifier(), compObjO.getTxtOwner(),remarkO.getIntComplianceID());		
				}
				else
					outputResponseO.append(commentCheckO);
			}
			ResponseModel resOS=new ResponseModel();
			resOS.setStrStatus(Constants.SUCCESS);
			resOS.setStrMessage(outputResponseO.toString());
			log.log(Message.SUCCESSFULLY+" "+outputResponseO);
			audit.setLogEventData(Message.SUCCESSFULLY +" /updateORemark");
			return ResponseEntity.ok(resOS);
		} catch (Exception e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /updateORemark");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	public String checkComment(String comment) {
		if(comment==null || comment.trim().length()<=0)
			return Constants.EMPTYCOMMENT;
		else if(comment.length()>1500)
			return Constants.COMMENTEXCEEDED;
		return null;
	}
	
	@ApiOperation(value = "Get Reasons")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/getReasons",produces = "application/json")
	public ResponseEntity<Object> getReasons(@RequestParam(value="txtFinding") String txtFinding) throws CustomException{
		try {
			log.log("/getReasons()");
			List<String> reasons=compService.getReason(txtFinding);
			log.log(Message.SUCCESSFULLY+"/getReasons");
			audit.setLogEventData(Message.SUCCESSFULLY +" /getReasons");
			return ResponseEntity.ok(reasons);
		} catch (CustomException e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /getReasons");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Submit action item to owner")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/submitActionItemToOwner",produces = "application/json")
	public ResponseEntity<Object> submitActionItemToOwner(@RequestBody ViewActionItemMobModel actionItemMob) throws CustomException{
		try {
			log.log("/submitActionItemToOwner()");
			String submitExeStat=compService.submitRemark(actionItemMob, Constants.ACTIONITEMACTIONSUBMIT);
			log.log(Message.SUCCESSFULLY+"/submitActionItemToOwner");
			audit.setLogEventData(Message.SUCCESSFULLY +" /submitActionItemToOwner");
			return ResponseEntity.ok(submitExeStat);
		} catch (CustomException e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /submitActionItemToOwner");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Reject action item")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/rejectActionItem",produces = "application/json")
	public ResponseEntity<Object> rejectActionItem(@RequestBody ViewActionItemMobModel actionItemMob) throws CustomException{
		try {
			log.log("/rejectActionItem()");
			String rejectExeStat=compService.submitRemark(actionItemMob, Constants.ACTIONITEMACTIONREJECT);
			log.log(Message.SUCCESSFULLY+"/rejectActionItem");
			audit.setLogEventData(Message.SUCCESSFULLY +" /rejectActionItem");
			return ResponseEntity.ok(rejectExeStat);
		} catch (CustomException e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /rejectActionItem");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Close action item")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/closeActionItem",produces = "application/json")
	public ResponseEntity<Object> closeActionItem(@RequestBody ViewActionItemMobModel actionItemMob) throws CustomException{
		try {
			log.log("/closeActionItem()");
			String closeExeStat=compService.submitRemark(actionItemMob, Constants.ACTIONITEMACTIONCLOSE);
			log.log(Message.SUCCESSFULLY+"/closeActionItem");
			audit.setLogEventData(Message.SUCCESSFULLY +" /closeActionItem");
			return ResponseEntity.ok(closeExeStat);
		} catch (CustomException e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /closeActionItem");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}
	
	@ApiOperation(value = "Get Mobile action item model")
	@HystrixCommand(commandProperties = {
			@HystrixProperty(name = "execution.isolation.thread.timeoutInMilliseconds", value = "30000") })
	@PostMapping(path="/getActionItemMobModel",produces = "application/json")
	public ResponseEntity<Object> getActionItemMobModel(@RequestParam(value="intActionItemId") int intActionItemId) throws CustomException{
		try {
			log.log("/getActionItemMobModel()");
			if (compService.checkIfActionItemExists(intActionItemId)) {
				ViewActionItemMobModel actionItemModel = compService.getActionItemDetails(intActionItemId);
				log.log(Message.SUCCESSFULLY + "/getActionItemMobModel");
				audit.setLogEventData(Message.SUCCESSFULLY + " /getActionItemMobModel");
				return ResponseEntity.ok(actionItemModel);
			}
			else {
				log.log(Message.SUCCESSFULLY + "/getActionItemMobModel");
				audit.setLogEventData(Message.SUCCESSFULLY + " /getActionItemMobModel");
				return ResponseEntity.ok(new ResponseModel(Constants.SUCCESS,"Action item does not exist"));
			}
			
		} catch (CustomException e) {
			log.log(e);
			audit.setExeceptionEventData(String.valueOf(HttpStatus.BAD_REQUEST.value()), e.toString(), "Error in /getActionItemMobModel");
			return new ResponseEntity<>(new ResponseModel(Constants.ERROR,Constants.ERRORMESSAGE), HttpStatus.BAD_REQUEST);
		}
	}

	  
	  public ResponseEntity<Object> defaultFallback() {
	        return ResponseEntity.ok(Arrays.asList(new Response(Message.ERROR, "Timeout! FallBack of Method")));
	    }	  
}
