package com.infosys.reach.model.generic;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
public class TabView {

	private String name;
	private String value;
	private String type;
	private String guid;
	private String apiType;
	private List<Object> pages;
	public TabView(String name, String value) {
		super();
		this.name = name;
		this.value = value;
		this.type = "tabview";
		this.guid = "";
		this.apiType = "GET";
		this.pages = new ArrayList<>();
	}
	
	
}
