package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.joda.time.DateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name="elcmectrnashiactiondetails")
public class ELCMECTrnASHIActionDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intcaseactionid")
	private int caseActionId;
	
	@Column(name="intcaseid")
	private int caseId;

	@Column(name="txtrole")
	private String role;

	@Column(name="txtcomments")
	private String comments;

	@Column(name="txtstatus")
	private String status;

	@Column(name="txtassigneeempno")
	private String assigneeEmpNo;

	@Column(name="flgsentforopinion")
	private int flgSentForOpinion;

	@Column(name="txtdmsfilename")
	private String dmsFileName;

	@Column(name="flgreassign")
	private int flgReAssign;

	@Column(name="txtcreatedby")
	private String createdBy;

	@Column(name="txtmodifiedby")
	private String modifiedBy;

	@Column(name="dtcreatedon")
	private Timestamp createdOn;
	
	@Column(name="dtmodifiedon")
	private Timestamp modifiedOn;
	
	@Column(name="txtassigneelocation")
	private String assigneeLocation;
	
	@Transient
	private String statusDesc;
	
	@Transient
	private String currentRole;

	public ELCMECTrnASHIActionDetails(int caseId, String role, String status, String comments, String createdBy,
			Timestamp createdOn, String filenames) {
		this.caseId = caseId;
		this.role = role;
		this.comments = comments;
		this.status = status;
		this.assigneeEmpNo = "";
		this.flgSentForOpinion = 0;
		this.dmsFileName = filenames;
		this.flgReAssign = 0;
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
	}
	
	public ELCMECTrnASHIActionDetails(int caseId, String comments, String status, String createdBy,
			DateTime createdOn) {
		super();
		this.caseId = caseId;
		this.role = "GRB";
		this.comments = comments;
		this.status = status;
		this.assigneeEmpNo = "";
		this.flgSentForOpinion = 0;
		this.dmsFileName = "";
		this.flgReAssign = 0;
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = new Timestamp(createdOn.getMillis());
	}
	
	public ELCMECTrnASHIActionDetails(ELCMECTrnASHIActionDetails action, String status, String currentRole) {
		super();
		this.caseActionId = action.getCaseActionId();
		this.caseId = action.getCaseId();
		this.role = action.getRole();
		this.comments = action.getComments();
		this.status = action.getStatus();
		this.assigneeEmpNo = action.getAssigneeEmpNo();
		this.flgSentForOpinion = action.getFlgSentForOpinion();
		this.dmsFileName = action.getDmsFileName();
		this.flgReAssign = action.getFlgReAssign();
		this.createdBy = action.getCreatedBy();
		this.modifiedBy = action.getModifiedBy();
		this.createdOn = action.getCreatedOn();
		this.assigneeLocation = action.getAssigneeLocation();
		this.statusDesc = status;
		this.currentRole = currentRole;
	}
	
	public ELCMECTrnASHIActionDetails(int caseId, String role, String comments, String status,
			 String dmsFileName, String createdBy,
			Timestamp createdOn) {
		super();
		this.caseId = caseId;
		this.role = role;
		this.comments = comments;
		this.status = status;
		this.assigneeEmpNo = "";
		this.flgSentForOpinion = 0;
		this.dmsFileName = dmsFileName;
		this.flgReAssign = 0;
		this.createdBy = createdBy;
		this.modifiedBy = createdBy;
		this.createdOn = createdOn;
	}


	
}
