package com.infosysit.rctmscompliance.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@AllArgsConstructor
public class OldAssigneeRem {

	private String txtAssigneeRemarks;
	private String txtVerifierApprovalRemarks;
	private String txtOwnerRemarks;
	private String txtVerifierRejectRemark;
	private String txtAssigneeAfterRejectRemark;
	private int intNoOfCycles;
	private String txtAttachmentListVerifier;
	private String txtStatus;
}
