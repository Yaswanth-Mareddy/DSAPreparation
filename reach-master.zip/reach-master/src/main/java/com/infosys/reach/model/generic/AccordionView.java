package com.infosys.reach.model.generic;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class AccordionView {

	private String name;
	private String id;
	private String topnotes;
	private String bottomnotes;
	private String type;
	private String heading;
	private List<Accordion> accordions;
	
	public AccordionView(String name, String type, List<Accordion> accordions) {
		this(name, "", null, null, type, "", accordions);
	}
	
	
}