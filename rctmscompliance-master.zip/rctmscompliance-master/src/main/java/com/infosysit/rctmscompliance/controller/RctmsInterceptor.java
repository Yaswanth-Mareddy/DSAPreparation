package com.infosysit.rctmscompliance.controller;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;
import org.sunbird.common.models.util.JsonKey;
import org.sunbird.common.request.ExecutionContext;
import org.sunbird.common.request.Request;
import org.sunbird.telemetry.util.TelemetryEvents;
import org.sunbird.telemetry.util.TelemetryLmaxWriter;
import org.sunbird.telemetry.util.TelemetryUtil;

import com.infosysit.rctmscompliance.teleconfig.TelemetryConfig;




@Component
public class RctmsInterceptor implements HandlerInterceptor {
	@Autowired
	TelemetryConfig telemetryConfig;
	
	private    Map<String, Map<String, Object>> requestInfo = new HashMap<>();
	private   String messageId;

	private TelemetryLmaxWriter lmaxWriter = TelemetryLmaxWriter.getInstance();

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		request.getUserPrincipal();
		initializeRequestInfo(request);
		return true;
	}

	
	private  void initializeRequestInfo(HttpServletRequest request) {

		ExecutionContext context = ExecutionContext.getCurrent();

		String methodName = request.getMethod();

		String url = request.getRequestURI();

		messageId = ExecutionContext.getRequestId();

		if (StringUtils.isBlank(messageId)) {
			UUID uuid = UUID.randomUUID();
			messageId = uuid.toString();
		}

		ExecutionContext.setRequestId(messageId);

		Map<String, Object> reqContext = new HashMap<>();

		String channel = telemetryConfig.getContext().getChannel();

		reqContext.put(JsonKey.CHANNEL, channel);

		reqContext.put(JsonKey.ENV, getEnv(request));
		reqContext.put(JsonKey.ACTOR_ID, "internal");
		reqContext.put(JsonKey.ACTOR_TYPE, JsonKey.CONSUMER);

		context.setRequestContext(reqContext);

		context.getGlobalContext().put(JsonKey.PDATA_ID, telemetryConfig.getContext().getpData().getId());

		context.getGlobalContext().put(JsonKey.PDATA_PID, telemetryConfig.getContext().getpData().getPid());

		context.getGlobalContext().put(JsonKey.PDATA_VERSION, telemetryConfig.getContext().getpData().getVersion());

		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.CONTEXT, TelemetryUtil.getTelemetryContext());

		Map<String, Object> additionalInfo = new HashMap<>();
		additionalInfo.put(JsonKey.URL, url);
		additionalInfo.put(JsonKey.METHOD, methodName);

		map.put(JsonKey.ADDITIONAL_INFO, additionalInfo);

		if (requestInfo == null) {
			requestInfo = new HashMap<>();
		}

		if (StringUtils.isBlank(messageId)) {
			messageId = JsonKey.DEFAULT_CONSUMER_ID;
		}
		requestInfo.put(messageId, map);
	}

	private String getEnv(HttpServletRequest request) {
		if (request.getQueryString() != null)
			return "New Content";
		else
			return "Default Content";
	}

	@Override
	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		/*
        * postHandle method
        */
	}
	
	
	public void setSearchEventData(String query, int size, int topn) {
		
		Map<String, Object> telemetryInfo1 = requestInfo.get(messageId);
		
		List<Object> list = new ArrayList<>(Arrays.asList(topn)); 

		Request telemetryRequest1 = new Request();
		Map<String, Object> telemetryParameters1 = new HashMap<>();
		telemetryParameters1.put(JsonKey.TOPN, list);
		telemetryParameters1.put(JsonKey.SIZE, Long.valueOf(size));
		telemetryParameters1.put(JsonKey.QUERY, query);
		telemetryParameters1.put(JsonKey.TYPE, "Database");
		
		telemetryRequest1.setRequest(generateTelemetryRequest(TelemetryEvents.SEARCH.getName(), telemetryParameters1,
				(Map<String, Object>) telemetryInfo1.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest1);
		
	}
	

	public void setLogEventData(String message) {

		Map<String, Object> telemetryInfo2 = requestInfo.get(messageId);
		
		Request telemetryRequest2 = new Request();
		
		// Setting fields for logging information
		Map<String, Object> telemetryParameters2 = new HashMap<>();
		telemetryParameters2.put(JsonKey.LOG_TYPE, JsonKey.API_CALL);
		telemetryParameters2.put(JsonKey.LOG_LEVEL, "Trace");
		telemetryParameters2.put(JsonKey.MESSAGE,message);
		telemetryParameters2.put(JsonKey.PDATA_ID, telemetryConfig.getContext().getpData().getPid()); 
		
		telemetryRequest2.setRequest(generateTelemetryRequest(TelemetryEvents.LOG.getName(), telemetryParameters2,
				(Map<String, Object>) telemetryInfo2.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest2);
	}

	public void setExeceptionEventData(String statusCode, String message, String methodName) {


		Map<String, Object> telemetryInfo3 = requestInfo.get(messageId);

		Request telemetryRequest3 = new Request();

		Map<String, Object> telemetryParameters3 = new HashMap<>();
		telemetryParameters3.put(JsonKey.ERROR, statusCode);
		telemetryParameters3.put(JsonKey.ERR_TYPE, "SYSTEM");
		telemetryParameters3.put(JsonKey.STACKTRACE, "Error in method: " + methodName + ", Message: " + message);

		String code = statusCode.subSequence(0, 3).toString();

		if (code.equals("400") || code.equals("403") || code.equals("404"))
			telemetryParameters3.put(JsonKey.ERR_TYPE, "CONTENT");

		telemetryRequest3.setRequest(generateTelemetryRequest(TelemetryEvents.ERROR.getName(), telemetryParameters3,
				(Map<String, Object>) telemetryInfo3.get(JsonKey.CONTEXT)));

		lmaxWriter.submitMessage(telemetryRequest3);
	}

	
	private Map<String, Object> generateTelemetryRequest(String eventType, Map<String, Object> telemetryParameters,
			Map<String, Object> telemetryContext) {
		Map<String, Object> map = new HashMap<>();
		map.put(JsonKey.TELEMETRY_EVENT_TYPE, eventType);
		map.put(JsonKey.CONTEXT, telemetryContext);
		map.put(JsonKey.PARAMS, telemetryParameters);

		return map;
	}

}

