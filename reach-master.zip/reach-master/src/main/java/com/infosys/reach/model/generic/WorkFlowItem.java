package com.infosys.reach.model.generic;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@Getter
@Setter
@AllArgsConstructor
public class WorkFlowItem {

	private String status;
	private String description;
	
	@JsonProperty("ETA")
	private String eta;
	
	private String comments;
	private String isprogress;
	private boolean complete;
	private List<WorkFlowItem> parallel;
	private List<WorkFlowItem> series;
}
