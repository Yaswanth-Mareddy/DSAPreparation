package com.infosys.reach.model.hear;



import com.infosys.reach.entity.ELCMECMstConcernModulesDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Categories {

	private int moduleId;
	private int concernId;
	private String concern;
	private String concernDesc;
	private String company;
	private String countryCode;
	public Categories(ELCMECMstConcernModulesDetails obj) {
		super();
		this.moduleId = obj.getModuleId();
		this.concernId = obj.getConcernId();
		this.concern = obj.getConcern();
		this.concernDesc = obj.getConcernDesc();
		this.company = obj.getCompany();
		this.countryCode = obj.getCountryCode();
	}
	
	
}
