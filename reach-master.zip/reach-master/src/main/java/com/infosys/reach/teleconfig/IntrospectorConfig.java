package com.infosys.reach.teleconfig;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("introspector")
public class IntrospectorConfig {

	private DefaultGreetings defaultGreetings = new DefaultGreetings();

	public DefaultGreetings getDefaultGreetings() {
		return defaultGreetings;
	}

	public static class DefaultGreetings {
		private String defaultContent;

		public String getDefaultContent() {
			return defaultContent;
		}

		public void setDefaultContent(String content) {
			this.defaultContent = content;
		}
	}

}