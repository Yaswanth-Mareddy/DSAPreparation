/*
 * package com.infosys.hello.springboot.config;
 * 
 * 
 * import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
 * import org.springframework.boot.context.properties.ConfigurationProperties;
 * import org.springframework.context.annotation.Bean; import
 * org.springframework.context.annotation.Configuration; import
 * org.springframework.context.annotation.Primary; import
 * com.zaxxer.hikari.HikariDataSource;
 * 
 * @Configuration public class DataSourceConfiguration {
 * 
 * @Bean
 * 
 * @Primary
 * 
 * @ConfigurationProperties("spring.datasource") public DataSourceProperties
 * mainDataSourceProperties() { return new DataSourceProperties(); }
 * 
 * @Bean
 * 
 * @Primary
 * 
 * @ConfigurationProperties("spring.datasource.configuration") public
 * HikariDataSource mainDataSource() { return
 * mainDataSourceProperties().initializeDataSourceBuilder().type(
 * HikariDataSource.class).build(); }
 * 
 * @Bean
 * 
 * @ConfigurationProperties("spring.datasource1") public DataSourceProperties
 * secondDataSourceProperties() { return new DataSourceProperties(); }
 * 
 * @Bean
 * 
 * @ConfigurationProperties("spring.datasource1.configuration") public
 * HikariDataSource secondDataSource() { return
 * secondDataSourceProperties().initializeDataSourceBuilder().type(
 * HikariDataSource.class).build(); } }
 */