package com.infosys.reach.model.generic;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class GenModelFormObj {

	private GenModelFormData genModel;
	private GenModelFormData accordion;
}
