package com.infosys.reach.entity;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.infosys.reach.model.ashi.GMFields;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Entity
@NoArgsConstructor
@Table(name="elcmectrnashiinterimreliefdetails")
public class ELCMECTrnASHIInterimReliefDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="intserialno")
	private int serialNo;
	
	@Column(name="intcaseid")
	private int caseId;
	
	@Column(name="flgreliefrequired")
	private int flgRelief;
	
	@Column(name="txtreliefs")
	private String reliefs;
	
	@Column(name="txtremarks")
	private String remarks;
	
	@Column(name="txtrequesterrole")
	private String requesterRole;
	
	@Column(name="txtrequestedby")
	private String requestedBy;
	
	@Column(name="dtrequesteddate")
	private Timestamp requestedDate;
	
	@Column(name="txtdmsfile")
	private String dmsFiles;
	
	@Column(name="flgactiontaken")
	private int flgActionTaken;
	
	@Column(name="txtapproverrole")
	private String approverRole;
	
	@Column(name="txtapprovedby")
	private String approvedBy;
	
	@Column(name="dtapproveddate")
	private Timestamp approvedDate;
	
	@Column(name="txtapprovalstatus")
	private String approvalStatus;
	
	@Column(name="txtapproverremarks")
	private String approverRemarks;
	
	@Column(name="flgresubmit")
	private int flgReSubmit;

	public ELCMECTrnASHIInterimReliefDetails(GMFields fields, String requestedBy, Timestamp requestedDate, String dmsFiles) {
		super();
		this.caseId = fields.getCaseid();
		this.flgRelief = fields.getFlgRelief();
		this.reliefs = fields.getFlgRelief()==1 ? fields.getReliefs() : "";
		this.remarks = fields.getRemarks();
		this.requesterRole = "IC";
		this.requestedBy = requestedBy;
		this.requestedDate = requestedDate;
		this.dmsFiles = dmsFiles;
		this.flgActionTaken = fields.getFlgRelief()==1 ? 0 : 1;
		this.approverRole = fields.getFlgRelief()==1 ? "GRB" : "";
		this.flgReSubmit = 0;
	}
	
	
}
