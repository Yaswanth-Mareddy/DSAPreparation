package com.infosysit.rctmscompliance.util;

public class AuthenticationClass {
	private AuthenticationClass() {
		
	}
	public static String getUserMailFromLoginId(String loginId)
    {
        String mailId = "";
        if (loginId==null || loginId.isEmpty())
        {
            mailId = "";
        }
        else if (loginId.toUpperCase().startsWith(InfraConstants.INFOSYSDOMAINPREFIXITL))
        {
            mailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINPREFIXITL, "");
        }
        else if (loginId.toUpperCase().endsWith(InfraConstants.INFOSYSDOMAINSUFFIX))
        {
            mailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINSUFFIX, "");
        }
        else if (loginId.toUpperCase().endsWith(InfraConstants.INFOSYSDOMAINSUFFIXAD))
        {
            mailId = loginId.toUpperCase().replace(InfraConstants.INFOSYSDOMAINSUFFIXAD, "");
        }
        return mailId;
    }

}