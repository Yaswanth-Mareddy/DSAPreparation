package com.infosysit.itsm;


import static org.junit.Assert.*;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.infosysit.itsm.exception.CustomException;
import com.infosysit.itsm.model.EDSTrnDepPassportDetailsModel;
import com.infosysit.itsm.model.ISLeapAutoResponseModel;
import com.infosysit.itsm.model.ISLeapTicket;
import com.infosysit.itsm.mysqldatasource.repository.ICMTicketsRepository;
import com.infosysit.itsm.mysqldatasource.repository.ISLeapMstAutoResponseRepository;
import com.infosysit.itsm.mysqldatasource.repository.ISLeapTrnRuleMappingRepository;
import com.infosysit.itsm.service.ITSMServiceImpl;
import com.infosysit.itsm.sqldatasource.repository.EDSTrnDepPassportDetailsRepository;

@ExtendWith(MockitoExtension.class)
 class ITSMServiceTests {
	
	@InjectMocks
	ITSMServiceImpl service;
	
	@Mock
	ICMTicketsRepository icmTicketsRepository;
	
	@Mock
	ISLeapMstAutoResponseRepository isLeapAutoResponseRepository;
	
	@Mock
	ISLeapTrnRuleMappingRepository isLeapRuleMappingRepository;
	
	@Mock
	EDSTrnDepPassportDetailsRepository edsTrnDepPassportDetailsRepository;
	
	@Test
	 void decisionAnalysisTests() throws CustomException {
		
		List<ISLeapTicket> lstIcmTickets = new ArrayList<>();
		Mockito.when(icmTicketsRepository.getIcmOpenTickets()).thenReturn(lstIcmTickets);
		
		boolean objExpected = false;
		boolean objActual = service.decisionAnalysis();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void decisionAnalysisTest1() throws CustomException {
		
		List<ISLeapTicket> lstIcmTickets = new ArrayList<>();
		Date createdDate = null;
		lstIcmTickets.add(new ISLeapTicket("722284","1234567890","shortdescription","category",createdDate,"sysId",2));
		Mockito.when(icmTicketsRepository.getIcmOpenTickets()).thenReturn(lstIcmTickets);
		
		List<EDSTrnDepPassportDetailsModel> lstDependentPassportDetails = new ArrayList<>();
		lstDependentPassportDetails.add(new EDSTrnDepPassportDetailsModel("722284",123,"txtRelationDesc","txtPassPortNo"));
		lstDependentPassportDetails.add(new EDSTrnDepPassportDetailsModel("722285",123,"txtRelationDesc","txtPassPortNo"));
		Mockito.when(edsTrnDepPassportDetailsRepository.getDependentPassportDetails(Mockito.anyString())).thenReturn(lstDependentPassportDetails);
		
		String ticketNumber="";
		String resolutionSteps="";
		//Mockito.doNothing().when(icmTicketsRepository.updateIcmTicketsUsingNumber(ticketNumber,resolutionSteps));
		
		boolean objExpected = true;
		boolean objActual = service.decisionAnalysis();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void decisionAnalysisTest2() throws CustomException {
		
		List<ISLeapTicket> lstIcmTickets = new ArrayList<>();
		Date createdDate = null;
		lstIcmTickets.add(new ISLeapTicket("722284","1234567890","shortdescription","category",createdDate,"sysId",2));
		lstIcmTickets.add(new ISLeapTicket("722285","1234567891","shortdescription","category",createdDate,"sysId",2));
		Mockito.when(icmTicketsRepository.getIcmOpenTickets()).thenReturn(lstIcmTickets);
		
		List<EDSTrnDepPassportDetailsModel> lstDependentPassportDetails = new ArrayList<>();
		//lstDependentPassportDetails.add(new EDSTrnDepPassportDetailsModel("722284",123,"txtRelationDesc","txtPassPortNo"));
		//lstDependentPassportDetails.add(new EDSTrnDepPassportDetailsModel("722285",123,"txtRelationDesc","txtPassPortNo"));
		Mockito.when(edsTrnDepPassportDetailsRepository.getDependentPassportDetails(Mockito.anyString())).thenReturn(lstDependentPassportDetails);
		
		String ticketNumber="";
		String resolutionSteps="";
		//Mockito.doNothing().when(icmTicketsRepository.updateIcmTicketsUsingNumber(ticketNumber,resolutionSteps));
		
		boolean objExpected = true;
		boolean objActual = service.decisionAnalysis();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseTest() throws CustomException {
		
		List<String> lstTicketNumbers = new ArrayList<>();
		lstTicketNumbers.add("ticketnumber");
		Mockito.when(icmTicketsRepository.getIcmOpenTicketNumbers()).thenReturn(lstTicketNumbers);
		
		Mockito.when(isLeapRuleMappingRepository.getRuleUsingTickerNumber(Mockito.anyString())).thenReturn("");
		ISLeapAutoResponseModel resolutionSolution = new ISLeapAutoResponseModel("","","Not Required","","");
		Mockito.when(isLeapAutoResponseRepository.getResolutionDetails(Mockito.anyString())).thenReturn(resolutionSolution);
		
		//Mockito.when(icmTicketsRepository.updateIcmTicketsNotRequired(Mockito.anyString(),Mockito.anyString(),Mockito.anyString()));
		
		boolean objExpected = true;
		boolean objActual = service.autoResponse();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseTest1() throws CustomException {
		
		List<String> lstTicketNumbers = new ArrayList<>();
		lstTicketNumbers.add("ticketnumber");
		lstTicketNumbers.add("ticketnumber1");
		Mockito.when(icmTicketsRepository.getIcmOpenTicketNumbers()).thenReturn(lstTicketNumbers);
		
		Mockito.when(isLeapRuleMappingRepository.getRuleUsingTickerNumber(Mockito.anyString())).thenReturn("");
		ISLeapAutoResponseModel resolutionSolution = new ISLeapAutoResponseModel("","","Required","","");
		Mockito.when(isLeapAutoResponseRepository.getResolutionDetails(Mockito.anyString())).thenReturn(resolutionSolution);
		
		Mockito.doNothing().when(icmTicketsRepository).updateIcmTicketsRequired(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		
		boolean objExpected = true;
		boolean objActual = service.autoResponse();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseTest2() throws CustomException {
		
		List<String> lstTicketNumbers = new ArrayList<>();
		Mockito.when(icmTicketsRepository.getIcmOpenTicketNumbers()).thenReturn(lstTicketNumbers);
		
		boolean objExpected = false;
		boolean objActual = service.autoResponse();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseTest3() throws CustomException {
		
		List<String> lstTicketNumbers = new ArrayList<>();
		lstTicketNumbers.add("ticketnumber");
		lstTicketNumbers.add("ticketnumber1");
		Mockito.when(icmTicketsRepository.getIcmOpenTicketNumbers()).thenReturn(lstTicketNumbers);
		
		Mockito.when(isLeapRuleMappingRepository.getRuleUsingTickerNumber(Mockito.anyString())).thenReturn("");
		ISLeapAutoResponseModel resolutionSolution = new ISLeapAutoResponseModel("","","Required!","","");
		Mockito.when(isLeapAutoResponseRepository.getResolutionDetails(Mockito.anyString())).thenReturn(resolutionSolution);
		
		
		boolean objExpected = true;
		boolean objActual = service.autoResponse();
		
		assertEquals(objExpected, objActual);
	}
	
	@Test
	 void autoResponseTest4() throws CustomException {
		
		List<String> lstTicketNumbers = new ArrayList<>();
		lstTicketNumbers.add("ticketnumber");
		lstTicketNumbers.add("ticketnumber1");
		Mockito.when(icmTicketsRepository.getIcmOpenTicketNumbers()).thenReturn(lstTicketNumbers);
		
		Mockito.when(isLeapRuleMappingRepository.getRuleUsingTickerNumber(Mockito.anyString())).thenReturn("");
		ISLeapAutoResponseModel resolutionSolution = null;
		Mockito.when(isLeapAutoResponseRepository.getResolutionDetails(Mockito.anyString())).thenReturn(resolutionSolution);
		
		//Mockito.doNothing().when(icmTicketsRepository).updateIcmTicketsRequired(Mockito.anyString(),Mockito.anyString(),Mockito.anyString());
		
		boolean objExpected = true;
		boolean objActual = service.autoResponse();
		
		assertEquals(objExpected, objActual);
	}

}
