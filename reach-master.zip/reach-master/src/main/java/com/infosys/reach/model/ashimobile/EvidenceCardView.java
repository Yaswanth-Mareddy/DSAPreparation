package com.infosys.reach.model.ashimobile;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class EvidenceCardView {

	private String name;
	private String guid;
	private String type;
	private List<EvidenceCard> cards;

	public EvidenceCardView(String name, List<EvidenceCard> cards) {
		super();
		this.name = name;
		this.guid = "";
		this.type = "cardview";
		this.cards = cards;
	}
}
