package com.infosysit.rctmscompliance.repo.read;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.infosysit.rctmscompliance.entity.CMSMstComplianceDetails;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserDateNotNull;
import com.infosysit.rctmscompliance.model.ComplianceDetailsForUserDateNull;
import com.infosysit.rctmscompliance.util.CustomQueries;

@Repository
public interface CMSMstComplianceDetailsRepoRead extends JpaRepository<CMSMstComplianceDetails, Integer>{
	@Query(value=CustomQueries.GETCOMPLIANCEDETAILSFORUSERDATENULL)
	public ComplianceDetailsForUserDateNull getComplianceDetailsForUserDateNull(@Param("intComplianceID") int intComplianceID);
	
	@Query(value=CustomQueries.GETCOMPLIANCEDETAILSFORUSERDATENOTNULL)
	public ComplianceDetailsForUserDateNotNull getComplianceDetailsForUserDateNotNull(@Param("intComplianceID") int intComplianceID,@Param("dtAssignedDate") String dtAssignedDate);
	
	@Query(value="select CD.intComplianceID from CMSMstComplianceDetails as CD where CD.txtComplianceName= :txtComplianceName")
	int getComplianceIDByComplianceName(@Param("txtComplianceName") String txtComplianceName);
	
	@Query(value="select CD.intNodeID from CMSMstComplianceDetails as CD where CD.txtComplianceName= :txtComplianceName")
	int getIntNodeIDByComplianceName(@Param("txtComplianceName") String txtComplianceName);
}
