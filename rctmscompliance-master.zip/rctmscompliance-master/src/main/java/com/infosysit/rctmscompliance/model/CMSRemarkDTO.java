package com.infosysit.rctmscompliance.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CMSRemarkDTO {
               
	private int intComplianceID;             
	private String dtAssignedDate;
	@JsonProperty(value="Comments")
	private String comments;
}
